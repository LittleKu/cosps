//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SoundGenerator.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SOUNDGENERATOR_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDC_VARX                        1000
#define IDC_VARY                        1001
#define IDC_VARZ                        1002
#define IDC_APPLY_VARX                  1003
#define IDC_APPLY_VARY                  1004
#define IDC_APPLY_VARZ                  1005
#define IDC_SHAPE1                      1006
#define IDC_SHAPE2                      1007
#define IDC_SHAPE3                      1008
#define IDC_APPLY_SHAPE1                1009
#define IDC_APPLY_SHAPE2                1010
#define IDC_APPLY_SHAPE3                1011
#define IDC_ACTIVE_SHAPE1               1012
#define IDC_ACTIVE_SHAPE2               1013
#define IDC_ACTIVE_SHAPE3               1014
#define IDC_VOLUME_SHAPE1               1017
#define IDC_VOLUME_SHAPE2               1018
#define IDC_VOLUME_SHAPE3               1019
#define IDC_MSG                         1020
#define IDC_BUTTON1                     1021
#define IDC_WAVE                        1022
#define IDC_MSGWARNING                  1023
#define ID_FILE_SAVEAS                  32771
#define ID_FILE_QUIT                    32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
