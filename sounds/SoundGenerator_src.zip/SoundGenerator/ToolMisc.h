#ifndef _TOOLMISC_INCLUDED
#define _TOOLMISC_INCLUDED

#include <windows.h>

HANDLE runThread(LPTHREAD_START_ROUTINE fct, void* param);


#endif