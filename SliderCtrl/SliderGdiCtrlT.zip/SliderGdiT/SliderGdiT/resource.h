//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SliderGdiT.rc
//
#define IDD_SLIDERGDI_DIALOG            103
#define IDR_MAINFRAME                   128
#define IDB_CHK32                       129
#define IDR_MNOPRIONS                   129
#define IDB_CHKNO32                     130
#define IDB_BMPSQUEEZE                  132
#define IDB_BMPEXPAND                   133
#define IDB_BMPMOVEL                    134
#define IDB_BMPMOVER                    135
#define IDB_BMPEXPANDV                  136
#define IDB_BMPSQUEEZEV                 137
#define IDB_BITMAP1                     138
#define IDB_BMPCOLS                     138
#define IDC_SLINT                       1000
#define IDC_SLDBL                       1001
#define IDC_CHENBL                      1002
#define IDC_STINT                       1003
#define IDC_STDBL                       1004
#define IDC_SLTEST                      1005
#define IDC_SLMIN                       1006
#define IDC_BTNSQUEEZE                  1007
#define IDC_BTNEXPAND                   1008
#define IDC_BTNMOVEL                    1009
#define IDC_BTNMOVER                    1010
#define IDC_BTNEXPANDV                  1011
#define IDC_BTSQUEEZEV                  1012
#define IDC_BTNOPTIONS                  1013
#define IDC_BTNPREC                     1014
#define IDC_BTNCOL                      1015
#define IDC_ST                          1017
#define IDC_BUTTON1                     1018
#define IDC_SLIDER1                     1019
#define IDM_COLOR                       32771
#define IDM_STRFORMAT                   32772
#define IDM_FONTATTR                    32773
#define ID_OPTIONS_CHANGECAPTION        32774
#define IDM_CAPTION                     32775
#define IDM_CURRVAL                     32776
#define IDM_MINMAX                      32777
#define IDM_INITVALS                    32778
#define IDM_PRECISION                   32779
#define IDM_KEYSTEP                     32780
#define IDM_MOVE                        32781
#define IDM_SIZE                        32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
