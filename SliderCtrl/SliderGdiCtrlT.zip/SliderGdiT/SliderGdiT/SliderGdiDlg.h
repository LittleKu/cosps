

// SliderGDIDlg.h : header file
//

#include "slidergdictrl.h"
#include "afxbutton.h"
#include "afxwin.h"
#include "afxcmn.h"

#pragma once

using namespace SliderGdi;
// CSliderGDIDlg dialog
class CSliderGDIDlg : public CDialog
{
// Construction
public:
	CSliderGDIDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SLIDERGDI_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
  afx_msg void  OnSlidePosChanged(NMHDR *pNMHDR, LRESULT *pResult);
  afx_msg void OnSliderRClk(NMHDR*pNotifyStruct,LRESULT*result);
  afx_msg void OnBnClickedChenbl();
  afx_msg void OnBnClickedBtnsqueeze();
  afx_msg void OnBnClickedBtnexpand();
  afx_msg void OnBnClickedBtnmovel();
  afx_msg void OnBnClickedBtnmover();
  afx_msg void OnBnClickedBtsqueezev();
  afx_msg void OnBnClickedBtnexpandv();
  afx_msg void OnBnClickedBtncol();
  afx_msg void OnBnClickedBtnopt();
  afx_msg void OnTimer(UINT_PTR nIDEvent);
  afx_msg void OnBnClickedBtnprec();

	DECLARE_MESSAGE_MAP()

public:
  CSliderGdiCtrlT<short> m_slInt;
  CSliderGdiCtrlT<double> m_slDbl;
  CSliderGdiCtrlT<double> m_slTest;
  CSliderGdiCtrlT<long> m_slMin;
  CMFCButton m_chEnable;
  CStatic m_stInt;
  CStatic m_stDbl;
  CMFCButton m_btnSqueeze;
  CMFCButton m_btnExpand;
  CMFCButton m_btnLeft;
  CMFCButton m_btnRight;
  CMFCButton m_btnSqueezeV;
  CMFCButton m_btnExpandV;
  CMFCButton m_btnCol;
  CMFCMenuButton m_btnOptions;
  CMenu m_mnOptions;
  CButton m_btnPrec;

private:
  Gdiplus::Color m_tmpBarCol;
public:
  afx_msg void OnBnClickedButton1();
};

