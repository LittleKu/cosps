
// SliderGDIDlg.cpp : implementation file
//

#include "stdafx.h"
#include <exception>
#include <tchar.h>
#include "SliderGDIT.h"
#include "SliderGDIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Gdiplus;

// CSliderGDIDlg dialog




CSliderGDIDlg::CSliderGDIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSliderGDIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSliderGDIDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, IDC_SLINT, m_slInt);
  DDX_Control(pDX, IDC_SLDBL, m_slDbl);
  DDX_Control(pDX, IDC_CHENBL, m_chEnable);
  DDX_Control(pDX, IDC_STINT, m_stInt);
  DDX_Control(pDX, IDC_STDBL, m_stDbl);
  DDX_Control(pDX, IDC_SLTEST, m_slTest);
  DDX_Control(pDX, IDC_SLMIN, m_slMin);
  DDX_Control(pDX, IDC_BTNSQUEEZE, m_btnSqueeze);
  DDX_Control(pDX, IDC_BTNEXPAND, m_btnExpand);
  DDX_Control(pDX, IDC_BTNMOVEL, m_btnLeft);
  DDX_Control(pDX, IDC_BTNMOVER, m_btnRight);
  DDX_Control(pDX, IDC_BTSQUEEZEV, m_btnSqueezeV);
  DDX_Control(pDX, IDC_BTNEXPANDV, m_btnExpandV);
  DDX_Control(pDX, IDC_BTNCOL, m_btnCol);
  DDX_Control(pDX, IDC_BTNOPTIONS, m_btnOptions);
  DDX_Control(pDX, IDC_BTNPREC, m_btnPrec);
}

BEGIN_MESSAGE_MAP(CSliderGDIDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
  ON_BN_CLICKED(IDC_CHENBL, &CSliderGDIDlg::OnBnClickedChenbl)
  ON_NOTIFY(TB_THUMBPOSITION, IDC_SLINT, OnSlidePosChanged)
  ON_NOTIFY(TB_THUMBPOSITION, IDC_SLDBL, OnSlidePosChanged)
  ON_NOTIFY(NM_RCLICK, IDC_SLTEST, OnSliderRClk)


  ON_BN_CLICKED(IDC_BTNSQUEEZE, &CSliderGDIDlg::OnBnClickedBtnsqueeze)
  ON_BN_CLICKED(IDC_BTNEXPAND, &CSliderGDIDlg::OnBnClickedBtnexpand)
  ON_BN_CLICKED(IDC_BTNMOVEL, &CSliderGDIDlg::OnBnClickedBtnmovel)
  ON_BN_CLICKED(IDC_BTNMOVER, &CSliderGDIDlg::OnBnClickedBtnmover)
  ON_BN_CLICKED(IDC_BTSQUEEZEV, &CSliderGDIDlg::OnBnClickedBtsqueezev)
  ON_BN_CLICKED(IDC_BTNEXPANDV, &CSliderGDIDlg::OnBnClickedBtnexpandv)
  ON_BN_CLICKED(IDC_BTNCOL, &CSliderGDIDlg::OnBnClickedBtncol)
  ON_BN_CLICKED(IDC_BTNOPTIONS, &CSliderGDIDlg::OnBnClickedBtnopt)
  ON_WM_TIMER()
  ON_BN_CLICKED(IDC_BTNPREC, &CSliderGDIDlg::OnBnClickedBtnprec)
  ON_BN_CLICKED(IDC_BUTTON1, &CSliderGDIDlg::OnBnClickedButton1)
END_MESSAGE_MAP()

void CSliderGDIDlg::OnSliderRClk(NMHDR* /*pNotifyStruct*/,LRESULT*result)
{
  *result = 1L;
}
// CSliderGDIDlg message handlers

BOOL CSliderGDIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

  m_slInt.SetInitVals(0i16, 10i16, 0, 1i16);
  m_slInt.SetCaption(L"SHORT INT");

  m_slDbl.SetInitVals(0.0, 10000.0, 10, 10.6);
  m_slDbl.SetCaption(L"DOUBLE VALUES");

//  m_slTest.SetInitVals(0, 4.0e-200, 215, 1.0e-200);
//  m_slTest.SetInitVals(0, 4.0e+015, -1, 1.0e+015);
  m_slTest.SetInitVals(-1.0, 1.0, 6, -0.567894);
  m_slTest.SetCaption(L"Test");

  m_slMin.SetInitVals(-10000015L, 10000015L, -2, -527L);
  m_slMin.SetCaption(L"Min Height Slide");

  m_chEnable.SetImage(IDB_CHKNO32);
	m_chEnable.SetCheckedImage(IDB_CHK32);
  m_chEnable.SetFaceColor(Color((ARGB)Color::PaleGreen).ToCOLORREF(), FALSE);
	m_chEnable.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;
  m_chEnable.SetCheck(BST_CHECKED);

  m_btnSqueeze.SetImage(IDB_BMPSQUEEZE);
  m_btnSqueeze.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnSqueeze.SizeToContent();
	m_btnSqueeze.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnExpand.SetImage(IDB_BMPEXPAND);
  m_btnExpand.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnExpand.SizeToContent();
	m_btnExpand.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnLeft.SetImage(IDB_BMPMOVEL);
  m_btnLeft.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnLeft.SizeToContent();
	m_btnLeft.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnRight.SetImage(IDB_BMPMOVER);
  m_btnRight.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnRight.SizeToContent();
	m_btnRight.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnSqueezeV.SetImage(IDB_BMPSQUEEZEV);
  m_btnSqueezeV.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnSqueezeV.SizeToContent();
	m_btnSqueezeV.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnExpandV.SetImage(IDB_BMPEXPANDV);
  m_btnExpandV.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnExpandV.SizeToContent();
	m_btnExpandV.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnCol.SetImage(IDB_BMPCOLS);
  m_btnCol.SetFaceColor(Color((ARGB)Color::Gray).ToCOLORREF());
  m_btnCol.SizeToContent();
	m_btnCol.m_nFlatStyle = CMFCButton::BUTTONSTYLE_3D;

  m_btnOptions.m_nAlignStyle = CMFCButton::ALIGN_CENTER;
  m_btnOptions.m_nFlatStyle = CMFCButton::BUTTONSTYLE_FLAT;
  m_btnOptions.SetFaceColor(Color((ARGB)Color::LightGreen).ToCOLORREF(), FALSE);
  
  m_mnOptions.LoadMenu(IDR_MNOPRIONS);
	m_btnOptions.m_hMenu = m_mnOptions.GetSubMenu(0)->GetSafeHmenu();
	m_btnOptions.m_bOSMenu = FALSE;

  CString szVal;
  int valInt = m_slInt.GetCurrValue();
  szVal.Format(CString("Slider thumb position is at %d"), valInt);
  m_stInt.SetWindowTextW(szVal);
  double valDbl = m_slDbl.GetCurrValue();
  szVal.Format(CString("Slider thumb position is at %.2f"), valDbl);
  m_stDbl.SetWindowTextW(szVal);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSliderGDIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSliderGDIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CSliderGDIDlg::OnBnClickedChenbl()
{
  UINT state = m_chEnable.GetCheck();
  if (state == BST_CHECKED)
  {
    CString szVal;
    m_chEnable.SetFaceColor(Color((ARGB)Color::PaleGreen).ToCOLORREF());
    m_slInt.EnableWindow();
    int valInt = m_slInt.GetCurrValue();
    szVal.Format(CString("Slider thumb position is at %d"), valInt);
    m_stInt.SetWindowTextW(szVal);
  }
  else
  {
    m_chEnable.SetFaceColor(Color((ARGB)Color::Bisque).ToCOLORREF());
    m_slInt.EnableWindow(0);
    m_stInt.SetWindowTextW(L"Slider is disabled");
  }
}

void  CSliderGDIDlg::OnSlidePosChanged(NMHDR *pNMHDR, LRESULT *pResult)
{
  CString szVal;
  switch (pNMHDR->idFrom)
  {
  case IDC_SLINT:
    {
      int valInt = m_slInt.GetCurrValue();
      szVal.Format(CString("Slider thumb position is at %d"), valInt);
      m_stInt.SetWindowTextW(szVal);
    }
    break;
  case IDC_SLDBL:
    {
      double valDbl = m_slDbl.GetCurrValue();
      szVal.Format(CString("Slider thumb position is at %.2f"), valDbl);
      m_stDbl.SetWindowTextW(szVal);
    }
    break;
  default:
    AfxMessageBox(L"Wrong Notification");
  }
  *pResult = 1L;
}


void CSliderGDIDlg::OnBnClickedBtnsqueeze()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.DeflateRect(10, 0); 
  if (wR.Width() > 10)
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtnexpand()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.InflateRect(10, 0);
  CRect pR;
  GetClientRect(&pR);
  ClientToScreen(&pR);
  CWnd* grBoxPtr = GetDlgItem(IDC_ST);
  CRect gR;
  grBoxPtr->GetClientRect(&gR);
  grBoxPtr->ClientToScreen(&gR);
  pR.left = gR.left;
  pR.right = gR.right;
  pR.IntersectRect(&pR, &wR);
  if (pR.EqualRect(wR))
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtnmovel()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.OffsetRect(-10, 0);
  CRect pR;
  GetClientRect(&pR);
  ClientToScreen(&pR);
  CWnd* grBoxPtr = GetDlgItem(IDC_ST);
  CRect gR;
  grBoxPtr->GetClientRect(&gR);
  grBoxPtr->ClientToScreen(&gR);
  pR.left = gR.left;
  pR.right = gR.right;
  pR.IntersectRect(&pR, &wR);
  if (pR.EqualRect(wR))
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtnmover()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.OffsetRect(10, 0);
  CRect pR;
  GetClientRect(&pR);
  ClientToScreen(&pR);
  CWnd* grBoxPtr = GetDlgItem(IDC_ST);
  CRect gR;
  grBoxPtr->GetClientRect(&gR);
  grBoxPtr->ClientToScreen(&gR);
  pR.left = gR.left;
  pR.right = gR.right;
  pR.IntersectRect(&pR, &wR);
  if (pR.EqualRect(wR))
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtsqueezev()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.top += 10;
  if (wR.Height() > 10)
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtnexpandv()
{
  CRect wR;
  m_slTest.GetWindowRect(&wR);
  wR.top -= 10;
  CRect pR;
  GetClientRect(&pR);
  ClientToScreen(&pR);
  CWnd* grBoxPtr = GetDlgItem(IDC_ST);
  CRect gR;
  grBoxPtr->GetClientRect(&gR);
  grBoxPtr->ClientToScreen(&gR);
  pR.top = gR.top;
  pR.IntersectRect(&wR, &pR);
  if (pR.EqualRect(&wR))
  {
    ScreenToClient(&wR);
    m_slTest.MoveWindow(wR.left, wR.top, wR.Width(), wR.Height());
  }
}

void CSliderGDIDlg::OnBnClickedBtncol()
{
  CColorDialog colDlg;
  if (IDOK == colDlg.DoModal())
  {
    COLORREF colRef = colDlg.GetColor();
    Color color;
    color.SetFromCOLORREF(colRef);
    m_slTest.BarColor(color, true);
  }
  else
    m_slTest.SetBarColorDefault(true);
}

void CSliderGDIDlg::OnBnClickedBtnopt()
{
  switch (m_btnOptions.m_nMenuResult)
  {
  case IDM_COLOR: 
    {
      CColorDialog colDlg;
      if (IDOK == colDlg.DoModal())
      {
        COLORREF colRef = colDlg.GetColor();
        m_tmpBarCol.SetFromCOLORREF(colRef);
      }
      else
        m_tmpBarCol =  Color(255, 91, 122, 202);
      SetTimer(1, 2000, NULL);
    }
    break;
  case IDM_STRFORMAT: SetTimer(2, 2000, NULL); break;
  case IDM_FONTATTR:  SetTimer(3, 2000, NULL); break;
  case IDM_CAPTION:   SetTimer(4, 2000, NULL); break;
  case IDM_CURRVAL:   SetTimer(5, 2000, NULL); break;
  case IDM_MINMAX:    SetTimer(6, 2000, NULL); break;
  case IDM_PRECISION: SetTimer(7, 2000, NULL); break;
  case IDM_MOVE:      SetTimer(8, 2000, NULL); break;
  case IDM_SIZE:      SetTimer(9, 2000, NULL); break;
  }

  UINT mnState = m_mnOptions.GetMenuState(m_btnOptions.m_nMenuResult,
                                                          MF_BYCOMMAND);

  if (mnState && MF_CHECKED)
    mnState = MF_UNCHECKED;
  else
    mnState = MF_CHECKED;
  m_mnOptions.CheckMenuItem(m_btnOptions.m_nMenuResult, mnState|MF_BYCOMMAND);

}

void CSliderGDIDlg::OnBnClickedBtnprec()
{
  if (m_slDbl.Precision() == 1)
    m_slDbl.SetPrecision(3, true);
  else
    m_slDbl.SetPrecision(1, true);
}

void CSliderGDIDlg::OnTimer(UINT_PTR nIDEvent)
{
  switch (nIDEvent)
  {
  case 1:     // Bar Color
    m_slTest.BarColor(m_tmpBarCol, true);  break;
  case 2:     // String Format
    if (m_slTest.GetValStrAlignmentH() == StringAlignmentCenter)
      m_slTest.SetSliderStrFormat(StringAlignmentFar, StringAlignmentFar, true);
    else
      m_slTest.SetSliderStrFormat(StringAlignmentCenter, StringAlignmentCenter, true);
    break;
  case 3:     // Font Attributes
    if (m_slTest.GetSliderFontStyle() == FontStyleRegular)
      m_slTest.SetSliderFontAttributes(FontStyleBoldItalic, L"Arial", true);
    else
      m_slTest.SetSliderFontAttributes(FontStyleRegular, L"Palatino Linotype", true);
    break;
  case 4:     // Caption
    if (m_slTest.GetCaption().length() == 4)
    {
      wstring wstrCaption(L"Test This Slider");
      m_slTest.SetCaption(wstrCaption, true);
    }
    else
    {
      wstring wstrCaption(L"Test");
      m_slTest.SetCaption(wstrCaption, true);
    }
    break;
  case 5:     // Curr value
    if (m_slTest.GetCurrValue() == 23.98)
      m_slTest.SetCurrValue(105.00, true);
    else
      m_slTest.SetCurrValue(23.98, true);
    break;
  case 6:     // MinMax
    if (m_slTest.GetMinVal() == -1.0)
      m_slTest.SetMinMaxVal(-50.3, 345.6, true, true);
    else
      m_slTest.SetMinMaxVal(-1.0, 1.0, true, true);
    break;
  case 7:     // Precision
    if (m_slTest.Precision() == 10)
      m_slTest.SetPrecision(9, true);
    else
      m_slTest.SetPrecision(10, true);
    break;
  case 8:     // Move
    {
      UINT itState = m_mnOptions.GetMenuState(IDM_MOVE, MF_BYCOMMAND);
      int dist =  (itState == MF_UNCHECKED) ? -10 : 10;
      CRect wR;
      m_slTest.GetWindowRect(&wR);
      ScreenToClient(&wR);
      m_slTest.MoveWindow(wR.left+dist, wR.top, wR.Width(), wR.Height());
    }
    break;
  case 9:    // Change size
    {
      UINT itState = m_mnOptions.GetMenuState(IDM_SIZE, MF_BYCOMMAND);
      int dx = (itState == MF_UNCHECKED) ? -10 : 10;
      CRect wR;
      m_slTest.GetWindowRect(&wR);
      ScreenToClient(&wR);
      m_slTest.MoveWindow(wR.left + dx, wR.top, wR.Width() - dx, wR.Height());
    }
    break;
  }
  KillTimer(nIDEvent);
}

void CSliderGDIDlg::OnBnClickedButton1()
{
  try
  {
    if (!m_slTest.SetInitVals(-0.0002, 0.0002, -1, 0.0))
      throw std::invalid_argument(string(
                        "Wrong parameters in slTest.SetInitVals(-0.002, 0.0020, -1, 0)"));
  }
  catch (exception& iae)
  {
    MessageBox(CString(iae.what()), CString(typeid(iae).name()), MB_ICONERROR);
  }
}
