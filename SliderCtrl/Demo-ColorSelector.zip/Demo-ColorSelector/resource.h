//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ColorSelector.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COLORSELECTOR_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDI_MFC_ICON                    129
#define IDC_PLACEHOLDER                 1000
#define IDC_SLIDER_LUM                  1001
#define IDC_SLIDER_RED                  1002
#define IDC_SLIDER_GREEN                1003
#define IDC_SLIDER_BLUE                 1004
#define IDC_EDIT_RED                    1005
#define IDC_EDIT_RED1                   1005
#define IDC_EDIT_GREEN                  1006
#define IDC_EDIT_BLUE                   1007
#define IDC_EDIT_LUM                    1008
#define IDC_STATIC_SAMPLECOLOR          1009
#define IDC_STATIC_RED                  1010
#define IDC_BUTTON_COPYVALUE            1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
