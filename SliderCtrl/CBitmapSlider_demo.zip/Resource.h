//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CBitmapSlider Demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CBITMAPSLIDERDEMO_DIALOG    102
#define IDR_MAINFRAME                   128
#define IDB_BIRD                        131
#define IDB_BUS                         132
#define IDB_MP_CHANNEL                  133
#define IDB_MP_CHANNEL_ACTIVE           134
#define IDB_MP_THUMB                    135
#define IDB_MP_THUMB_ACTIVE             136
#define IDB_ROAD                        137
#define IDB_SKY                         138
#define IDB_VOL_OFF                     139
#define IDB_VOL_ON                      140
#define IDB_BALLOON                     141
#define IDC_SLIDER_VOL                  1000
#define IDC_SLIDER_MP                   1001
#define IDC_SLIDER_VOL2                 1002
#define IDC_SLIDER_BIRD                 1003
#define IDC_SLIDER_ROAD                 1004
#define IDC_SLIDER_BALLOON              1005
#define IDC_MIN                         1006
#define IDC_POS                         1007
#define IDC_MAX                         1008
#define IDC_APPLY                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
