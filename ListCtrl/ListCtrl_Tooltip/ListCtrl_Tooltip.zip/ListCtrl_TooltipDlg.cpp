// ListCtrl_TooltipDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ListCtrl_TooltipApp.h"
#include "ListCtrl_TooltipDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CListCtrl_TooltipDlg dialog



CListCtrl_TooltipDlg::CListCtrl_TooltipDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CListCtrl_TooltipDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CListCtrl_TooltipDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ENABLETOOLTIP, m_EnableToolTip);
	DDX_Control(pDX, IDC_TOOLTIPCTRL, m_ToolTipCtrl);
	DDX_Control(pDX, IDC_OWNTOOLTIPCTRL, m_OwnToolTipCtrl);
	DDX_Control(pDX, IDC_LABELTOOLTIP, m_LabelToolTip);
	DDX_Control(pDX, IDC_INFOTOOLTIP, m_InfoToolTip);
}

BEGIN_MESSAGE_MAP(CListCtrl_TooltipDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY_EX(TTN_NEEDTEXTA, 0, OnToolNeedText)
	ON_NOTIFY_EX(TTN_NEEDTEXTW, 0, OnToolNeedText)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CListCtrl_TooltipDlg message handlers

BOOL CListCtrl_TooltipDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_ToolTip.Create(this);
	//m_ToolTip.AddTool(&m_OwnToolTipCtrl);
	//m_ToolTip.AddTool(m_OwnToolTipCtrl.GetHeaderCtrl());
	m_ToolTip.Activate(TRUE);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	LoadListCtrl(m_EnableToolTip);
	LoadListCtrl(m_ToolTipCtrl);
	LoadListCtrl(m_OwnToolTipCtrl);
	LoadListCtrl(m_LabelToolTip);
	LoadListCtrl(m_InfoToolTip);
	//m_InfoToolTip.SetExtendedStyle(GetExtendedStyle() | LVS_EX_INFOTIP);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

BOOL CListCtrl_TooltipDlg::PreTranslateMessage(MSG* pMsg)
{
	//if (m_ToolTip)
	//	m_ToolTip.RelayEvent(pMsg);
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CListCtrl_TooltipDlg::OnToolNeedText(UINT id, NMHDR* pNMHDR, LRESULT* pResult)
{
	int i = 0;
	return FALSE;
}

void CListCtrl_TooltipDlg::LoadListCtrl(CListCtrl& listCtrl)
{
	// Create Columns
	for(int col = 0; col < m_DataModel.GetColCount() ; ++col)
	{
		const string& title = m_DataModel.GetColTitle(col);
		listCtrl.InsertColumn(col, CString(title.c_str()), LVCFMT_LEFT, 75);
	}

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for(size_t rowId = 0; rowId < m_DataModel.GetRowIds() ; ++rowId)
	{
		nItem = listCtrl.InsertItem(++nItem, CString(m_DataModel.GetCellText(rowId, 0).c_str()));
		listCtrl.SetItemData(nItem, rowId);
		for(int col = 0; col < m_DataModel.GetColCount() ; ++col)
		{
			listCtrl.SetItemText(nItem, col, CString(m_DataModel.GetCellText(rowId, col).c_str()));
		}
	}
}

void CListCtrl_TooltipDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CListCtrl_TooltipDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CListCtrl_TooltipDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
