#pragma once

#include "CListCtrl_ToolTip.h"

class CListCtrl_ToolTipCtrl : public CListCtrl_ToolTip
{
	DECLARE_MESSAGE_MAP();
};
