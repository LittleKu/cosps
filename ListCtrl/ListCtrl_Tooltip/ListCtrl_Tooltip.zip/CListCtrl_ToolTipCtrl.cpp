#include "stdafx.h"
#include "CListCtrl_ToolTipCtrl.h"

// Handle the messages received from the CListCtrl::GetToolTip()
BEGIN_MESSAGE_MAP(CListCtrl_ToolTipCtrl, CListCtrl)
	ON_NOTIFY_EX(TTN_NEEDTEXTA, 0, OnToolNeedText)
	ON_NOTIFY_EX(TTN_NEEDTEXTW, 0, OnToolNeedText)
END_MESSAGE_MAP()
