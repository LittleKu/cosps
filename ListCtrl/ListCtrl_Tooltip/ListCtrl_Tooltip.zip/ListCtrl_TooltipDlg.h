// ListCtrl_TooltipDlg.h : header file
//

#pragma once
#include "afxcmn.h"

#include "CListCtrl_DataModel.h"
#include "CListCtrl_EnableToolTip.h"
#include "CListCtrl_InfoTip.h"
#include "CListCtrl_LabelTip.h"
#include "CListCtrl_OwnToolTipCtrl.h"
#include "CListCtrl_ToolTipCtrl.h"

// CListCtrl_TooltipDlg dialog
class CListCtrl_TooltipDlg : public CDialog
{
// Construction
public:
	CListCtrl_TooltipDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_LISTCTRL_TOOLTIP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	void LoadListCtrl(CListCtrl& listCtrl);

	// Generated message map functions
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg BOOL OnToolNeedText(UINT id, NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	CToolTipCtrl m_ToolTip;
	CListCtrl_DataModel m_DataModel;
	CListCtrl_EnableToolTip m_EnableToolTip;
	CListCtrl_ToolTipCtrl m_ToolTipCtrl;
	CListCtrl_OwnToolTipCtrl m_OwnToolTipCtrl;
	CListCtrl_LabelTip m_LabelToolTip;
	CListCtrl_InfoTip m_InfoToolTip;
};
