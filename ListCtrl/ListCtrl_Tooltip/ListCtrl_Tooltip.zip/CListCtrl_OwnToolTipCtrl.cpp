#include "stdafx.h"
#include "CListCtrl_OwnToolTipCtrl.h"

// Maintain our own CToolTipCtrl
BEGIN_MESSAGE_MAP(CListCtrl_OwnToolTipCtrl, CListCtrl)
	ON_WM_MOUSEMOVE()
	ON_NOTIFY_EX(TTN_NEEDTEXTA, 0, OnToolNeedText)
	ON_NOTIFY_EX(TTN_NEEDTEXTW, 0, OnToolNeedText)
END_MESSAGE_MAP()

void CListCtrl_OwnToolTipCtrl::PreSubclassWindow()
{
	CListCtrl_ToolTip::PreSubclassWindow();

	// Disable the CToolTipCtrl of CListCtrl so it won't disturb our own tooltip-ctrl
	GetToolTips()->Activate(FALSE);

	// Enable our own tooltip-ctrl and make it show tooltip even if not having focus
	VERIFY( m_OwnToolTipCtrl.Create(this, TTS_ALWAYSTIP) );
	m_OwnToolTipCtrl.Activate(TRUE);
}

BOOL CListCtrl_OwnToolTipCtrl::PreTranslateMessage(MSG* pMsg)
{
	if (m_OwnToolTipCtrl.m_hWnd)
		m_OwnToolTipCtrl.RelayEvent(pMsg);
	return CListCtrl::PreTranslateMessage(pMsg);
}

void CListCtrl_OwnToolTipCtrl::OnMouseMove(UINT nFlags, CPoint point)
{
	CPoint pt(GetMessagePos());
	ScreenToClient(&pt);

	// Find the subitem
	LVHITTESTINFO hitinfo = {0};
	hitinfo.flags = nFlags;
	hitinfo.pt = pt;
	SubItemHitTest(&hitinfo);

	if (m_LastToolTipCol!=hitinfo.iSubItem || m_LastToolTipRow!=hitinfo.iItem)
	{
		// Mouse moved over a new cell
		m_LastToolTipCol = hitinfo.iSubItem;
		m_LastToolTipRow = hitinfo.iItem;

		// Remove the old tooltip (if available)
		if (m_OwnToolTipCtrl.GetToolCount()>0)
		{
			m_OwnToolTipCtrl.DelTool(this);
			m_OwnToolTipCtrl.Activate(FALSE);
		}

		// Add the new tooltip (if available)
		if (m_LastToolTipRow!=-1 && m_LastToolTipRow!=-1)
		{
			// Not using CToolTipCtrl::AddTool() because it redirects the messages to CListCtrl parent
			TOOLINFO ti = {0};
			ti.cbSize = sizeof(TOOLINFO);
			ti.uFlags = TTF_IDISHWND;	// Indicate that uId is handle to a control
			ti.uId = (UINT_PTR)m_hWnd;	// Handle to the control
			ti.hwnd = m_hWnd;			// Handle to window to receive the tooltip-messages
			ti.hinst = AfxGetInstanceHandle();
			ti.lpszText = LPSTR_TEXTCALLBACK;
			m_OwnToolTipCtrl.SendMessage(TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
			m_OwnToolTipCtrl.Activate(TRUE);
		}
	}

	CListCtrl::OnMouseMove(nFlags, point);
}

BOOL CListCtrl_OwnToolTipCtrl::OnToolNeedText(UINT id, NMHDR* pNMHDR, LRESULT* pResult)
{
	return CListCtrl_ToolTip::OnToolNeedText(id, pNMHDR, pResult);
}
