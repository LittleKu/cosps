// ListCtrl_Column_PickerDlg.h : header file
//

#pragma once

#include "CListCtrl_Column_Picker.h"
#include "CListCtrl_DataModel.h"
#include "afxcmn.h"

// CListCtrl_Column_PickerDlg dialog
class CListCtrl_Column_PickerDlg : public CDialog
{
// Construction
public:
	CListCtrl_Column_PickerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_LISTCTRL_COLUMN_PICKER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	CListCtrl_DataModel m_DataModel;
	CListCtrl_Column_Picker m_ListCtrl;
};
