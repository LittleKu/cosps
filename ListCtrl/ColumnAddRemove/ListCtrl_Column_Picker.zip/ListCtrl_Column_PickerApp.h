// ListCtrl_Column_Picker.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CListCtrl_Column_PickerApp:
// See ListCtrl_Column_Picker.cpp for the implementation of this class
//

class CListCtrl_Column_PickerApp : public CWinApp
{
public:
	CListCtrl_Column_PickerApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CListCtrl_Column_PickerApp theApp;