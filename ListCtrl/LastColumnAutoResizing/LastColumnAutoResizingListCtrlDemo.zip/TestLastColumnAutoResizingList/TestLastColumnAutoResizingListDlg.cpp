
// TestLastColumnAutoResizingListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestLastColumnAutoResizingList.h"
#include "TestLastColumnAutoResizingListDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTestAutoResizingListDlg dialog

CTestAutoResizingListDlg::CTestAutoResizingListDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CTestAutoResizingListDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestAutoResizingListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_listLeft);
	DDX_Control(pDX, IDC_LIST2, m_listRight);
}

BEGIN_MESSAGE_MAP(CTestAutoResizingListDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CTestAutoResizingListDlg message handlers

BOOL CTestAutoResizingListDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	InitializeListCtrl(&m_listLeft);
	InitializeListCtrl(&m_listRight);

	RECT rect;
	GetClientRect(&rect);
	AdjustListControls(rect.right, rect.bottom);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestAutoResizingListDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestAutoResizingListDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestAutoResizingListDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CTestAutoResizingListDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if (m_listLeft.GetSafeHwnd() != NULL && m_listRight.GetSafeHwnd() != NULL)
	{
		AdjustListControls(cx, cy);
		m_listLeft.SetColumnWidth(m_listLeft.GetHeaderCtrl()->GetItemCount() - 1, LVSCW_AUTOSIZE_USEHEADER);
	}
}

void CTestAutoResizingListDlg::InitializeListCtrl(CListCtrl* pListCtrl)
{
	pListCtrl->SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER | LVS_EX_CHECKBOXES);

	// uncomment following lines to reset HDS_FULLDARG style
	//DWORD headerStyle = pListCtrl->GetHeaderCtrl()->GetStyle();
	//ASSERT((headerStyle & HDS_FULLDRAG) == HDS_FULLDRAG);
	//pListCtrl->GetHeaderCtrl()->ModifyStyle(HDS_FULLDRAG, 0);

	int nColumnCount = 3;

	CString strText;
	for (int i = 0; i < nColumnCount; ++i)
	{
		strText.Format(_T("Column %d"), i);
		pListCtrl->InsertColumn(i, strText, LVCFMT_LEFT, 100);
	}

	for (int i = 0; i < 10; ++i)
    {
        strText.Format(_T("item(%d)"), i);
        pListCtrl->InsertItem(i, strText);

        for (int j = 1; j < nColumnCount; ++j)
        {
            strText.Format(_T("sub-item(%d, %d)"), i, j);
            pListCtrl->SetItemText(i, j, strText);
        }
    }

	pListCtrl->SetColumnWidth(nColumnCount - 1, LVSCW_AUTOSIZE_USEHEADER);
}


void CTestAutoResizingListDlg::AdjustListControls(int cx, int cy)
{
	static int gap = 3;
	int width = cx / 2 - gap;
	m_listLeft.MoveWindow(0, 0, width, cy);
	m_listRight.MoveWindow(cx - width, 0, width, cy);
}
