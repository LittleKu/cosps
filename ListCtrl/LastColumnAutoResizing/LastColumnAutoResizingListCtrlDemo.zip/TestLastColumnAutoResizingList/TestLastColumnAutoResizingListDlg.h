
// TestLastColumnAutoResizingListDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "LastColumnAutoResizingListCtrl.h"


// CTestAutoResizingListDlg dialog
class CTestAutoResizingListDlg : public CDialogEx
{
// Construction
public:
	CTestAutoResizingListDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_TESTAUTORESIZINGLIST_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
private:
	CListCtrl m_listLeft;
	CLastColumnAutoResizingListCtrl m_listRight;
	void InitializeListCtrl(CListCtrl* pListCtrl);
	void AdjustListControls(int cx, int cy);
};
