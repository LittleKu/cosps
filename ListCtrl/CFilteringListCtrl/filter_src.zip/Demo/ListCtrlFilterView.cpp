// ListCtrlFilterView.cpp : implementation of the CListCtrlFilterView class
//

#include "stdafx.h"

#include "ListCtrlFilter.h"

#include "ListCtrlFilterDoc.h"
#include "ListCtrlFilterView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView

IMPLEMENT_DYNCREATE(CListCtrlFilterView, CView)

BEGIN_MESSAGE_MAP(CListCtrlFilterView, CView)
	//{{AFX_MSG_MAP(CListCtrlFilterView)
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView construction/destruction

CListCtrlFilterView::CListCtrlFilterView()
{
	// TODO: add construction code here

	menu.LoadMenu(IDR_POPUP_MENU);
}

CListCtrlFilterView::~CListCtrlFilterView()
{
}

BOOL CListCtrlFilterView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView drawing

void CListCtrlFilterView::OnDraw(CDC* pDC)
{
	CListCtrlFilterDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView printing

BOOL CListCtrlFilterView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CListCtrlFilterView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CListCtrlFilterView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView diagnostics

#ifdef _DEBUG
void CListCtrlFilterView::AssertValid() const
{
	CView::AssertValid();
}

void CListCtrlFilterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CListCtrlFilterDoc* CListCtrlFilterView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CListCtrlFilterDoc)));
	return (CListCtrlFilterDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterView message handlers

void CListCtrlFilterView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();

	listCtrl.CreateEx(this, 111);

	int ndx_dummy = listCtrl.InsertColumn(0, "Dummy", LVCFMT_LEFT, 200);

	listCtrl.InsertColumn(1, "Column #1", LVCFMT_CENTER, 200);
	listCtrl.InsertColumn(2, "Column #2", LVCFMT_CENTER, 200);
	listCtrl.InsertColumn(3, "Column #3", LVCFMT_CENTER, 200);

	listCtrl.DeleteColumn(ndx_dummy);

	for(int i = 0; i < 50; i++)
	{
		CString str1, str2;

		str1.Format("Item %i", i + 1);
		str2.Format("%i", i + 1);

		listCtrl.InsertItemEx(i, 0, str1);
		listCtrl.InsertItemEx(i, 1, str2);
		listCtrl.InsertItemEx(i, 2, str2);
	}

	listCtrl.SetFilter(0, "Item 5", "Item 20", true);
	listCtrl.SetFilter(1, "7", "10", false);
	listCtrl.SetFilter(2, "14", "18", false);
}

void CListCtrlFilterView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here	
	CRect rc;
	this->GetClientRect(rc);

	if(listCtrl) listCtrl.MoveWindow(rc);
}

void CListCtrlFilterView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	POINT curPos;
	CRect headRect, itRect;
	bool head_click = false;

	int CurrentClmn = -1, CurrentIndex = -1;

	GetCursorPos(&curPos);
	CHeaderCtrl* Header = listCtrl.GetHeaderCtrl();

	Header->GetClientRect(&headRect);
	Header->ClientToScreen(&headRect);

	for(int i = 0; i < Header->GetItemCount(); i++)
	{
		Header->GetItemRect(Header->OrderToIndex(i), &itRect);
		Header->ClientToScreen(&itRect);

		if(itRect.PtInRect(curPos))
		{
			CurrentClmn = i;
			CurrentIndex = Header->OrderToIndex(i);

			head_click = true;
			break;
		}
	}

	if(head_click)
	{
		CMenu *pMenu = menu.GetSubMenu(0);
		int selection = pMenu->TrackPopupMenu(TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON, curPos.x, curPos.y, this);

		switch(selection)
		{
			case ID_POPUP_EDITTFILTER:
			{
				CFilterDialog dialog;

				HDITEM item;
				TCHAR  lpBuffer[256];

				item.mask = HDI_TEXT;
				item.pszText = lpBuffer;
				item.cchTextMax = 256;

				Header->GetItem(CurrentIndex, &item);

				CString title("Edit filter for ");
				title += item.pszText;
				dialog.SetTitle(title);

				CString from, to;
				bool direction = true;

				if(listCtrl.GetFilter(CurrentIndex, from, to, &direction))
				{
					dialog.m_From = from;
					dialog.m_To = to;
					dialog.m_Interior = !direction;
				}
				else
				{
					dialog.m_From = "";
					dialog.m_To = "";
					dialog.m_Interior = false;
				}

				if(dialog.DoModal() == IDOK)
				{
					if(!dialog.m_From.IsEmpty() && !dialog.m_To.IsEmpty())
					{
						listCtrl.SetFilter(CurrentIndex, dialog.m_From, dialog.m_To, !dialog.m_Interior);

						for(int i = 0; i < listCtrl.GetItemCount(); i++)
						{
							if(!listCtrl.CheckItemAgainstAllFilters(i))
								listCtrl.SetItemState(i, 0, LVIS_SELECTED);
						}
					}
					else
					{
						if(dialog.m_From.IsEmpty() && dialog.m_To.IsEmpty())
							listCtrl.RemoveFilter(CurrentIndex);
					}
				}

				this->RedrawWindow();
			}
			break;

			default: break;
		}
	}
}