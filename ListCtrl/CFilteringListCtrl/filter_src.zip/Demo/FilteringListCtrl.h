#if !defined(AFX_FILTERINGLISTCTRL_H__CD313945_2668_415A_B32A_C309060A6385__INCLUDED_)
#define AFX_FILTERINGLISTCTRL_H__CD313945_2668_415A_B32A_C309060A6385__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilteringListCtrl.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CFilteringListCtrl window

class CFilteringListCtrl : public CListCtrl
{
// Construction
public:
	CFilteringListCtrl();

	// Convenience method, initiates list control with the most common options.
	int CreateEx(CWnd* parent, UINT id);

// Attributes & operations
public:

	// Convenience method, always inserts 'str' into 'index'/'subindex'.
	int InsertItemEx(int index, int subindex, CString str);

	// Filters' management:
	bool GetFilter(int nFilter, CString& upper_bound, CString& lower_bound, bool* direction);
	bool SetFilter(int nFilter, CString  upper_bound, CString  lower_bound, bool  direction);
	bool RemoveFilter(int nFilter);

	bool CheckItemAgainstAllFilters(int iItem);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilteringListCtrl)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFilteringListCtrl();

protected:

	// Filter core:
	CStringArray Filters_From;		// Upper bounds
	CStringArray Filters_To;		// Lower bounds
	CByteArray Filters_Direction;	// Filters' directions: internal (true) or external (false).

	int last_selected_item,			// Index of the item last selected.
		first_in_a_row;				// Index of the first selected item during multiselection.

	// Checks input str against a 'nFilter' (zero-based) filter.
	// Comparison is case-sensitive and IS NOT lexicographical:
	//
	// I < Iguana < Idiotproof
	bool CheckStringAgainstFilter(CString str, int nFilter) const;

	// The same as prev., but comparison IS lexicographical:
	//
	// I < Iguana < J.
	bool CheckStringAgainstFilterLexicographical(CString str, int nFilter) const;

	// Checks if input 'str' is convertible to double through atof():
	bool IsNumeric(CString str) const;

	// Shinks input 'lpszLong' to 'nColumnLen' symbols + "..."
	LPCTSTR MakeShortString(CDC* pDC, LPCTSTR lpszLong, int nColumnLen, int nOffset);

	// Generated message map functions
protected:

	//{{AFX_MSG(CFilteringListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRdblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydown(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

// Overridables:

	// Allows us to show custom tooltips:
	int OnToolHitTest(CPoint point, TOOLINFO * pTI) const;

	// Custom draw:
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERINGLISTCTRL_H__CD313945_2668_415A_B32A_C309060A6385__INCLUDED_)
