// ListCtrlFilterView.h : interface of the CListCtrlFilterView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTCTRLFILTERVIEW_H__65CBBDBF_AAEF_4D08_AAAE_794A7C0772C7__INCLUDED_)
#define AFX_LISTCTRLFILTERVIEW_H__65CBBDBF_AAEF_4D08_AAAE_794A7C0772C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FilteringListCtrl.h"
#include "FilterDialog.h"

class CListCtrlFilterView : public CView
{
protected: // create from serialization only
	CListCtrlFilterView();
	DECLARE_DYNCREATE(CListCtrlFilterView)

// Attributes
public:
	CListCtrlFilterDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListCtrlFilterView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CListCtrlFilterView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	CMenu menu;
	CFilteringListCtrl listCtrl;

// Generated message map functions
protected:
	//{{AFX_MSG(CListCtrlFilterView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ListCtrlFilterView.cpp
inline CListCtrlFilterDoc* CListCtrlFilterView::GetDocument()
   { return (CListCtrlFilterDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCTRLFILTERVIEW_H__65CBBDBF_AAEF_4D08_AAAE_794A7C0772C7__INCLUDED_)
