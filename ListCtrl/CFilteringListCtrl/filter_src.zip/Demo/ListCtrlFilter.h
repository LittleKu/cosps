// ListCtrlFilter.h : main header file for the LISTCTRLFILTER application
//

#if !defined(AFX_LISTCTRLFILTER_H__658CF66C_EEC9_4C8B_8FC5_0EF17331E5A6__INCLUDED_)
#define AFX_LISTCTRLFILTER_H__658CF66C_EEC9_4C8B_8FC5_0EF17331E5A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CListCtrlFilterApp:
// See ListCtrlFilter.cpp for the implementation of this class
//

class CListCtrlFilterApp : public CWinApp
{
public:
	CListCtrlFilterApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListCtrlFilterApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CListCtrlFilterApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCTRLFILTER_H__658CF66C_EEC9_4C8B_8FC5_0EF17331E5A6__INCLUDED_)
