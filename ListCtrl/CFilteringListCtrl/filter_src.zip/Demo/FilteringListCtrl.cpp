// FilteringListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "FilteringListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilteringListCtrl

CFilteringListCtrl::CFilteringListCtrl() : last_selected_item(-1), first_in_a_row(-1)
{
}

CFilteringListCtrl::~CFilteringListCtrl()
{
}

BEGIN_MESSAGE_MAP(CFilteringListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CFilteringListCtrl)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(NM_CLICK, OnClick)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_NOTIFY_REFLECT(NM_RDBLCLK, OnRdblclk)
	ON_NOTIFY_REFLECT(LVN_KEYDOWN, OnKeydown)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilteringListCtrl message handlers

BOOL CFilteringListCtrl::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= LVS_REPORT | LVS_OWNERDRAWFIXED;
	return CListCtrl::PreCreateWindow(cs);
}

int CFilteringListCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;

	this->EnableToolTips(true);

	return 0;
}

int CFilteringListCtrl::CreateEx(CWnd* parent, UINT id)
{
	CRect rc;
	parent->GetClientRect(rc);

	int ret = Create(WS_CHILD | /*WS_BORDER |*/ WS_VISIBLE | WS_VSCROLL | WS_HSCROLL, CRect(0, 0, rc.right - rc.left, rc.bottom - rc.top), parent, id);

	SetExtendedStyle(GetExtendedStyle() | LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP);

	return ret;
}

int CFilteringListCtrl::InsertItemEx(int index, int subindex, CString str)
{
	LVITEM item;
	item.iItem = index;
	item.iSubItem = 0;
	item.mask = LVIF_STATE;
	item.pszText = " ";
	item.cchTextMax = 1;

	int ret_index = -1;

	if(subindex && !GetItem(&item))
	{
		item.mask = LVIF_TEXT;
		ret_index = InsertItem(&item);
	}

	item.iSubItem = subindex;
	item.mask = LVIF_TEXT;
	item.pszText = str.GetBuffer(str.GetLength());
	item.cchTextMax = str.GetLength();

	if(subindex)
		SetItem(&item);
	else
		ret_index = InsertItem(&item);

	return ret_index;
}

bool CFilteringListCtrl::GetFilter(int nFilter, CString& upper_bound, CString& lower_bound, bool* direction)
{
	if(nFilter >= this->GetHeaderCtrl()->GetItemCount())
		return false;

	if(nFilter >= this->Filters_From.GetSize())
		return false;

	upper_bound = this->Filters_From.GetAt(nFilter);
	lower_bound = this->Filters_To.GetAt(nFilter);
	*direction = (this->Filters_Direction.GetAt(nFilter) != 0);

	return true;
}

bool CFilteringListCtrl::SetFilter(int nFilter, CString upper_bound, CString lower_bound, bool direction)
{
	if(nFilter >= this->GetHeaderCtrl()->GetItemCount())
		return false;

	int upper_length = upper_bound.GetLength();
	int lower_length = lower_bound.GetLength();

	if((upper_length == 0) || (lower_length == 0))
		return false;

	int compare = 0;

	if(upper_length > lower_length)
		compare = -1;
	else if(upper_length < lower_length)
		compare = 1;
	else
		compare = lower_bound.Compare(upper_bound);

	this->Filters_From.SetAtGrow(nFilter, (compare >= 0) ? upper_bound : lower_bound);
	this->Filters_To.SetAtGrow(nFilter, (compare >= 0) ? lower_bound : upper_bound);
	this->Filters_Direction.SetAtGrow(nFilter, (BYTE)direction);

	for(int i = 0; i < GetItemCount(); i++)
	{
		if(!CheckItemAgainstAllFilters(i))
		{
			SetItemState(i, 0, LVIS_SELECTED);
			SetItemState(i, 0, LVIS_FOCUSED);
		}
	}

	return true;
}

bool CFilteringListCtrl::RemoveFilter(int nFilter)
{
	if(this->Filters_From.GetSize() > nFilter)
	{
		this->Filters_From.SetAt(nFilter, "");
		this->Filters_To.SetAt(nFilter, "");
		this->Filters_Direction.SetAt(nFilter, 0);

		return true;
	}

	return false;
}

int CFilteringListCtrl::OnToolHitTest(CPoint point, TOOLINFO * pTI) const
{
	LVHITTESTINFO lvhitTestInfo;
	lvhitTestInfo.pt = point;

	int nItem = ListView_SubItemHitTest(this->m_hWnd, &lvhitTestInfo);

	// If no item, ignore this:
	if(nItem < 0)
		return -1;

	int nSubItem = lvhitTestInfo.iSubItem;

	// retrieve item from the list:
	LVITEM item;
	TCHAR buffer[128];

	item.iItem = nItem;
	item.iSubItem = nSubItem;
	item.pszText = buffer;
	item.cchTextMax = 128;
	item.mask = LVIF_TEXT;

	GetItem(&item);

	if(CheckStringAgainstFilter(item.pszText, nSubItem))
		return -1;

	if(lvhitTestInfo.flags)
	{
		RECT rcClient;
		GetClientRect(&rcClient);

		// fill in the TOOLINFO structure
		pTI->hwnd = m_hWnd;
		pTI->uId = (UINT)(nItem * 1000 + nSubItem + 1);

		// construct a string:
		if(this->Filters_From.GetSize() <= nSubItem)
			return -1;

		CString filter = this->Filters_From.GetAt(nSubItem);
		if(filter.IsEmpty())
			return -1;

		filter += "\" to \"" + this->Filters_To.GetAt(nSubItem) + (this->Filters_Direction.GetAt(nSubItem) ? "\" are valid." : "\" are invalid.");
		filter.Insert(0, " filtered by condition: values from \"");
		filter.Insert(0, CString(buffer) + "\"");
		filter.Insert(0, "Value \"");

		// There is no memory leak here - MFC frees the memory after it has added the tool.
		// See MSDN KB 156067 for more info.
		pTI->lpszText = (char*)malloc(filter.GetLength() + 1);
		strcpy(pTI->lpszText, filter.GetBuffer(filter.GetLength()));

		pTI->rect = rcClient;

		return pTI->uId;
	}
	else
		return -1;
}

bool CFilteringListCtrl::CheckStringAgainstFilter(CString str, int nFilter) const
{
	if(this->Filters_From.GetSize() <= nFilter)
		return true;

//	return CheckStringAgainstFilterLexicographical(str, nFilter);

	CString from = this->Filters_From.GetAt(nFilter);
	CString to = this->Filters_To.GetAt(nFilter);

	if(IsNumeric(str) && IsNumeric(from) && IsNumeric(to))
	{
		double from_d = atof(from.GetBuffer(from.GetLength()));
		double to_d = atof(to.GetBuffer(to.GetLength()));
		double str_d = atof(str.GetBuffer(str.GetLength()));

		if((str_d >= from_d) && (str_d <= to_d))
			return (this->Filters_Direction.GetAt(nFilter) != 0);
	}
	else
	{
		int compare_from = 0, compare_to = 0;

		if(str.GetLength() > from.GetLength())
			compare_from = 1;
		else if(str.GetLength() < from.GetLength())
			compare_from = -1;
		else
			compare_from = str.Compare(from);

		if(str.GetLength() > to.GetLength())
			compare_to = 1;
		else if(str.GetLength() < to.GetLength())
			compare_to = -1;
		else
			compare_to = str.Compare(to);

		if((compare_from >= 0) && (compare_to <= 0))
			return (this->Filters_Direction.GetAt(nFilter) != 0);
	}

	return !this->Filters_Direction.GetAt(nFilter);
}

bool CFilteringListCtrl::CheckStringAgainstFilterLexicographical(CString str, int nFilter) const
{
	if(this->Filters_From.GetSize() <= nFilter)
		return true;

	CString from = this->Filters_From.GetAt(nFilter);
	CString to = this->Filters_To.GetAt(nFilter);

	if(IsNumeric(str) && IsNumeric(from) && IsNumeric(to))
	{
		double from_d = atof(from.GetBuffer(from.GetLength()));
		double to_d = atof(to.GetBuffer(to.GetLength()));
		double str_d = atof(str.GetBuffer(str.GetLength()));

		if((str_d >= from_d) && (str_d <= to_d))
			return (this->Filters_Direction.GetAt(nFilter) != 0);
	}
	else
	{
		if((str.Compare(from) >= 0) && (str.Compare(to) <= 0))
			return (this->Filters_Direction.GetAt(nFilter) != 0);
	}

	return !this->Filters_Direction.GetAt(nFilter);
}

bool CFilteringListCtrl::IsNumeric(CString str) const
{
	bool valid = true;
	for(int i = 0; i < str.GetLength(); i++)
	{
		TCHAR ch = str.GetAt(i);
		if(!(isdigit(ch) || (ch == '-') || (ch == '+') || (ch == '.') || (ch == ',')))
		{
			valid = false;
			break;
		}
	}

	return valid;
}

bool CFilteringListCtrl::CheckItemAgainstAllFilters(int iItem)
{
	if((iItem < 0) || (iItem >= GetItemCount()))
		return false;

	int nColumns = GetHeaderCtrl()->GetItemCount();
	bool valid = true;

	LVITEM item;
	_TCHAR szBuff[MAX_PATH];

	for(int k = 0; k < nColumns; k++)
	{
		item.iItem = iItem;
		item.iSubItem = k;
		item.pszText = szBuff;
		item.cchTextMax = MAX_PATH;
		item.mask = LVIF_TEXT;

		if(GetItem(&item))
		{
			if(!CheckStringAgainstFilter(szBuff, k) && !this->Filters_From.GetAt(k).IsEmpty())
			{
				valid = false;
				break;
			}
		}
		else
			return false;
	}

	return valid;
}

// 'DrawItem' and 'MakeShortString' are based on MFC's "ListVwEx" sample application.
void CFilteringListCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rcItem(lpDrawItemStruct->rcItem);
	UINT uiFlags = ILD_TRANSPARENT;

	DWORD full_row = (this->GetExtendedStyle() & LVS_EX_FULLROWSELECT);
	int nItem = lpDrawItemStruct->itemID;

	_TCHAR szBuff[MAX_PATH];
	LPCTSTR pszText;
	LVITEM item;

	static CBrush brush_invalid(RGB(255, 215, 215));
	static CBrush brush_select(GetSysColor(COLOR_HIGHLIGHT));
	static CBrush brush_window(GetSysColor(COLOR_WINDOW));

	// Check all item's subitems against filters:

	int nColumns = this->GetHeaderCtrl()->GetItemCount();

	bool valid = true;
	bool *validity = new bool[nColumns];

	for(int k = 0; k < nColumns; k++)
	{
		validity[k] = true;

		item.iItem = nItem;
		item.iSubItem = k;
		item.pszText = szBuff;
		item.cchTextMax = MAX_PATH;
		item.mask = LVIF_TEXT;

		GetItem(&item);

		if(!CheckStringAgainstFilter(szBuff, k) && !this->Filters_From.GetAt(k).IsEmpty())
		{
			valid = false;
			validity[k] = false;
		}
	}

//

	item.iSubItem = 0;
	item.pszText = szBuff;
	item.cchTextMax = MAX_PATH;
	item.mask = LVIF_TEXT | LVIF_STATE;
	item.stateMask = 0xFFFF;     // get all state flags

	GetItem(&item);

	CRect rcAllLabels;
	GetItemRect(nItem, rcAllLabels, LVIR_BOUNDS);

	CRect rcLabel;
	GetItemRect(nItem, rcLabel, LVIR_LABEL);

	pDC->FillRect(rcAllLabels, &brush_window);

	GetItemRect(nItem, rcItem, LVIR_LABEL);

	pszText = MakeShortString(pDC, szBuff, rcItem.right-rcItem.left, 4);
	rcLabel = rcItem;

	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH;
	GetColumn(0, &lvc);

	UINT nJustify = DT_LEFT;
	if(pszText == szBuff)
	{
		switch(lvc.fmt & LVCFMT_JUSTIFYMASK)
		{
			case LVCFMT_LEFT:
				nJustify = DT_LEFT;
				break;

			case LVCFMT_CENTER:
				nJustify = DT_CENTER;
				break;

			case LVCFMT_RIGHT:
				nJustify = DT_RIGHT;
				break;

			default:
				break;
		}
	}

	unsigned long prevText = pDC->SetTextColor(GetSysColor(valid ? ((lpDrawItemStruct->itemState & ODS_SELECTED) ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT) : COLOR_GRAYTEXT));

	if(!validity[0])
		pDC->FillRect(rcItem, &brush_invalid);
	else
	{
		if(valid &&(lpDrawItemStruct->itemState & ODS_SELECTED))
			pDC->FillRect(rcItem, &brush_select);
	}

	pDC->DrawText(pszText, -1, rcLabel, nJustify | DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | DT_VCENTER);

	lvc.mask = LVCF_FMT | LVCF_WIDTH;
	for(int nColumn = 1; GetColumn(nColumn, &lvc); nColumn++)
	{
		GetSubItemRect(nItem, nColumn, LVIR_BOUNDS, rcItem);

		if(!validity[nColumn])
			pDC->FillRect(rcItem, &brush_invalid);
		else
		{
			if(valid && (lpDrawItemStruct->itemState & ODS_SELECTED) && full_row)
				pDC->FillRect(rcItem, &brush_select);
		}

		int nRetLen = GetItemText(nItem, nColumn, szBuff, sizeof(szBuff));
		if(!nRetLen)
			continue;

		pszText = MakeShortString(pDC, szBuff, rcItem.right - rcItem.left, 2 * 6);

		nJustify = DT_LEFT;
		if(pszText == szBuff)
		{
			switch(lvc.fmt & LVCFMT_JUSTIFYMASK)
			{
				case LVCFMT_LEFT:
					nJustify = DT_LEFT;
					break;

				case LVCFMT_CENTER:
					nJustify = DT_CENTER;
					break;

				case LVCFMT_RIGHT:
					nJustify = DT_RIGHT;
					break;

				default:
					break;
			}
		}

		rcLabel = rcItem;
		rcLabel.left += 6;
		rcLabel.right -= 6;

		pDC->DrawText(pszText, -1, rcLabel, nJustify | DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | DT_VCENTER);
	}

	LV_ITEM lvi;
	lvi.mask = LVIF_STATE;
	lvi.iItem = nItem;
	lvi.iSubItem = 0;
	lvi.stateMask = 0xFFFF;     // get all state flags
	GetItem(&lvi);

	if((lvi.state & LVIS_FOCUSED) && valid)
		pDC->DrawFocusRect(rcAllLabels);

	pDC->SetTextColor(prevText);
	delete[] validity;
}

LPCTSTR CFilteringListCtrl::MakeShortString(CDC* pDC, LPCTSTR lpszLong, int nColumnLen, int nOffset)
{
	static const _TCHAR szThreeDots[] = _T("...");

	int nStringLen = lstrlen(lpszLong);

	if(nStringLen == 0 || (pDC->GetTextExtent(lpszLong, nStringLen).cx + nOffset) <= nColumnLen)
		return(lpszLong);

	static _TCHAR szShort[MAX_PATH];

	_tcsncpy(szShort, lpszLong, MAX_PATH);
	int nAddLen = pDC->GetTextExtent(szThreeDots, sizeof(szThreeDots)).cx;

	for(int i = nStringLen-1; i > 0; i--)
	{
		szShort[i] = 0;
		if((pDC->GetTextExtent(szShort, i).cx + nOffset + nAddLen) <= nColumnLen)
		{
			break;
		}
	}

	_tcscat(szShort, szThreeDots);
	return szShort;
}

void CFilteringListCtrl::OnClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLISTVIEW* nmhdr = (NMLISTVIEW*)pNMHDR;

	if(nmhdr->iItem < 0)
	{
		*pResult = 0;
		return;
	}

	last_selected_item = nmhdr->iItem;

	if(HIBYTE(GetKeyState(VK_SHIFT)))
	{
		first_in_a_row = first_in_a_row == -1 ? last_selected_item : first_in_a_row;
		SetSelectionMark(first_in_a_row);
	}
	else
		first_in_a_row = -1;

	if(CheckItemAgainstAllFilters(nmhdr->iItem))
	{
		SetItemState(nmhdr->iItem, LVIS_SELECTED, LVIS_SELECTED);
		SetItemState(nmhdr->iItem, LVIS_FOCUSED, LVIS_FOCUSED);
	}

	if(first_in_a_row != -1)
	{
		for(int i = 0; i < GetItemCount(); i++)
		{
			if(first_in_a_row < last_selected_item)
				SetItemState(i, (CheckItemAgainstAllFilters(i) && (i <= last_selected_item && i >= first_in_a_row) ? LVIS_SELECTED : 0), LVIS_SELECTED);
			else
				SetItemState(i, (CheckItemAgainstAllFilters(i) && (i >= last_selected_item && i <= first_in_a_row) ? LVIS_SELECTED : 0), LVIS_SELECTED);
		}
	}

	*pResult = 1;
}

void CFilteringListCtrl::OnRclick(NMHDR* pNMHDR, LRESULT* pResult)
{
	OnClick(pNMHDR, pResult);
}

void CFilteringListCtrl::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnClick(pNMHDR, pResult);
}

void CFilteringListCtrl::OnRdblclk(NMHDR* pNMHDR, LRESULT* pResult)
{
	OnClick(pNMHDR, pResult);
}

void CFilteringListCtrl::OnKeydown(NMHDR* pNMHDR, LRESULT* pResult)
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;

	int nItem = last_selected_item, nNextItem = last_selected_item, i = 1;

	if(HIBYTE(GetKeyState(VK_SHIFT)))
	{
		if(first_in_a_row == -1)
		{
			first_in_a_row = last_selected_item;
			SetSelectionMark(first_in_a_row);
		}
	}
	else
		first_in_a_row = -1;

	switch(pLVKeyDow->wVKey)
	{
		case VK_UP:
			if(nItem > 0)
			{
				for(; i <= nItem; i++)
				{
					if(CheckItemAgainstAllFilters(nItem - i))
					{
						nNextItem = nItem - i;
						break;
					}
				}

				for(i = 0; i < GetItemCount(); i++)
				{
					if(first_in_a_row == -1)
						SetItemState(i, (i == nNextItem ? LVIS_SELECTED : 0), LVIS_SELECTED);
					else
					{
						if(first_in_a_row < nNextItem)
							SetItemState(i, (i <= nNextItem && i >= first_in_a_row ? LVIS_SELECTED : 0), LVIS_SELECTED);
						else
							SetItemState(i, (i >= nNextItem && i <= first_in_a_row ? LVIS_SELECTED : 0), LVIS_SELECTED);
					}
				}
			}
			break;

		case VK_DOWN:
			if(nItem < (GetItemCount() - 1))
			{
				for(; i < (GetItemCount() - nItem); i++)
				{
					if(CheckItemAgainstAllFilters(nItem + i))
					{
						nNextItem = nItem + i;
						break;
					}
				}

				for(i = 0; i < GetItemCount(); i++)
				{
					if(first_in_a_row == -1)
						SetItemState(i, (i == nNextItem ? LVIS_SELECTED : 0), LVIS_SELECTED);
					else
					{
						if(first_in_a_row < nNextItem)
							SetItemState(i, (i <= nNextItem && i >= first_in_a_row ? LVIS_SELECTED : 0), LVIS_SELECTED);
						else
							SetItemState(i, (i >= nNextItem && i <= first_in_a_row ? LVIS_SELECTED : 0), LVIS_SELECTED);
					}
				}
			}
			break;

		default:
			break;
	}

	last_selected_item = nNextItem;
	SetItemState(last_selected_item, LVIS_FOCUSED, LVIS_FOCUSED);

	for(i = 0; i < GetItemCount(); i++)
	{
		if(!CheckItemAgainstAllFilters(i))
		{
			SetItemState(i, 0, LVIS_SELECTED);
			SetItemState(i, 0, LVIS_FOCUSED);
		}
	}

	*pResult = 1;
}