// ListCtrlFilterDoc.h : interface of the CListCtrlFilterDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTCTRLFILTERDOC_H__E48D4BE4_5BEB_4E2D_BB55_BD8570E59C2E__INCLUDED_)
#define AFX_LISTCTRLFILTERDOC_H__E48D4BE4_5BEB_4E2D_BB55_BD8570E59C2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CListCtrlFilterDoc : public CDocument
{
protected: // create from serialization only
	CListCtrlFilterDoc();
	DECLARE_DYNCREATE(CListCtrlFilterDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListCtrlFilterDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CListCtrlFilterDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CListCtrlFilterDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCTRLFILTERDOC_H__E48D4BE4_5BEB_4E2D_BB55_BD8570E59C2E__INCLUDED_)
