#if !defined(AFX_FILTERDIALOG_H__A9BD0A77_9A36_41C3_B4A0_D57E1F3C65F0__INCLUDED_)
#define AFX_FILTERDIALOG_H__A9BD0A77_9A36_41C3_B4A0_D57E1F3C65F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilterDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFilterDialog dialog

class CFilterDialog : public CDialog
{
// Construction
public:
	CFilterDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFilterDialog)
	enum { IDD = IDD_FILTER_DIALOG };
	CString	m_From;
	CString	m_To;
	int		m_Interior;
	//}}AFX_DATA

	void SetTitle(CString newtitle);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CString title;

	// Generated message map functions
	//{{AFX_MSG(CFilterDialog)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERDIALOG_H__A9BD0A77_9A36_41C3_B4A0_D57E1F3C65F0__INCLUDED_)
