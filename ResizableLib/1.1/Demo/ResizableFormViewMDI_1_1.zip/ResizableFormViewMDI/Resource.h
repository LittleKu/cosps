//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DEMO_FORM                   101
#define IDR_MAINFRAME                   128
#define IDR_DEMOTYPE                    129
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_COMBO1                      1005
#define IDC_RADIO1                      1008
#define IDC_RADIO2                      1009
#define IDC_STATIC1                     1010
#define IDC_GROUP1                      1011
#define IDC_ICON1                       1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
