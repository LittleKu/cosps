//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_DEMO_DIALOG                 102
#define IDS_PROPSHT_CAPTION             103
#define IDD_PROPPAGE1                   104
#define IDD_PROPPAGE2                   105
#define IDD_PROPPAGE3                   106
#define IDS_PROPSHT_CAPTION1            107
#define IDD_PROPPAGE11                  108
#define IDD_PROPPAGE21                  109
#define IDD_PROPPAGE31                  110
#define IDR_MAINFRAME                   128
#define IDD_MAINDIALOG                  129
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     132
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_COMBO1                      1002
#define IDC_CHECK1                      1003
#define IDC_BUTTON3                     1003
#define IDC_RADIO1                      1004
#define IDC_LIST1                       1006
#define IDC_GROUP1                      1007
#define IDC_PICTURE1                    1008
#define IDC_SLIDER1                     1010
#define IDC_LABEL1                      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
