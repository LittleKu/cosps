//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Wizard97.rc
//
#define IDS_SAMPLEWIZARD                1
#define IDS_HEADERTITLE                 2
#define IDS_HEADERSUBTITLE              3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WIZARD97_DIALOG             102
#define IDB_BANNER256                   103
#define IDB_BANNER16                    104
#define IDB_WATERMARK16                 105
#define IDB_WATERMARK256                106
#define IDC_BIGBOLDTITLE                107
#define IDC_BOLDTITLE                   108
#define IDC_TRANSPARENT1                109
#define IDC_TRANSPARENT2                110
#define IDC_TRANSPARENT3                111
#define IDC_LIST1                       112
#define IDC_BUTTON1                     113
#define IDC_RADIO1                      114
#define IDC_RADIO2                      115
#define IDD_INTRO_NEW                   116
#define IDD_INTERIOR1_NEW               117
#define IDD_INTERIOR2_NEW               118
#define IDD_COMPLETION_NEW              119
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_STATIC1                     1000
#define IDC_STATIC2                     1001
#define IDC_GROUP1                      1002
#define IDC_STATIC_TITLE                1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
