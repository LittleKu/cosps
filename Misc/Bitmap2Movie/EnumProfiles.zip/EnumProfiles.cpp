// EnumProfiles.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <wmsdk.h>
#include <wmsysprf.h>

#define WMFORMAT_SDK_VERSION WMT_VER_8_0

void EnumProfiles();

int _tmain(int argc, _TCHAR* argv[])
{
	char ch;
	CoInitialize(NULL);
	printf("\n\n\t\tAvailable profiles in this machine are:\n");
	EnumProfiles();
	printf("\n\n\t\tPress Any Character To Terminate\n");
	scanf("%c",&ch);
	CoUninitialize();
	return 0;
}

void EnumProfiles()
{
	DWORD	dwLen=0;
	WCHAR	szProfileName[1024];
	DWORD	dwProfileCount=0;
	IWMProfile			*pProfile=NULL;
	IWMProfileManager	*pProfileManager=NULL;
	IWMProfileManager2	*pProfileManager2=NULL;
	if(FAILED(WMCreateProfileManager(&pProfileManager)))
	{
		MessageBox(NULL,"Unable to Create WindowsMedia Profile Manager","Error",MB_OK|MB_ICONERROR);
		goto TerminateEnumeration;
	}
	if(FAILED(pProfileManager->QueryInterface(IID_IWMProfileManager2,(void**)&pProfileManager2)))
	{
		MessageBox(NULL,"Unable to Query Interface ","Error",MB_OK|MB_ICONERROR);
		goto TerminateEnumeration;
	}
	if(FAILED(pProfileManager2->SetSystemProfileVersion(WMT_VER_8_0)))
	{
		MessageBox(NULL,"Unable to Set System Profile Version","Error",MB_OK|MB_ICONERROR);
		goto TerminateEnumeration;
	}
	pProfileManager2->Release();
	if(FAILED(pProfileManager->GetSystemProfileCount(&dwProfileCount)))
	{
		MessageBox(NULL,"Unable to Get System Profile Count","Error",MB_OK|MB_ICONERROR);
		goto TerminateEnumeration;
	}
	for(DWORD dwProfileIndex=0;dwProfileIndex<dwProfileCount;dwProfileIndex++)
	{
		if(FAILED(pProfileManager->LoadSystemProfile(dwProfileIndex,&pProfile)))
		{
			//MessageBox(NULL,"Unable to Load System Profile","Error",MB_OK|MB_ICONERROR);
			continue;//goto TerminateEnumeration;
		}
		dwLen=1024;
        if(!FAILED(pProfile->GetName(szProfileName,&dwLen)))
		{
			char msg[1024];
			WideCharToMultiByte(CP_ACP,0,szProfileName,-1,msg,1024,0,false);
			printf("\n%s",msg);
			//MessageBox(NULL,msg,"Profile",MB_OK);
		}		
		
		pProfile->Release();
		pProfile=NULL;
	}
TerminateEnumeration:
	if(pProfileManager)
	{
		pProfileManager->Release();
		pProfileManager=NULL;
	}
	return ;
}
