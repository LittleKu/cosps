#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <stdio.h>
#include "afxres.h"
#include "resource.h"
#include <list>

// Example how to arrange the MDI windows in most recently used order.

#define AFX_IDM_LAST_MDICHILD (AFX_IDM_FIRST_MDICHILD+9)

HINSTANCE g_hInstance;
HWND g_hwndMain, g_hwndMDIClient;

WNDPROC g_OldClientProc;

std::list<HWND> g_MDIChildren; // MDI children list in MRU order
HWND g_MDITopChild; // last activated child

// Message handler for the MDI child
LRESULT CALLBACK MDIChildProc( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_CREATE) {
		// add to the front of the list
		g_MDIChildren.push_front(hwnd);
	}

	if (uMsg==WM_DESTROY) {
		// remove from the list
		for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end();++it)
			if (*it==hwnd) {
				g_MDIChildren.erase(it);
				break;
			}
	}

	if (uMsg==WM_MDIACTIVATE && (HWND)lParam==hwnd && GetKeyState(VK_CONTROL)>=0) {
		// put the child at the start of the list
		for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end();++it)
			if (*it==hwnd) {
				g_MDIChildren.erase(it);
				g_MDIChildren.push_front(hwnd);
				break;
			}
	}

	return DefMDIChildProc(hwnd,uMsg,wParam,lParam);
}

// Message handler for the MDI client
LRESULT CALLBACK MDIClientProc( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_MDINEXT && GetKeyState(VK_CONTROL)<0) {
		// the current window
		HWND child=(HWND)SendMessage(hwnd,WM_MDIGETACTIVE,0,0);

		// find the next window
		HWND next=NULL;

		if (lParam) { // backward
			for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end();++it)
				if (*it==child) {
					if (it==g_MDIChildren.begin())
						next=*g_MDIChildren.rbegin();
					else
						next=*(--it);
					break;
				}
		}
		else { // forward
			for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end();++it)
				if (*it==child) {
					++it;
					if (it==g_MDIChildren.end())
						next=*g_MDIChildren.begin();
					else
						next=*it;
					break;
				}
		}

		if (next) {
			SendMessage(hwnd,WM_MDIACTIVATE,(WPARAM)next,0);
			g_MDITopChild=next;
			return 0;
		}
	}
	return CallWindowProc(g_OldClientProc,hwnd,uMsg,wParam,lParam);
}

// Message handler for the MDI frame
LRESULT CALLBACK MDIFrameProc( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_COMMAND) {
		int command=LOWORD(wParam);
		if (command==ID_FILE_NEW) {
			// create new child window
			TCHAR title[256];
			static int s_Index=1;
			_stprintf(title,_T("Child: %d"),s_Index);
			s_Index++;
			CreateMDIWindow(_T("MDIChild"),title,0,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,g_hwndMDIClient,g_hInstance,0);
			return TRUE;
		}

		if (command==ID_APP_EXIT) {
			// exit
			SendMessage(hwnd,WM_CLOSE,0,0);
			return TRUE;
		}

		if (command==ID_WINDOW_CASCADE) {
			// arrange child windows
			SendMessage(g_hwndMDIClient,WM_MDICASCADE,0,0);
			return TRUE;
		}

		if (command>=AFX_IDM_FIRST_MDICHILD && command<=AFX_IDM_LAST_MDICHILD) {
			// a window was selected from the Window menu
			int idx=AFX_IDM_FIRST_MDICHILD;
			for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end() && idx<=AFX_IDM_LAST_MDICHILD;++it,idx++)
				if (idx==command) {
					SendMessage(g_hwndMDIClient,WM_MDIACTIVATE,(WPARAM)*it,0);
					break;
				}
			return TRUE;
		}
	}

	if (uMsg==WM_INITMENUPOPUP && (HMENU)wParam==GetSubMenu(GetMenu(hwnd),1)) {
		// update the Window menu
		HMENU menu=(HMENU)wParam;

		// delete old items
		for (int i=AFX_IDM_FIRST_MDICHILD;i<=AFX_IDM_LAST_MDICHILD;i++)
			DeleteMenu(menu,i,MF_BYCOMMAND);

		// add children in their current order
		int idx=AFX_IDM_FIRST_MDICHILD;
		for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end() && idx<=AFX_IDM_LAST_MDICHILD;++it,idx++) {
			TCHAR title[256];
			GetWindowText(*it,title,256);
			title[255]=0;
			AppendMenu(menu,MF_STRING,idx,title);
		}
		return 0;
	}

	if (uMsg==WM_CREATE) {
		// create and subclass the MDI client window
		CLIENTCREATESTRUCT ccs={NULL,0};
		g_hwndMDIClient=CreateWindow(_T("MDICLIENT"),NULL,WS_CHILD|WS_CLIPCHILDREN|WS_VSCROLL|WS_HSCROLL|WS_VISIBLE,0,0,0,0,hwnd,(HMENU)1,g_hInstance,(LPSTR)&ccs);
		g_OldClientProc=(WNDPROC)SetWindowLongPtr(g_hwndMDIClient,GWLP_WNDPROC,(LONG_PTR)MDIClientProc);
	}

	if (uMsg==WM_DESTROY)
		PostQuitMessage(0);

	return DefFrameProc(hwnd,g_hwndMDIClient,uMsg,wParam,lParam);
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	g_hInstance=hInstance;

	// register frame class
	WNDCLASS wc;
	memset(&wc,0,sizeof(wc));
	wc.style=CS_VREDRAW|CS_HREDRAW;
	wc.lpfnWndProc=MDIFrameProc;
	wc.hInstance=hInstance;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hbrBackground=(HBRUSH)GetStockObject(NULL_BRUSH);
	wc.lpszClassName=_T("MDITest");
	RegisterClass(&wc);

	// register child class
	wc.lpfnWndProc=MDIChildProc;
	wc.lpszClassName=_T("MDIChild");
	wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	RegisterClass(&wc);

	// create main window
	HMENU menu=LoadMenu(hInstance,MAKEINTRESOURCE(IDR_MENU1));
	g_hwndMain=CreateWindowEx(WS_EX_APPWINDOW,_T("MDITest"),_T("MDITest"),WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN|WS_VISIBLE,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,NULL,menu,hInstance,NULL);

	// process messages
	MSG msg;
	while (GetMessage(&msg,0,0,0)) {

		if (msg.message==WM_KEYUP && msg.wParam==VK_CONTROL && g_MDITopChild) {
			// put the child at the start of the list
			for (std::list<HWND>::iterator it=g_MDIChildren.begin();it!=g_MDIChildren.end();++it)
				if (*it==g_MDITopChild) {
					g_MDIChildren.erase(it);
					g_MDIChildren.push_front(g_MDITopChild);
					break;
				}
			g_MDITopChild=NULL;
		}

		if (!TranslateMDISysAccel(g_hwndMDIClient, &msg)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return 0;
}
