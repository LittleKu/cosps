#include <windows.h>
#include <commctrl.h>
#include "resource.h"

// Shows how to resize a multi-line static control and how to reduce the flicker of a group box

static RECT g_rcDialog, g_rcStatic1, g_rcStatic2, g_rcStatic3, g_rcStatic4, g_rcGroup1, g_rcGroup2, g_rcCancel;

static int TOP_BORDER;
static int SIDE_BORDER;
static int BOTTOM_BORDER;

static WNDPROC g_GroupProc;

// Overrides the WM_PAINT and WM_ERASEBKGND for a group box to reduce flicker
static LRESULT CALLBACK GroupBoxProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_PAINT) {
		// draw the background of the border, clipping with the current update region
		RECT rc;
		GetClientRect(hWnd,&rc);
		HDC hdc=GetWindowDC(hWnd);
		HRGN rgn=CreateRectRgn(0,0,0,0);
		GetUpdateRgn(hWnd,rgn,FALSE);
		SelectClipRgn(hdc,rgn);
		DeleteObject(rgn);
		SelectObject(hdc,GetStockObject(NULL_PEN));
		SelectObject(hdc,GetSysColorBrush(COLOR_BTNFACE));
		Rectangle(hdc,rc.left,rc.top,rc.right+1,rc.top+TOP_BORDER+1);
		Rectangle(hdc,rc.left,rc.top+TOP_BORDER,rc.left+SIDE_BORDER+1,rc.bottom-BOTTOM_BORDER+1);
		Rectangle(hdc,rc.right-SIDE_BORDER,rc.top+TOP_BORDER,rc.right+1,rc.bottom-BOTTOM_BORDER+1);
		Rectangle(hdc,rc.left,rc.bottom-BOTTOM_BORDER,rc.right+1,rc.bottom+1);
		ReleaseDC(hWnd,hdc);
	}
	if (uMsg==WM_ERASEBKGND) {
		// draw the background of the inside
		RECT rc;
		GetClientRect(hWnd,&rc);
		rc.top+=TOP_BORDER;
		rc.left+=SIDE_BORDER;
		rc.right-=SIDE_BORDER;
		rc.bottom-=BOTTOM_BORDER;
		FillRect((HDC)wParam,&rc,GetSysColorBrush(COLOR_BTNFACE));
		return TRUE;
	}
	return CallWindowProc(g_GroupProc,hWnd,uMsg,wParam,lParam);
}

static INT_PTR CALLBACK DialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		// get the initial rectangles for all controls
		GetWindowRect(hwndDlg,&g_rcDialog);
		HWND group1=GetDlgItem(hwndDlg,IDC_GROUP1);
		HWND group2=GetDlgItem(hwndDlg,IDC_GROUP2);
		GetWindowRect(group1,&g_rcGroup1);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcGroup1,2);
		GetWindowRect(group2,&g_rcGroup2);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcGroup2,2);
		GetWindowRect(GetDlgItem(hwndDlg,IDC_STATIC1),&g_rcStatic1);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcStatic1,2);
		GetWindowRect(GetDlgItem(hwndDlg,IDC_STATIC2),&g_rcStatic2);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcStatic2,2);
		GetWindowRect(GetDlgItem(hwndDlg,IDC_STATIC3),&g_rcStatic3);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcStatic3,2);
		GetWindowRect(GetDlgItem(hwndDlg,IDC_STATIC4),&g_rcStatic4);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcStatic4,2);
		GetWindowRect(GetDlgItem(hwndDlg,IDCANCEL),&g_rcCancel);
		MapWindowPoints(NULL,hwndDlg,(POINT*)&g_rcCancel,2);

		RECT rc={5,10,5,5};
		MapDialogRect(hwndDlg,&rc);
		TOP_BORDER=rc.top;
		BOTTOM_BORDER=rc.bottom;
		SIDE_BORDER=rc.left;

		// fix the styles
		SetWindowLong(group2,GWL_STYLE,GetWindowLong(group2,GWL_STYLE)|WS_CLIPSIBLINGS);
		SetWindowLong(group2,GWL_EXSTYLE,GetWindowLong(group2,GWL_EXSTYLE)&~WS_EX_TRANSPARENT);

		// move to the bottom
		SetWindowPos(group2,HWND_BOTTOM,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

		// subclass
		g_GroupProc=(WNDPROC)SetWindowLongPtr(group2,GWLP_WNDPROC,(LONG_PTR)GroupBoxProc);

		return TRUE;
	}

	if (uMsg==WM_GETMINMAXINFO) {
		// limit the minimum size of the dialog to the initial size
		MINMAXINFO *info=(MINMAXINFO*)lParam;
		info->ptMinTrackSize.x=g_rcDialog.right-g_rcDialog.left;
		info->ptMinTrackSize.y=g_rcDialog.bottom-g_rcDialog.top;
		return TRUE;
	}

	if (uMsg==WM_SIZE) {
		// resize and move the controls when the dialog is resized
		RECT rc;
		GetWindowRect(hwndDlg,&rc);
		int dx=(rc.right-rc.left)-(g_rcDialog.right-g_rcDialog.left);
		int dy=(rc.bottom-rc.top)-(g_rcDialog.bottom-g_rcDialog.top);

		SetWindowPos(GetDlgItem(hwndDlg,IDC_STATIC1),NULL,g_rcStatic1.left,g_rcStatic1.top,
			g_rcStatic1.right-g_rcStatic1.left+dx/2,g_rcStatic1.bottom-g_rcStatic1.top,SWP_NOZORDER);

		SetWindowPos(GetDlgItem(hwndDlg,IDC_STATIC2),NULL,g_rcStatic2.left+dx/2,g_rcStatic2.top,
			(g_rcStatic2.right+dx)-(g_rcStatic2.left+dx/2),g_rcStatic2.bottom-g_rcStatic2.top,SWP_NOZORDER);

		SetWindowPos(GetDlgItem(hwndDlg,IDC_GROUP1),NULL,g_rcGroup1.left,g_rcGroup1.top+dy,
			g_rcGroup1.right-g_rcGroup1.left+dx/2,g_rcGroup1.bottom-g_rcGroup1.top,SWP_NOZORDER);

		SetWindowPos(GetDlgItem(hwndDlg,IDC_GROUP2),NULL,g_rcGroup2.left+dx/2,g_rcGroup2.top+dy,
			(g_rcGroup2.right+dx)-(g_rcGroup2.left+dx/2),g_rcGroup2.bottom-g_rcGroup2.top,SWP_NOZORDER);

		SetWindowPos(GetDlgItem(hwndDlg,IDCANCEL),NULL,g_rcCancel.left+dx,g_rcCancel.top+dy,0,0,SWP_NOSIZE|SWP_NOZORDER);

		// resize the left control without SWP_NOCOPYBITS
		SetWindowPos(GetDlgItem(hwndDlg,IDC_STATIC3),NULL,0,0,
			g_rcStatic3.right-g_rcStatic3.left+dx/2,g_rcStatic3.bottom-g_rcStatic3.top+dy,SWP_NOMOVE|SWP_NOZORDER);
		// resize the right control with SWP_NOCOPYBITS
		SetWindowPos(GetDlgItem(hwndDlg,IDC_STATIC4),NULL,g_rcStatic4.left+dx/2,g_rcStatic4.top,
			(g_rcStatic4.right+dx)-(g_rcStatic4.left+dx/2),g_rcStatic4.bottom-g_rcStatic4.top+dy,SWP_NOZORDER|SWP_NOCOPYBITS);
		return FALSE;
	}

	if (uMsg==WM_COMMAND && wParam==IDCANCEL) {
		// close the dialog
		EndDialog(hwndDlg,0);
		return TRUE;
	}

	return FALSE;
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	InitCommonControls();
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DialogProc);
	return 0;
}
