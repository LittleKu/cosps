#include <windows.h>
#include <tchar.h>
#include <assert.h>
#include "StringSet.h"

static const TCHAR *CreateString( const WORD *data )
{
	int len=*data;
	data++;
	if (len==0) return NULL;

#ifdef _UNICODE
	wchar_t *str=(wchar_t*)malloc(2*len+2);
	if (str) {
		memcpy(str,data,len*2);
		str[len]=0;
	}
#else
	int len2=WideCharToMultiByte(CP_ACP,0,(const wchar_t *)data,len,NULL,0,NULL,NULL);
	char *str=(char*)malloc(len2+1);
	if (str) {
		WideCharToMultiByte(CP_ACP,0,(const wchar_t *)data,len,str,len2,NULL,NULL);
		str[len2]=0;
	}
#endif
	return str;
}

BOOL CALLBACK CStringSet::EnumResNameProc( HMODULE hModule, LPCTSTR lpszType, LPTSTR lpszName, LONG_PTR lParam )
{
	CStringSet *set=(CStringSet*)lParam;
	// find resource
	HRSRC hr=FindResourceEx(hModule,RT_STRING,lpszName,set->m_Language);
	if (!hr) {
		// fall back to the default language
		hr=FindResource(hModule,lpszName,RT_STRING);
	}
	if (!hr) return TRUE;

	HGLOBAL hg=LoadResource(hModule,hr);
	if (hg) {
		const WORD *res=(WORD*)LockResource(hg);
		if (res) {
			for (int i=0;i<16;i++) {
				UINT id=(((int)lpszName)<<4)+i-16;
				assert(set->find(id)==((baseClass*)set)->end()); // the string already exists

				const TCHAR *str=CreateString(res);
				if (str)
					set->insert(std::pair<UINT,const TCHAR *>(id,str));
				res+=(*res)+1;
			}
			UnlockResource(hg);
		}
	}
	return TRUE;
}

// Initializes the string database
void CStringSet::Init( HINSTANCE hInstance, WORD wLanguage, bool bLoadAll )
{
	m_hInstance=hInstance;
	m_Language=wLanguage;
	m_bLoadAll=bLoadAll;
	clear();
	if (bLoadAll)
		EnumResourceNames(hInstance,RT_STRING,EnumResNameProc,(LONG_PTR)this);
}

// Returns a string by ID (returns "" if the string is missing)
const TCHAR *CStringSet::GetString( UINT uID )
{
	const TCHAR *blank=_T("");

	// search in the database
	const_iterator it=find(uID);

	if (it!=end()) {
		if (it->second)
			return it->second;
		return blank;
	}

	if (m_bLoadAll)
		return blank;

	// load the string
	LPCTSTR lpszName=MAKEINTRESOURCE((uID>>4)+1);
	HRSRC hr=FindResourceEx(m_hInstance,RT_STRING,lpszName,m_Language);
	if (!hr) {
		// fall back to the default language
		hr=FindResource(m_hInstance,lpszName,RT_STRING);
	}
	if (hr) {
		HGLOBAL hg=LoadResource(m_hInstance,hr);
		if (hg) {
			const WORD *res=(WORD*)LockResource(hg);
			if (res) {
				int n=uID&15;
				// skip the first n strings
				for (int i=0;i<n;i++)
					res+=(*res)+1;

				const TCHAR *str=CreateString(res);
				if (str)
					it=insert(std::pair<UINT,const TCHAR *>(uID,str)).first;

				UnlockResource(hg);
			}
		}
	}

	if (it!=end()) return it->second;

	// if the string is not found add NULL in the database (so we don't try to load it next time)
	insert(std::pair<UINT,const TCHAR *>(uID,NULL));
	return blank;
}

void CStringSet::clear( void )
{
	for (iterator it=baseClass::begin();it!=baseClass::end();++it)
		if (it->second)
			free((void*)it->second);
	baseClass::clear();
}
