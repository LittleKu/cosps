#ifndef _RESOURCEEX_H
#define _RESOURCEEX_H

// Functions to load resources for a specific language
// If wLanguage is 0xFFFF then the app language is used. Call SetAppLanguage before any resources
// are used. If SetAppLanguage is not called, the default UI language is used.
//
///////////////////////////////////////////////////////////////////////////////

// Sets the global app language. Call before any resources are used
void SetAppLanguage( WORD wLanguage );

// Returns the global app language
WORD GetAppLanguage( void );

// Loads accelerator resource
HACCEL LoadAcceleratorsEx( HINSTANCE hInstance, LPCTSTR lpTableName, WORD wLanguage=0xFFFF );
HACCEL LoadAcceleratorsEx( HINSTANCE hInstance, UINT uTableID, WORD wLanguage=0xFFFF );

// Loads a string resource
int LoadStringEx( HINSTANCE hInstance, UINT uID, LPTSTR lpBuffer, int nBufferMax, WORD wLanguage=0xFFFF );

// Loads a menu resource
HMENU LoadMenuEx( HINSTANCE hInstance, LPCTSTR lpMenuName, WORD wLanguage=0xFFFF );
HMENU LoadMenuEx( HINSTANCE hInstance, UINT uMenuID, WORD wLanguage=0xFFFF );

// Dialog box creation
INT_PTR DialogBoxParamEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage=0xFFFF );
HWND CreateDialogParamEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage=0xFFFF );
INT_PTR DialogBoxEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage=0xFFFF );
HWND CreateDialogEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage=0xFFFF );

INT_PTR DialogBoxParamEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage=0xFFFF );
HWND CreateDialogParamEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage=0xFFFF );
INT_PTR DialogBoxEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage=0xFFFF );
HWND CreateDialogEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage=0xFFFF );

#endif
