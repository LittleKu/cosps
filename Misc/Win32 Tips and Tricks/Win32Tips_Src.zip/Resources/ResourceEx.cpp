#include <windows.h>
#include <tchar.h>
#include <assert.h>
#include "ResourceEx.h"

static WORD g_AppLanguage=GetUserDefaultLangID();

void SetAppLanguage( WORD wLanguage )
{
	g_AppLanguage=wLanguage;
}

WORD GetAppLanguage( void )
{
	return g_AppLanguage;
}

// Loads a resource for the specified language
static LPVOID LoadResourceEx( HINSTANCE hInstance, LPCTSTR lpType, LPCTSTR lpName, WORD wLanguage=0xFFFF, HRSRC *phrsrc=NULL )
{
	// default to the app language
	if (wLanguage==0xFFFF) wLanguage=g_AppLanguage;

	// first try wLanguage
	HRSRC hrsrc=FindResourceEx(hInstance,lpType,lpName,wLanguage);

	// try the default UI language
	WORD ui=GetUserDefaultLangID();
	if (!hrsrc && wLanguage!=ui) hrsrc=FindResourceEx(hInstance,lpType,lpName,ui);

	// fall back to default behavior
	if (!hrsrc) hrsrc=FindResource(hInstance,lpName,lpType);
	assert(hrsrc);
	if (!hrsrc) return NULL;

	// load the resource
	if (phrsrc) *phrsrc=hrsrc;
	HGLOBAL hglb=LoadResource(hInstance,hrsrc);
	assert(hglb);
	if (!hglb) return NULL;

	// finally lock the resource
	LPVOID res=LockResource(hglb);
	assert(res);
	return res;
}


// Loads accelerator resource
HACCEL LoadAcceleratorsEx( HINSTANCE hInstance, LPCTSTR lpTableName, WORD wLanguage )
{
	HRSRC hrsrc;
	LPVOID lpsz=LoadResourceEx(hInstance,RT_ACCELERATOR,lpTableName,wLanguage,&hrsrc);
	if (!lpsz) return NULL;

	struct ACCELTABLEENTRY { 
		WORD fFlags; 
		WORD wAnsi; 
		WORD wId; 
		WORD padding; 
	};

	ACCELTABLEENTRY *src=(ACCELTABLEENTRY *)lpsz;
	int n=SizeofResource(hInstance,hrsrc)/sizeof(ACCELTABLEENTRY);
	ACCEL *dst=(ACCEL*)malloc(n*sizeof(ACCEL));
	if (!dst) {
		SetLastError(ERROR_NOT_ENOUGH_MEMORY);
		return NULL;
	}
	for (int i=0;i<n;i++) {
		dst[i].fVirt=src[i].fFlags&(FALT|FCONTROL|FNOINVERT|FSHIFT|FVIRTKEY);
		dst[i].key=src[i].wAnsi;
		dst[i].cmd=src[i].wId;
	}
	HACCEL hacc=CreateAcceleratorTable(dst,n);
	free(dst);
	return hacc;
}

HACCEL LoadAcceleratorsEx( HINSTANCE hInstance, UINT uTableID, WORD wLanguage )
{
	return LoadAcceleratorsEx(hInstance,MAKEINTRESOURCE(uTableID),wLanguage);
}


// Loads a string resource
int LoadStringEx( HINSTANCE hInstance, UINT uID, LPTSTR lpBuffer, int nBufferMax, WORD wLanguage )
{
	uID+=16;
	if (uID&~0xFFFFF) {
		SetLastError(ERROR_RESOURCE_NAME_NOT_FOUND);
		return 0;
	}
	WORD *data=(WORD*)LoadResourceEx(hInstance,RT_STRING,MAKEINTRESOURCE(uID>>4),wLanguage);
	if (!data) return 0;
	int n=uID&15;
	for (int i=0;i<n;i++)
		data+=*data+1;
	int len=*data;
	if (len==0) return 0;
	data++;

#ifdef _UNICODE
	if (len>nBufferMax-1) len=nBufferMax-1;
	memcpy(lpBuffer,data,len*2);
	lpBuffer[len]=0;
	return len;
#else
	int len2=WideCharToMultiByte(CP_ACP,0,(wchar_t*)data,len,NULL,NULL,0,NULL);
	if (len2>nBufferMax-1) len2=nBufferMax-1;
	WideCharToMultiByte(CP_ACP,0,(wchar_t*)data,len,lpBuffer,len2,0,NULL);
	lpBuffer[len2]=0;
	return len2;
#endif
}


// Loads a menu resource
HMENU LoadMenuEx( HINSTANCE hInstance, LPCTSTR lpMenuName, WORD wLanguage )
{
	LPVOID lpsz=LoadResourceEx(hInstance,RT_MENU,lpMenuName,wLanguage);
	if (!lpsz) return NULL;
	return LoadMenuIndirect(lpsz);
}

HMENU LoadMenuEx( HINSTANCE hInstance, UINT uMenuID, WORD wLanguage)
{
	return LoadMenuEx(hInstance,MAKEINTRESOURCE(uMenuID),wLanguage);
}


// Dialog box creation
INT_PTR DialogBoxParamEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage )
{
	DLGTEMPLATE *dlg=(DLGTEMPLATE*)LoadResourceEx(hInstance,RT_DIALOG,lpTemplateName,wLanguage);
	if (!dlg) return -1;
	return DialogBoxIndirectParam(hInstance,dlg,hWndParent,lpDialogFunc,dwInitParam);
}

HWND CreateDialogParamEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage )
{
	DLGTEMPLATE *dlg=(DLGTEMPLATE*)LoadResourceEx(hInstance,RT_DIALOG,lpTemplateName,wLanguage);
	if (!dlg) return NULL;
	return CreateDialogIndirectParam(hInstance,dlg,hWndParent,lpDialogFunc,dwInitParam);
}

INT_PTR DialogBoxEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage )
{
	return DialogBoxParamEx(hInstance,lpTemplateName,hWndParent,lpDialogFunc,0,wLanguage);
}

HWND CreateDialogEx( HINSTANCE hInstance, LPCTSTR lpTemplateName, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage )
{
	return CreateDialogParamEx(hInstance,lpTemplateName,hWndParent,lpDialogFunc,0,wLanguage);
}

INT_PTR DialogBoxParamEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage )
{
	return DialogBoxParamEx(hInstance,MAKEINTRESOURCE(uTemplateID),hWndParent,lpDialogFunc,dwInitParam,wLanguage);
}

HWND CreateDialogParamEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, LPARAM dwInitParam, WORD wLanguage )
{
	return CreateDialogParamEx(hInstance,MAKEINTRESOURCE(uTemplateID),hWndParent,lpDialogFunc,dwInitParam,wLanguage);
}

INT_PTR DialogBoxEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage )
{
	return DialogBoxParamEx(hInstance,MAKEINTRESOURCE(uTemplateID),hWndParent,lpDialogFunc,0,wLanguage);
}

HWND CreateDialogEx( HINSTANCE hInstance, UINT uTemplateID, HWND hWndParent, DLGPROC lpDialogFunc, WORD wLanguage )
{
	return CreateDialogParamEx(hInstance,MAKEINTRESOURCE(uTemplateID),hWndParent,lpDialogFunc,0,wLanguage);
}
