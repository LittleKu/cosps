#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include "ResourceEx.h"
#include "StringSet.h"
#include "resource.h"

// Sample program to demonstrate the use of ResourceEx and StringSet


static HINSTANCE g_hInstance; // the module handle

static CStringSet g_MainStringSet; // the string database

static WORD g_Languages[4]={
	MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),
	MAKELANGID(LANG_FRENCH,SUBLANG_FRENCH),
	MAKELANGID(LANG_GERMAN,SUBLANG_GERMAN),
	MAKELANGID(LANG_JAPANESE,SUBLANG_DEFAULT), // No Japanese resources - will default to English
};

static void UpdateLanguage( HWND hwndDlg, WORD wLanguage )
{
	// sets the application language and refreshes the string list box
	SetAppLanguage(wLanguage);
	g_MainStringSet.Init(g_hInstance,wLanguage,true);

	HWND list=GetDlgItem(hwndDlg,IDC_STRINGLIST);
	SendMessage(list,LB_RESETCONTENT,0,0);
	for (CStringSet::const_iterator it=g_MainStringSet.begin();it!=g_MainStringSet.end();++it) {
		if (it->second)
			SendMessage(list,LB_ADDSTRING,0,(LPARAM)it->second);
	}
}

static INT_PTR CALLBACK DialogProc2( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		// Set the text of the label from the string database
		SetDlgItemText(hwndDlg,IDC_STATIC1,g_MainStringSet.GetString(IDS_STRING1));
		return TRUE;
	}

	if (uMsg==WM_COMMAND) {
		if (wParam==IDCANCEL) {
			// close the dialog
			EndDialog(hwndDlg,0);
			return TRUE;
		}
	}

	return FALSE;
}

static INT_PTR CALLBACK DialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		HWND combo=GetDlgItem(hwndDlg,IDC_LANGUAGE);
		SendMessage(combo,CB_ADDSTRING,0,(LPARAM)_T("English"));
		SendMessage(combo,CB_ADDSTRING,0,(LPARAM)_T("French"));
		SendMessage(combo,CB_ADDSTRING,0,(LPARAM)_T("German"));
		SendMessage(combo,CB_ADDSTRING,0,(LPARAM)_T("Japanese"));
		SendMessage(combo,CB_SETCURSEL,0,0);
		UpdateLanguage(hwndDlg,g_Languages[0]);
		return TRUE;
	}

	if (uMsg==WM_COMMAND) {
		if (LOWORD(wParam)==IDC_LANGUAGE && HIWORD(wParam)==CBN_SELENDOK) {
			// Language changed
			HWND combo=GetDlgItem(hwndDlg,IDC_LANGUAGE);
			int sel=SendMessage(combo,CB_GETCURSEL,0,0);
			UpdateLanguage(hwndDlg,g_Languages[sel]);
			return TRUE;
		}

		if (wParam==IDC_RUN) {
			// Show translated dialog
			DialogBoxEx(g_hInstance,IDD_DIALOG2,hwndDlg,DialogProc2);
			return TRUE;
		}

		if (wParam==IDCANCEL) {
			// close the dialog
			EndDialog(hwndDlg,0);
			return TRUE;
		}
	}

	return FALSE;
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	g_hInstance=hInstance;
	InitCommonControls();
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DialogProc);
	return 0;
}
