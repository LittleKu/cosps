#ifndef _STRINGSET_H
#define _STRINGSET_H

// CStringSet - a database collecting all string resources from a module.
// You can use GetString to get the string resource instead of the more
// inconvenient LoadString.
//
///////////////////////////////////////////////////////////////////////////////

#if _MSC_VER<=1200
#pragma warning(disable:4786) // identifier was truncated to '255' characters in the debug information
#endif

#include <map>

class CStringSet: private std::map<UINT,const TCHAR *>
{
public:
	typedef std::map<UINT,const TCHAR *> baseClass;
	typedef baseClass::const_iterator const_iterator;

	~CStringSet( void ) { clear(); }

	// Initializes the string database
	void Init( HINSTANCE hInstance, WORD wLanguage, bool bLoadAll );

	// Returns a string by ID (returns "" if the string is missing)
	const TCHAR *GetString( UINT uID );

	// Iterators to get all strings (they are needed primarily for the demo program)
	const_iterator begin( void ) const { return baseClass::begin(); }
	const_iterator end( void ) const { return baseClass::end(); }

private:
	HINSTANCE m_hInstance;
	WORD m_Language;
	bool m_bLoadAll;

	void clear( void );
	static BOOL CALLBACK CStringSet::EnumResNameProc( HMODULE hModule, LPCTSTR lpszType, LPTSTR lpszName, LONG_PTR lParam );
};

#endif
