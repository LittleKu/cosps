//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CommonDialogs.rc
//
#define IDD_DIALOG1                     101
#define IDC_FOLDERNAME                  1000
#define IDC_BROWSE1                     1001
#define IDC_BROWSE2                     1002
#define IDC_BROWSE3                     1003
#define IDC_FILENAME                    1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
