#define _WIN32_WINNT 0x500 // Windows 2000 and up
#include <windows.h>
#include <shlobj.h>
#include <tchar.h>
#include "resource.h"
#include "Shlwapi.h"

// Examples how to use the folder and file common dialogs

///////////////////////////////////////////////////////////////////////////////
// Browse for folder using SHBrowseForFolder
// Shows how to set the initial folder using a callback

int CALLBACK BrowseCallbackProc( HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData )
{
	if (uMsg==BFFM_INITIALIZED)
		SendMessage(hWnd,BFFM_SETSELECTION,TRUE,lpData);
	return 0;
}

bool BrowseForFolder1( HWND parent, TCHAR *path, const TCHAR *title )
{
	TCHAR name[_MAX_PATH];
	BROWSEINFO info={parent,NULL,name,title,BIF_USENEWUI,BrowseCallbackProc,(LPARAM)path};
	LPITEMIDLIST items=SHBrowseForFolder(&info);
	if (!items) return false;
	SHGetPathFromIDList(items,path);
	LPMALLOC pMalloc;
	SHGetMalloc(&pMalloc);
	pMalloc->Free(items);
	pMalloc->Release();
	return true;
}


///////////////////////////////////////////////////////////////////////////////
// Browse for folder using GetOpenFileName
// Shows how to customize the file browser dialog to select folders instead of files
// Also stores and restores the dialog placement

static WNDPROC g_OldOFNFolderProc;
static TCHAR *g_Path;
static RECT *g_Placement;

static LRESULT CALLBACK OFNFolderProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	// if the OK button is pressed
	if (uMsg==WM_COMMAND && HIWORD(wParam)==BN_CLICKED && LOWORD(wParam)==IDOK) {

		bool valid=false;

		HWND list=GetDlgItem(GetDlgItem(hWnd,lst2),1);
		int idx=ListView_GetNextItem(list,-1,LVNI_SELECTED);
		if (GetWindowTextLength(GetDlgItem(hWnd,cmb13))>0) {
			// the file name box is not empty
			// use the default processing, which will open the folder with that name
			CallWindowProc(g_OldOFNFolderProc,hWnd,uMsg,wParam,lParam);
			// then clear the text
			SetDlgItemText(hWnd,cmb13,_T(""));
			return TRUE;
		}
		else if (idx>=0) {
			// if a folder is selected in the list view, its user data is a PIDL
			// get the full folder name as described here: http://msdn.microsoft.com/msdnmag/issues/03/09/CQA/
			LVITEM item={LVIF_PARAM,idx,0};
			ListView_GetItem(list,&item);

			int len=SendMessage(hWnd,CDM_GETFOLDERIDLIST,0,NULL);
			if (len>0) {
				LPMALLOC pMalloc;
				SHGetMalloc(&pMalloc);
				LPCITEMIDLIST pidlFolder=(LPCITEMIDLIST)pMalloc->Alloc(len);
				SendMessage(hWnd,CDM_GETFOLDERIDLIST,len,(LPARAM)pidlFolder);

				STRRET str={STRRET_WSTR};

				IShellFolder *pDesktop, *pFolder;
				SHGetDesktopFolder(&pDesktop);
				if (SUCCEEDED(pDesktop->BindToObject(pidlFolder,NULL,IID_IShellFolder,(void**)&pFolder))) {
					if (FAILED(pFolder->GetDisplayNameOf((LPITEMIDLIST)item.lParam,SHGDN_FORPARSING,&str)))
						str.pOleStr=NULL;
					pFolder->Release();
					pDesktop->Release();
				}
				else {
					if (FAILED(pDesktop->GetDisplayNameOf((LPITEMIDLIST)item.lParam,SHGDN_FORPARSING,&str)))
						str.pOleStr=NULL;
					pDesktop->Release();
				}

				if (str.pOleStr) {
					DWORD attrib=GetFileAttributesW(str.pOleStr);
					if (attrib!=INVALID_FILE_ATTRIBUTES && (attrib&FILE_ATTRIBUTE_DIRECTORY)) {
#ifdef _UNICODE
						wcsncpy(g_Path,str.pOleStr,_MAX_PATH);
#else
						WideCharToMultiByte(CP_ACP,0,str.pOleStr,-1,g_Path,_MAX_PATH,NULL,NULL);
#endif
						g_Path[_MAX_PATH-1]=0;
						valid=true;
					}
					pMalloc->Free(str.pOleStr);
				}

				pMalloc->Free((void*)pidlFolder);
				pMalloc->Release();
			}
		}
		else {
			// no item is selected, use the current folder
			TCHAR path[_MAX_PATH];
			SendMessage(hWnd,CDM_GETFOLDERPATH,_MAX_PATH,(LPARAM)path);
			DWORD attrib=GetFileAttributes(path);
			if (attrib!=INVALID_FILE_ATTRIBUTES && (attrib&FILE_ATTRIBUTE_DIRECTORY)) {
				_tcscpy(g_Path,path);
				valid=true;
			}
		}
		if (valid) {
			EndDialog(hWnd,IDOK);
			return TRUE;
		}
	}

	if (uMsg==WM_SHOWWINDOW && wParam && g_Placement)
		SetWindowPos(hWnd,NULL,g_Placement->left,g_Placement->top,g_Placement->right-g_Placement->left,g_Placement->bottom-g_Placement->top,SWP_NOZORDER);

	if (uMsg==WM_DESTROY && g_Placement)
		GetWindowRect(hWnd,g_Placement);

	return CallWindowProc(g_OldOFNFolderProc,hWnd,uMsg,wParam,lParam);
}

static UINT APIENTRY OFNFolderHook( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		HWND hWnd=GetParent(hDlg);
		SendMessage(hWnd,CDM_HIDECONTROL,stc2,0); // hide "Save as type"
		SendMessage(hWnd,CDM_HIDECONTROL,cmb1,0); // hide the filter combo box
		SendMessage(hWnd,CDM_SETCONTROLTEXT,IDOK,(LPARAM)_T("Select"));
		SendMessage(hWnd,CDM_SETCONTROLTEXT,stc3,(LPARAM)_T("Folder Name:"));
		g_OldOFNFolderProc=(WNDPROC)SetWindowLong(hWnd,GWLP_WNDPROC,(LONG)OFNFolderProc);

		if (g_Placement && (g_Placement->top>=g_Placement->bottom)) {
			// the first time center the dialog relative to its parent
			RECT rc1,rc2;
			HWND parent=GetParent(hWnd);
			if (parent) {
				GetClientRect(parent,&rc1);
				MapWindowPoints(parent,NULL,(POINT*)&rc1,2);
			}
			else
				GetWindowRect(GetDesktopWindow(),&rc1);
			GetWindowRect(hWnd,&rc2);
			int x=rc1.left+((rc1.right-rc1.left)-(rc2.right-rc2.left))/2;
			int y=rc1.top+((rc1.bottom-rc1.top)-(rc2.bottom-rc2.top))/2;
			if (x<rc1.left) x=rc1.left;
			if (y<rc1.top) y=rc1.top;
			g_Placement->left=x;
			g_Placement->top=y;
			g_Placement->right=x+(rc2.right-rc2.left);
			g_Placement->bottom=y+(rc2.bottom-rc2.top);
		}

		return 1;
	}

	if (uMsg==WM_NOTIFY && ((NMHDR*)lParam)->code==CDN_FILEOK) {
		// reject all files when the OK button is pressed
		// this will stop the dialog from closing
		SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
		return TRUE;
	}

	return 0;
}

bool BrowseForFolder2( HWND parent, TCHAR *path, const TCHAR *title, RECT *placement )
{
	OPENFILENAME of;
	TCHAR path2[_MAX_PATH];
	_tcscpy(path2,path);
	TCHAR fname[_MAX_PATH];
	fname[0]=0;

	memset(&of,0,sizeof(of));
	of.lStructSize=sizeof(of);
	of.hwndOwner=parent;
	// weird filter to exclude all files and just keep the folders
	of.lpstrFilter=_T("Folders\0qqqqqqqqqqqqqqq.qqqqqqqqq\0");
	of.nFilterIndex=1;
	of.lpstrInitialDir=path2; // use the original path as the initial directory
	of.lpstrFile=fname;
	of.lpstrTitle=title;
	of.nMaxFile=_MAX_PATH;
	of.Flags=OFN_ENABLEHOOK|OFN_HIDEREADONLY|OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_ENABLESIZING|OFN_DONTADDTORECENT;
	of.lpstrDefExt=_T("");
	of.lpfnHook=OFNFolderHook;

	g_Path=path;
	g_Placement=placement;

	bool res=(GetOpenFileName(&of)!=FALSE);
	return res;
}


///////////////////////////////////////////////////////////////////////////////
// Browse for file using GetOpenFileName
// Shows how to store and restore the dialog placement

#define OFN_RESTORESIZE
#define OFN_RESTORESETTINGS

static WNDPROC g_OldOFNFileProc;

#ifdef OFN_RESTORESETTINGS

// undocumented message to get IShellBrowser from the file dialog
#ifndef WM_GETISHELLBROWSER
#define WM_GETISHELLBROWSER (WM_USER+7)
#endif

// custom message to subclass the list view
static UINT WM_RESETLIST=RegisterWindowMessage(_T("WM_RESETLIST"));
enum // wParam for WM_RESETLIST
{
	RESET_INIT, // subclass the list view and restore the settings
	RESET_SUBCLASS, // subclass the list view
	RESET_WIDTH, // restore the width only (if lParam matches the HWND of the header control)
};

static WNDPROC g_OldListProc;
static int g_ViewMode=-1;
static int g_NameWidth=-1;

static LRESULT CALLBACK OFNListProc( HWND hwndList, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_PARENTNOTIFY && LOWORD(wParam)==WM_CREATE && g_NameWidth>=0) {
		// restore the width of the first column when the header control is created
		// Note: This message is sent also for the Rename editbox. The WM_RESETLIST handler
		// must compare the lParam with the header control before messing with the widths
		HWND hWnd=GetAncestor(hwndList,GA_ROOT);
		PostMessage(hWnd,WM_RESETLIST,RESET_WIDTH,lParam);
	}

	if (uMsg==WM_DESTROY) {
		// get the width of the name column
		HWND hwndHeader=ListView_GetHeader(hwndList);
		if (hwndHeader && (GetWindowLong(hwndHeader,GWL_STYLE)&WS_VISIBLE)!=0) {
			HDITEM item;
			item.mask=HDI_WIDTH;
			if (Header_GetItem(hwndHeader,0,&item))
				g_NameWidth=item.cxy;
		}

		// get the view mode
		HWND hWnd=GetAncestor(hwndList,GA_ROOT);
		IShellBrowser *shBrowser=(IShellBrowser*)SendMessage(hWnd,WM_GETISHELLBROWSER,0,0);
		if (shBrowser) {
			IShellView *shView=NULL;
			if (shBrowser->QueryActiveShellView(&shView)==S_OK) {
				FOLDERSETTINGS settings;
				shView->GetCurrentInfo(&settings);
				g_ViewMode=settings.ViewMode;
 				shView->Release();
			}
		}

		// unsubclass the control
		SetWindowLong(hwndList,GWLP_WNDPROC,(LONG)g_OldListProc);
		g_OldListProc=NULL;
		// subclass the next control
		PostMessage(hWnd,WM_RESETLIST,RESET_SUBCLASS,0);
	}

	return CallWindowProc(g_OldListProc,hwndList,uMsg,wParam,lParam);
}
#endif


static LRESULT CALLBACK OFNFileProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_SHOWWINDOW && wParam) {
#ifdef OFN_RESTORESIZE
		// restore the window placement
		if (g_Placement)
			SetWindowPos(hWnd,NULL,g_Placement->left,g_Placement->top,g_Placement->right-g_Placement->left,g_Placement->bottom-g_Placement->top,SWP_NOZORDER);
#endif

#ifdef OFN_RESTORESETTINGS
		// restore the view settings
		SendMessage(hWnd,WM_RESETLIST,RESET_INIT,0);
#endif
	}

#ifdef OFN_RESTORESIZE
	// store the window placement
	if (uMsg==WM_DESTROY && g_Placement)
		GetWindowRect(hWnd,g_Placement);
#endif

#ifdef OFN_RESTORESETTINGS
	if (uMsg==WM_RESETLIST) {
		HWND hwndView=FindWindowEx(hWnd,NULL,_T("SHELLDLL_DefView"),NULL);
		if (!hwndView) return 0;
		HWND hwndList=GetDlgItem(hwndView,1);
		if (wParam==RESET_WIDTH && (HWND)lParam!=ListView_GetHeader(hwndList))
			return 0;

		if (wParam==RESET_INIT || wParam==RESET_SUBCLASS) {
			// subclass the list view
			if (!g_OldListProc)
				g_OldListProc=(WNDPROC)SetWindowLong(hwndList,GWLP_WNDPROC,(LONG)OFNListProc);
		}

		if (wParam==RESET_INIT && g_ViewMode!=-1) {
			// restore the view mode

			// this only works on Win XP
			IShellBrowser *shBrowser=(IShellBrowser*)SendMessage(hWnd,WM_GETISHELLBROWSER,0,0);
			IShellView *shView=NULL;
			if (shBrowser->QueryActiveShellView(&shView)==S_OK) {
				IFolderView *folder=NULL; // requires Win XP
				if (shView->QueryInterface(IID_IFolderView,(void **)&folder)==S_OK) {
					folder->SetCurrentViewMode(g_ViewMode);
					folder->Release();
					g_ViewMode=-1;
				}
	 			shView->Release();
			}

			if (g_ViewMode!=-1) {
				// if we can't get IShellFolder but got IShellView try an alternative (undocumented) approach
				switch (g_ViewMode) {
					case FVM_ICON:
						SendMessage(hwndView,WM_COMMAND,28713,0);
						break;
					case FVM_SMALLICON:
						SendMessage(hwndView,WM_COMMAND,28714,0);
						break;
					case FVM_LIST:
						SendMessage(hwndView,WM_COMMAND,28715,0);
						break;
					case FVM_DETAILS:
						SendMessage(hwndView,WM_COMMAND,28716,0);
						break;
					case FVM_THUMBNAIL: // this only works on XP
						SendMessage(hwndView,WM_COMMAND,28717,0);
						break;
					case FVM_TILE: // this only works on XP
						SendMessage(hwndView,WM_COMMAND,28718,0);
						break;
				}
				g_ViewMode=-1;
			}
		}

		// restore the width
		if (hwndList && g_NameWidth>=0) {
			HWND hwndHeader=ListView_GetHeader(hwndList);
			if (hwndHeader) {
				if ((GetWindowLong(hwndHeader,GWL_STYLE)&WS_VISIBLE)!=0)
					ListView_SetColumnWidth(hwndList,0,g_NameWidth);
				else {
					HDITEM item;
					item.mask=HDI_WIDTH;
					item.cxy=g_NameWidth;
					Header_SetItem(hwndHeader,0,&item);
				}
			}
		}

		return 0;
	}
#endif

	return CallWindowProc(g_OldOFNFileProc,hWnd,uMsg,wParam,lParam);
}

static UINT APIENTRY OFNFileHook( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		HWND hWnd=GetParent(hDlg);
		// subclass the parent dialog
		g_OldOFNFileProc=(WNDPROC)SetWindowLong(hWnd,GWLP_WNDPROC,(LONG)OFNFileProc);

		if (g_Placement && (g_Placement->top>=g_Placement->bottom)) {
			// the first time center the dialog relative to its parent
			RECT rc1,rc2;
			HWND parent=GetParent(hWnd);
			if (parent) {
				GetClientRect(parent,&rc1);
				MapWindowPoints(parent,NULL,(POINT*)&rc1,2);
			}
			else
				GetWindowRect(GetDesktopWindow(),&rc1);
			GetWindowRect(hWnd,&rc2);
			int x=rc1.left+((rc1.right-rc1.left)-(rc2.right-rc2.left))/2;
			int y=rc1.top+((rc1.bottom-rc1.top)-(rc2.bottom-rc2.top))/2;
			if (x<rc1.left) x=rc1.left;
			if (y<rc1.top) y=rc1.top;
			g_Placement->left=x;
			g_Placement->top=y;
			g_Placement->right=x+(rc2.right-rc2.left);
			g_Placement->bottom=y+(rc2.bottom-rc2.top);
		}

		return 1;
	}

	return 0;
}

bool BrowseForFile( HWND parent, TCHAR *path, const TCHAR *title, RECT *placement )
{
	OPENFILENAME of;
	memset(&of,0,sizeof(of));
	of.lStructSize=sizeof(of);
	of.hwndOwner=parent;
	of.lpstrFile=path;
	of.lpstrTitle=title;
	of.nMaxFile=_MAX_PATH;
	of.Flags=OFN_ENABLEHOOK|OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_ENABLESIZING|OFN_DONTADDTORECENT;
	of.lpstrDefExt=_T("");
	of.lpfnHook=OFNFileHook;

	g_Placement=placement;

	bool res=(GetOpenFileName(&of)!=FALSE);
	return res;
}


///////////////////////////////////////////////////////////////////////////////

static RECT g_Placement1, g_Placement2;

INT_PTR CALLBACK DialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		SetDlgItemText(hwndDlg,IDC_FOLDERNAME,_T("C:\\Program Files"));
		return TRUE;
	}

	if (uMsg==WM_COMMAND) {
		if (wParam==IDC_BROWSE1) {
			// use SHBrowseForFolder
			TCHAR path[_MAX_PATH];
			GetDlgItemText(hwndDlg,IDC_FOLDERNAME,path,_MAX_PATH);
			if (BrowseForFolder1(hwndDlg,path,_T("Select Folder")))
				SetDlgItemText(hwndDlg,IDC_FOLDERNAME,path);
			return TRUE;
		}
		if (wParam==IDC_BROWSE2) {
			// use GetOpenFileName as folder browser
			TCHAR path[_MAX_PATH];
			GetDlgItemText(hwndDlg,IDC_FOLDERNAME,path,_MAX_PATH);
			if (BrowseForFolder2(hwndDlg,path,_T("Select Folder"),&g_Placement1))
				SetDlgItemText(hwndDlg,IDC_FOLDERNAME,path);
			return TRUE;
		}
		if (wParam==IDC_BROWSE3) {
			// use GetOpenFileName
			TCHAR path[_MAX_PATH];
			GetDlgItemText(hwndDlg,IDC_FILENAME,path,_MAX_PATH);
			if (BrowseForFile(hwndDlg,path,_T("Select File"),&g_Placement2))
				SetDlgItemText(hwndDlg,IDC_FILENAME,path);
			return TRUE;
		}
		if (wParam==IDCANCEL) {
			// close the dialog
			EndDialog(hwndDlg,0);
			return TRUE;
		}
	}

	return FALSE;
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	CoInitialize(NULL);
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DialogProc);
	CoUninitialize();
	return 0;
}
