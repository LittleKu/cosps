#ifndef _MYASSERT_H
#define _MYASSERT_H

#include <crtdbg.h>

// A replacement for assert. Suspends the calling thread while the assert message is displayed.

#if !defined(NDEBUG)
bool my_assert( const char *exp, const char *file, unsigned line );
#define MyAssert(exp) do { if (!(exp) && !my_assert(#exp,__FILE__,__LINE__)) _CrtDbgBreak(); } while (0)
#else
#define MyAssert(exp) ((void)0)
#endif

#endif
