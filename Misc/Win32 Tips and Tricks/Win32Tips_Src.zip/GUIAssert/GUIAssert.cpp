#include <windows.h>
#include <commctrl.h>
#include <assert.h>
#include "resource.h"
#include "MyAssert.h"

// Compares the behavior of assert, _ASSERT and MyAssert

static INT_PTR CALLBACK DialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if (uMsg==WM_INITDIALOG) {
		CheckDlgButton(hwndDlg,IDC_NOASSERT,BST_CHECKED);
		return TRUE;
	}

	if (uMsg==WM_COMMAND) {
		if (wParam==IDC_ASSERT1 || wParam==IDC_ASSERT2 || wParam==IDC_MYASSERT) {
			// invalidate the window to trigger WM_PAINT
			InvalidateRect(hwndDlg,NULL,FALSE);
			return TRUE;
		}
		if (wParam==IDCANCEL) {
			// close the dialog
			EndDialog(hwndDlg,0);
			return TRUE;
		}
	}

	if (uMsg==WM_PAINT) {
		if (IsDlgButtonChecked(hwndDlg,IDC_ASSERT1)) {
			assert(0);
		}
		else if (IsDlgButtonChecked(hwndDlg,IDC_ASSERT2)) {
			_ASSERT(0);
		}
		else if (IsDlgButtonChecked(hwndDlg,IDC_MYASSERT)) {
			MyAssert(0);
		}
	}

	return FALSE;
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
	InitCommonControls();
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DialogProc);
	return 0;
}
