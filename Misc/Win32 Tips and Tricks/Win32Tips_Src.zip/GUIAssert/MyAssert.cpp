#include <windows.h>
#include <stdio.h>

static DWORD _stdcall AssertThreadProc( void *param )
{
	return MessageBoxA(NULL,(const char *)param,"Assertion Failed",MB_ABORTRETRYIGNORE|MB_TASKMODAL|MB_ICONERROR);
}

bool my_assert( const char *exp, const char *file, unsigned line )
{
	char buf[2048];
	sprintf(buf,"Expression: %s\r\nFile: %s\r\nLine: %d\n",exp,file,line);
	HANDLE h=CreateThread(NULL,0,AssertThreadProc,buf,0,NULL);
	if (h) {
		WaitForSingleObject(h,INFINITE);
		DWORD res=IDRETRY;
		GetExitCodeThread(h,&res);
		if (res==IDABORT)
			TerminateProcess(GetCurrentProcess(),3);
		return (res==IDIGNORE); // true will continue, false will cause _CrtDbgBreak
	}
	return true;
}
