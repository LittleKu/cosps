/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "StdAfx.h"
#include "FileParser.h"
#include "Config.h"
#include "Utils.h"

CString CFileInfo::GetTotalLinesStr(bool bDecorated) const
{
    return DecoratedNumber(m_iTotalLines, bDecorated, false);
}

CString CFileInfo::GetLinesWithCodeStr(bool bDecorated) const
{
    return DecoratedNumber(
		// Prior to v2.2, "code lines" and "comment lines" meant "any code"
		// and "any comment" lines.
		// Starting with v2.2, the stat reported is "code only" and "comments
		// only", so we need to adjust.
		m_iLinesWithCode - CalculateMixedLines(),

		bDecorated, false);
}

CString CFileInfo::GetLinesWithCommentsStr(bool bDecorated) const
{
    return DecoratedNumber(
		// Prior to v2.2, "code lines" and "comment lines" meant "any code"
		// and "any comment" lines.
		// Starting with v2.2, the stat reported is "code only" and "comments
		// only", so we need to adjust.
		m_iLinesWithComments - CalculateMixedLines(),

		bDecorated, !cfg_bProcessComments);
}

CString CFileInfo::GetMixedLinesStr(bool bDecorated) const
{
    return DecoratedNumber(CalculateMixedLines(), bDecorated, 
        !cfg_bProcessComments);
}

CString CFileInfo::GetBlankLinesStr(bool bDecorated) const
{
    return DecoratedNumber(m_iBlankLines, bDecorated, 
        !cfg_bProcessBlanks);
}


void CFileInfo::SetFileName(LPCTSTR pszFullFileName)
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];
    char fname[_MAX_FNAME];
    char ext[_MAX_EXT];
    m_sFullFileName = pszFullFileName;
    _splitpath(m_sFullFileName, drive, dir, fname, ext);
    m_sFilePath = drive;
    m_sFilePath += dir;
    m_sFileName = fname;
    m_sFileExt = ext;
}

CString CFileInfo::DecoratedNumber(int iNum, bool bDecorated, bool bNA) const
{
    switch (m_stat)
    {
        case file_error:
        case unknown:
            return cfg_sMarkerBadFile;

        case filtered:
            return cfg_sMarkerFiltered;

        default:
            if (bNA)
            {
                return "n/a";
            }
            if (bDecorated)
            {
                return NumberWithCommas(iNum);
            }
            else
            {
                CString cStr;
                cStr.Format("%d", iNum);
                return cStr;
            }
    }
}

