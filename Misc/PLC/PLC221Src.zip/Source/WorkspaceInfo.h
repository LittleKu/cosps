/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __WORKSPACEINFO_H
#define __WORKSPACEINFO_H

interface IWorkspaceProject;
interface IProjectFile;

interface IWorkspaceInfo
{
public:
    virtual ~IWorkspaceInfo() {};

    virtual void Refresh() = 0;

    virtual CString GetWorkspaceName() const = 0;

    virtual int GetProjectCount() const = 0;
    virtual IWorkspaceProject *GetProject(int iIndex) const = 0;

    // project filters
    virtual int GetWorkspaceFilterCount() const = 0;
    virtual LPCTSTR GetWorkspaceFilterName(int iFilterIndex) const = 0;
	virtual int GetWorkspaceFilterProjectCount(int iFilterIndex) const = 0;
	virtual IWorkspaceProject *GetWorkspaceFilterProject(int iFilterIndex,
        int iProjectIndex) const = 0;
};

interface IWorkspaceProject
{
    virtual ~IWorkspaceProject() {}

    virtual CString GetName() const = 0;

    virtual int GetFileCount() const = 0;
    virtual IProjectFile *GetFile(int iIndex) const = 0;
};

interface IProjectFile
{
    virtual ~IProjectFile() {};

    virtual CString GetPath() const = 0;
    virtual CString GetExt() const = 0;
};

extern IWorkspaceInfo *g_pWorkspaceInfo;

#ifdef TARGET_VC6
void InitializeWorkspaceInfo_VC6(IApplication *pApplication);
#endif
#ifdef TARGET_VC7
namespace EnvDTE { struct _DTE; }
void InitializeWorkspaceInfo_VC_NET(EnvDTE::_DTE *pDTE);
#endif

#endif // __WORKSPACEINFO_H
