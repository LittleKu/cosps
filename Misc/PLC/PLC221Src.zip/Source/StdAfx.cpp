// stdafx.cpp : source file that includes just the standard includes
//	LineCount.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#if _MSC_VER <= 1200
#include "atlimpl.cpp"
#endif
