/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// HelpInterceptionWnd.cpp : implementation file
//

#include "stdafx.h"
#include "linecount.h"
#include "HHSupp.h"
#include "HelpInterceptionWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHelpInterceptionWnd

CHelpInterceptionWnd::CHelpInterceptionWnd(DWORD helpID) :
    m_iHelpID(helpID)
{
    CreateEx(0, AfxRegisterWndClass(0), "Help Interception Wnd",
        WS_POPUP, CRect(0, 0, 0, 0), NULL, 0);
}

CHelpInterceptionWnd::~CHelpInterceptionWnd()
{
}


BEGIN_MESSAGE_MAP(CHelpInterceptionWnd, CWnd)
	//{{AFX_MSG_MAP(CHelpInterceptionWnd)
	//}}AFX_MSG_MAP
    ON_MESSAGE(WM_HELP, OnHelp)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CHelpInterceptionWnd message handlers

LRESULT CHelpInterceptionWnd::OnHelp(WPARAM, LPARAM /*lParam*/) 
{
//  HELPINFO *pHI = (HELPINFO *)lParam;
    ShowHTMLHelp(NULL, m_iHelpID);
	return TRUE;
}
