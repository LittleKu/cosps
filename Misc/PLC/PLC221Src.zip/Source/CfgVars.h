/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// == configuration variable list - may be #included more than once == //

#ifndef SHOWFLAGS
#define SHOWFLAGS
const int SF_GRID   = 0x01;  // show-bad-file bit masks
const int SF_EXPORT = 0x02;

const int PU_DSW    = 0x00;  // "path usage" options
const int PU_FILTER = 0x01;
const int PU_FULL   = 0x02;
#endif SHOWFLAGS

CFG_STR(InitAfterInstall,   cfg_sInitedEnvs,        "")

// user options
CFG_VAR(ProcessBlanks,      BOOL,       cfg_bProcessBlanks,         TRUE)
CFG_VAR(ProcessComments,    BOOL,       cfg_bProcessComments,       TRUE)
CFG_VAR(DefaultFilter,      int,        cfg_iDefaultFilter,         0)
CFG_VAR(DefaultExportType,  int,        cfg_iDefaultExportType,     -1)
CFG_VAR(UseXSLT,            XSLT_Usage, cfg_XSLTUsage,              fixed_name)
CFG_VAR(UsePath,            int,        cfg_PathUsage,              PU_FULL)
CFG_VAR(ShowBadFiles,       int,        cfg_ShowBadFiles,           SF_GRID)
CFG_VAR(ShowFiltered,       int,        cfg_ShowFiltered,           0)

CFG_STR(XSLTTemplate,       cfg_sXSLTTemplate,      "Simple-Color.xsl")
CFG_STR(ExtList,            cfg_sExtList,           "")
CFG_STR(FileIgnoreList,     cfg_sFileIgnoreList,    DEF_IGNORE_LIST)
CFG_STR(LastFilter,         cfg_sLastFilter,        "")

CFG_STR(MARKER_BADFILE,     cfg_sMarkerBadFile,     "?")
CFG_STR(MARKER_FILTERED,    cfg_sMarkerFiltered,    "-")
