/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// ConnectVC7.h : Addin interface for VC7

#pragma once

#ifndef TARGET_VC7
#error Should only be included when targeting VC7
#endif

#include "resource.h"       // main symbols
#include "LineCountVC7_h.h"

// CConnect
class ATL_NO_VTABLE CConnect : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CConnect, &CLSID_Connect>,
#if _MSC_VER > 1200  // VC7
	public IDispatchImpl<EnvDTE::IDTCommandTarget, &__uuidof(EnvDTE::IDTCommandTarget), &EnvDTE::LIBID_EnvDTE, 7, 0>,
	public IDispatchImpl<AddInDesignerObjects::_IDTExtensibility2, &AddInDesignerObjects::IID__IDTExtensibility2, &AddInDesignerObjects::LIBID_AddInDesignerObjects, 1, 0>
#else
	public IDispatchImpl<EnvDTE::IDTCommandTarget, &__uuidof(EnvDTE::IDTCommandTarget)>,
	public IDispatchImpl<AddInDesignerObjects::_IDTExtensibility2, &__uuidof(AddInDesignerObjects::_IDTExtensibility2)>
#endif
{
public:
	CConnect() : m_bConnectSignaled(false)
	{
	}


    // Usually you would use DECLARE_REGISTRY_RESOURCEID(IDR_REGISTRY_VC7),
    // but here I declare custom macro expansions
	static HRESULT WINAPI UpdateRegistry(BOOL bRegister)
	{
        // figure out the path of this DLL
        wchar_t path_buffer[MAX_PATH + 1];
        GetModuleFileNameW(AfxGetInstanceHandle(), path_buffer, 
            countof(path_buffer));
        wchar_t * const last_slash = wcsrchr(path_buffer, '\\');
        if (last_slash) *(last_slash + 1) = '\0';

        CString sAboutBoxDetails;
        sAboutBoxDetails.Format(IDS_ABOUT_BOX_DETAILS, GetOwnVersion());
    
        // custom expansion macros (like %MODULE%)
        _ATL_REGMAP_ENTRY macro_map[] = 
        {
            L"SATELLITE_NAME",      L"LineCountResources.dll",
            L"MODULE_PATH",         path_buffer,
            L"ABOUT_BOX_DETAILS",   CComBSTR(sAboutBoxDetails),
            NULL,                   NULL 
        };

        return _Module.UpdateRegistryFromResource(IDR_REGISTRY_VC7, 
            bRegister, macro_map);
    }

DECLARE_NOT_AGGREGATABLE(CConnect)


BEGIN_COM_MAP(CConnect)
	COM_INTERFACE_ENTRY(AddInDesignerObjects::IDTExtensibility2)
	COM_INTERFACE_ENTRY(EnvDTE::IDTCommandTarget)
	COM_INTERFACE_ENTRY2(IDispatch, AddInDesignerObjects::IDTExtensibility2)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:
	//IDTExtensibility2 implementation:
	STDMETHOD(OnConnection)(IDispatch * Application, AddInDesignerObjects::ext_ConnectMode ConnectMode, IDispatch *AddInInst, SAFEARRAY **custom);
	STDMETHOD(OnDisconnection)(AddInDesignerObjects::ext_DisconnectMode RemoveMode, SAFEARRAY **custom );
	STDMETHOD(OnAddInsUpdate)(SAFEARRAY **custom );
	STDMETHOD(OnStartupComplete)(SAFEARRAY **custom );
	STDMETHOD(OnBeginShutdown)(SAFEARRAY **custom );
	
	//IDTCommandTarget implementation:
	STDMETHOD(QueryStatus)(BSTR CmdName, EnvDTE::vsCommandStatusTextWanted NeededText, EnvDTE::vsCommandStatus *StatusOption, VARIANT *CommandText);
	STDMETHOD(Exec)(BSTR CmdName, EnvDTE::vsCommandExecOption ExecuteOption, VARIANT *VariantIn, VARIANT *VariantOut, VARIANT_BOOL *Handled);

	CComPtr<EnvDTE::_DTE> m_pDTE;
	CComPtr<EnvDTE::AddIn> m_pAddInInstance;
	bool m_bConnectSignaled;
	
};
