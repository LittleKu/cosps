/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// ResultsDlg.h : header file
//

#if !defined(AFX_RESULTSDLG_H__23E5E9B1_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_)
#define AFX_RESULTSDLG_H__23E5E9B1_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_

#include "NiceGroupBox.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CResultsDlg dialog

#include "PrjStats.h"

interface IWorkspaceInfo;

class CResultsDlg : public CResizableDialog
{
public:

// Construction
public:
	void SetPair(int idc, int idp, int count, int tot);
	CResultsDlg(IWorkspaceInfo *pWI, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CResultsDlg)
	enum { IDD = IDD_RESULTS };
	CNiceGroupBox	m_SummaryFrame;
	CNiceGroupBox	m_ProjStatsFrame;
	CComboBox	m_Filter;
	CMultiColumnSortListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResultsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetNum(int id, int num, TCHAR suffix = '\0');
    int AddRow(const class CFileInfo& fi);

    void AddFilter(const char *pszFilter, int data);
    void SetFilter(int iIndex);
    void ProjectListFromFilter(int iFilterIndex, ProjectList& projects);

    void InitStats();
    void RefreshStats();

	// Generated message map functions
	//{{AFX_MSG(CResultsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnExport();
	afx_msg void OnOptions();
	afx_msg void OnAbout();
	afx_msg void OnSelchangeFilter();
	afx_msg void OnDownloads();
	afx_msg void OnHomepage();
	afx_msg void OnFileSummary();
	afx_msg void OnUpdateStatsCommand(CCmdUI* pCmdUI);
	afx_msg void OnHelpCheckForNewVersion();
	afx_msg void OnHelpStylesheetgallery();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	afx_msg void OnStatisticsFilterProjects(UINT iCmd);
	afx_msg void OnUpdateStatisticsFilterProjects(CCmdUI* pCmdUI);
	afx_msg void OnInitMenuPopup(CMenu*, UINT, BOOL);
	DECLARE_MESSAGE_MAP()

    DECLARE_HELP_IDS();

    IWorkspaceInfo *m_pWI;
    bool            m_bHasProject;
    int             m_iFilterIndex;
    int             m_iContext;
    CString         m_sNA;
    int             m_nWorkspaceFilters;
	CBrush			m_brBGBrush;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESULTSDLG_H__23E5E9B1_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_)
