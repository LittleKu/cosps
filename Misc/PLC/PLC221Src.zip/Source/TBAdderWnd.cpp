/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// TBAdderWnd.cpp : implementation file
//

#include "stdafx.h"

#ifdef TARGET_VC6

#include "LineCount.h"
#include "DSAddin.h"
#include "TBAdderWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CDSAddIn *g_pDSAddin;

HHOOK CTBAdderWnd::m_hHook = NULL;


/////////////////////////////////////////////////////////////////////////////
// CTBAdderWnd

CTBAdderWnd::CTBAdderWnd()
{
}

CTBAdderWnd::~CTBAdderWnd()
{
}


BEGIN_MESSAGE_MAP(CTBAdderWnd, CWnd)
	//{{AFX_MSG_MAP(CTBAdderWnd)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTBAdderWnd message handlers

void CTBAdderWnd::OnClose() 
{
    // this hook is used to set the toolbar title
    m_hHook = SetWindowsHookEx(WH_CBT, CatchToolbarTitle, 
        AfxGetInstanceHandle(), 0);

    // the following code is here because calls to 
    // IApplication->AddCommandBarButton are not valid in 
    // CDSAddIn::OnConnection if bFirstTime isn't true.  
    // this is an alternate location for that call
    g_pDSAddin->AddToolbarCmds();           

    UnhookWindowsHookEx(m_hHook);
    
	CWnd::OnClose();
}

void CTBAdderWnd::PostNcDestroy() 
{
	CWnd::PostNcDestroy();
    delete this;
}

// this function intercepts the creation of the DevStudio toolbar, and 
// changes it's name
LRESULT CALLBACK CTBAdderWnd::CatchToolbarTitle(int nCode, 
  WPARAM wParam, LPARAM lParam)
{
    static const char *TOOLBAR_TITLE = "PLC";

    if (nCode == HCBT_CREATEWND)
    {
        CREATESTRUCT& cs = *((CBT_CREATEWND *)lParam)->lpcs;
        if (cs.lpszName  &&  strncmp(cs.lpszName, "Toolbar", 7) == 0)
        {
            // since we're about to overwite DS's own buffer, let's make 
            // sure we have enough space
            const bool bTitleLenIsOK = 
                strlen(TOOLBAR_TITLE) <= strlen(cs.lpszName);
            ASSERT(bTitleLenIsOK);
            if (bTitleLenIsOK)
            {
                strcpy((char *)cs.lpszName, TOOLBAR_TITLE);
            }
        }
    }

    return CallNextHookEx(m_hHook, nCode, wParam, lParam);
}

#endif // TARGET_VC6
