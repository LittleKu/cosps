/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// InsertExtDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LineCount.h"
#include "InsertExtDlg.h"
#include "ParserManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsertExtDlg dialog


CInsertExtDlg::CInsertExtDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInsertExtDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInsertExtDlg)
	m_Ext = _T("");
	//}}AFX_DATA_INIT
}


void CInsertExtDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsertExtDlg)
	DDX_Control(pDX, IDC_COMBO_PARSER, m_ComboParser);
	DDX_Text(pDX, IDC_EDIT, m_Ext);
	DDV_MaxChars(pDX, m_Ext, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsertExtDlg, CDialog)
	//{{AFX_MSG_MAP(CInsertExtDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsertExtDlg message handlers

BOOL CInsertExtDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    IFileParser **pArr;
    int cParsers;
    CParserManager::Get().GetParsers(pArr, cParsers);
    ASSERT(cParsers > 0);
    while (cParsers--)
    {
        const int ndx = m_ComboParser.AddString(
            CString(MAKEINTRESOURCE((*pArr)->GetParserNameResourceID())));
        m_ComboParser.SetItemData(ndx, (DWORD)*pArr);
        ++pArr;
    }
    m_ComboParser.SetCurSel(0);
    
	return TRUE;
}

void CInsertExtDlg::OnOK() 
{
    UpdateData();

    if (m_Ext.FindOneOf("\\/:<>|\"") >= 0)
    {
        CString sMsg;
        AfxFormatString1(sMsg, IDS_ERR_BADCHAR, "\\ / : < > | \"");
        AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
        return;
    }

    m_Ext.MakeLower();
    CParserManager::PairArray arr;
    CParserManager::Get().GetPairs(arr);
    for (int i = 0; i < arr.GetSize(); ++i)
    {
        if (arr[i].sExt == m_Ext)
        {
            AfxMessageBox(IDS_ERR_EXTINUSE, MB_OK | MB_ICONEXCLAMATION);
            return;
        }
    }

    int idPrompt = -1;
    if (m_Ext.IsEmpty())
    {
        idPrompt = IDS_MSG_EMPTYEXT;
    }
    else if (m_Ext[0] == '.')
    {
        idPrompt = IDS_MSG_FIRSTDOTEXT;
    }

    if (idPrompt >= 0)
    {
        int res = AfxMessageBox(idPrompt, MB_YESNOCANCEL | MB_ICONQUESTION);
        if (res == IDNO)
        {
            return;
        }
        else if (res == IDCANCEL)
        {
            OnCancel();
            return;
        }
    }

    ASSERT(m_ComboParser.GetCurSel() >= 0);
    m_pParser = (IFileParser *)m_ComboParser.GetItemData(m_ComboParser.GetCurSel());
    ASSERT(m_pParser != NULL);

	CDialog::OnOK();
}
