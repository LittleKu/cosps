/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// LineCount.h : main header file for the LINECOUNT DLL
//

#if !defined(AFX_LINECOUNT_H__04727E6B_B52C_11D3_BA83_0000861DFCE7__INCLUDED_)
#define AFX_LINECOUNT_H__04727E6B_B52C_11D3_BA83_0000861DFCE7__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#ifdef TARGET_VC6
#include "ObjModelVC6\addguid.h"
#include "ObjModelVC6\appguid.h"
#include "ObjModelVC6\bldguid.h"
#include "ObjModelVC6\textguid.h"
#include "ObjModelVC6\dbgguid.h"
#endif // TARGET_VC6

void OnAddinConnect();
void OnAddinDisconnect();

CString GetOwnVersion();

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LINECOUNT_H__04727E6B_B52C_11D3_BA83_0000861DFCE7__INCLUDED)
