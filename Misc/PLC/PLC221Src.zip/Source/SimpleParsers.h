/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __SIMPLEPARSERS_H
#define __SIMPLEPARSERS_H

#include "FileParser.h"

class CSimpleCommentParser : public IFileParser
{
public:
    CSimpleCommentParser(LPCTSTR pszCommentPrefix);

    virtual void ParseFile(CLineViewOfFile& file, CFileInfo& info);

protected:
    CString m_sCommentPrefix;
};


class CPlainTextParser : public CSimpleCommentParser
{
public:

    CPlainTextParser() : CSimpleCommentParser("") {}

    LPCTSTR GetDefaultExtensions() const
    {
        return _T("BAT/TXT/RGS");
    }

    virtual LPCTSTR GetParserCfgCode() const 
    {
        return _T("TXT");
    }

    virtual int GetParserNameResourceID() const
    {
        return IDS_PARSERNAME_TXT;
    }
};

class CINIParser : public CSimpleCommentParser
{
public:

    CINIParser() : CSimpleCommentParser(";") {}

    LPCTSTR GetDefaultExtensions() const
    {
        return _T("INI/DEF/HHP/HPJ");
    }

    virtual LPCTSTR GetParserCfgCode() const 
    {
        return _T("INI");
    }

    virtual int GetParserNameResourceID() const
    {
        return IDS_PARSERNAME_INI;
    }
};

class CMakeFileParser : public CSimpleCommentParser
{
public:

    CMakeFileParser() : CSimpleCommentParser("#") {}

    LPCTSTR GetDefaultExtensions() const
    {
        return _T("MAK/MAKE/PROPERTIES");
    }

    virtual LPCTSTR GetParserCfgCode() const 
    {
        return _T("MAK");
    }

    virtual int GetParserNameResourceID() const
    {
        return IDS_PARSERNAME_MAK;
    }
};


#endif // __SIMPLEPARSERS_H
