/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// InsertExtDlg.h : header file
//

#if !defined(AFX_INSERTEXTDLG_H__614A4D81_B55F_11D3_BA83_0000861DFCE7__INCLUDED_)
#define AFX_INSERTEXTDLG_H__614A4D81_B55F_11D3_BA83_0000861DFCE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CInsertExtDlg dialog

class CInsertExtDlg : public CDialog
{
// Construction
public:
	CInsertExtDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInsertExtDlg)
	enum { IDD = IDD_INSERT_EXT };
	CComboBox	m_ComboParser;
	CString	m_Ext;
	//}}AFX_DATA

    class IFileParser *m_pParser;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInsertExtDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInsertExtDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSERTEXTDLG_H__614A4D81_B55F_11D3_BA83_0000861DFCE7__INCLUDED_)
