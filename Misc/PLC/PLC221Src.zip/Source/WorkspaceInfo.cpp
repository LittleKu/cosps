/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "stdafx.h"
#include "WorkspaceInfo.h"

#include "ExtrnSrc\WWhizInterface2.h"
#include "ExtrnSrc\WWhizInterface2Loader.h"

IWorkspaceInfo *g_pWorkspaceInfo = NULL;

class Auto_Destruct_WorkspaceInfo
{
public:
    ~Auto_Destruct_WorkspaceInfo()
    {
        delete g_pWorkspaceInfo;
        g_pWorkspaceInfo = NULL;
    }
} auto_var;


#ifdef TARGET_VC6

class CProjectFile_VC6 : public IProjectFile
{
protected:
    WWhizFile *m_pFile;

public:
    CProjectFile_VC6(WWhizFile *pFile) : m_pFile(pFile)
    {
        ASSERT(pFile != NULL);
    }

    virtual ~CProjectFile_VC6() {};

    virtual CString GetPath() const
    {
        return (LPCTSTR)m_pFile->GetFullName();
    }

    virtual CString GetExt() const
    {
        return (LPCTSTR)m_pFile->GetExt();
    }
};

class CWorkspaceProject_VC6 : public IWorkspaceProject
{
protected:
    WWhizProject *m_pPrj;

public:
    CWorkspaceProject_VC6(WWhizProject *pPrj) : m_pPrj(pPrj)
    {
        ASSERT(pPrj != NULL);
    }

    virtual ~CWorkspaceProject_VC6() {}

    virtual CString GetName() const
    {
        return (LPCTSTR)m_pPrj->GetName();
    }

    virtual int GetFileCount() const
    {
        return m_pPrj->GetFileList().GetCount();
    }

    virtual IProjectFile *GetFile(int iIndex) const
    {
        return new CProjectFile_VC6(m_pPrj->GetFileList().Get(iIndex));
    }
};


class CWorkspaceInfo_VC6 : public IWorkspaceInfo
{
protected:
    WWhizInterface *m_pWWI;

    enum 
    { 
        FILTER_NDX_WORKSPACE = 0,
        FILTER_NDX_ACTIVEPRJ = 1 
    };

public:
    CWorkspaceInfo_VC6(IApplication *pApplication)
    {
        m_pWWI = WWhizInterface2Create(AfxGetInstanceHandle(), 
            pApplication);
        if (!m_pWWI) throw "Could not load WWhiz";
    }

    virtual ~CWorkspaceInfo_VC6() 
    {
        WWhizInterface2Destroy();    
    };

    virtual void Refresh()
    {
        m_pWWI->RefreshFileList();
    }

    virtual CString GetWorkspaceName() const
    {
        return (LPCTSTR)m_pWWI->GetWorkspaceName();
    }

    virtual int GetProjectCount() const
    {
        return m_pWWI->GetProjectList().GetProjectCount();
    }

    virtual IWorkspaceProject *GetProject(int iIndex) const 
    {
        ASSERT(iIndex >= 0);
        ASSERT(iIndex < GetProjectCount());
        return new CWorkspaceProject_VC6(
            m_pWWI->GetProjectList().GetProjectByIndex(iIndex));
    }


    virtual int GetWorkspaceFilterCount() const
    {
        return 2;
    }

    virtual LPCTSTR GetWorkspaceFilterName(int iFilterIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_WORKSPACE:
                return "Workspace";
                
            case FILTER_NDX_ACTIVEPRJ:
                return "Active Project";

            default:
                ASSERT(0);
        }
        return "";
    }

    virtual int GetWorkspaceFilterProjectCount(int iFilterIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_WORKSPACE:
                return GetProjectCount();
                
            case FILTER_NDX_ACTIVEPRJ:
                return 1;

            default:
                ASSERT(0);
        }
        return 0;
    }

    virtual IWorkspaceProject *GetWorkspaceFilterProject(int iFilterIndex,
        int iProjectIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_WORKSPACE:
                return GetProject(iProjectIndex);
                
            case FILTER_NDX_ACTIVEPRJ:
            {
                WWhizProject *pWWPrj = m_pWWI->GetCurrentProject();
                if (!pWWPrj) return NULL;
                return new CWorkspaceProject_VC6(pWWPrj);
            }

            default:
                ASSERT(0);
        }
        return NULL;
    }
};

void InitializeWorkspaceInfo_VC6(IApplication *pApplication)
{
    ASSERT(g_pWorkspaceInfo == NULL);
    ASSERT(pApplication != NULL);
    try
    {
        g_pWorkspaceInfo = new CWorkspaceInfo_VC6(pApplication);
    }
    catch (...)
    {
    }
}

#endif // TARGET_VC6


// *********************************************************************** //

#ifdef TARGET_VC7

class CProjectFile_VC7 : public IProjectFile
{
protected:
    CString m_strPath;

public:
    CProjectFile_VC7(const CString& strPath) : m_strPath(strPath)
    {
    }

    virtual ~CProjectFile_VC7() {};

    virtual CString GetPath() const
    {
        return m_strPath;
    }

    virtual CString GetExt() const
    {
        CString sPath = m_strPath;
        int dotPos = sPath.ReverseFind('.');
        ASSERT(dotPos >= 0);
        sPath.Delete(0, dotPos + 1);
        return sPath;
    }
};


namespace EnvDTE
{
	namespace ProjectKinds
	{
		const char *SolutionFolder	= "{66A26720-8FB5-11D2-AA7E-00C04F688DDE}";
		const char *VisualBasic		= "{F184B08F-C81C-45F6-A57F-5ABD9991F28F}";
		const char *VisualCSharp	= "{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}";
		const char *VisualCPP		= "{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}";
		const char *VisualJSharp	= "{E6FDF86B-F3D1-11D4-8576-0002A516ECE8}";
		const char *WebProject		= "{E24C65DC-7377-472b-9ABA-BC803B73C61A}";
	}
}

class CWorkspaceProject_VC7 : public IWorkspaceProject
{
protected:
    typedef CComPtr<EnvDTE::Project>      DTEProject;
    typedef CComPtr<EnvDTE::ProjectItem>  DTEProjectItem;
    typedef CComPtr<EnvDTE::ProjectItems> DTEProjectItems;
    DTEProject m_pPrj;
    CStringArray m_Files;

public:
    CWorkspaceProject_VC7(DTEProject pPrj) : m_pPrj(pPrj)
    {
        ASSERT(pPrj != NULL);

        DTEProjectItems pItems;
        if (SUCCEEDED(pPrj->get_ProjectItems(&pItems)))
        {
            RecurseAddProjectFiles(pItems);
        }
    }

    virtual ~CWorkspaceProject_VC7()
    {
    }

    void RecurseAddProjectFiles(DTEProjectItems& pItems) 
    {
        if (pItems == NULL) return;

        LONG cItems;
        if (SUCCEEDED(pItems->get_Count(&cItems)))
        {
            for (int i = 1; i <= cItems; ++i)
            {
                DTEProjectItem pItem;
                if (SUCCEEDED(pItems->Item(CComVariant(i), &pItem)))
                {
                    // make sure this item is rooted at this level
                    DTEProjectItems pCollection;
                    if (!SUCCEEDED(pItem->get_Collection(&pCollection))  ||
                        pCollection != pItems)
                    {
                        continue;
                    }

                    if (IsAFile(pItem))
                    {
                        CComBSTR bStr;
                        if (SUCCEEDED(pItem->get_FileNames(1, &bStr)))
                        {
                            m_Files.Add(CString(bStr));
                        }
                    }

                    DTEProjectItems pSubItems;
                    if (SUCCEEDED(pItem->get_ProjectItems(&pSubItems))  &&
                        pSubItems != NULL)
                    {
                        RecurseAddProjectFiles(pSubItems);
                    }
                }
            }
        }
    }

    bool IsAFile(DTEProjectItem& pItem)
    {
        // How do you distinguish between a file item and a non-file item 
        // (such as a folder)?  Good question!  (Wish I has a good answer)...
        // Here I do it by:
        // 1. Making sure there is only 1 file associated with the item at
        //    this level (otherwise it is a folder).
        // 2. Comparing the name to the file name.  If they are the same, 
        //    this is not a file.  This is because the "name" of a file item
        //    is the name of the file without the path, and the "file-name"
        //    is the name of the file with the path.
        // 3. If all the previous checks passed, verify that the file-name
        //    is not pointing to a physical directory.
        //
        // I have considered other ways, but these involve item properties,
        // which I am not sure will be named the same in localized versions
        // of DevEnv..
        
        ASSERT(pItem != NULL);

        // 1 //
        short cFiles;
        if (!SUCCEEDED(pItem->get_FileCount(&cFiles))  ||  cFiles != 1)
        {
            return false;
        }

        // 2 //
        CComBSTR bStrName, bStrFileName;
        if (!SUCCEEDED(pItem->get_Name(&bStrName))              ||
            !SUCCEEDED(pItem->get_FileNames(1, &bStrFileName))  ||
            wcscmp(bStrName, bStrFileName) == 0)
        {
            return false;
        }

        // 3 //
        CString sPath(bStrFileName);
		const DWORD attr = GetFileAttributes(sPath);
        if (attr != ((unsigned)-1)  &&  
			CHK_FLAG(attr, FILE_ATTRIBUTE_DIRECTORY))
        {
            return false;
        }

        return true;
    }

    virtual CString GetName() const
    {
        CString cStr = "Error!";
        CComBSTR bStr;
        if (SUCCEEDED(m_pPrj->get_FileName(&bStr)))
        {
            cStr = bStr;
        }
		if (SUCCEEDED(m_pPrj->get_Kind(&bStr)))
		{
			if (bStr == EnvDTE::ProjectKinds::WebProject)
			{
				cStr = "[Web] " + cStr;
			}
		}
        return cStr;
    }

    virtual int GetFileCount() const
    {
        return m_Files.GetSize();
    }

    virtual IProjectFile *GetFile(int iIndex) const
    {
        ASSERT(iIndex >= 0);
        ASSERT(iIndex < GetFileCount());
        return new CProjectFile_VC7(m_Files[iIndex]);
    }
};


class CWorkspaceInfo_VC7 : public IWorkspaceInfo
{
protected:
    EnvDTE::_DTE *m_pDTE;

    enum 
    { 
        FILTER_NDX_SOLUTION = 0,
        FILTER_NDX_STARTUP  = 1 
    };

    typedef CComPtr<EnvDTE::Project> DTEProject;
    CArray<CAdapt<DTEProject>, CAdapt<DTEProject> > m_arrDTEProjects;


public:
    CWorkspaceInfo_VC7(EnvDTE::_DTE *pDTE) : m_pDTE(pDTE)
    {
        ASSERT(pDTE != NULL);
    }

    virtual ~CWorkspaceInfo_VC7() 
    {
    };

    virtual void Refresh()
    {
        m_arrDTEProjects.RemoveAll();

        CComPtr<EnvDTE::_Solution> pSolution;

        HRESULT hr = m_pDTE->get_Solution(&pSolution);
        if (SUCCEEDED(hr))
        {
			AddSolution(pSolution);
		}
	}

	virtual void AddSolution(CComPtr<EnvDTE::_Solution> pSolution)
	{
        HRESULT hr;
        LONG lCount;
        CComPtr<EnvDTE::Projects> pProjects;

        hr = pSolution->get_Projects(&pProjects);
        if (SUCCEEDED(hr))
        {
            hr = pProjects->get_Count(&lCount);
        }
        if (SUCCEEDED(hr)  &&  lCount)
        {
            for (LONG i = 0; i < lCount; ++i)
            {
                DTEProject pPrj;
                if (SUCCEEDED(pProjects->Item(CComVariant(i + 1), &pPrj)))
                {
					AddProject(pPrj);
                }
            }
        }
        ASSERT(SUCCEEDED(hr));
    }

	virtual void AddProject(DTEProject pPrj)
	{
        // We know there are lCount projects in all, however .NET
        // actually creates virtual project for files that are
        // open but don't belong to any physical project.
        // We will scan through all the projects, making sure
        // that they have a physical file.
        CComBSTR bStr;
        if (SUCCEEDED(pPrj->get_FileName(&bStr))  &&
            bStr.Length() > 0)
        {
            // the project has a physical file, save it 
            // in our list
            m_arrDTEProjects.Add(pPrj);
        }
	}

    virtual CString GetWorkspaceName() const
    {
        CString sName = "Error!";
        CComPtr<EnvDTE::_Solution> pSolution;
        if (SUCCEEDED(m_pDTE->get_Solution(&pSolution)))
        {
            CComBSTR bStr;
            pSolution->get_FullName(&bStr);
            sName = bStr;
        }
        return sName;
    }

    virtual int GetProjectCount() const
    {
        return m_arrDTEProjects.GetSize();
        return 0;
    }

    virtual IWorkspaceProject *GetProject(int iIndex) const 
    {
        ASSERT(iIndex >= 0);
        ASSERT(iIndex < GetProjectCount());
        return new CWorkspaceProject_VC7(m_arrDTEProjects[iIndex]);
    }

    virtual IWorkspaceProject *GetProject(CComVariant id) const 
    {
        CComPtr<EnvDTE::_Solution> pSolution;
        if (SUCCEEDED(m_pDTE->get_Solution(&pSolution)))
        {
            CComPtr<EnvDTE::Projects> pProjects;
            if (SUCCEEDED(pSolution->get_Projects(&pProjects)))
            {
                CComPtr<EnvDTE::Project> pProject;
                if (SUCCEEDED(pProjects->Item(id, &pProject)))
                {
                    return new CWorkspaceProject_VC7(pProject);
                }
            }
        }
        ASSERT(FALSE);
        return NULL;
    }

    
    HRESULT GetStartupProjectsSafeArray(VARIANT& v) const
    {
        CComPtr<EnvDTE::_Solution> pSolution;
        HRESULT hr;
        hr = m_pDTE->get_Solution(&pSolution);
        if (SUCCEEDED(hr))
        {
            CComPtr<EnvDTE::SolutionBuild> pSolutionBuild;
            hr = pSolution->get_SolutionBuild(&pSolutionBuild);
            if (SUCCEEDED(hr))
            {
                hr = pSolutionBuild->get_StartupProjects(&v);
            }
        }
        return hr;
    }

    virtual int GetWorkspaceFilterCount() const
    {
        return 2;
    }

    virtual LPCTSTR GetWorkspaceFilterName(int iFilterIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_SOLUTION:
                return "Solution";
                
            case FILTER_NDX_STARTUP:
                return "Startup Projects";

            default:
                ASSERT(0);
        }
        return "";
    }

    virtual int GetWorkspaceFilterProjectCount(int iFilterIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_SOLUTION:
                return GetProjectCount();
                
            case FILTER_NDX_STARTUP:
            {
                VARIANT v;
                v.vt = VT_EMPTY;
                if (SUCCEEDED(GetStartupProjectsSafeArray(v)))
                {
                    LRESULT lCount = 0;
                    SafeArrayGetUBound(v.parray, 1, &lCount);
                    VariantClear(&v);
                    return lCount + 1;
                }
                ASSERT(0);
                return 0;
            }

            default:
                ASSERT(0);
        }
        return 0;
    }

    virtual IWorkspaceProject *GetWorkspaceFilterProject(int iFilterIndex,
        int iProjectIndex) const
    {
        switch (iFilterIndex)
        {
            case FILTER_NDX_SOLUTION:
                return GetProject(iProjectIndex);
                
            case FILTER_NDX_STARTUP:
            {
                VARIANT v;
                v.vt = VT_EMPTY;
                IWorkspaceProject *pPrj = NULL;
                if (SUCCEEDED(GetStartupProjectsSafeArray(v)))
                {
                    LONG l = iProjectIndex;
                    VARIANT vElem;
                    vElem.vt = VT_EMPTY;
                    if (SUCCEEDED(SafeArrayGetElement(v.parray, &l, &vElem)))
                    {
                        pPrj = GetProject(vElem);
                        VariantClear(&vElem);
                    }
                    VariantClear(&v);
                }
                return pPrj;
            }

            default:
                ASSERT(0);
        }
        return NULL;
    }
};

class CWorkspaceInfo_VC8 : public CWorkspaceInfo_VC7
{
public:
    CWorkspaceInfo_VC8(EnvDTE::_DTE *pDTE) : CWorkspaceInfo_VC7(pDTE)
	{
	}

	virtual void AddProject(DTEProject pPrj)
	{
        // We know there are lCount projects in all, however .NET
        // actually creates virtual project for files that are
        // open but don't belong to any physical project.
        // We will scan through all the projects, making sure
        // that they have a physical file.
        CComBSTR bStr;
        if (SUCCEEDED(pPrj->get_FileName(&bStr))  &&
            bStr.Length() > 0)
        {
            // the project has a physical file, save it 
            // in our list
            m_arrDTEProjects.Add(pPrj);
        }

		if (SUCCEEDED(pPrj->get_Kind(&bStr))  &&
			bStr == EnvDTE80::vsProjectKindSolutionFolder)
		{
			CComPtr<EnvDTE::ProjectItems> pItems;
			if (SUCCEEDED(pPrj->get_ProjectItems(&pItems))  &&  pItems != NULL)
			{
				LONG cItems;
				if (SUCCEEDED(pItems->get_Count(&cItems)))
				{
					for (int i = 1; i <= cItems; ++i)
					{
						CComPtr<EnvDTE::ProjectItem> pItem;
						CComBSTR name;
						if (SUCCEEDED(pItems->Item(CComVariant(i), &pItem)))
						{
							CComQIPtr<EnvDTE::Project> pr2;
							CComPtr<IDispatch> disp;
							pItem->get_Object(&disp);
							pr2=disp;
							if (pr2 != NULL)
							{
								AddProject(DTEProject(pr2));

							}
						}
					}
				}
			}
		}
	}

    virtual IWorkspaceProject *GetProject(CComVariant id) const 
    {
		ASSERT(id.vt == VT_BSTR);
		if (id.vt != VT_BSTR) return NULL;
		CComBSTR bstrID = id.bstrVal;
		CComBSTR bstrProjectUniqueName;

		// this way works with solution folders (see a faster way
		// in VC7 version that does not)
		for (int i = 0; i < m_arrDTEProjects.GetSize(); ++i)
		{
			DTEProject pProject = m_arrDTEProjects[i];
			if (SUCCEEDED(pProject->get_UniqueName(&bstrProjectUniqueName)))
			{
				if (bstrProjectUniqueName == bstrID)
				{
					return new CWorkspaceProject_VC7(pProject);
				}
            }
        }
        ASSERT(FALSE);
        return NULL;
    }

};

void InitializeWorkspaceInfo_VC_NET(EnvDTE::_DTE *pDTE)
{
    ASSERT(g_pWorkspaceInfo == NULL);
    ASSERT(pDTE != NULL);

	CComQIPtr<EnvDTE80::DTE2> pDTE_V8 = pDTE;
	if (pDTE != NULL)
	{
		// VS 2005 (aka 8)
	    g_pWorkspaceInfo = new CWorkspaceInfo_VC8(pDTE);
	}
	else
	{
		// VS 2000 (aka 7), VS 2003 (aka 7.1)
	    g_pWorkspaceInfo = new CWorkspaceInfo_VC7(pDTE);
	}
}

#endif // TARGET_VC7
