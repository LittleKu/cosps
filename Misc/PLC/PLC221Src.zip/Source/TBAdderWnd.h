/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// TBAdderWnd.h : header file
//

#if !defined(AFX_TBADDERWND_H__88B97FC6_C3B6_46FD_A323_248E89FCCBD4__INCLUDED_)
#define AFX_TBADDERWND_H__88B97FC6_C3B6_46FD_A323_248E89FCCBD4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTBAdderWnd window

class CTBAdderWnd : public CWnd
{
// Construction
public:
	CTBAdderWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTBAdderWnd)
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTBAdderWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTBAdderWnd)
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    static HHOOK m_hHook;

    static LRESULT CALLBACK CatchToolbarTitle(int nCode, 
        WPARAM wParam, LPARAM lParam);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBADDERWND_H__88B97FC6_C3B6_46FD_A323_248E89FCCBD4__INCLUDED_)
