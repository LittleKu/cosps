/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// LineCount.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <initguid.h>
#include "LineCount.h"
#include "Config.h"
#include "ExtrnSrc\AddInComm.h"
#include "ExtrnSrc\AICLoader.h"
#include "ParserManager.h"

#ifdef TARGET_VC6
#include "Commands.h"
#include "DSAddIn.h"
#endif

#ifdef TARGET_VC7
#include "ConnectVC7.h"
#endif

#define REG_KEY_BASE    "WndTabs.com\\LineCounter"
#define REG_KEY_SUB     "Options"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CComModule _Module;

int g_iVerMaj;
int g_iVerMin;


BEGIN_OBJECT_MAP(ObjectMap)
    #ifdef TARGET_VC6
        OBJECT_ENTRY(CLSID_DSAddIn, CDSAddIn)       // VC6 addin
    #endif
    #ifdef TARGET_VC7
        OBJECT_ENTRY(__uuidof(Connect), CConnect)   // VC7 addin
    #endif
END_OBJECT_MAP()

#ifdef TARGET_VC6
BEGIN_OBJECT_MAP(ObjectMapVC6Only)
    OBJECT_ENTRY(CLSID_DSAddIn, CDSAddIn)
END_OBJECT_MAP()
#endif

bool BetaHasExpired();


/////////////////////////////////////////////////////////////////////////////
// CLineCountApp

class CLineCountApp : public CWinApp
{
public:
    CLineCountApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CLineCountApp)
    public:
    virtual BOOL InitInstance();
    virtual int ExitInstance();
    //}}AFX_VIRTUAL

    //{{AFX_MSG(CLineCountApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CLineCountApp

BEGIN_MESSAGE_MAP(CLineCountApp, CWinApp)
    //{{AFX_MSG_MAP(CLineCountApp)
        // NOTE - the ClassWizard will add and remove mapping macros here.
        //    DO NOT EDIT what you see in these blocks of generated code!
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// The one and only CLineCountApp object

CLineCountApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CLineCountApp construction

CLineCountApp::CLineCountApp()
{
    // TODO: add construction code here,
    // Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// CLineCountApp initialization
    
CString GetVersionForRegKey()
{
    char s[256];

    char path[MAX_PATH];
    GetModuleFileName(AfxGetInstanceHandle(), path, sizeof(path));
    aiclGetFileVersion(path, s);

    char *pos = strchr(s, '.');
    if (pos == NULL) return "0.0";
    ++pos;
    if (!*pos) return "0.0";
    if (isdigit(*pos)) { ++pos; }
    *pos = '\0';

    if (RUNNING_IN_DOT_NET())
    {
        strcat(s, ".NET");
    }

    return s;
}

CString GetRegKeyBase()
{
    return ("Software\\" REG_KEY_BASE "\\") + GetVersionForRegKey();
}


BOOL CLineCountApp::InitInstance()
{
    SetRegistryKey(REG_KEY_BASE);
    CString sVerForReg = GetVersionForRegKey();
    ASSERT(strlen(m_pszProfileName) > (size_t)sVerForReg.GetLength());
    strcpy((char *)m_pszProfileName, sVerForReg);

    RegisterHHWindowType(1, "MainWnd");

    // Trick: VC6 tries to find all the registered objects from this module
    // (when adding through Tools|Customize|Addins), so we'll only register
    // the VC6 addin if we detect that we are running under VC6
#ifdef TARGET_VC6
    if (GetModuleHandle("MSDEV.EXE") != NULL  ||
        GetModuleHandle("EVC.EXE")   != NULL)
    {
        _Module.Init(ObjectMapVC6Only, m_hInstance);
    }
    else
#endif
    {
        _Module.Init(ObjectMap, m_hInstance);
    }

    AfxEnableControlContainer();

    return CWinApp::InitInstance();
}

int CLineCountApp::ExitInstance()
{
    _Module.Term();
    return CWinApp::ExitInstance();
}

HADDIN s_hAddin = NULL;

void OnAddinConnect()
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    aiclUseDebugLibrary(FALSE);
    aiclLoadAICLibrary(AfxGetInstanceHandle());

    GetConfiguration();

    CParserManager::Get().LoadConfig();

    // == Register With AddInComm ==
    // LineCounter doens't export any commands, but registration broadcasts
    // it's presence.
    char buf[256], *p;
    int verextra;

    strcpy(buf, "Build ");
    p = buf + strlen(buf);

    // use loader facilities to read own version resource...
    aiclGetModuleVersion("LineCount.dll", p);  

    // extract it numerically
    sscanf(p, "%d.%d.%d", &g_iVerMaj, &g_iVerMin, &verextra);

    // do actual registration
    s_hAddin = AICRegisterAddIn("Line Counter", g_iVerMaj, g_iVerMin, 
        verextra);
    AICSetAddInVersionString(s_hAddin, buf);

	// check if expired
	if (BetaHasExpired())
	{
		AfxMessageBox(
			"This beta of Line Counter has expired.  Please check the web site for a newer version.",
			MB_OK | MB_ICONSTOP);
	}
}

void OnAddinDisconnect()
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    if (s_hAddin)
    {
        AICUnregisterAddIn(s_hAddin);
    }

    CParserManager::Get().SaveConfig();
    WriteConfiguration();
}

CString GetOwnVersion()
{
    char path[MAX_PATH + 1], ver[1024];
    GetModuleFileName(AfxGetInstanceHandle(), path, countof(path));
    aiclGetModuleVersion(path, ver);
    return ver;
}

// Returns TRUE if the beta has expired.  Betas expire 6 months
// after initially released
bool BetaHasExpired()
{
	CString ver = GetOwnVersion();
	ver.MakeLower();
	if (ver.Find("alpha") >= 0  ||  ver.Find("beta") >= 0)
	{
		COleDateTime ExpiresDate, now;

		now = COleDateTime::GetCurrentTime();

		// expires 120 days after build
		ExpiresDate.ParseDateTime(__DATE__, VAR_DATEVALUEONLY, LANG_ENGLISH);
		ExpiresDate += COleDateTimeSpan(120, 0, 0, 0);

		if (ExpiresDate <= now)
		{
			return true;
		}
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////
// Special entry points required for inproc servers

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    HRESULT hr = S_FALSE;
    hr = _Module.GetClassObject(rclsid, riid, ppv);
    return hr;
}

STDAPI DllCanUnloadNow(void)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    HRESULT hr = AfxDllCanUnloadNow();
    if (hr == S_OK)
    {
        hr = (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
    }
    return hr;
}

// by exporting DllRegisterServer, you can use regsvr32.exe
STDAPI DllRegisterServer(void)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    return _Module.UnregisterServer();
}


/////////////////////////////////////////////////////////////////////////////
// Debugging support

// GetLastErrorDescription is used in the implementation of the VERIFY_OK
//  macro, defined in stdafx.h.

#ifdef _DEBUG

void GetLastErrorDescription(CComBSTR& bstr)
{
    CComPtr<IErrorInfo> pErrorInfo;
    if (GetErrorInfo(0, &pErrorInfo) == S_OK)
        pErrorInfo->GetDescription(&bstr);
}

#endif //_DEBUG
