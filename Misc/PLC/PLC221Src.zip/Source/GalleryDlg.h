/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// GalleryDlg.h : header file
//

#if !defined(AFX_GALLERYDLG_H__23BAEA87_B9CB_410E_91CE_0911AD210F15__INCLUDED_)
#define AFX_GALLERYDLG_H__23BAEA87_B9CB_410E_91CE_0911AD210F15__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//{{AFX_INCLUDES()
#include "webbrowser2.h"
//}}AFX_INCLUDES

/////////////////////////////////////////////////////////////////////////////
// CGalleryDlg dialog

class CGalleryDlg : public CResizableDialog
{
// Construction
public:
	CGalleryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGalleryDlg)
	enum { IDD = IDD_GALLERY };
	CStatic	m_ctlMessage;
	CString	m_sMessage;
	CWebBrowser2	m_ctlWebBrowser;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGalleryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGalleryDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnNavigateComplete2Html(LPDISPATCH pDisp, VARIANT FAR* URL);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
    afx_msg LRESULT OnGotGalleryInfo(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

    static UINT BeginFetchGalleryInfo(LPVOID pContext);

    CString m_sGalleryError;
    CComBSTR xm_sPendingHTML;
    CString m_sPendingHTML;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GALLERYDLG_H__23BAEA87_B9CB_410E_91CE_0911AD210F15__INCLUDED_)
