/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// DSAddIn.cpp : implementation file
//

#include "stdafx.h"

#ifdef TARGET_VC6

#include "LineCount.h"
#include "DSAddIn.h"
#include "Commands.h"
#include "Config.h"
#include "TBAdderWnd.h"

#include "ExtrnSrc\AICLoader.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CDSAddIn *g_pDSAddin = NULL;

// This is called when the user first loads the add-in, and on start-up
//  of each subsequent Developer Studio session
STDMETHODIMP CDSAddIn::OnConnection(IApplication* pApp, VARIANT_BOOL bFirstTime,
        long dwCookie, VARIANT_BOOL* OnConnection)
{
    // must be before the AFX_MANAGE_STATE
    char host_path[1024];
    GetModuleFileName(NULL, host_path, countof(host_path));

    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    g_pDSAddin = this;

    // assume the worst
    *OnConnection = VARIANT_FALSE;
    m_pCommands = NULL;

    // Store info passed to us
    IApplication* pApplication = NULL;
    if (FAILED(pApp->QueryInterface(IID_IApplication, (void**) &pApplication))
        || pApplication == NULL)
    {
        return S_OK;
    }

    OnAddinConnect();

    m_pApplication = pApplication;

    m_dwCookie = dwCookie;

    // Create command dispatch, send info back to DevStudio
    CCommandsObj::CreateInstance(&m_pCommands);
    m_pCommands->AddRef();

    // The QueryInterface above AddRef'd the Application object.  It will
    //  be Release'd in CCommand's destructor.
    m_pCommands->SetApplicationObject(pApplication);

    // (see stdafx.h for the definition of VERIFY_OK)

    VERIFY_OK(pApplication->SetAddInInfo((long) AfxGetInstanceHandle(),
        (LPDISPATCH) m_pCommands, IDR_TOOLBAR_MEDIUM, IDR_TOOLBAR_LARGE, m_dwCookie));

    // Inform DevStudio of the commands we implement

    // TODO: Replace the AddCommand call below with a series of calls,
    //  one for each command your add-in will add.

    // The command name should not be localized to other languages.  The 
    //  tooltip, command description, and other strings related to this
    //  command are stored in the string table (IDS_CMD_STRING) and should
    //  be localized.
    LPCTSTR szCommand = _T("LCConsole");
    VARIANT_BOOL bRet;
    CString strCmdString;
    strCmdString.LoadString(IDS_CMD_STRING);
    strCmdString = szCommand + strCmdString;
    CComBSTR bszCmdString(strCmdString);
    CComBSTR bszMethod(_T("LC_Console"));
    CComBSTR bszCmdName(szCommand);
/*
    VERIFY_OK(pApplication->AddCommand(bszCmdString, bszMethod, 0, m_dwCookie, &bRet));
    if (bRet == VARIANT_FALSE)
    {
        // AddCommand failed because a command with this name already
        //  exists.  You may try adding your command under a different name.
        //  Or, you can fail to load as we will do here.
        return S_OK;
    }
*/

    szCommand = _T("CountLines");
    strCmdString.LoadString(IDS_CMD_STRING2);
    strCmdString = szCommand + strCmdString;
    bszCmdString = strCmdString;
    bszMethod = _T("LC_Go");
    bszCmdName = szCommand;
    VERIFY_OK(pApplication->AddCommand(bszCmdString, bszMethod, 0, 
        m_dwCookie, &bRet));

    if (bFirstTime == VARIANT_FALSE)
    {
        // see if we have a registry setting forcing a first time init
        bFirstTime = VARIANT_TRUE;
        int i = 0;
        CString sHost;
        while (AfxExtractSubString(sHost, cfg_sInitedEnvs, i++))
        {
            if (sHost.CompareNoCase(host_path) == 0)
            {
                bFirstTime = FALSE;
                break;
            }
        }
    }

    // the following is a trick that will allow up to add a toolbar even
    // if bFirstTime is false
    if (bFirstTime == VARIANT_TRUE)
    {
        CTBAdderWnd *pAdder = new CTBAdderWnd();
        pAdder->CreateEx(0, NULL, "", WS_CHILD, CRect(0, 0, 1, 1), 
            CWnd::GetDesktopWindow(), 0);
        pAdder->PostMessage(WM_CLOSE);
        cfg_sInitedEnvs += '\n';
        cfg_sInitedEnvs += host_path;
    }

    *OnConnection = VARIANT_TRUE;
    return S_OK;
}

// This is called on shut-down, and also when the user unloads the add-in
STDMETHODIMP CDSAddIn::OnDisconnection(VARIANT_BOOL bLastTime)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    OnAddinDisconnect();

    if (m_pCommands)
    {
        m_pCommands->Release();
        m_pCommands = NULL;
    }

    return S_OK;
}

void CDSAddIn::AddToolbarCmds() const
{
    LPCTSTR szCommand = _T("CountLines");
    CComBSTR bszCmdName(szCommand);

    VERIFY_OK(m_pApplication->
        AddCommandBarButton(dsGlyph, bszCmdName, m_dwCookie));
}

#endif // TARGET_VC6