/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// Options.cpp : implementation file
//

#include "stdafx.h"
#include "LineCount.h"
#include "Options.h"
#include "Config.h"
#include "InsertExtDlg.h"
#include "InsertFileDlg.h"
#include "Help\HelpIDs.h"
#include "Utils.h"
#include "ParserManager.h"
#include "WorkspaceInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsSheet

IMPLEMENT_DYNAMIC(COptionsSheet, CHHPropSheet)

COptionsSheet::COptionsSheet(CWnd* pParentWnd, UINT iSelectPage)
	: CHHPropSheet("Options", pParentWnd, iSelectPage)
{
    AddPage(&m_FilesPage);
    AddPage(&m_ExtPage);
    AddPage(&m_StatsPage);
    AddPage(&m_OptionsPage);
}

COptionsSheet::~COptionsSheet()
{
}


BEGIN_MESSAGE_MAP(COptionsSheet, CHHPropSheet)
	//{{AFX_MSG_MAP(COptionsSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsSheet message handlers



/////////////////////////////////////////////////////////////////////////////
// CPageWithList class

IMPLEMENT_DYNCREATE(CPageWithList, CAutoPropPage)

CPageWithList::CPageWithList(CListBox& managedList, int iDelButton, 
    int iInsButton, UINT nIDTemplate, bool bAllowImplicit /*= true*/, 
    int iHelpID /*= -1*/, UINT nIDCaption /*= 0*/) : 
    CAutoPropPage(nIDTemplate, bAllowImplicit, iHelpID, nIDCaption),
    m_pManagedList(&managedList), m_iDelButton(iDelButton), 
    m_iInsButton(iInsButton)
{
}

void CPageWithList::InitPageWithList()
{
    m_pUndoWnd = GetDlgItem(IDC_UNDO);
    SetLastUndo(none, "");
    SetModified(FALSE);
}

void CPageWithList::DeleteString(CString str)
{
    m_pManagedList->DeleteString(m_pManagedList->FindStringExact(0, str));
    OnUpdateList();
    SetLastUndo(del, str);
	SetModified();
}

void CPageWithList::InsertString(CString str)
{
    m_pManagedList->SetCurSel(m_pManagedList->AddString(str));
    OnUpdateList();
    SetLastUndo(ins, str);
    HandlerImpl_OnSelChange();
	SetModified();
}

void CPageWithList::SetLastUndo(undo_ops op, CString val)
{
    m_LastUndoOp = op;
    m_sLastUndoVal = val;
    m_pUndoWnd->SetWindowText("Und&o");
    m_pUndoWnd->EnableWindow(m_LastUndoOp != none);
}

void CPageWithList::HandlerImpl_OnSelChange() 
{
    BOOL bEnable = (m_pManagedList->GetCurSel() != LB_ERR);
    GetDlgItem(m_iDelButton)->EnableWindow(bEnable);
}

void CPageWithList::HandlerImpl_OnUndo() 
{
    switch (m_LastUndoOp)
    {
        case del:
            InsertString(m_sLastUndoVal);
            m_LastUndoOp = ins;
            break;

        case ins:
            DeleteString(m_sLastUndoVal);
            m_LastUndoOp = del;
            break;

        default:
            return;
    }

    m_pUndoWnd->SetWindowText("Red&o");
}

void CPageWithList::HandlerImpl_OnDelete() 
{
    CString sToDel;
    int iCurSel = m_pManagedList->GetCurSel();

    if (iCurSel < 0)
        return;

    m_pManagedList->GetText(iCurSel, sToDel);
    DeleteString(sToDel);

    if (iCurSel > m_pManagedList->GetCount()) iCurSel--;
    if (iCurSel >= 0)
        m_pManagedList->SetCurSel(iCurSel);

    HandlerImpl_OnSelChange();
    OnUpdateList();
}

int CPageWithList::HandlerImpl_OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex) 
{
    if (pListBox == m_pManagedList)
    {
	    switch (nKey)
        {
            case VK_DELETE:
            {
                if (m_pManagedList->GetCurSel() != LB_ERR)
                {
                    GetParent()->SendMessage(WM_COMMAND, m_iDelButton, NULL);
                }
                break;
            }

            case VK_INSERT:
            {
                GetParent()->SendMessage(WM_COMMAND, m_iInsButton, NULL);
                break;
            }
        }
    }
	
    return CAutoPropPage::OnVKeyToItem(nKey, pListBox, nIndex);
}



/////////////////////////////////////////////////////////////////////////////
// CFilesPage property page

IMPLEMENT_DYNCREATE(CFilesPage, CPageWithList)

CFilesPage::CFilesPage() : CPageWithList(m_FileList, IDC_DELETEFILE,
    IDC_INSERTFILE, CFilesPage::IDD)
{
	//{{AFX_DATA_INIT(CFilesPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

    m_iHelpID = IDH_OPT_FILES;

	strpair strs[] = 
    {
        { &m_sFileList,   &cfg_sFileIgnoreList }
    };
	
    InitAutoStrs(countof(strs), strs);
}

CFilesPage::~CFilesPage()
{
}

void CFilesPage::DoDataExchange(CDataExchange* pDX)
{
	CPageWithList::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilesPage)
	DDX_Control(pDX, IDC_FILE_LIST, m_FileList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilesPage, CPageWithList)
	//{{AFX_MSG_MAP(CFilesPage)
	ON_BN_CLICKED(IDC_INSERTFILE, OnInsertfile)
	ON_BN_CLICKED(IDC_DELETEFILE, OnDeletefile)
	ON_BN_CLICKED(IDC_UNDO, OnUndo)
	ON_BN_CLICKED(IDC_CLEARALLFILES, OnClearallfiles)
	ON_LBN_SELCHANGE(IDC_FILE_LIST, OnSelchangeFileList)
	ON_LBN_SELCANCEL(IDC_FILE_LIST, OnSelchangeFileList)
	ON_WM_VKEYTOITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilesPage message handlers

BOOL CFilesPage::OnInitDialog() 
{
	CPageWithList::OnInitDialog();

    InitPageWithList();
    FillFileList();

    return TRUE;
}

void CFilesPage::OnInsertfile() 
{
    CInsertFileDlg dlg;
    
    if (dlg.DoModal() == IDOK)
    {
        InsertString(dlg.m_sFile);
    }
}

void CFilesPage::OnDeletefile() 
{
    HandlerImpl_OnDelete();
}

void CFilesPage::OnUndo() 
{
    HandlerImpl_OnUndo();
}

void CFilesPage::OnClearallfiles() 
{
    m_sFileList = "";
    FillFileList();
    SetLastUndo(none, "");
}

void CFilesPage::OnSelchangeFileList() 
{
    HandlerImpl_OnSelChange();
}

int CFilesPage::OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex) 
{
    return HandlerImpl_OnVKeyToItem(nKey, pListBox, nIndex);
}

void CFilesPage::OnUpdateList()
{
    m_sFileList.Empty();

    const int items = m_FileList.GetCount();
    CString cStr;
    for (int i = 0; i < items; ++i)
    {
         if (!m_sFileList.IsEmpty())
         {
             m_sFileList += LIST_DELIMITER;
         }
         m_FileList.GetText(i, cStr);
         m_sFileList += cStr;
    }
}

void CFilesPage::FillFileList()
{
    CStringList strList;
    m_FileList.ResetContent();
    String2StringList(m_sFileList, LIST_DELIMITER, strList);
    POSITION p = strList.GetHeadPosition();
    while (p)
    {
        m_FileList.AddString(strList.GetNext(p));
    }

    OnUpdateList();
    OnSelchangeFileList();
    SetModified();
}


/////////////////////////////////////////////////////////////////////////////
// CExtensionsPage property page

IMPLEMENT_DYNCREATE(CExtensionsPage, CAutoPropPage)

CExtensionsPage::CExtensionsPage() : CAutoPropPage(CExtensionsPage::IDD, true)
{
	//{{AFX_DATA_INIT(CExtensionsPage)
	//}}AFX_DATA_INIT

    m_iHelpID = IDH_OPT_EXT;

    CParserManager::Get().GetState(m_OldPMState);
}

CExtensionsPage::~CExtensionsPage()
{
}

void CExtensionsPage::DoDataExchange(CDataExchange* pDX)
{
	CAutoPropPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExtensionsPage)
	DDX_Control(pDX, IDC_EXT_LIST, m_ExtList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExtensionsPage, CAutoPropPage)
	//{{AFX_MSG_MAP(CExtensionsPage)
	ON_BN_CLICKED(IDC_RESET, OnResetList)
	ON_WM_VKEYTOITEM()
	ON_BN_CLICKED(IDC_INSERTEXT, OnInsertext)
	ON_BN_CLICKED(IDC_DELETEEXT, OnDeleteext)
	ON_BN_CLICKED(IDC_UNDO, OnUndo)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_EXT_LIST, OnItemchangedExtList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExtensionsPage message handlers

BOOL CExtensionsPage::OnInitDialog() 
{
	CAutoPropPage::OnInitDialog();

    m_ExtList.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    m_ExtList.InsertColumn(0, "Extension", LVCFMT_LEFT, 100);
    m_ExtList.InsertColumn(1, "Parser",    LVCFMT_LEFT, 200);
	
    m_pUndoWnd = GetDlgItem(IDC_UNDO);
    m_pUndoWnd->EnableWindow(FALSE);

    FillExtList();

    m_ExtList.SetColumnWidth(1, LVSCW_AUTOSIZE);

    OnSelChange();

	return TRUE;
}

void CExtensionsPage::OnCancel()
{
    CAutoPropPage::OnCancel();
    CParserManager::Get().SetState(m_OldPMState);
}

void CExtensionsPage::OnSelChange() 
{
    const bool bHasSelected = m_ExtList.GetFirstSelectedItemPosition() != NULL;

    GetDlgItem(IDC_DELETEEXT)->EnableWindow(bHasSelected);
}

void CExtensionsPage::OnItemchangedExtList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

    OnSelChange();
	
	*pResult = 0;
}

void CExtensionsPage::OnResetList() 
{
    MarkUndo();
    CParserManager::Get().ResetPairs();
    FillExtList();
    SetModified(TRUE);
}

void CExtensionsPage::MarkUndo()
{
    CParserManager::Get().GetState(m_LastUndoVal);
    m_pUndoWnd->SetWindowText("Und&o");
    m_pUndoWnd->EnableWindow(TRUE);
}

void CExtensionsPage::OnInsertext() 
{
    CInsertExtDlg dlg;
    
    if (dlg.DoModal() == IDOK)
    {
        MarkUndo();
        CParserManager::parser_fileext_pair tmp;
        tmp.sExt = dlg.m_Ext;
        tmp.pParser = dlg.m_pParser;
        CParserManager::Get().AddPair(tmp);
        FillExtList();
    }
}

void CExtensionsPage::OnDeleteext() 
{
    MarkUndo();
    int ndx = -1;
    for (;;)
    {
        ndx = m_ExtList.GetNextItem(ndx, LVNI_SELECTED);
        if (ndx < 0) break;
        CParserManager::Get().RemovePair(m_ExtList.GetItemText(ndx, 0));
    }
    FillExtList();
}

void CExtensionsPage::OnUndo() 
{
    undo_t tmpState;
    CParserManager::Get().GetState(tmpState);
    CParserManager::Get().SetState(m_LastUndoVal);
    m_LastUndoVal = tmpState;
    FillExtList();
    m_pUndoWnd->SetWindowText("Red&o");
}

int CExtensionsPage::OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex) 
{
//    return HandlerImpl_OnVKeyToItem(nKey, pListBox, nIndex);
    return 0;
}

void CExtensionsPage::InsertPair(CParserManager::parser_fileext_pair& pair)
{
    int ndx = m_ExtList.InsertItem(0, pair.sExt);
    m_ExtList.SetItemData(ndx, (DWORD)pair.pParser);
    m_ExtList.SetItem(ndx, 1, LVIF_TEXT, 
        CString(MAKEINTRESOURCE(pair.pParser->GetParserNameResourceID())), 
        0, 0, 0, 0);
}


void CExtensionsPage::FillExtList()
{
    CParserManager::PairArray arr;
    CParserManager::Get().GetPairs(arr);

    m_ExtList.DeleteAllItems();

    for (int i = 0; i < arr.GetSize(); ++i)
    {
        InsertPair(arr[i]);
    }

    OnSelChange();
    SetModified();
}



/////////////////////////////////////////////////////////////////////////////
// CStatsPage property page

IMPLEMENT_DYNCREATE(CStatsPage, CAutoPropPage)

BEGIN_HELP_IDS(CStatsPage)
    IDC_STATIC_DEFAULT_FILTER,  IDC_DEFAULT_FILTER,
    IDC_STATIC_DEFAULT_FILTER2, IDC_DEFAULT_FILTER

END_HELP_IDS()

CStatsPage::CStatsPage() : CAutoPropPage(CStatsPage::IDD)
{
	//{{AFX_DATA_INIT(CStatsPage)
	m_bCheckComments = FALSE;
	m_bCountBlanks = FALSE;
	m_bIncBad_Export = FALSE;
	m_bIncBad_Grid = FALSE;
	m_bIncFilter_Export = FALSE;
	m_bIncFilter_Grid = FALSE;
	//}}AFX_DATA_INIT
    
    m_iHelpID = IDH_OPT_STATS;

    varpair vars[] = 
    {
        { &m_bCountBlanks,      &cfg_bProcessBlanks   },
        { &m_bCheckComments,    &cfg_bProcessComments },
        { &m_iDefFilter,        &cfg_iDefaultFilter   },
        { &m_sfFiltered,        &cfg_ShowFiltered     },
        { &m_sfBadFiles,        &cfg_ShowBadFiles     }
    };

    InitAutoVars(countof(vars), vars);
}

CStatsPage::~CStatsPage()
{
}

void CStatsPage::DoDataExchange(CDataExchange* pDX)
{
	CAutoPropPage::DoDataExchange(pDX);

    if (!pDX->m_bSaveAndValidate)
    {
        m_bIncBad_Grid      = CHK_FLAG(m_sfBadFiles, SF_GRID);
        m_bIncBad_Export    = CHK_FLAG(m_sfBadFiles, SF_EXPORT);
        m_bIncFilter_Grid   = CHK_FLAG(m_sfFiltered, SF_GRID);
        m_bIncFilter_Export = CHK_FLAG(m_sfFiltered, SF_EXPORT);
    }

	//{{AFX_DATA_MAP(CStatsPage)
	DDX_Control(pDX, IDC_DEFAULT_FILTER, m_DefFilter);
	DDX_Check(pDX, IDC_CHECKCOMMENTS, m_bCheckComments);
	DDX_Check(pDX, IDC_COUNTBLANK, m_bCountBlanks);
	DDX_Check(pDX, IDC_INCBAD_EXPORT, m_bIncBad_Export);
	DDX_Check(pDX, IDC_INCBAD_GRID, m_bIncBad_Grid);
	DDX_Check(pDX, IDC_INCFILTER_EXPORT, m_bIncFilter_Export);
	DDX_Check(pDX, IDC_INCFILTER_GRID, m_bIncFilter_Grid);
	//}}AFX_DATA_MAP

    if (!pDX->m_bSaveAndValidate)
    {
        m_DefFilter.SetCurSel(m_iDefFilter);
    }
    else
    {
        m_iDefFilter = m_DefFilter.GetCurSel();
        if (m_iDefFilter < 0  ||  
            m_iDefFilter > m_DefFilter.GetCount())
        {
            m_iDefFilter = 0;
        }

        m_sfBadFiles = 0;
        if (m_bIncBad_Export) m_sfBadFiles |= SF_EXPORT;
        if (m_bIncBad_Grid)   m_sfBadFiles |= SF_GRID;

        m_sfFiltered = 0;
        if (m_bIncFilter_Export) m_sfFiltered |= SF_EXPORT;
        if (m_bIncFilter_Grid)   m_sfFiltered |= SF_GRID;
    }
}

BEGIN_MESSAGE_MAP(CStatsPage, CAutoPropPage)
	//{{AFX_MSG_MAP(CStatsPage)
	ON_BN_CLICKED(IDC_CHECKCOMMENTS, DoModified)
	ON_BN_CLICKED(IDC_COUNTBLANK, DoModified)
	ON_CBN_SELCHANGE(IDC_DEFAULT_FILTER, DoModified)
	ON_BN_CLICKED(IDC_INCFILTER_GRID, DoModified)
	ON_BN_CLICKED(IDC_INCFILTER_EXPORT, DoIncFilterExport)
	ON_BN_CLICKED(IDC_INCBAD_GRID, DoModified)
	ON_BN_CLICKED(IDC_INCBAD_EXPORT, OnIncBadExport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStatsPage message handlers

BOOL CStatsPage::OnInitDialog() 
{
	CAutoPropPage::OnInitDialog();

    PopuplateDefaultFilters(g_pWorkspaceInfo);

	return TRUE;
}

void CStatsPage::PopuplateDefaultFilters(IWorkspaceInfo *pWI)
{
    const int nWorkspaceFilters = pWI->GetWorkspaceFilterCount();
    ASSERT(nWorkspaceFilters > 0);
    for (int i = 0; i < nWorkspaceFilters; ++i)
    {
        CString cStr;
        cStr = pWI->GetWorkspaceFilterName(i);
        cStr.Insert(0, '<');
        cStr += '>';

        const int ndx = m_DefFilter.AddString(cStr);
        m_DefFilter.SetItemData(ndx, i);
    }
    UpdateData(FALSE);
}


void CStatsPage::DoModified() 
{
    SetModified();
}

void CStatsPage::DoIncFilterExport() 
{
    bool bDoModify = true;
	UpdateData();
    if (m_bIncFilter_Export)
    {
        if (AfxMessageBox(IDS_WARN_SPECIAL_FILES_IN_EXPORT, 
            MB_YESNO | MB_ICONWARNING) != IDYES)
        {
            m_sfFiltered &= ~SF_EXPORT;
            UpdateData(FALSE);
            bDoModify = false;
        }
    }
    if (bDoModify) DoModified();
}

void CStatsPage::OnIncBadExport() 
{
    bool bDoModify = true;
	UpdateData();
    if (m_bIncBad_Export)
    {
        if (AfxMessageBox(IDS_WARN_SPECIAL_FILES_IN_EXPORT, 
            MB_YESNO | MB_ICONWARNING) != IDYES)
        {
            m_sfBadFiles &= ~SF_EXPORT;
            UpdateData(FALSE);
            bDoModify = false;
        }
    }
    if (bDoModify) DoModified();
}


/////////////////////////////////////////////////////////////////////////////
// COptionsPage property page

IMPLEMENT_DYNCREATE(COptionsPage, CAutoPropPage)

BEGIN_HELP_IDS(COptionsPage)
    IDC_STYLESHEET,             IDC_XSL_FIXED
END_HELP_IDS()

COptionsPage::COptionsPage() : CAutoPropPage(COptionsPage::IDD)
{
	//{{AFX_DATA_INIT(COptionsPage)
	m_XSLType = -1;
	m_sXSLName = _T("");
	m_PathType = -1;
	//}}AFX_DATA_INIT
    
    m_iHelpID = IDH_OPT_OPT;

    varpair vars[] = 
    {
        { &m_XSLType,           (int *)&cfg_XSLTUsage },
        { &m_PathType,          (int *)&cfg_PathUsage },
    };
    strpair strs[] =
    {
        { &m_sXSLName,          &cfg_sXSLTTemplate    }
    };

    InitAutoVars(countof(vars), vars);
    InitAutoStrs(countof(strs), strs);
}

COptionsPage::~COptionsPage()
{
}

void COptionsPage::DoDataExchange(CDataExchange* pDX)
{
	CAutoPropPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsPage)
	DDX_Radio(pDX, IDC_XSL_NONE, m_XSLType);
	DDX_Text(pDX, IDC_STYLESHEET, m_sXSLName);
	DDX_Radio(pDX, IDC_PATH_DSW, m_PathType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsPage, CAutoPropPage)
	//{{AFX_MSG_MAP(COptionsPage)
	ON_EN_CHANGE(IDC_STYLESHEET, DoModified)
	ON_BN_CLICKED(IDC_XSL_NONE, OnXSLSel)
	ON_BN_CLICKED(IDC_XSL_SAMENAME, OnXSLSel)
	ON_BN_CLICKED(IDC_XSL_FIXED, OnXSLSel)
	ON_BN_CLICKED(IDC_PATH_DSW, OnPathSel)
	ON_BN_CLICKED(IDC_PATH_FILTER, OnPathSel)
	ON_BN_CLICKED(IDC_PATH_FULL, OnPathSel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsPage message handlers


BOOL COptionsPage::OnInitDialog() 
{
	CAutoPropPage::OnInitDialog();

    OnXSLSel();
    OnPathSel();

	return TRUE;
}

void COptionsPage::DoModified() 
{
    SetModified();
}

void COptionsPage::OnXSLSel() 
{
    UpdateData();
    DoModified();
    GetDlgItem(IDC_STYLESHEET)->EnableWindow(m_XSLType == 2);
}

void COptionsPage::OnPathSel() 
{
    UpdateData();
    DoModified();
}
