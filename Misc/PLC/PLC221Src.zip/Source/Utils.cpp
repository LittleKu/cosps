/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "stdafx.h"
#include "Utils.h"


// keep in mind - this is not an efficient function
void String2StringList(LPCSTR pszString, TCHAR tcSep, CStringList& lst)
{
    lst.RemoveAll();
    CString cStr;
    int i = 0;
    while (AfxExtractSubString(cStr, pszString, i, tcSep))
    {
        if (!cStr.IsEmpty())
        {
            lst.AddTail(cStr);
        }
        ++i;
    }
}


// the following function based on a function by Jack Handy - you may find 
// his original article at: http://www.codeproject.com/useritems/wildcmp.asp
int wildcmp(const char *wild, const char *string) {
	const char *cp, *mp;
	
	while ((*string) && (*wild != '*')) {
		if ((*wild != *string) && (*wild != '?')) {
			return 0;
		}
		wild++;
		string++;
	}
		
	while (*string) {
		if (*wild == '*') {
			if (!*++wild) {
				return 1;
			}
			mp = wild;
			cp = string+1;
		} else if ((*wild == *string) || (*wild == '?')) {
			wild++;
			string++;
		} else {
			wild = mp;
			string = cp++;
		}
	}
		
	while (*wild == '*'  ||  *wild == '?') {
		wild++;
	}
	return !*wild;
}

CString NumberWithCommas(int num)
{
    CString cStr;
    int pos;

    cStr.Format("%d", num);
    pos = cStr.GetLength() - 1;
    while (pos >= 3)
    {
        cStr = cStr.Left(pos - 2) + "," + cStr.Mid(pos - 2);
        pos -= 3;
    }

    return cStr;
}
