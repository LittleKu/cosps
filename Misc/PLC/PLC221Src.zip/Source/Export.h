/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __EXPORT_H
#define __EXPORT_H

#include "PrjStats.h"

bool ExportAsCSV(CString sFileName, ProjectList& projects,
                 LPCTSTR pszWorkspaceName);
bool ExportAsXML(CString sFileName, ProjectList& projects, 
                 LPCTSTR pszWorkspaceName);

#endif // __EXPORT_H
