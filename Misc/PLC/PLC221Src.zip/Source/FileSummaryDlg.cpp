/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// FileSummaryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "linecount.h"
#include "FileSummaryDlg.h"
#include "WorkspaceInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileSummaryDlg dialog


CFileSummaryDlg::CFileSummaryDlg(ProjectList& projects, 
    CWnd* pParent /*=NULL*/) : CDialog(CFileSummaryDlg::IDD, pParent),
    m_Projects(projects)
{
	//{{AFX_DATA_INIT(CFileSummaryDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFileSummaryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileSummaryDlg)
	DDX_Control(pDX, IDC_LIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFileSummaryDlg, CDialog)
	//{{AFX_MSG_MAP(CFileSummaryDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileSummaryDlg message handlers

BOOL CFileSummaryDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

    static LPCTSTR    sColumns[]  = { _T("File Extension"), _T("Count"), _T("%") };
    static SORT_TYPE  stColumns[] = { TYPE_TEXT, TYPE_NUMERIC, TYPE_NUMERIC };
    static SORT_STATE ssColumns[] = { DESCENDING, DESCENDING, DESCENDING };
    static int        lColumns[]  = { 20, 15, 25 };

    int         i;
    LVCOLUMN    lvc;

    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;

    for(i = 0; i < countof(sColumns); i++)
    {
        lvc.iSubItem = i;
        lvc.pszText = (char *)sColumns[i];
        lvc.cx = m_ListCtrl.GetStringWidth(lvc.pszText) + lColumns[i] + 15;
        if (lvc.cx < 40) lvc.cx = 40;
        lvc.fmt = (i >= 1)? LVCFMT_RIGHT : LVCFMT_LEFT;
        m_ListCtrl.InsertColumn(i, stColumns[i], ssColumns[i], &lvc);
    }

    LV_ITEM lvi;
    CString cStr, cExt;
    POSITION p;
    int iCount;

    // count extensions
    p = m_Projects.GetHeadPosition();
    int cAllPrjFiles = 0;
    CMap<CString, LPCTSTR, int, int> mapExtCount;
    while (p)
    {
        const IWorkspaceProject * const pPrj = m_Projects.GetNext(p);
        const int cFiles = pPrj->GetFileCount();
        for (int f = 0; f < cFiles; ++f)
        {
            IProjectFile *pFile = pPrj->GetFile(f);
            mapExtCount[pFile->GetExt()]++;
            delete pFile;
            ++cAllPrjFiles;
        }
    }

    p = mapExtCount.GetStartPosition();
    i = 0;
    while (p)
    {
        mapExtCount.GetNextAssoc(p, cExt, iCount);

        lvi.mask    = LVIF_TEXT;
        lvi.iItem   = m_ListCtrl.GetItemCount();
        lvi.iSubItem = 0;
        lvi.pszText = (LPTSTR)(LPCTSTR)cExt;
        i = m_ListCtrl.InsertItem(&lvi);

        /* count */
        cStr.Format("%d", iCount);
        m_ListCtrl.SetItemText(i, 1, CString(cStr));

        /* percent */
        cStr.Format("%0.1f", float(iCount * 100) / cAllPrjFiles);
        m_ListCtrl.SetItemText(i, 2, cStr);
        i++;
    }

	m_ListCtrl.SetUniqueName( "FileSummaryListCtrl" );
    m_ListCtrl.SortColumn(0);  // default sort
	m_ListCtrl.LoadColumnWidths();
	m_ListCtrl.LoadColumnOrder();
	m_ListCtrl.LoadColumnSort();
    m_ListCtrl.SortCombinedColumns(true);
	
	return TRUE;
}
