/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// GalleryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "linecount.h"
#include "GalleryDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int WM_GOT_GALLERY_INFO = (WM_USER + 1);


// utility functions
CString GetResourceAsString(HMODULE hModule, LPCTSTR lpName, LPCTSTR lpType)
{
    HRSRC hRsrc = FindResource(hModule, lpName, lpType);
    if (hRsrc != NULL)
    {
        HGLOBAL hGlob = LoadResource(hModule, hRsrc);
        if (hGlob != NULL)
        {
            LPVOID pRes = LockResource(hGlob);
            if (pRes != NULL)
            {
                return CString((char *)pRes, SizeofResource(hModule, hRsrc));
            }
        }
    }
    ASSERT(!"Resource not found");
    return "";
}

bool LoadXMLDocument(LPCWSTR src, IXMLDOMDocumentPtr& outPtr, CString& outErr)
{
	IUnknownPtr object;
	CLSID clsid;
    outPtr = NULL;

	if (SUCCEEDED(CLSIDFromProgID(L"MSXML.DOMDocument", &clsid)))
	{
        object.CreateInstance(clsid);
        outPtr = object;
	}

    if (outPtr == NULL)
    {
        outErr = "Failed to create MSXML Object.  "
            "You need to install the MSXML library.";
        return false;
    }

    HRESULT hr = outPtr->put_async(VARIANT_FALSE);
    if (SUCCEEDED(hr))
    {
       hr = outPtr->put_validateOnParse(VARIANT_FALSE);
    }
    if (SUCCEEDED(hr))
    {
       hr = outPtr->put_resolveExternals(VARIANT_FALSE);
    }

    if (src == NULL) return true;

    CComBSTR bStr;
    VARIANT_BOOL bSuccess;
    CComVariant v;
    v = bStr;
    outPtr->load(CComVariant(src), &bSuccess);

    if (bSuccess != VARIANT_TRUE)
    {
        CComBSTR bStr;
        IXMLDOMParseErrorPtr pObjError;
        hr = outPtr->get_parseError(&pObjError);
        hr = pObjError->get_reason(&bStr);
        outErr.Format(
            "There was an error downloading the XML data: %S", bStr);
        return false;
    }

    outErr = "";
    return true;
}



/////////////////////////////////////////////////////////////////////////////
// CGalleryDlg dialog


CGalleryDlg::CGalleryDlg(CWnd* pParent /*=NULL*/)
	: CResizableDialog(CGalleryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGalleryDlg)
	m_sMessage = _T("");
	//}}AFX_DATA_INIT

    m_sMessage = "Downloading information...";
}


void CGalleryDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizableDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGalleryDlg)
	DDX_Control(pDX, IDC_MESSAGE, m_ctlMessage);
	DDX_Text(pDX, IDC_MESSAGE, m_sMessage);
	DDX_Control(pDX, IDC_HTML, m_ctlWebBrowser);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGalleryDlg, CResizableDialog)
	//{{AFX_MSG_MAP(CGalleryDlg)
	//}}AFX_MSG_MAP
    ON_MESSAGE(WM_GOT_GALLERY_INFO, OnGotGalleryInfo)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGalleryDlg message handlers

BOOL CGalleryDlg::OnInitDialog() 
{
	CResizableDialog::OnInitDialog();

    AfxBeginThread(BeginFetchGalleryInfo, (LPVOID)this);

    AddAnchor(m_ctlWebBrowser.m_hWnd, TOP_LEFT, BOTTOM_RIGHT);
    AddAnchor(IDC_MESSAGE,            TOP_LEFT, BOTTOM_RIGHT);
    AddAnchor(IDOK,                   BOTTOM_RIGHT);

    EnableSaveRestore("GalleryDlg");

	return TRUE;
}

LRESULT CGalleryDlg::OnGotGalleryInfo(WPARAM wParam, LPARAM lParam)
{
    if (!m_sGalleryError.IsEmpty())
    {
        m_sMessage = m_sGalleryError;
        UpdateData(FALSE);
    }
    else
    {
        // reset the current document... when done, the event handler will
        // set the pending HTML text.
        m_ctlWebBrowser.Navigate("about:blank", NULL, NULL, NULL, NULL);
    }
    return 1;
}


BEGIN_EVENTSINK_MAP(CGalleryDlg, CResizableDialog)
    //{{AFX_EVENTSINK_MAP(CGalleryDlg)
	ON_EVENT(CGalleryDlg, IDC_HTML, 252 /* NavigateComplete2 */, OnNavigateComplete2Html, VTS_DISPATCH VTS_PVARIANT)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CGalleryDlg::OnNavigateComplete2Html(LPDISPATCH pDisp, VARIANT FAR* URL) 
{
    if (m_sPendingHTML.GetLength() > 0)
    {
        CComQIPtr<IHTMLDocument2> pDoc;

        pDoc = m_ctlWebBrowser.GetDocument();

        if (pDoc != NULL)
        {
            CComQIPtr<IHTMLElement> pBody;
  
            pDoc->get_body(&pBody);
            pBody->put_innerHTML(CComBSTR(m_sPendingHTML));

            m_ctlMessage.ShowWindow(SW_HIDE);
            m_ctlWebBrowser.ShowWindow(SW_SHOW);

            // force resize (otherwise browser comes out wrong size)
            CRect rc;
            GetWindowRect(rc);
            rc.bottom++;
            MoveWindow(rc);
            rc.bottom--;
            MoveWindow(rc);

            m_sPendingHTML = L"";
        }
    }
}

UINT CGalleryDlg::BeginFetchGalleryInfo(LPVOID pContext)
{
    CGalleryDlg * const pThis = (CGalleryDlg *)pContext;

    IXMLDOMDocumentPtr pXMLDoc;
    IXMLDOMDocumentPtr pXSLDoc;

    CString sErr;
    CComBSTR bStr;
    HRESULT hr;
    VARIANT_BOOL bSuccess;

    CoInitialize(NULL);

    if (LoadXMLDocument(L"http://www.wndtabs.com/ftp/PLC-Gallery/gallery.xml", pXMLDoc, sErr) &&
        LoadXMLDocument(NULL, pXSLDoc, sErr))
    {
        CComBSTR bStrXSL = CComBSTR(GetResourceAsString(
            AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_XSL_GALLERY), "XSL"));
        pXSLDoc->loadXML(bStrXSL, &bSuccess);
        if (bSuccess != VARIANT_TRUE)
        {
            IXMLDOMParseErrorPtr pObjError;
            hr = pXSLDoc->get_parseError(&pObjError);
            hr = pObjError->get_reason(&bStr);
            sErr.Format(
                "There was loading the XSL resource: %S", bStr);
        }
        else
        {
            hr = pXMLDoc->transformNode(pXSLDoc, &bStr);

            if (SUCCEEDED(hr))
            {
                sErr.Empty();
                pThis->m_sPendingHTML = bStr;
            }
            else
            {
                sErr = "Could not transform the XML data.";
            }
        }
    }
    pThis->m_sGalleryError = sErr;
    pThis->PostMessage(WM_GOT_GALLERY_INFO);

    CoUninitialize();

    return 0;
}
