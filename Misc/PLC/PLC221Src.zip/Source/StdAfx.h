/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__04727E6E_B52C_11D3_BA83_0000861DFCE7__INCLUDED_)
#define AFX_STDAFX_H__04727E6E_B52C_11D3_BA83_0000861DFCE7__INCLUDED_

#define TARGET_VC6     // remove this to disable the VC6 addin target
#define TARGET_VC7     // remove this to disable the VC7 addin target

#include <stdlib.h>

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxdisp.h>
#include <afxcmn.h>
#include <afxtempl.h>
#include <afxext.h>
#include <afxhtml.h>

#include <atlbase.h>

extern CComModule _Module;

#include <atlcom.h>

// MS XML Parser
#if !defined(__IXMLDOMDocument_INTERFACE_DEFINED__)
#import <msxml3.dll> raw_interfaces_only
using namespace MSXML2;
#endif

#include <mshtml.h>


#ifdef TARGET_VC6
// Developer Studio Object Model
#include "ObjModelVC6\addauto.h"
#include "ObjModelVC6\appdefs.h"
#include "ObjModelVC6\appauto.h"
#include "ObjModelVC6\blddefs.h"
#include "ObjModelVC6\bldauto.h"
#include "ObjModelVC6\textdefs.h"
#include "ObjModelVC6\textauto.h"
#include "ObjModelVC6\dbgdefs.h"
#include "ObjModelVC6\dbgauto.h"
#endif // TARGET_VC6

#ifdef TARGET_VC7
#pragma warning( disable : 4278 )
#pragma warning( disable : 4146 )
#if _MSC_VER > 1200  // VC7
    //The following #import imports the IDTExtensibility2 interface based on it's LIBID
    #import "libid:AC0714F2-3D04-11D1-AE7D-00A0C90F26F4" version("1.0") lcid("0")  raw_interfaces_only named_guids
    //The following #import imports MSO based on it's LIBID
    #import "libid:2DF8D04C-5BFA-101B-BDE5-00AA0044DE52" version("2.2") lcid("0") raw_interfaces_only named_guids
    //The following #import imports DTE based on it's LIBID
    #import "libid:80cc9f66-e7d8-4ddd-85b6-d9e6cd0e93e2" version("7.0") lcid("0") raw_interfaces_only named_guids
#else
//  #import "C:\Program Files\Common Files\designer\MSADDNDR.DLL"              raw_interfaces_only named_guids
//  #import "C:\Program Files\Common Files\Microsoft Shared\Office10\MSO.DLL"  raw_interfaces_only named_guids
//  #import "C:\Program Files\Common Files\Microsoft Shared\MSEnv\dte.olb"     raw_interfaces_only named_guids
    #include "ObjModelVC7\MSADDNDR.tlh"
    #include "ObjModelVC7\MSO.tlh"
    #include "ObjModelVC7\dte.tlh"

    #include "ObjModelVC8\dte80.tlh"
#endif
#pragma warning( default : 4146 )
#pragma warning( default : 4278 )
class DECLSPEC_UUID("C14D829C-90AE-46CE-8EA2-B60C53E3071B") LineCountLib;
#endif  // TARGET_VC7

#ifndef WS_EX_LAYOUTRTL
#define WS_EX_LAYOUTRTL                    0x00400000L
#endif


#include "HHSupp.h"
#include "ExtrnSrc\HyperLink.h"
#include "ExtrnSrc\htmlhelp.h"
#include "ExtrnSrc\MultiColumnSortListView.h"
#include "ExtrnSrc\ResizableLib\ResizableDialog.h"
#include "ExtrnSrc\AggressiveOptimize.h"
#include "Globals.h"

/////////////////////////////////////////////////////////////////////////////
// Debugging support

// Use VERIFY_OK around all calls to the Developer Studio objects which
//  you expect to return S_OK.
// In DEBUG builds of your add-in, VERIFY_OK displays an ASSERT dialog box
//  if the expression returns an HRESULT other than S_OK.  If the HRESULT
//  is a success code, the ASSERT box will display that HRESULT.  If it
//  is a failure code, the ASSERT box will display that HRESULT plus the
//  error description string provided by the object which raised the error.
// In RETAIL builds of your add-in, VERIFY_OK just evaluates the expression
//  and ignores the returned HRESULT.

#ifdef _DEBUG

void GetLastErrorDescription(CComBSTR& bstr);		// Defined in LineCount.cpp
#define VERIFY_OK(f) \
	{ \
		HRESULT hr = (f); \
		if (hr != S_OK) \
		{ \
			if (FAILED(hr)) \
			{ \
				CComBSTR bstr; \
				GetLastErrorDescription(bstr); \
				_RPTF2(_CRT_ASSERT, "Object call returned %lx\n\n%S", hr, (BSTR) bstr); \
			} \
			else \
				_RPTF1(_CRT_ASSERT, "Object call returned %lx", hr); \
		} \
	}

#else //_DEBUG

#define VERIFY_OK(f) (f);

#endif //_DEBUG

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__04727E6E_B52C_11D3_BA83_0000861DFCE7__INCLUDED)
