#if !defined(AFX_NICEGROUPBOX_H__02B281FB_00DF_4E88_B754_5EAA4E5EF8FB__INCLUDED_)
#define AFX_NICEGROUPBOX_H__02B281FB_00DF_4E88_B754_5EAA4E5EF8FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NiceGroupBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNiceGroupBox window

class CNiceGroupBox : public CStatic
{
// Construction
public:
	CNiceGroupBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNiceGroupBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNiceGroupBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CNiceGroupBox)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	CBrush *m_pbrWhite;
	CBrush m_brBgExternal;
	CBitmap m_bmTL;
	CBitmap m_bmTR;
	CBitmap m_bmTC;
	CBitmap m_bmBL;
	CBitmap m_bmBR;
	CBitmap m_bmBC;
	CPen m_penSides;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NICEGROUPBOX_H__02B281FB_00DF_4E88_B754_5EAA4E5EF8FB__INCLUDED_)
