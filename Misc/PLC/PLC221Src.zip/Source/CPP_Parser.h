/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __CPP_PARSER_H
#define __CPP_PARSER_H

#include "FileParser.h"

class CCParser : public IFileParser
{
public:
    CCParser() {};

    virtual void ParseFile(CLineViewOfFile& file, CFileInfo& info);

    LPCTSTR GetDefaultExtensions() const
    {
        return _T("C/CPP/CXX/H/HPP/HXX/HM/INL/RC?/ODL/IDL/CS/JAVA");
    }

    virtual LPCTSTR GetParserCfgCode() const 
    {
        return _T("CPP");
    }

    virtual int GetParserNameResourceID() const
    {
        return IDS_PARSERNAME_CPP;
    }

protected:

    virtual void ParseLine(
        const CString *pLine,
        /* in out */ bool& bMultiLineComment,
        /* out */ bool& bHasCode,
        /* out */ bool& bHasComments);
};


#endif // __CPP_PARSER_H
