// NiceGroupBox.cpp : implementation file
//
// PLEASE NOTE: There was no attempt to make this class "generic".
// The background colors are hard-coded into the bitmap.

#include "stdafx.h"
#include "LineCount.h"
#include "NiceGroupBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNiceGroupBox

CNiceGroupBox::CNiceGroupBox()
{
	m_pbrWhite = CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH));
	m_brBgExternal.CreateSolidBrush(RGB(0xEB, 0xF1, 0xFE));
	m_bmTL.LoadBitmap(IDB_NICEGB_TL);
	m_bmTR.LoadBitmap(IDB_NICEGB_TR);
	m_bmTC.LoadBitmap(IDB_NICEGB_TC);
	m_bmBL.LoadBitmap(IDB_NICEGB_BL);
	m_bmBR.LoadBitmap(IDB_NICEGB_BR);
	m_bmBC.LoadBitmap(IDB_NICEGB_BC);
	m_penSides.CreatePen(PS_SOLID, 1, RGB(0x2F, 0x43, 0x73));
}

CNiceGroupBox::~CNiceGroupBox()
{
}


BEGIN_MESSAGE_MAP(CNiceGroupBox, CStatic)
	//{{AFX_MSG_MAP(CNiceGroupBox)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNiceGroupBox message handlers

void CNiceGroupBox::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rect, rect_clip;

	GetClientRect(&rect);
	dc.GetClipBox(&rect_clip);

	dc.FillRect(rect_clip, m_pbrWhite);

	int l, r;

	CDC mem_dc;
	mem_dc.CreateCompatibleDC(&dc);
	BITMAP bm;

	mem_dc.SelectObject(&m_bmTL);
	m_bmTL.GetBitmap(&bm);
	dc.BitBlt(0, 0, bm.bmWidth, bm.bmHeight, &mem_dc, 0, 0, SRCCOPY);
	l = bm.bmWidth;

	mem_dc.SelectObject(m_bmTR);
	m_bmTL.GetBitmap(&bm);
	r = rect.right - bm.bmWidth;
	dc.BitBlt(r, 0, bm.bmWidth, bm.bmHeight, &mem_dc, 0, 0, SRCCOPY);

	mem_dc.SelectObject(m_bmTC);
	m_bmTC.GetBitmap(&bm);
	dc.StretchBlt(l, 0, r - l, bm.bmHeight, &mem_dc, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

	const int topHeight = bm.bmHeight;

	mem_dc.SelectObject(m_bmBL);
	m_bmBL.GetBitmap(&bm);
	dc.BitBlt(0, rect.bottom - bm.bmHeight, bm.bmWidth, bm.bmHeight, &mem_dc, 0, 0, SRCCOPY);
	l = bm.bmWidth;
	const int bottomHeight = bm.bmHeight;

	mem_dc.SelectObject(m_bmBR);
	m_bmBL.GetBitmap(&bm);
	r = rect.right - bm.bmWidth;
	dc.BitBlt(r, rect.bottom - bm.bmHeight, bm.bmWidth, bm.bmHeight, &mem_dc, 0, 0, SRCCOPY);

	mem_dc.SelectObject(m_bmBC);
	m_bmBC.GetBitmap(&bm);
	dc.StretchBlt(l, rect.bottom - bm.bmHeight, r - l, bm.bmHeight, &mem_dc, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

	const HGDIOBJ oldPen = dc.SelectObject(m_penSides);
	dc.MoveTo(0, bm.bmHeight);
	dc.LineTo(0, rect.bottom - bottomHeight);
	dc.MoveTo(rect.right - 1, bm.bmHeight);
	dc.LineTo(rect.right - 1, rect.bottom - bottomHeight);
	dc.SelectObject(oldPen);

	const int oldBKMode = dc.SetBkMode(TRANSPARENT);
	const COLORREF oldTextColor = dc.SetTextColor(RGB(0xFF, 0xFF, 0xFF));
	CString text;
	GetWindowText(text);
	dc.DrawText(text, CRect(16, 2, rect.right - 16, 21), DT_VCENTER);
	dc.SetTextColor(oldTextColor);
	dc.SetBkMode(oldBKMode);
}

BOOL CNiceGroupBox::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}
