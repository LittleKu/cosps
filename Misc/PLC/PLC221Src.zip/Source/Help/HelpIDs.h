/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __HELPIDS_H
#define __HELPIDS_H

// Constants 0x00000000...0x1FFFFFFF are used for popup text (for dialog/
// property page controls) and for HTML pages using the default window type 
// (context help for menu items and ShowHTMLHelp()).
// The lower ranges (0...0xFFFF) are used by command identifiers, but you can
// freely define constants in the rest of the range.
#define IDH_COPYINFO            0x10000000

// Constants 0x20000000...0x2FFFFFFF use the 'PopupTopicWnd' window type 
#define IDH_ABOUT               0x20000002

// Constants 0x30000000...0x3000FFFF use window types registered with the 
// RegisterHTMLHelpWindowType() function.  The type number is designated in 
// the lower byte of the high word, i.e. the number format is 0x30NNxxxx 
// where NN denotes the type number.  When NN == 0, the default window type 
// is used.
#define IDH_DLG_MAIN            0x30010001
#define IDH_OPT_FILES           0x30010100
#define IDH_OPT_EXT             0x30010101
#define IDH_OPT_STATS           0x30010102
#define IDH_OPT_OPT             0x30010103

#define IDH_WWHIZ_INT           0x30011000


// #include the application's resource header so its command IDs can be 
// processed by the HTML Help compiler
#include "..\Resource.h"

#endif // __HELPIDS_H

