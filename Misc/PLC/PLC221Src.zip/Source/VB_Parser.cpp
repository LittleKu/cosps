/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by John Kohler, and is bound by the      */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "stdafx.h"
#include "Resource.h"
#include "VB_Parser.h"
#include "config.h"
#include "LineViewOfFile.h"

void CVBParser::ParseFile(CLineViewOfFile& file, CFileInfo& info)
{
    const CString *pLine;
    bool bInComment = false, bHasCode, bHasComments;
    while (file.GetNextLine(pLine))
    {
        ParseLine(*pLine, bInComment, bHasCode, bHasComments);

        if (bHasComments)
        {
            ++info.m_iLinesWithComments;
        }
        if (bHasCode)
        {
            ++info.m_iLinesWithCode;
        }
        if (!bHasCode  &&  !bHasComments)
        {
            if (cfg_bProcessBlanks)
            {
                ++info.m_iBlankLines;
            }
            else
            {
                ++info.m_iLinesWithCode;
            }
        }
        ++info.m_iTotalLines;
    }
}

#define IS_PAIR(A, B) (ch == #@A  &&  chNext == #@B)

void CVBParser::ParseLine(
    CString sLine,
    /* in out */ bool& bMultiLineComment,
    /* out */ bool& bHasCode,
    /* out */ bool& bHasComments)
{
	bMultiLineComment = false;

	sLine.TrimLeft();
	sLine.TrimRight();

	if ( sLine.IsEmpty() )
	{
		// Blank Line
		bHasCode = false;
		bHasComments = false;
		return;
	}

	if ( sLine.GetAt(0) == '\'' )
	{
		// Whole line is comment
		bHasCode = false;
		bHasComments = true;
		return;
	}

	if ( sLine.Find('\'') != -1 )
	{
		// Code + Comment
		bHasCode = true;
		bHasComments = true;
		return;
	}

	// Pure Code
	bHasCode = true;
	bHasComments = false;

	return;
}
