/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#if !defined(AFX_HELPINTERCEPTIONWND_H__B67CB503_B0F5_4B25_99BE_F1FBE555DF11__INCLUDED_)
#define AFX_HELPINTERCEPTIONWND_H__B67CB503_B0F5_4B25_99BE_F1FBE555DF11__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HelpInterceptionWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHelpInterceptionWnd window

class CHelpInterceptionWnd : public CWnd
{
// Construction
public:
	CHelpInterceptionWnd(DWORD helpID);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHelpInterceptionWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHelpInterceptionWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CHelpInterceptionWnd)
	//}}AFX_MSG
	afx_msg LRESULT OnHelp(WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()

    int m_iHelpID;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HELPINTERCEPTIONWND_H__B67CB503_B0F5_4B25_99BE_F1FBE555DF11__INCLUDED_)
