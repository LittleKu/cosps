/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __GLOBALS_H
#define __GLOBALS_H

#define LIST_DELIMITER  '/'
#define DEF_IGNORE_LIST "stdafx.cpp"

enum XSLT_Usage { none, same_name, fixed_name };

#define RUNNING_IN_DOT_NET() ( GetModuleHandle("DEVENV.EXE") != NULL )

#define countof(arr)  (sizeof(arr)/sizeof(arr[0]))

#define CHK_FLAG(bitfield, flag) ((bitfield & flag) == flag)

extern int g_iVerMaj;
extern int g_iVerMin;

#endif //__GLOBALS_H
