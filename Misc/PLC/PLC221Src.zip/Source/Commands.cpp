/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// Commands.cpp : implementation file
//

#include "stdafx.h"

#ifdef TARGET_VC6

#include "LineCount.h"
#include "Commands.h"
#include "ResultsDlg.h"
#include "WorkspaceInfo.h"
#include "HelpInterceptionWnd.h"
#include "Help\HelpIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCommands

CCommands::CCommands()
{
    m_pApplication = NULL;
}

CCommands::~CCommands()
{
    ASSERT (m_pApplication != NULL);
    m_pApplication->Release();
}

void CCommands::SetApplicationObject(IApplication* pApplication)
{
    // This function assumes pApplication has already been AddRef'd
    //  for us, which CDSAddIn did in its QueryInterface call
    //  just before it called us.
    m_pApplication = pApplication;
}


/////////////////////////////////////////////////////////////////////////////
// CCommands methods

CWnd *s_pActiveWnd = NULL;

HRESULT CCommands::LCCmd(int iCmd)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (s_pActiveWnd)
    {
        s_pActiveWnd->SetFocus();
        MessageBeep(MB_ICONHAND);
        return S_OK;
    }

    VERIFY_OK(m_pApplication->EnableModeless(VARIANT_FALSE));

    if (!g_pWorkspaceInfo)
    {
        InitializeWorkspaceInfo_VC6(m_pApplication);

        // no luck? notify the user:
        if (g_pWorkspaceInfo == NULL) 
        {
            CHelpInterceptionWnd wnd(IDH_WWHIZ_INT);
            wnd.MessageBox(
                CString(MAKEINTRESOURCE(IDS_ERR_WWHIZLOAD)), 
                CString(MAKEINTRESOURCE(IDS_LINECOUNT_LONGNAME)), 
                MB_OK | MB_ICONSTOP | MB_HELP);
            wnd.SendMessage(WM_DESTROY);
            goto out;
        }
    }

    switch (iCmd)
    {
        case 1:
        {
            ASSERT(FALSE);  // no longer in use

            // fall through
        }

        case 2:
        {
            CResultsDlg dlg(g_pWorkspaceInfo);
            s_pActiveWnd = &dlg;
            dlg.DoModal();
            break;
        }
    }

out:    
    VERIFY_OK(m_pApplication->EnableModeless(VARIANT_TRUE));

    s_pActiveWnd = NULL;

    return S_OK;
}

STDMETHODIMP CCommands::LC_Console()
{
    ASSERT(FALSE);  // no longer in use
    return LCCmd(1);
}

STDMETHODIMP CCommands::LC_Go()
{
    return LCCmd(2);
}

#endif // TARGET_VC6
