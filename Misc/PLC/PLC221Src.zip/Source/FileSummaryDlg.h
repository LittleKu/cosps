/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// FileSummaryDlg.h : header file
//

#if !defined(AFX_FILESUMMARYDLG_H__BB865A85_1F4F_11D4_BACD_0000861DFCE7__INCLUDED_)
#define AFX_FILESUMMARYDLG_H__BB865A85_1F4F_11D4_BACD_0000861DFCE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFileSummaryDlg dialog

#include "ExtrnSrc\MultiColumnSortListView.h"
#include "PrjStats.h"

class CFileSummaryDlg : public CDialog
{
// Construction
public:
    CFileSummaryDlg(ProjectList& projects, CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CFileSummaryDlg)
	enum { IDD = IDD_FILESUMMARY };
	CMultiColumnSortListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileSummaryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFileSummaryDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    ProjectList& m_Projects;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILESUMMARYDLG_H__BB865A85_1F4F_11D4_BACD_0000861DFCE7__INCLUDED_)
