/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// DSAddIn.h : header file
//

#if !defined(AFX_DSADDIN_H__04727E75_B52C_11D3_BA83_0000861DFCE7__INCLUDED_)
#define AFX_DSADDIN_H__04727E75_B52C_11D3_BA83_0000861DFCE7__INCLUDED_

#include "commands.h"

#ifdef TARGET_VC6

// {04727E62-B52C-11D3-BA83-0000861DFCE7}
DEFINE_GUID(CLSID_DSAddIn,
0x4727e62, 0xb52c, 0x11d3, 0xba, 0x83, 0, 0, 0x86, 0x1d, 0xfc, 0xe7);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	//DECLARE_REGISTRY(CDSAddIn, "LineCount.DSAddIn.1",
	//	"LINECOUNT Developer Studio Add-in", IDS_LINECOUNT_LONGNAME,
	//	THREADFLAGS_BOTH)
	
	DECLARE_REGISTRY_RESOURCEID(IDR_REGISTRY_VC6)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

	void AddToolbarCmds() const;

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj *m_pCommands;
	IApplication *m_pApplication;
	DWORD m_dwCookie;
};

#endif // TARGET_VC6

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__04727E75_B52C_11D3_BA83_0000861DFCE7__INCLUDED)
