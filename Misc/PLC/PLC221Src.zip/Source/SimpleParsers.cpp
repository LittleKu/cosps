/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "StdAfx.h"
#include "Resource.h"
#include "SimpleParsers.h"
#include "Config.h"
#include "LineViewOfFile.h"

CSimpleCommentParser::CSimpleCommentParser(LPCTSTR pszCommentPrefix) :
    m_sCommentPrefix(pszCommentPrefix)
{
}

void CSimpleCommentParser::ParseFile(CLineViewOfFile& file, CFileInfo& info)
{
    const int comment_length = m_sCommentPrefix.GetLength();

    CString sLine;
    CString *pLineRO;
    while (file.GetNextLine(pLineRO))
    {
        sLine = *pLineRO;  // copy so we can edit
        sLine.TrimLeft();
        sLine.TrimRight();
        if (sLine.IsEmpty()  &&  cfg_bProcessBlanks)
        {
            ++info.m_iBlankLines;
        }
        else
        {
            if (comment_length > 0                   &&
                sLine.GetLength() >= comment_length  &&
                sLine.Left(comment_length) == m_sCommentPrefix)
            {
                ++info.m_iLinesWithComments;
            }
            else
            {
                ++info.m_iLinesWithCode;
            }
        }
        ++info.m_iTotalLines;
    }
}
