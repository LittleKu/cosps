/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// AboutDialog.cpp : implementation file
//

#include "stdafx.h"
#include "linecount.h"
#include "AboutDialog.h"
#include "ExtrnSrc\AICLoader.h"
#include "ExtrnSrc\AddInComm.h"
#include "WorkspaceInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDialog dialog


CAboutDialog::CAboutDialog(CWnd* pParent /*=NULL*/)
	: CDialog(GetResourceID(), pParent)
{
	//{{AFX_DATA_INIT(CAboutDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAboutDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDialog)
	DDX_Control(pDX, IDC_PLC_VER, m_Title);
	DDX_Control(pDX, IDC_WWW2, m_WWW2);
	DDX_Control(pDX, IDC_WWW1, m_WWW1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAboutDialog, CDialog)
	//{{AFX_MSG_MAP(CAboutDialog)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDialog message handlers

BOOL CAboutDialog::OnInitDialog() 
{
    int iVerMaj, iVerMin, iVerExtra;
    CString s; //cStr1, cStr2, cStr3;
    char ver[1024];

	CDialog::OnInitDialog();

    CFont *pFontTTL = m_Title.GetFont();
    LOGFONT lf;
    pFontTTL->GetLogFont(&lf);
    lf.lfWeight = FW_BOLD;
    m_fontBold.CreateFontIndirect(&lf);
    m_Title.SetFont(&m_fontBold);

    SetVersionStr(IDC_PLC_VER, "Build " + GetOwnVersion());
	
    // AddInComm Version
    if (!aiclIsAICLoaded())
    {
        s = "Not loaded";
    }
    else
    {
        AICGetDllVersion(iVerMaj, iVerMin, iVerExtra);
        aiclGetModuleVersion("AIC.mod", (LPSTR)ver);
        s.Format("Version %d.%d.%d (%s)", iVerMaj, iVerMin, iVerExtra,
            ver);
    }
    SetVersionStr(IDC_AIC_VER, s);

    // WWhiz! Interface Version
    if (!g_pWorkspaceInfo)
    {
        s = "Not loaded";
    }
    else
    {
#ifdef _DEBUG
        aiclGetModuleVersion("WWhizInterface2D.mod", (LPSTR)ver);
#else
        aiclGetModuleVersion("WWhizInterface2.mod", (LPSTR)ver);
#endif
        s.Format("Version %s", ver);
    }
    SetVersionStr(IDC_WWI_VER, s);
	
	return TRUE;
}

void CAboutDialog::SetVersionStr(int id, CString& sVer)
{
    CString s1, s2;
    GetDlgItemText(id, s1);
    s2.Format(s1, sVer);
    SetDlgItemText(id, s2);
}

int CAboutDialog::GetResourceID()
{
    if (RUNNING_IN_DOT_NET())
    {
        return IDD_ABOUT_VC7;
    }
    else
    {
        return IDD_ABOUT_VC6;
    }
}

HBRUSH CAboutDialog::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	const CWnd *pWndTest = GetDlgItem(IDC_BANNER_BG); // see if this is the V7 dialog
	if (pWndTest != NULL)
	{
		switch (pWnd->GetDlgCtrlID())
		{
			case IDC_LOGO:
			case IDC_PLC_VER:
			case IDC_VERSION:
			{		   
				return (HBRUSH)::GetStockObject(WHITE_BRUSH);
			}
		}

	}

	return CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
}
