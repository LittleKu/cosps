/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/


#ifndef __UTILS_H
#define __UTILS_H


void String2StringList(LPCSTR pszString, TCHAR tcSep, CStringList& lst);
int wildcmp(const char *wild, const char *string);
CString NumberWithCommas(int iNum);

#endif // __UTILS_H
