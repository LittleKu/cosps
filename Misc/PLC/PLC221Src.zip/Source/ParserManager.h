/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __PARSERMANAGER_H
#define __PARSERMANAGER_H

#include "FileParser.h"

class CParserManager
{
protected:
    CParserManager();

public:

    ~CParserManager();

    // Singelton
    static CParserManager& Get();

    void LoadConfig();
    void SaveConfig();

    typedef CString state_t;
    void GetState(state_t& state) const;
    void SetState(state_t& state);

    struct parser_fileext_pair
    {
        CString sExt;
        IFileParser *pParser;
    };
    
    typedef CArray<parser_fileext_pair, parser_fileext_pair&> PairArray;
    
    void GetParsers(OUT IFileParser **& pParserArray, OUT int& iCount) const;

    IFileParser *GetParserForFile(const char *pszFileName) const;

    void GetPairs(OUT PairArray& arr) const;
    void AddPair(const parser_fileext_pair& pair);
    void RemovePair(LPCTSTR pszExt);
    void ResetPairs();

protected:

    typedef CMap<CString, LPCTSTR, IFileParser *, IFileParser *&> PairMap;
    PairMap m_mapExtToParser;
};

#endif // __PARSERMANAGER_H
