/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// Options.h : header file
//

#if !defined(AFX_OPTIONS_H__23E5E9B8_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_)
#define AFX_OPTIONS_H__23E5E9B8_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AutoPropPage.h"
#include "ParserManager.h"

/////////////////////////////////////////////////////////////////////////////
// CPageWithList class

class CPageWithList : public CAutoPropPage
{
	DECLARE_DYNCREATE(CPageWithList)

    CPageWithList() {};

public:
    CPageWithList(CListBox& managedList, int iDelButton, int iInsButton,
        UINT nIDTemplate, bool bAllowImplicit = true, int iHelpID = -1, 
        UINT nIDCaption = 0);

    void InitPageWithList();

    virtual void OnUpdateList() {};

protected:

    enum undo_ops {none, ins, del};

    void DeleteString(CString str);
    void InsertString(CString str);
    void SetLastUndo(undo_ops op, CString val);

    afx_msg void HandlerImpl_OnSelChange();
	afx_msg void HandlerImpl_OnUndo();
	afx_msg void HandlerImpl_OnDelete();
    afx_msg int HandlerImpl_OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex);

private:
	CListBox*	m_pManagedList;

    undo_ops m_LastUndoOp;
    CString  m_sLastUndoVal;
    CWnd *   m_pUndoWnd;

    int      m_iDelButton;
    int      m_iInsButton;
};


/////////////////////////////////////////////////////////////////////////////
// CFilesPage dialog

class CFilesPage : public CPageWithList
{
	DECLARE_DYNCREATE(CFilesPage)

// Construction
public:
	CFilesPage();
	~CFilesPage();

// Dialog Data
	//{{AFX_DATA(CFilesPage)
	enum { IDD = IDD_OPTPAGE_FILES };
	CListBox	m_FileList;
	//}}AFX_DATA

    CString m_sFileList;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFilesPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFilesPage)
	afx_msg void OnInsertfile();
	afx_msg void OnDeletefile();
	afx_msg void OnUndo();
	afx_msg void OnClearallfiles();
	afx_msg void OnSelchangeFileList();
	virtual BOOL OnInitDialog();
	afx_msg int OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    virtual void OnUpdateList();
    void FillFileList();
};


/////////////////////////////////////////////////////////////////////////////
// CExtensionsPage dialog

class CExtensionsPage : public CAutoPropPage
{
	DECLARE_DYNCREATE(CExtensionsPage)

// Construction
public:
	CExtensionsPage();
	~CExtensionsPage();

// Dialog Data
	//{{AFX_DATA(CExtensionsPage)
	enum { IDD = IDD_OPTPAGE_EXTENSIONS };
	CListCtrl	m_ExtList;
	//}}AFX_DATA

    CString m_sExtList;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CExtensionsPage)
    public:
    virtual void OnCancel();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void FillExtList();

    typedef CParserManager::state_t undo_t;

    undo_t  m_LastUndoVal;
    CWnd *  m_pUndoWnd;

    void MarkUndo();

    CParserManager::state_t m_OldPMState;

    void InsertPair(CParserManager::parser_fileext_pair& pair);

    // Generated message map functions
	//{{AFX_MSG(CExtensionsPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnResetList();
	afx_msg int OnVKeyToItem(UINT nKey, CListBox* pListBox, UINT nIndex);
	afx_msg void OnInsertext();
	afx_msg void OnDeleteext();
	afx_msg void OnUndo();
	afx_msg void OnItemchangedExtList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void OnSelChange();
};


/////////////////////////////////////////////////////////////////////////////
// CStatsPage dialog

class CStatsPage : public CAutoPropPage
{
	DECLARE_DYNCREATE(CStatsPage)

// Construction
public:
	CStatsPage();
	~CStatsPage();

// Dialog Data
	//{{AFX_DATA(CStatsPage)
	enum { IDD = IDD_OPTPAGE_STATS };
	CComboBox	m_DefFilter;
	BOOL	m_bCheckComments;
	BOOL	m_bCountBlanks;
	BOOL	m_bIncBad_Export;
	BOOL	m_bIncBad_Grid;
	BOOL	m_bIncFilter_Export;
	BOOL	m_bIncFilter_Grid;
	//}}AFX_DATA

    int m_iDefFilter;
    int m_sfFiltered;
    int m_sfBadFiles;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CStatsPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CStatsPage)
	virtual BOOL OnInitDialog();
	afx_msg void DoModified();
	afx_msg void DoIncFilterExport();
	afx_msg void OnIncBadExport();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    DECLARE_HELP_IDS();

    void PopuplateDefaultFilters(interface IWorkspaceInfo *pWI);
};


/////////////////////////////////////////////////////////////////////////////
// COptionsPage dialog

class COptionsPage : public CAutoPropPage
{
	DECLARE_DYNCREATE(COptionsPage)

// Construction
public:
	COptionsPage();
	~COptionsPage();

// Dialog Data
	//{{AFX_DATA(COptionsPage)
	enum { IDD = IDD_OPTPAGE_OPTIONS };
	int		m_XSLType;
	CString	m_sXSLName;
	int		m_PathType;
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptionsPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(COptionsPage)
	virtual BOOL OnInitDialog();
	afx_msg void DoModified();
	afx_msg void OnXSLSel();
	afx_msg void OnPathSel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    DECLARE_HELP_IDS();
};


/////////////////////////////////////////////////////////////////////////////
// COptionsSheet

class COptionsSheet : public CHHPropSheet
{
	DECLARE_DYNAMIC(COptionsSheet)

// Construction
public:
	COptionsSheet(CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
    CFilesPage      m_FilesPage;
    CExtensionsPage m_ExtPage;
    CStatsPage      m_StatsPage;
    COptionsPage    m_OptionsPage;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COptionsSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(COptionsSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONS_H__23E5E9B8_C14F_11D3_BA8F_0000861DFCE7__INCLUDED_)
