/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by John Kohler, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __VB_PARSER_H
#define __VB_PARSER_H

#include "FileParser.h"

class CVBParser : public IFileParser
{
public:
    CVBParser() {};

    virtual void ParseFile(CLineViewOfFile& file, CFileInfo& info);

    virtual LPCTSTR GetDefaultExtensions() const 
    {
        return _T("FRM/CLS/BAS/MOD/VB");
    }

    virtual LPCTSTR GetParserCfgCode() const 
    {
        return _T("VB");
    }

    virtual int GetParserNameResourceID() const
    {
        return IDS_PARSERNAME_VB;
    }

protected:

    virtual void ParseLine(
        CString sLine,
        /* in out */ bool& bMultiLineComment,
        /* out */ bool& bHasCode,
        /* out */ bool& bHasComments);
};


#endif // __CPP_PARSER_H
