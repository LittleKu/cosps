/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "stdafx.h"
#include "Resource.h"
#include "CPP_Parser.h"
#include "config.h"
#include "LineViewOfFile.h"

void CCParser::ParseFile(CLineViewOfFile& file, CFileInfo& info)
{
    CString *pLine;
    bool bInComment = false, bHasCode, bHasComments;
    while (file.GetNextLine(pLine))
    {
        ParseLine(pLine, bInComment, bHasCode, bHasComments);

        if (bHasComments)
        {
            ++info.m_iLinesWithComments;
        }
        if (bHasCode)
        {
            ++info.m_iLinesWithCode;
        }
        if (!bHasCode  &&  !bHasComments)
        {
            if (cfg_bProcessBlanks)
            {
                ++info.m_iBlankLines;
            }
            else
            {
                ++info.m_iLinesWithCode;
            }
        }
        ++info.m_iTotalLines;
    }
}

#define IS_PAIR(A, B) (ch == #@A  &&  chNext == #@B)

void CCParser::ParseLine(
    const CString *pLine,
    /* in out */ bool& bMultiLineComment,
    /* out */ bool& bHasCode,
    /* out */ bool& bHasComments)
{
    // state flags
    bool bInString = false;
    bool bInTwoPairSequence = false;

    const int iLineLen = pLine->GetLength();

    bHasComments = bMultiLineComment;
    bHasCode = false;

    for (int i = 0; i < iLineLen; ++i)
    {
        unsigned char ch = (*pLine)[i];
        unsigned char chNext = i < (iLineLen - 1)? (*pLine)[i + 1] : 0;

        // a // type comment - ignore rest of line
        if (IS_PAIR(/, /)  &&  !bMultiLineComment  &&  !bInString  &&
            cfg_bProcessComments)
        {
            bHasComments = true;
            return;
        }

        // start of /* comment
        else if (IS_PAIR(/, *)  &&  !bMultiLineComment  &&  !bInString  &&  
            cfg_bProcessComments)
        {
            bMultiLineComment = true;
            bHasComments = true;
            ++i;
        }

        // end of /* comment (
        else if (IS_PAIR(*, /)  &&  !bInString  &&  cfg_bProcessComments)
        {
            bMultiLineComment = false;
            ++i;
        }

        else if (ch == '\\'  &&  !bMultiLineComment)
        {
            // escape character - so skip next char
            ++i;
            bHasCode = true;
        }

        else if (ch == '"'  &&  !bMultiLineComment)
        {
            bInString = !bInString;
            bHasCode = true;
        }

        else if (!bMultiLineComment)
        {
            if (!isspace(ch))
            {
                bHasCode = true;
            }
        }
    }
}
