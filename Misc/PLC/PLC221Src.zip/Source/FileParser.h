/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

#ifndef __FILEPARSER_H
#define __FILEPARSER_H

class CLineViewOfFile;

class CFileInfo
{
public:
    CFileInfo() : 
        m_iLinesWithComments(0), 
        m_iLinesWithCode(0), 
        m_iBlankLines(0), 
        m_iTotalLines(0),
        m_iContext(-1),
        m_stat(unknown) {}

    enum stat 
    { 
        unknown,        // file not processed yet
        file_error,     // error reading the file
        filtered,       // the file was not read due to filtering
        full            // stats have been fully read
    };
    stat m_stat;

    int m_iContext;  // used by list control population code to track duplicates

    CString m_sFullFileName;

    CString m_sFilePath;
    CString m_sFileName;
    CString m_sFileExt;

    int m_iTotalLines;
    int m_iLinesWithCode;
    int m_iLinesWithComments;
    int m_iBlankLines;

    CString GetTotalLinesStr       (bool bDecorated = true) const;
    CString GetLinesWithCodeStr    (bool bDecorated = true) const;
    CString GetLinesWithCommentsStr(bool bDecorated = true) const;
    CString GetMixedLinesStr       (bool bDecorated = true) const;
    CString GetBlankLinesStr       (bool bDecorated = true) const;

    int CalculateMixedLines() const
    {
        return m_iLinesWithCode + m_iLinesWithComments - 
            (m_iTotalLines - m_iBlankLines);
    }

    void SetFileName(LPCTSTR pszFullFileName);

protected:

    CString DecoratedNumber(int iNum, bool bDecorated, bool bNA) const;
};

class IFileParser
{
public:
    IFileParser() {};
    virtual ~IFileParser() {};

    virtual void ParseFile(CLineViewOfFile& file, CFileInfo& info) = 0;

    virtual LPCTSTR GetDefaultExtensions() const = 0;
    virtual LPCTSTR GetParserCfgCode() const = 0;
    virtual int GetParserNameResourceID() const = 0;
};

#endif // __FILEPARSER_H
