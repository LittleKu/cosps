/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// PrjStats.h: interface for the PrjStats class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PRJSTATS_H__59D4827C_3A4F_412D_88E4_080AE9618CAB__INCLUDED_)
#define AFX_PRJSTATS_H__59D4827C_3A4F_412D_88E4_080AE9618CAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FileParser.h"

interface IWorkspaceInfo;
interface IWorkspaceProject;

class ProjectList : public CTypedPtrList<CPtrList, IWorkspaceProject *>
{
public:
    ~ProjectList();
};

int CalculateMixedLines(int iLinesTotal, int iLinesCode, int iLinesComments, 
                        int iLinesBlank);

void ResetStats();
bool UpdateStats(IWorkspaceInfo *pWI, ProjectList& projects);
CFileInfo& GetStats(LPCTSTR pszFullFileName);

#endif // !defined(AFX_PRJSTATS_H__59D4827C_3A4F_412D_88E4_080AE9618CAB__INCLUDED_)
