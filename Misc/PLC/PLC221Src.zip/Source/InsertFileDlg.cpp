/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// InsertFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "linecount.h"
#include "InsertFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsertFileDlg dialog


CInsertFileDlg::CInsertFileDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInsertFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInsertFileDlg)
	m_sFile = _T("");
	//}}AFX_DATA_INIT
}


void CInsertFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsertFileDlg)
	DDX_Text(pDX, IDC_EDIT, m_sFile);
	DDV_MaxChars(pDX, m_sFile, 512);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsertFileDlg, CDialog)
	//{{AFX_MSG_MAP(CInsertFileDlg)
	ON_EN_CHANGE(IDC_EDIT, OnChangeEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsertFileDlg message handlers

BOOL CInsertFileDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
    OnChangeEdit();
	return TRUE;
}

void CInsertFileDlg::OnOK() 
{
    UpdateData();

    if (m_sFile.FindOneOf("/:<>|\"") >= 0)
    {
        CString sMsg;
        AfxFormatString1(sMsg, IDS_ERR_BADCHAR, "/ : < > | \"");
        AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
        return;
    }
	
	CDialog::OnOK();
}

void CInsertFileDlg::OnChangeEdit() 
{
    UpdateData();
    GetDlgItem(IDOK)->EnableWindow(!m_sFile.IsEmpty());
}
