/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// Connect.cpp : Implementation of CConnect
#include "stdafx.h"

#ifdef TARGET_VC7

#include "LineCount.h"
#include "ConnectVC7.h"
#include "WorkspaceInfo.h"
#include "ResultsDlg.h"
#include "Config.h"

const wchar_t * const TOOLBAR_NAME      = L"PLC (Project Line Counter)";

const wchar_t * const COMMAND_NAME_FULL = L"LineCount.CountLines";
const wchar_t * const COMMAND_NAME      = L"CountLines";
const wchar_t * const COMMAND_TEXT      = L"Count Lines";
const wchar_t * const COMMAND_TIP       = L"Count lines of code in your projects";

// When run, the Add-in wizard prepared the registry for the Add-in.
// At a later time, if the Add-in becomes unavailable for reasons such as:
//   1) You moved this project to a computer other than which is was originally created on.
//   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
//   3) Registry corruption.
// you will need to re-register the Add-in by building the MyAddin21Setup project 
// by right clicking the project in the Solution Explorer, then choosing install.


// CConnect
STDMETHODIMP CConnect::OnConnection(IDispatch *pApplication, AddInDesignerObjects::ext_ConnectMode ConnectMode, IDispatch *pAddInInst, SAFEARRAY ** /*custom*/ )
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    HRESULT hr = S_OK;
    pApplication->QueryInterface(__uuidof(EnvDTE::_DTE), (LPVOID*)&m_pDTE);
    pAddInInst->QueryInterface(__uuidof(EnvDTE::AddIn), (LPVOID*)&m_pAddInInstance);

    if(ConnectMode == 5 /* AddInDesignerObjects::ext_cm_UISetup */)
    {
        CComPtr<EnvDTE::Commands> pCommands;
        CComPtr<EnvDTE::Command> pCreatedCommand;

        hr = m_pDTE->get_Commands(&pCommands);

        if (SUCCEEDED(hr))
        {
            hr = pCommands->Item(CComVariant(COMMAND_NAME_FULL), 0, 
                &pCreatedCommand);

            // remove command if it's already there
            if (SUCCEEDED(hr)  &&  pCreatedCommand)
            {
                pCreatedCommand->Delete();
                pCreatedCommand = NULL;
            }

            // add our command
            hr = pCommands->AddNamedCommand(
                m_pAddInInstance, 
                CComBSTR(COMMAND_NAME), 
                CComBSTR(COMMAND_TEXT), 
                CComBSTR(COMMAND_TIP), 
                VARIANT_FALSE, 
                IDB_LCGO,  // MSO: 127
                NULL, 
                EnvDTE::vsCommandStatusSupported+EnvDTE::vsCommandStatusEnabled, 
                &pCreatedCommand);

            if (SUCCEEDED(hr)  &&  pCreatedCommand)
            {
                CComPtr<Office::_CommandBars>      pCommandBars;
                CComPtr<Office::CommandBarControl> pCommandBarControl;
                CComQIPtr<Office::CommandBar>      pToolbar;

                hr = m_pDTE->get_CommandBars(&pCommandBars);
                if (SUCCEEDED(hr))
                {
                    // Get our toolbar
                    hr = pCommandBars->get_Item(CComVariant(TOOLBAR_NAME), 
                        &pToolbar);
                    if (!SUCCEEDED(hr))
                    {
                        // haven't created the toolbar yet
                        CComPtr<IDispatch> pDisp;
                        hr = pCommands->AddCommandBar(
                            (wchar_t *)(TOOLBAR_NAME),
                            EnvDTE::vsCommandBarTypeToolbar,
                            NULL,
                            0, 
                            &pDisp);        
                        if (SUCCEEDED(hr))
                        {
                            // load the new toolbar
                            hr = pCommandBars->get_Item(
                                CComVariant(TOOLBAR_NAME), &pToolbar);
                            if (pToolbar == NULL) hr = E_FAIL;
                        }
                    }

                    // make sure the toolbar is visible
                    if (pToolbar  &&  SUCCEEDED(hr))
                    {
                        pToolbar->put_Visible(VARIANT_TRUE);
                    }
                }

                // add the button to the toolbar
                if (SUCCEEDED(hr))
                {
                    // this causes a memory leak -- don't know why
                    hr = pCreatedCommand->AddControl(pToolbar, 1, 
                        &pCommandBarControl);
                    if (SUCCEEDED(hr))
                    {
                        // make sure it's image only
                        CComQIPtr<Office::_CommandBarButton> 
                            pButton(pCommandBarControl);
                        if (pButton)
                        {
                            pButton->put_Style(Office::msoButtonIcon);
                        }
                        else
                        {
                            CComQIPtr<Office::_CommandBarButtonVC8> 
                                pButtonVC8(pCommandBarControl);
                            if (pButtonVC8)
                            {
                                pButtonVC8->put_Style(Office::msoButtonIcon);
                            }
                        }
                    }
                }
            }
        }
        
        return hr;
    }

	// Note that we don't call OnAddinConnect for UI setup,
	// so we don't want to call OnAddinDisconnect in that case.
	// The m_bConnectSignaled variable helps us remember.
    OnAddinConnect();
	m_bConnectSignaled = true;

    if (g_pWorkspaceInfo == NULL)
    {
        InitializeWorkspaceInfo_VC_NET(m_pDTE);
    }

    return hr;
}

STDMETHODIMP CConnect::OnDisconnection(AddInDesignerObjects::ext_DisconnectMode a/*RemoveMode*/, SAFEARRAY ** /*custom*/ )
{
	if (m_bConnectSignaled) OnAddinDisconnect();
    
    m_pDTE = NULL;
    return S_OK;
}

STDMETHODIMP CConnect::OnAddInsUpdate (SAFEARRAY ** /*custom*/ )
{
    return S_OK;
}

STDMETHODIMP CConnect::OnStartupComplete (SAFEARRAY ** /*custom*/ )
{
    return S_OK;
}

STDMETHODIMP CConnect::OnBeginShutdown (SAFEARRAY ** /*custom*/ )
{
    return S_OK;
}

STDMETHODIMP CConnect::QueryStatus(BSTR bstrCmdName, EnvDTE::vsCommandStatusTextWanted NeededText, EnvDTE::vsCommandStatus *pStatusOption, VARIANT *pvarCommandText)
{
  if(NeededText == EnvDTE::vsCommandStatusTextWantedNone)
    {
      if(!_wcsicmp(bstrCmdName, COMMAND_NAME_FULL))
      {
          *pStatusOption = (EnvDTE::vsCommandStatus)
              (EnvDTE::vsCommandStatusEnabled |
               EnvDTE::vsCommandStatusSupported);
      }
  }
    return S_OK;
}

STDMETHODIMP CConnect::Exec(BSTR bstrCmdName, EnvDTE::vsCommandExecOption ExecuteOption, VARIANT * /*pvarVariantIn*/, VARIANT * /*pvarVariantOut*/, VARIANT_BOOL *pvbHandled)
{
    *pvbHandled = VARIANT_FALSE;
    if(ExecuteOption == EnvDTE::vsCommandExecOptionDoDefault)
    {
        if(!_wcsicmp(bstrCmdName, COMMAND_NAME_FULL))
        {
            AFX_MANAGE_STATE(AfxGetStaticModuleState());
            try
            {
                CResultsDlg dlg(g_pWorkspaceInfo);
                dlg.DoModal();
            }
            catch (...)
            {
                AfxMessageBox(
                    "Exception caught in LineCounter.\n"
                    "You should save all your work and restart Visual Studio.", 
                    MB_OK | MB_ICONEXCLAMATION);
            }
            *pvbHandled = VARIANT_TRUE;
            return S_OK;
        }
    }
    return S_OK;
}

#endif // TARGET_VC7
