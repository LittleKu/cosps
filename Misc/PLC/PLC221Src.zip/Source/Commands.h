/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomon, and is bound by the MIT   */
/* open source license (www.opensource.org/licenses/mit-license.html).     */
/* See License.txt for more information.                                   */
/***************************************************************************/

// Commands.h : header file
//

#if !defined(AFX_COMMANDS_H__04727E77_B52C_11D3_BA83_0000861DFCE7__INCLUDED_)
#define AFX_COMMANDS_H__04727E77_B52C_11D3_BA83_0000861DFCE7__INCLUDED_

#include "LineCountTypes.h"

class CCommands : 
    public CComDualImpl<ICommands, &IID_ICommands, &LIBID_LineCount>, 
    public CComObjectRoot,
    public CComCoClass<CCommands, &CLSID_Commands>
{
protected:
    IApplication* m_pApplication;

public:
    CCommands();
    ~CCommands();
    void SetApplicationObject(IApplication* m_pApplication);

    BEGIN_COM_MAP(CCommands)
        COM_INTERFACE_ENTRY(IDispatch)
        COM_INTERFACE_ENTRY(ICommands)
    END_COM_MAP()
    DECLARE_NOT_AGGREGATABLE(CCommands)

public:
    HRESULT LCCmd(int iCmd);
	STDMETHOD(LC_Go)(THIS);
	STDMETHOD(LC_Console)(THIS);
// ICommands methods
};

typedef CComObject<CCommands> CCommandsObj;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMANDS_H__04727E77_B52C_11D3_BA83_0000861DFCE7__INCLUDED)
