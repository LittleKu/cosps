// MYStatic.cpp : implementation file
//

#include "stdafx.h"
#include "ClipChildrenDemo.h"
#include "MYStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MYStatic

MYStatic::MYStatic()
{
}

MYStatic::~MYStatic()
{
}


BEGIN_MESSAGE_MAP(MYStatic, CStatic)
	//{{AFX_MSG_MAP(MYStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MYStatic message handlers

void MYStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	// ��ÿؼ��ͻ������δ�С
	CRect rect;
	GetClientRect(rect);
	// ���ƿؼ��߿�
	dc.MoveTo(0,0);
	dc.LineTo(rect.Width(),0);
	dc.LineTo(rect.Width(),rect.Height());
	dc.LineTo(0,rect.Height());
	dc.LineTo(0,0);


	// �����ı�
    dc.TextOut(rect.Width()/2 - 5,rect.Height()/2 - 5,"Hello");

	// Do not call CStatic::OnPaint() for painting messages
}


