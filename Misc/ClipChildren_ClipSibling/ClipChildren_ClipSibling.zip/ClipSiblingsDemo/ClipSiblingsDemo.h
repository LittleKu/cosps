// ClipSiblingsDemo.h : main header file for the CLIPSIBLINGSDEMO application
//

#if !defined(AFX_CLIPSIBLINGSDEMO_H__C717B5C2_E1BD_4916_B4DC_FD4904D9E81D__INCLUDED_)
#define AFX_CLIPSIBLINGSDEMO_H__C717B5C2_E1BD_4916_B4DC_FD4904D9E81D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CClipSiblingsDemoApp:
// See ClipSiblingsDemo.cpp for the implementation of this class
//

class CClipSiblingsDemoApp : public CWinApp
{
public:
	CClipSiblingsDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClipSiblingsDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CClipSiblingsDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIPSIBLINGSDEMO_H__C717B5C2_E1BD_4916_B4DC_FD4904D9E81D__INCLUDED_)
