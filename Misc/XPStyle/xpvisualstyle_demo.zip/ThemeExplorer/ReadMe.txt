===============================================
 Shell Common Controls - ThemeExplorer
================================================
Last Updated: May 29, 2001

DESCRIPTION
============
ThemeExplorer is a sample application that allows you to apply visual styles to your 
applications. When you run ThemeExplorer you can select a control and all the control's 
parts and states are displayed. Additionally, ThemeExplorer has a slide show option which shows the appearance of parts in different states. 


BROWSER/PLATFORM COMPATIBILITY
===============================
ThemeExplorer.exe operates with Microsoft� Internet Explorer 6 Public Preview on 
Microsoft Windows XP. This application will not run on any operating system except 
Windows XP because it requires ComCtl32.dll version 6. ComCtl32.dll version 6 is not 
redistributable therefore you must have Windows XP which contains this particular 
DLL. 

The headers and libraries that are required are:

Uxtheme.lib

Uxtheme.h

Tmschema.h

Schemadef.h

WinUser.h (newer version than the one I had in VC 6)

Tvout.h

All the above headers and library files are aavailable in the Platform SDK.


USAGE
=====
To build the sample, use Microsoft Visual C++ 6 and later with the latest headers 
and libraries for IE 6 Public Preview. The ThemeExplorer project files were designed 
to be built using the Win32 App Wizard. ThemeExplorer.exe is a Unicode application.

SOURCE FILES
=============
ThemeExplorer.exe
ThemeExplorer.cpp
ThemeExplorer.dsp
StdAfx.cpp


OTHER FILES
============
StdAfx.h
Readme.txt

========================
� Microsoft Corporation

  





