//
//
// Copyright (c) Microsoft Corporation
// All rights reserved.
//
//


//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ThemeExplorer.rc
//
#define IDD_DIALOG1                     101
#define IDD_DRAWTESTER                  129
#define IDC_THEMETREE                   1011
#define IDC_EXPANDALL                   1012
#define IDC_DISPLAYALL                  1015

// Default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
