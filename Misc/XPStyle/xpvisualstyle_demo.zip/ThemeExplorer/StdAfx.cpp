//
// Copyright (C) Microsoft Corporation
// All rights reserved.

// stdafx.cpp : source file that specifies the standard include files
// ThemeExplorer.pch is the pre-compiled header
// stdafx.obj contains the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
