//
// Copyright (C) Microsoft Corporation
// All rights reserved.
//

//
// ThemeExplorer.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

////////////// Global Variables ///////////////

// Boolean used to control the slide show.
BOOL g_bContinue = FALSE;

// Four rectangles used to draw the three sizes, sm., med., lg. and the text.
RECT g_rectBK_Sm = {0}, 
	 g_rectBK_Md = {0}, 
	 g_rectBK_Lg = {0}, 
	 g_rectText  = {0};


//-------------------------------------------------------------------------
//	Main window entry point.
//
//-------------------------------------------------------------------------
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	InitCommonControls();

	// Create the main dialog.
	HWND hDlg = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_DRAWTESTER), NULL, (DLGPROC)DlgProc);

	if (!hDlg)
	{
		::MessageBox(NULL, TEXT("Failed to create Dialog"), TEXT("ERROR"), MB_OK);
		return 0;
	}


	::ShowWindow(hDlg, SW_NORMAL);
	::UpdateWindow(hDlg);

	// Main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

//-------------------------------------------------------------------------
//
//  DialogProc is the window procedure for the main dialog window.
//
//-------------------------------------------------------------------------
LRESULT CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hTreeWnd	  = NULL;
	static BOOL bCollapsed    = TRUE;
	static BOOL bDone		  = TRUE;

	switch (message) 
	{
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				
				case IDCANCEL:
				{
					if (g_bContinue)
					{
						// If the slide show is running stop it and return.
						g_bContinue = FALSE;
						return 0;
					}

					if (!bDone)  //Prevents the application from not responding.
						return 0;
					
					// Traverse the tree and delete all the lParam.
					TCHAR szName[45];
					TVITEM tvi;
					tvi.mask = TVIF_HANDLE | TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN;
					tvi.pszText = szName;
					tvi.cchTextMax = 45;
					
					// Only two items are necessary.
					HTREEITEM hCurrent	= TreeView_GetRoot(hTreeWnd);
					HTREEITEM hNext		= TreeView_GetChild(hTreeWnd, hCurrent);

					if (!hCurrent)
						return 0;

					while (hNext)
					{
						hCurrent = hNext;

						tvi.hItem = hCurrent;
						TreeView_GetItem(hTreeWnd, &tvi);

						// Delete the lParam.
						if (tvi.lParam)
						{
							if (g_xpStyle.IsAppThemed())
								g_xpStyle.CloseThemeData(((LPDRAWSTUFF)tvi.lParam)->hTheme);
							
							LPDRAWSTUFF lpDS = (LPDRAWSTUFF)tvi.lParam;

							delete lpDS;
							tvi.lParam = NULL;
						}
					
						if (!(hNext = TreeView_GetChild(hTreeWnd, hNext)))
									hNext = TreeView_GetNextSibling(hTreeWnd, hCurrent);
						
						
						while (!hNext && hCurrent)
						{
							// The parent must exist or the application cannot reach these lines of code.
							hCurrent = TreeView_GetParent(hTreeWnd, hCurrent);
							hNext    = TreeView_GetNextSibling(hTreeWnd, hCurrent);
						}
					}
										
					PostMessage(hWnd, WM_QUIT, 0, 0);
					return 0;
				}
				
				case IDC_EXPANDALL:  // Expands all the items in the tree.
				{
					HTREEITEM hCurrent = TreeView_GetRoot(hTreeWnd);
					UINT uFlag = NULL;

					ShowWindow(hTreeWnd, SW_HIDE);
					UpdateWindow(hTreeWnd);
					
					if (bCollapsed)
					{
						SetWindowText((HWND)lParam, TEXT("Collapse All"));
						uFlag = TVE_EXPAND;
						bCollapsed = FALSE;
					}
					else
					{
						SetWindowText((HWND)lParam, TEXT("Expand All"));
						uFlag = TVE_COLLAPSE;
						bCollapsed = TRUE;
					}

					
					while (hCurrent)
					{
						TreeView_Expand(hTreeWnd, hCurrent,uFlag);
						hCurrent = TreeView_GetNextVisible(hTreeWnd, hCurrent);
					}

					ShowWindow(hTreeWnd, SW_NORMAL);
					UpdateWindow(hTreeWnd);
					
					break;
				}

				case IDC_DISPLAYALL:  // This is the slide show button.
					if (!g_bContinue)
					{
						SetWindowText((HWND)lParam, TEXT("S T O P"));
						g_bContinue = TRUE;
						bDone = FALSE;
						WalkTree(hTreeWnd);
						SetWindowText((HWND)lParam, TEXT("&Slide Show"));
						bDone = TRUE;
					}
					else
					{
						g_bContinue = FALSE;
						SetWindowText((HWND)lParam, TEXT("&Slide Show"));
					}

					break;
			}
			break;
		}

		case WM_NOTIFY:
		{
			// Draws the selected item.
			LPNMHDR pnmh = (LPNMHDR) lParam;
			
			switch (pnmh->code)
			{
				case TVN_SELCHANGED:
				{
					LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) lParam;
					
					// Draws the item.
					LPDRAWSTUFF lpDS = (LPDRAWSTUFF)pnmtv->itemNew.lParam;
					DrawItems(lpDS, hWnd);
					
				}
			}		
			break;
		}

	
		case WM_INITDIALOG:
		{
			hTreeWnd = GetDlgItem(hWnd, IDC_THEMETREE);

			// Fill the tree and set the drawing rectangles.
			if (!LoadTree(hTreeWnd) || !SetDrawRects(hWnd))
			{
				::MessageBox(NULL, TEXT("Failed to get client rect"), TEXT("ERROR"), MB_OK);
				PostQuitMessage(0);
			}
			
			break;
		}

	}	
   return 0;
}


//-------------------------------------------------------------------------
//
// Loads the theme data in a tree.
//
//   The roots represent the theme class
//   |
//    ----  Parts
//       |
//        ----  States
//
//-------------------------------------------------------------------------
BOOL LoadTree(HWND hTreeWnd)
{
	const TMSCHEMAINFO *pSchemaInfo = GetSchemaInfo();
	const int nSchCnt = pSchemaInfo->iPropCount;
	const TCHAR szParts[] = TEXT("PARTS");
	const TCHAR szStates[] = TEXT("STATES");
	const TMPROPINFO* pPropTable = pSchemaInfo->pPropTable;
	
	TCHAR szClassName[35];
	TCHAR szPartName[35];
	TCHAR szStateName[35];
	LPDRAWSTUFF lpDS = NULL;
	LPDRAWSTUFF lpDSPart = NULL;
	
	int i = 0;
	TVINSERTSTRUCT tvi = {0};
	
	// Move past the items at the beginning of the file.
	while ((i < nSchCnt) && !_tcsstr(pSchemaInfo->pPropTable[i].pszName, szParts))
		i++;

	if (i == nSchCnt) // No parts were found.
		return FALSE;
	
	
	for (int j = i; j < nSchCnt; j++)
	{
		if (_tcsstr(pPropTable[j].pszName, TEXT("PARTS")))
		{

			tvi.hParent = NULL;
			tvi.hInsertAfter = TVI_LAST;
			
			// Make a copy of the text for the treeview and remove the "PARTS".  
			int n = _tcslen(pPropTable[j].pszName) - 5;
			_tcsncpy(szClassName, pPropTable[j].pszName, n);
			szClassName[n] = TEXT('\0');    // Add the null terminator.

			// Get the theme handle if it exists for this item.
			// Open a handle to the theme data.
			HTHEME hTheme = NULL;
			if (g_xpStyle.IsAppThemed())
				hTheme = g_xpStyle.OpenThemeData(NULL, szClassName);
			
			if (hTheme)  // If the application does not find a handle, return.
			{

				// Enter the text.
				tvi.itemex.mask = TVIF_TEXT | TVIF_PARAM;
				tvi.itemex.pszText = szClassName;
				tvi.itemex.cchTextMax = n;
				tvi.itemex.lParam = 0;

				// Add the item to the end of the root.
				HTREEITEM hParent = TreeView_InsertItem(hTreeWnd, &tvi);
					
				// Retrieve the children.
				j++;

				int nPartNum = 0;  // This equates to the enum value for the part.
				while (!(_tcsstr(pPropTable[j].pszName, szParts)) &&
					   !(_tcsstr(pPropTable[j].pszName, szStates)))
				{
					nPartNum++;  // Part numbers start with number 1.
						
					tvi.hParent = hParent;
				
					_tcscpy(szPartName, pPropTable[j].pszName);
					tvi.itemex.pszText = szPartName;
					tvi.itemex.cchTextMax = _tcslen(pPropTable[j].pszName);
					
					lpDSPart = new DRAWSTUFF();					
					if (lpDSPart)
					{
						memset(lpDSPart, TEXT('\0'), sizeof(DRAWSTUFF));

						lpDSPart->hTheme = hTheme;
						lpDSPart->nPart = nPartNum;
						lpDSPart->nState = 0;
						_tcscpy(lpDSPart->szClassName, szClassName);
						_tcscpy(lpDSPart->szPartName, szPartName);
						lpDSPart->szState[0] = TEXT('\0');
										
					}
					else
						return FALSE;
					
					// Add the item as an lParam
					tvi.itemex.lParam = (LPARAM)lpDSPart;

					HTREEITEM hChild = TreeView_InsertItem(hTreeWnd, &tvi);
					j++;

					// Retrieve the states.
					int k = j;
					TCHAR Temp[45];
					StrCpy(Temp, szPartName);
					StrCat(Temp, szStates);  //szTest now equals partSTATES.
					while ((k < nSchCnt) && !(_tcsstr(pPropTable[k++].pszName, Temp)));

					
					if (k < nSchCnt)  //The item is found.
					{
						// Fill in states.
						int nStateNum = 0;
						while ((k < nSchCnt) && !(_tcsstr(pPropTable[k].pszName, szParts)) &&
							   !(_tcsstr(pPropTable[k].pszName, szStates)))
						{
							nStateNum++;
							tvi.hParent = hChild;
				
							_tcscpy(szStateName, pPropTable[k].pszName);
							tvi.itemex.pszText = szStateName;
							tvi.itemex.cchTextMax = _tcslen(pPropTable[k].pszName);

						
							lpDS = new DRAWSTUFF();
							
							if (lpDS)
							{
								memset(lpDS , TEXT('\0'), sizeof(DRAWSTUFF));
								lpDS->hTheme = hTheme;
								lpDS->nPart = nPartNum;
								lpDS->nState = nStateNum;
								_tcscpy(lpDS->szClassName, szClassName);
								_tcscpy(lpDS->szPartName, szPartName);
								_tcscpy(lpDS->szState, szStateName);								
							}
							else
								return FALSE;

							// Add the item as an lParam
							tvi.itemex.lParam = (LPARAM)lpDS;
							
							TreeView_InsertItem(hTreeWnd, &tvi);
							k++;
						}
					}				
				}
				j--;  // The item is incremented in the while statements.
			}
		}
	}		
	return TRUE;
} //End of LoadTree.


//-------------------------------------------------------------------------
//
// Walk each item in the tree and sets the focus to it.
// This causes each item to be displayed.
//
//-------------------------------------------------------------------------
void WalkTree(HWND hTreeWnd)
{	
	MSG msg;
	// Only two items are necessary.
	HTREEITEM hCurrent	= TreeView_GetRoot(hTreeWnd);
	HTREEITEM hNext		= TreeView_GetChild(hTreeWnd, hCurrent);

	if (!hCurrent)
		return;

	TreeView_Select(hTreeWnd, hCurrent, TVGN_CARET);

	while (hNext && g_bContinue)
	{
		hCurrent = hNext;
		
		TreeView_Select(hTreeWnd, hCurrent, TVGN_CARET);
		Sleep(1000);

		// Prevents the program from hanging.
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if (!(hNext = TreeView_GetChild(hTreeWnd, hNext)))
					hNext = TreeView_GetNextSibling(hTreeWnd, hCurrent);
		
		// The parent must exist or the application cannot reach this code.
		while (!hNext && hCurrent)
		{
			hCurrent = TreeView_GetParent(hTreeWnd, hCurrent);
			hNext    = TreeView_GetNextSibling(hTreeWnd, hCurrent);
		}
	}
} //End of WalkTree.

//-------------------------------------------------------------------------
//
//  Initially sets the drawing rectangles.  
//  These are set proportionally to the screens size.
//
//-------------------------------------------------------------------------
BOOL SetDrawRects(HWND hDlgWnd)
{
	// Retrieve the client rect.
	RECT rectClient = {0};

	if (!GetClientRect(hDlgWnd, &rectClient))
		return FALSE;
	

	int nWidth = rectClient.right - rectClient.left;
	int nHeight = rectClient.bottom - rectClient.top;

	if (!nWidth || !nHeight)
		return FALSE;

	int QuaterWidth			= nWidth	/ 4;
	int QuaterHeight		= nHeight	/ 4;
	int EightWidth			= nWidth	/ 8;
	int EightHeight			= nHeight	/ 8;
	int SixteenthWidth		= nWidth	/ 16;
	int SixteenthHeight		= nHeight	/ 16;


	//Small = 1/16 of the client rect.
	g_rectBK_Sm.left = nWidth - QuaterWidth - SixteenthWidth / 2;
	g_rectBK_Sm.right = g_rectBK_Sm.left + SixteenthWidth;
	g_rectBK_Sm.top = nHeight / 8;
	g_rectBK_Sm.bottom = g_rectBK_Sm.top + SixteenthHeight;

	//Med	= 1/8 of the client rect.
	g_rectBK_Md.left = nWidth - QuaterWidth - EightWidth / 2;
	g_rectBK_Md.right = g_rectBK_Md.left + EightWidth;
	g_rectBK_Md.top = g_rectBK_Sm.bottom + SixteenthHeight;
	g_rectBK_Md.bottom = g_rectBK_Md.top + EightHeight;

	//Large = 1/4 of the client rect.
	g_rectBK_Lg.left = nWidth - QuaterWidth - QuaterWidth / 2;
	g_rectBK_Lg.right = g_rectBK_Lg.left + QuaterWidth;
	g_rectBK_Lg.top = g_rectBK_Md.bottom + SixteenthHeight;
	g_rectBK_Lg.bottom = g_rectBK_Lg.top + QuaterHeight;

	//Text rect same as large.
	g_rectText.left = nWidth - QuaterWidth - QuaterWidth / 2;
	g_rectText.right = g_rectText.left + QuaterWidth;
	g_rectText.top = g_rectBK_Lg.bottom  + SixteenthHeight;
	g_rectText.bottom = g_rectText.top + QuaterHeight;

	return TRUE;
		 
} //End of SetDrawRects.


//-------------------------------------------------------------------------
//
//  Erases the old item and draws the new one.
//
//-------------------------------------------------------------------------	
void DrawItems(LPDRAWSTUFF lpDI, HWND hDlgWnd)
{	
	HDC hDC = GetDC(hDlgWnd);


	// Erases the background, with the old rects.
	RedrawWindow(hDlgWnd, &g_rectBK_Sm, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_UPDATENOW);
	RedrawWindow(hDlgWnd, &g_rectBK_Md, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_UPDATENOW);
	RedrawWindow(hDlgWnd, &g_rectBK_Lg, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_UPDATENOW);
	RedrawWindow(hDlgWnd, &g_rectText, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_UPDATENOW);

	if (!lpDI)
		return;
	

	// Draws the three sizes of the background.
	if (g_xpStyle.IsAppThemed())
	{
		g_xpStyle.DrawThemeBackground(lpDI->hTheme, hDC, lpDI->nPart, lpDI->nState, &g_rectBK_Sm, NULL);
		g_xpStyle.DrawThemeBackground(lpDI->hTheme, hDC, lpDI->nPart, lpDI->nState, &g_rectBK_Md, NULL);
		g_xpStyle.DrawThemeBackground(lpDI->hTheme, hDC, lpDI->nPart, lpDI->nState, &g_rectBK_Lg, NULL);
	}


	// Draws the text.
	TCHAR pszText[70];
	_stprintf(pszText, TEXT("%s %s %s"), lpDI->szClassName, lpDI->szPartName, lpDI->szState);
	if (g_xpStyle.IsAppThemed())
		g_xpStyle.DrawThemeText(lpDI->hTheme, hDC, lpDI->nPart, lpDI->nState, pszText, _tcsclen(pszText), 
				DT_WORDBREAK | DT_CENTER | DT_WORD_ELLIPSIS, NULL, &g_rectText);
	

	ReleaseDC(hDlgWnd, hDC);
} //End of DrawItems.
