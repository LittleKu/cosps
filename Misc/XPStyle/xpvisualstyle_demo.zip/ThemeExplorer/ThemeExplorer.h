//
// Copyright (C) Microsoft Corporation
// All rights reserved.
//

#if !defined(AFX_THEMEEXPLORER_H__DF1DCC0B_DD28_4B52_B037_A6680E49CE1B__INCLUDED_)
#define AFX_THEMEEXPLORER_H__DF1DCC0B_DD28_4B52_B037_A6680E49CE1B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

// The schema file expects these to be defined by the user.
#define TMT_ENUMDEF 8
#define TMT_ENUMVAL TEXT('A')
#define TMT_ENUM	TEXT('B')

#include <tmschema.h>
#define SCHEMA_STRINGS
#include "TmSchema.h" 

typedef struct lpds{
	HANDLE	hTheme;					//Handle to the theme.
	UINT	nPart;					//Enumeration for the part.
	UINT	nState;					//Enumeration for the state.
	TCHAR   szClassName[20];		//Class name.
	TCHAR   szPartName[35];			//Part name.
	TCHAR   szState[35];			//State name.
}DRAWSTUFF, *LPDRAWSTUFF;


// Foward declarations of functions included in this code module:

//-------------------------------------------------------------------------
//  LoadTree()			- Reads in the themes parts and states and creates
//						the tree.
//
//  hTreeWnd            - Tree control handle
//  pSchemaInfo			- Pointer to the schema info.  
//						Created by the tmschema.h file.
//-------------------------------------------------------------------------
BOOL LoadTree(HWND hTreeWnd);


//-------------------------------------------------------------------------
//	DlgProc				- Window proc for the main dialog.
//
//	Normal WndProc parameters.
//-------------------------------------------------------------------------
LRESULT CALLBACK	DlgProc(HWND, UINT, WPARAM, LPARAM);


//-------------------------------------------------------------------------
//	SetDrawRects		- Initializes the drawing rectangles.
//
//	hDlgWnd				- Handle to the main dialog
//-------------------------------------------------------------------------
BOOL SetDrawRects(HWND hDlgWnd);

//-------------------------------------------------------------------------
//	WalkTree			- Traveres the tree setting the focus to each member
//						and then pauses for a short period
//
//	hTreeWnd			- Handle to the tree.
//-------------------------------------------------------------------------
void WalkTree(HWND hTreeWnd);

//-------------------------------------------------------------------------
//	DrawItems			- Erases the previous items and draws the new section.
//
//	lpDrawInfo			- Contains the parts and states as well as the text.
//  hDlgWnd				- Handle to the main dialog window.
//-------------------------------------------------------------------------
void DrawItems(LPDRAWSTUFF lpDrawInfo, HWND hDlgWnd);



#endif // !defined(AFX_THEMEEXPLORER_H__DF1DCC0B_DD28_4B52_B037_A6680E49CE1B__INCLUDED_)
