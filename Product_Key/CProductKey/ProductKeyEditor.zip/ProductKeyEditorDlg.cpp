/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Implementation of the class "CProductKeyEditorDlg"
             (sample product key editor)

$Log$

******************************************************************************/

#include "stdafx.h"
#include "ProductKeyEditorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*** Definition of the class "CAboutDlg" *************************************/
class CAboutDlg: public CDialog
{
  public:
	CAboutDlg();

  // Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

  // Implementation
  protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/*** Constructor *************************************************************/
CAboutDlg::CAboutDlg(): CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

/*** Protected member functions **********************************************/

/*** Data exchange: member variables <--> controls ***************************/
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

/*** Message handler table ***************************************************/
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/*** Definition of the class "CProductKeyEditorDlg" **************************/

/*** Constructor *************************************************************/
CProductKeyEditorDlg::CProductKeyEditorDlg(CWnd* pParent):
  CDialog(IDD, pParent)
{
	//{{AFX_DATA_INIT(CProductKeyEditorDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

/*** Protected member functions **********************************************/

/*** Enable/disable buttons because of change of the product key *************/
void CProductKeyEditorDlg::OnChangeProductKey() 
{
  bool bProductKeyComplete = m_productKey.IsComplete();

	GetDlgItem(IDC_DELETE)->EnableWindow(!m_productKey.IsEmpty());
  GetDlgItem(IDC_CUT)   ->EnableWindow(bProductKeyComplete);
  GetDlgItem(IDC_COPY)  ->EnableWindow(bProductKeyComplete);
}

/*** The button "Copy" has been clicked **************************************/
void CProductKeyEditorDlg::OnCopy() 
{
	m_productKey.Copy();    // copy product key to clipboard
}

/*** The button "Cut" has been clicked ***************************************/
void CProductKeyEditorDlg::OnCut() 
{
	m_productKey.Cut     ();      // cut product key to clipboard
  m_productKey.SetFocus();
}

/*** The button "Delete" has been clicked ************************************/
void CProductKeyEditorDlg::OnDelete() 
{
  m_productKey.Delete  ();      // delete input fields of product key
  m_productKey.SetFocus();
}

/*** The button "Paste" has been clicked *************************************/
void CProductKeyEditorDlg::OnPaste() 
{
  m_productKey.Paste();	        // paste product key from clipboard
}

/*** Data exchange: member variables <--> controls ***************************/
void CProductKeyEditorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProductKeyEditorDlg)
	//}}AFX_DATA_MAP
}

/*** Will be called before the first display of the dialog *******************/
BOOL CProductKeyEditorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
  m_productKey.SubclassDlgItem(IDC_KEY1, this, 5);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

/*** System menu entry has been selected *************************************/
void CProductKeyEditorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

/*** Draw icon in minimized mode *********************************************/
void CProductKeyEditorDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

/*** The system calls this to obtain the cursor to display while the user ****/
/*** drags the minimized window                                           ****/
HCURSOR CProductKeyEditorDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/*** Message handler table ***************************************************/
BEGIN_MESSAGE_MAP(CProductKeyEditorDlg, CDialog)
	//{{AFX_MSG_MAP(CProductKeyEditorDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_COPY, OnCopy)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_CUT, OnCut)
	ON_BN_CLICKED(IDC_PASTE, OnPaste)
	ON_EN_CHANGE(IDC_KEY1, OnChangeProductKey)
	ON_EN_CHANGE(IDC_KEY2, OnChangeProductKey)
	ON_EN_CHANGE(IDC_KEY3, OnChangeProductKey)
	ON_EN_CHANGE(IDC_KEY4, OnChangeProductKey)
	ON_EN_CHANGE(IDC_KEY5, OnChangeProductKey)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
