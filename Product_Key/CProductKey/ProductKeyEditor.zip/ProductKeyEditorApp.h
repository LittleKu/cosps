/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Interface of the class "CProductKeyEditorApp"
             (sample product key editor)

$Log$

******************************************************************************/

/*** Declaration of the classe "CProductKeyEditorApp" ************************/
class CProductKeyEditorApp: public CWinApp
{
  public:
	CProductKeyEditorApp();

  // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProductKeyEditorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

  // Implementation

	//{{AFX_MSG(CProductKeyEditorApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
