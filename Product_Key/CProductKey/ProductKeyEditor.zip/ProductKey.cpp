/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Implementation of the class "CProductKey"
             (helper class for input and editing of product keys)

$Log$

******************************************************************************/

#include "stdafx.h"
#include "ProductKey.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*** Definition of class "CEditProductKey" ***********************************/
class CEditProductKey: public CEdit
{
  friend class CProductKey;

  public:
  CEditProductKey(CProductKey* pProductKey): m_pProductKey(pProductKey),
                                             m_pPrev      (0),
                                             m_pNext      (0)
  {}

  // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditProductKey)
	//}}AFX_VIRTUAL

	// Generated message map functions
  protected:
	//{{AFX_MSG(CEditProductKey)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

  DECLARE_MESSAGE_MAP()

  private:
  CProductKey*     m_pProductKey;
  CEditProductKey* m_pPrev;
  CEditProductKey* m_pNext;
};

/*** Protected member functions **********************************************/

/*** A character has been enetered *******************************************/
void CEditProductKey::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if (!m_pProductKey->IsValid(nChar) && nChar != _T('\b'))
  {
    MessageBeep(0xFFFFFFFF);
    return;
  }

  int nMaxChar = GetLimitText();

  if (m_pNext && nChar != _T('\b'))
  {
    // When the input field is filled and the cursor is positioned to the right
    // of the last character, the cursor will be positioned in the next input
    // field automatically.
    int nStartChar, nEndChar;
    GetSel(nStartChar, nEndChar);
    if (nStartChar == nMaxChar && nEndChar == nMaxChar)
    {
      CString str;

      m_pNext->GetWindowText(str);
      if (str.IsEmpty())
      {
        m_pNext->SetFocus     ();
        m_pNext->SetWindowText(CString(static_cast<TCHAR>(nChar)));
        m_pNext->SetSel       (1, 1);
      }
      else
        MessageBeep(0xFFFFFFFF);
      return;
    }
  }

  DefWindowProc(WM_CHAR, nChar, MAKELPARAM(nRepCnt, nFlags));

  if (m_pNext && nChar != _T('\b'))
  {
    // When the input field is filled and the cursor is positioned to the right
    // of the last character, the cursor will be positioned in the next input
    // field automatically.
    int nStartChar, nEndChar;
    GetSel(nStartChar, nEndChar);
    if (nStartChar == nMaxChar && nEndChar == nMaxChar)
    {
      CString str;

      m_pNext->GetWindowText(str);
      if (static_cast<UINT>(str.GetLength()) < m_pNext->GetLimitText())
        m_pNext->SetFocus();
    }
  }
}

/*** A key has been pressed **************************************************/
void CEditProductKey::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  int nStartChar, nEndChar;
  GetSel(nStartChar, nEndChar);

  switch (nChar)
  {
    case _T('\b'):
    case VK_LEFT:
      if (m_pPrev && nStartChar == 0 && nEndChar == 0)
      {
        // When the cursor is positioned to the left of the first character,
        // the cursor will positioned in the previous input field
        // automatically.
        m_pPrev->SetFocus();
        CString str;
        m_pPrev->GetWindowText(str);
        nEndChar = str.GetLength();
        m_pPrev->SetSel(nEndChar, nEndChar);
        return;
      }
      break;

    case VK_RIGHT:
    {
      CString str;
      GetWindowText(str);
      int nLastChar = str.GetLength();

      if (m_pNext && nStartChar == nLastChar && nEndChar == nLastChar)
      {
        // When the cursor is positioned to the right of the last character,
        // the cursor will be positioned in the next input field automatically.
        m_pNext->SetFocus();
        m_pNext->SetSel(0, 0);
        return;
      }
      break;
    }

    default:
      break;
  }
	
	CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

/*** Table of message handlers ***********************************************/
BEGIN_MESSAGE_MAP(CEditProductKey, CEdit)
	//{{AFX_MSG_MAP(CEditProductKey)
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/*** Definition of the class "CProductKey" ***********************************/

int     CProductKey::m_nUseCustomizedFont = 0;
CString CProductKey::m_strFontFileName;

/*** Destructor **************************************************************/
CProductKey::~CProductKey()
{
  while (m_pFirst)
  {
    CEditProductKey* pNext = m_pFirst->m_pNext;

    delete m_pFirst;
    m_pFirst = pNext;
  }

  RemoveCustomizedFont();
}

/*** Public member functions  ************************************************/

/*** Copy product key to clipboard as string *********************************/
bool CProductKey::Copy() const
{
  bool    bSuccess      = false;
  CString strProductKey = Get();


  if (!strProductKey.IsEmpty())
    if (OpenClipboard(0))
    {
      HGLOBAL hMem =
        GlobalAlloc(
          GMEM_MOVEABLE, (strProductKey.GetLength() + 1) * sizeof(TCHAR));

      if (hMem)
      {
        LPTSTR psz = static_cast<LPTSTR>(GlobalLock(hMem));

        if (psz)
        {
          _tcscpy(psz, strProductKey);
          if (GlobalUnlock(hMem) == NO_ERROR)
            if (EmptyClipboard() && SetClipboardData(CF_TEXT, hMem))
              bSuccess = true;
        }
        CloseClipboard();
        GlobalFree    (hMem);
      }
      else
        CloseClipboard();
    }

  return bSuccess;
}

/*** Cut product key to keyboard as string ***********************************/
bool CProductKey::Cut() const
{
  if (Copy())
  {
    Delete();
    return true;
  }
  else
    return false;
}

/*** Delete all input fields *************************************************/
void CProductKey::Delete() const
{
  for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
    p->SetWindowText(_T(""));
}

/*** Return product key as string (dashes are used as separator between ******/
/*** the single items)                                                  ******/
const CString CProductKey::Get() const
{
  CString strProductKey;

  if (IsComplete())
  {
    CString str;

    for (CEditProductKey* p = m_pFirst;;)
    {
      p->GetWindowText(str);
      strProductKey += str;
      p = p->m_pNext;
      if (p)
      {
        if (m_chDelimiter != _T('\0')) strProductKey += m_chDelimiter;
      }
      else
        break;
    }
  }

  return strProductKey;
}

/*** Has product key been filled in completely? ******************************/
bool CProductKey::IsComplete() const
{
  CString str;

  for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
  {
    p->GetWindowText(str);
    if (str.GetLength() < static_cast<int>(p->GetLimitText())) return false;
  }
  return true;
}

/*** Is product key empty? ***************************************************/
bool CProductKey::IsEmpty() const
{
  CString str;

  for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
  {
    p->GetWindowText(str);
    if (!str.IsEmpty()) return false;
  }
  return true;
}

/*** Is the given character a valid character of a product key? **************/
bool CProductKey::IsValid(int ch) const
{
  // alphanumeric product key allowed --> test for letter
  if (m_type == ALPHANUM && _istalpha(ch)) return true;

  // hexadecimal product key --> test for hex digit
  if (m_type == HEX && _istxdigit(ch)) return true;

  // digits are always allowed
  if (_istdigit(ch)) return true;

  return false;
}

/*** Limit the maximum length of all input fields ****************************/
void CProductKey::LimitText(int nItem, int nChars) const
{
  if (nChars > 0)
  {
    int i = 0;

    for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
      if (nItem == -1)
        p->SetLimitText(nChars);
      else if (nItem == i++)
      {
        p->SetLimitText(nChars);
        break;
      }
  }
}

/*** Paste product key from clipboard ****************************************/
bool CProductKey::Paste() const
{
  bool bSuccess = false;

  if (OpenClipboard(0))
  {
    HGLOBAL hMem = GetClipboardData(CF_TEXT);

    if (hMem)
    {
      bSuccess = Set(static_cast<LPCTSTR>(GlobalLock(hMem)));

      GlobalUnlock(hMem);
    }
    CloseClipboard();
  }

  return bSuccess;
}

/*** Set product key from string *********************************************/
bool CProductKey::Set(LPCTSTR pszProductKey) const
{
  bool bSuccess = false;

  if (pszProductKey)
  {
    // check validity of string
    bool    bValid = true;
    LPCTSTR psz1   = pszProductKey;

    if (m_chDelimiter != _T('\0'))
      // delimiter character
      for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
      {
        LPCTSTR  psz2 = _tcschr(psz1, m_chDelimiter);
        UINT_PTR nChars;

        if (psz2)
        {
          nChars = psz2 - psz1;

          if (nChars != p->GetLimitText())
          {
            bValid = false;
            break;
          }
        }
        else
        {
          nChars = _tcslen(psz1);

          if (p->m_pNext || nChars != p->GetLimitText())
          {
            bValid = false;
            break;
          }
        }

        for (UINT i = 0; i < nChars; ++i)
          if (!IsValid(*psz1++))
          {
            bValid = false;
            goto checkComplete;
          }

        ++psz1;
      }
    else
    {
      // no delimiter character
      UINT nChars = 0;

      for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
        nChars += p->GetLimitText();

      for (UINT i = 0; i < nChars; ++i)
        if (!IsValid(*psz1++))
        {
          bValid = false;
          break;
        }
    }

    checkComplete:
    if (bValid)
    {
      // copy clipboard data into input fields
      psz1 = pszProductKey;

      if (m_chDelimiter != _T('\0'))
      {
        // delimiter character
        CString str;
        for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
        {
          LPCTSTR psz2 = _tcschr(psz1, m_chDelimiter);

          if (psz2)
          {
            str = CString(psz1, static_cast<int>(psz2 - psz1));
            psz1 = ++psz2;
          }
          else
            str = psz1;

          p->SetWindowText(str);
        }
      }
      else
        // no delimiter character
        for (CEditProductKey* p = m_pFirst; p; p = p->m_pNext)
        {
          UINT nChars = p->GetLimitText();

          p->SetWindowText(CString(psz1, nChars));
          psz1 += nChars;
        }

      bSuccess = true;
    }
  }

  return bSuccess;
}

/*** Set delimiter between the elements of the product key *******************/
TCHAR CProductKey::SetDelimiter(TCHAR chDelimiter)
{
  TCHAR chOldDelimiter = m_chDelimiter;

  m_chDelimiter = chDelimiter;
  return chOldDelimiter;
}

/*** Set focus to first input field ******************************************/
CWnd* CProductKey::SetFocus() const
{
  if (m_pFirst) return m_pFirst->SetFocus(); else return 0;
}

/*** Set type of product key (decimal, hexadecimal, or alphanumeric) *********/
CProductKey::TYPE CProductKey::SetType(TYPE type)
{
  TYPE oldType = m_type;

  m_type = type;
  return oldType;
}

/*** Subclass all input fields from "CEditProductKey" ************************/
bool CProductKey::SubclassDlgItem(UINT nIDOfFirstItem, CWnd* pParent,
                                  int nItemCount, int nChars)
{
  CEditProductKey* pPrev = 0;

  for (int i = 0; i < nItemCount; ++i)
  {
    CEditProductKey* p = new CEditProductKey(this);

    if (p->SubclassDlgItem(nIDOfFirstItem++, pParent))
    {
      p->SetLimitText(nChars > 0 ? nChars : 5);

      if (i == 0)
      {
        m_pFirst = p;

        if (m_nUseCustomizedFont++ == 0)
        {
          // load font from resources
          HMODULE    hModule           = AfxGetInstanceHandle();
          HRSRC      hResInfo          =
            FindResource(hModule, MAKEINTRESOURCE(IDR_PIN_FONT), _T("FNT"));

          if (hResInfo)
          {
            DWORD   dwSizeOfFont = SizeofResource(hModule, hResInfo);
            HGLOBAL hResData     = LoadResource(hModule, hResInfo);

            if (hResData)
            {
              LPSTR pFont = static_cast<LPSTR>(LockResource(hResData));

              if (pFont)
              {
                const char szEmptyFontName[] = "$PIN$01234567$";
                      char szFontName[sizeof szEmptyFontName];

                // create font name and ...
                sprintf(szFontName, "$PIN$%08X$", GetCurrentProcessId());

                // ... patch the font resource with it
                LPSTR p;
                LPSTR pEnd = pFont + dwSizeOfFont - sizeof szEmptyFontName;
                for (p = pFont; p <= pEnd; ++p)
                  if (!strcmp(p, szEmptyFontName))
                  {
                    strcpy(p, szFontName);
                    break;
                  }

                if (p <= pEnd)
                {
                  // write font to temporary file
                  int nFontFileNameLength =
                    GetTempPath(1, m_strFontFileName.GetBuffer(1)) + 1;

                  m_strFontFileName.ReleaseBuffer();
                  if (nFontFileNameLength > 1 &&
                      GetTempPath(
                        nFontFileNameLength,
                        m_strFontFileName.GetBuffer(nFontFileNameLength)))
                  {
                    m_strFontFileName.ReleaseBuffer();
                    m_strFontFileName += CString(szFontName) + _T(".FNT");

                    try
                    {
                      CFile fileFont(m_strFontFileName, CFile::modeCreate |
                                     CFile::modeWrite | CFile::typeBinary);

                      fileFont.Write(pFont, dwSizeOfFont);
                    }
                    catch (CFileException* e)
                    {
                      m_nUseCustomizedFont = 0;
                      e->Delete();
                    }
                  }
                  else
                    m_nUseCustomizedFont = 0;

                  if (m_nUseCustomizedFont == 1)
                    // install font
                    if (!AddFontResource(m_strFontFileName))
                    {
                      _tremove(m_strFontFileName);
                      m_nUseCustomizedFont = 0;
                    }
                }
                else
                  m_nUseCustomizedFont = 0;
              }
              else
                m_nUseCustomizedFont = 0;
            }
            else
              m_nUseCustomizedFont = 0;
          }
          else
            m_nUseCustomizedFont = 0;
        }

        if (m_nUseCustomizedFont > 0)
        {
          // switch to a special modified font "Courier" to achieve better
          // distinguishability
          CFont*  pFont = p->GetFont();
          LOGFONT logFont;

          if (pFont->GetLogFont(&logFont))
          {
            _stprintf(logFont.lfFaceName, _T("$PIN$%08X$"),
                      GetCurrentProcessId());
            if (!m_font.CreateFontIndirect(&logFont)) RemoveCustomizedFont();
          }
          else
            RemoveCustomizedFont();
        }
      }
      else
      {
        pPrev->m_pNext = p;
        p->m_pPrev     = pPrev;
      }
      if (m_nUseCustomizedFont > 0) p->SetFont(&m_font);
      pPrev = p;
    }
    else
      return false;
  }
  return true;
}

/*** Private member functions ************************************************/

/*** Remove customized font from system **************************************/
void CProductKey::RemoveCustomizedFont()
{
  if (--m_nUseCustomizedFont == 0)
  {
    RemoveFontResource     (m_strFontFileName);
    _tremove               (m_strFontFileName);
    m_strFontFileName.Empty();
  }
}
