/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Includes all standard header files.

$Log$

******************************************************************************/

#include <afx.h>
#include <afxwin.h>
#include "resource.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
