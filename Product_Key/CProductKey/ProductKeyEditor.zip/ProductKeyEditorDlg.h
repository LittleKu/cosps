/******************************************************************************

$Author$
  
$Modtime$
$Revision$

Description: Interface of the class "CProductKeyEditorDlg"
             (sample product key editor)

$Log$

******************************************************************************/

#include "ProductKey.h"

/*** Declaration of the class "CProductKeyEditorDlg" *************************/
class CProductKeyEditorDlg: public CDialog
{
  // Construction
  public:
	CProductKeyEditorDlg(CWnd* pParent = 0);	// standard constructor

  // Dialog Data
	//{{AFX_DATA(CProductKeyEditorDlg)
	enum { IDD = IDD_PRODUCTKEYEDITOR_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProductKeyEditorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

  // Implementation
  protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CProductKeyEditorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCopy();
	afx_msg void OnDelete();
	afx_msg void OnCut();
	afx_msg void OnPaste();
	afx_msg void OnChangeProductKey();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  private:
  CProductKey m_productKey;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
