// BaseExp.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"

// Runtime Includes
#include <iostream>
#include <string>

// Crypto++ Library
#ifdef _DEBUG
#  pragma comment ( lib, "cryptlibd" )
#else
#  pragma comment ( lib, "cryptlib" )
#endif

// Crypto++ Includes
#include "cryptlib.h"
#include "osrng.h"      // Random Number Generator
#include "base32.h"     // Encoding-Decoding
#include "base64.h"     // Encoding-Decoding

int main(int argc, char* argv[]) {

    try {

        const unsigned int BUFFER_SIZE = 1024 * 32;

        CryptoPP::AutoSeededRandomPool rng;
        byte cbBuffer[ BUFFER_SIZE ];

        rng.GenerateBlock( cbBuffer, BUFFER_SIZE );

        // Base 32 Encoding
        CryptoPP::Base32Encoder Encoder32;
        Encoder32.Put( cbBuffer, BUFFER_SIZE );
        Encoder32.MessageEnd();
        unsigned int Encoded32TextLength = Encoder32.MaxRetrievable();


        // Base 64 Encoding
        CryptoPP::Base64Encoder Encoder64;
        Encoder64.Put( cbBuffer, BUFFER_SIZE );
        Encoder64.MessageEnd();
        unsigned int Encoded64TextLength = Encoder64.MaxRetrievable();

        std::cout << "Statistics (" << BUFFER_SIZE << " bytes):" << std::endl;

        std::cout << "    Base 32: " << Encoded32TextLength << " bytes ";
        std::cout << static_cast<float>( Encoded32TextLength - BUFFER_SIZE ) * 100 / BUFFER_SIZE << "%" << std::endl;

        std::cout << "    Base 64: " << Encoded64TextLength << " bytes ";
        std::cout << static_cast<float>( Encoded64TextLength - BUFFER_SIZE ) * 100 / BUFFER_SIZE << "%" << std::endl;

    }

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Crypto++ Error: " << e.what() << std::endl;
    }

    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

	return 0;
}
