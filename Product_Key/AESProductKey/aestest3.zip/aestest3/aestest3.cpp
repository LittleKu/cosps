// aestest3.cpp
#include "StdAfx.h"

// C Runtime Includes
#include <iostream>

// Crypto++ Includes
#include "cryptlib.h"
#include "Base32.h"
#include "aes.h"        // AES
#include "modes.h"      // CBC_Mode< >
#include "filters.h"    // StringSource and
                        // StreamTransformation
 
int main(int argc, char* argv[]) {
    
    // Key and IV setup
    byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], 
          iv[ CryptoPP::AES::BLOCKSIZE ];

    ::memset( key, 0x01, CryptoPP::AES::DEFAULT_KEYLENGTH );
    ::memset(  iv, 0x01, CryptoPP::AES::BLOCKSIZE );

    // Encryptor
    CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption
        Encryptor( key, sizeof(key), iv );

    // Message M
    std::string PlainText = "Hello World";
    std::string EncodedText;
   
    // Encryption
    CryptoPP::StringSource( PlainText, true,
        new CryptoPP::StreamTransformationFilter( Encryptor,
            new CryptoPP::Base32Encoder(
                new CryptoPP::StringSink( EncodedText )
            ) // Base32Encoder
        ) // StreamTransformationFilter
    ); // StringSource

    ///////////////////////////////////////
    //                DMZ                //
    ///////////////////////////////////////

    // Recovered Text Sink
    std::string RecoveredText;

    // Decryption
    CryptoPP::CBC_Mode<CryptoPP::AES>::Decryption
        Decryptor( key, sizeof(key), iv );

    CryptoPP::StringSource( EncodedText, true,
        new CryptoPP::Base32Decoder(
            new CryptoPP::StreamTransformationFilter( Decryptor,
                new CryptoPP::StringSink( RecoveredText )
            ) // StreamTransformationFilter
        ) // Base32Decoder
    ); // StringSource

    //////////////////////////////////////////
    //                Output                //
    //////////////////////////////////////////

    std::cout << "Algorithm:" << std::endl;
    std::cout << "  " << Encryptor.AlgorithmName() << std::endl;
    std::cout << std::endl;

    std::cout << "Plain Text (" << PlainText.length() << " bytes)" << std::endl;
    std::cout << "  '" << PlainText << "'" << std::endl;
    std::cout << std::endl;

    std::cout << "Base32 Encoded Cipher Text:" << std::endl;
    std::cout << "   " << EncodedText << std::endl;
    std::cout << std::endl;

    std::cout << "Recovered Text:" << std::endl;
    std::cout << "  '" << RecoveredText << "'" << std::endl;
    std::cout << std::endl;
   
    return 0;
}