// aestest1.cpp
#include "StdAfx.h"

// Runtime Includes
#include <iostream>
#include <iomanip>

// Crypto++ Includes
#include "cryptlib.h"
#include "aes.h"        // AES
#include "modes.h"      // CBC_Mode< >
#include "filters.h"    // StringSource
 
int main(int argc, char* argv[]) {
    
    // Key and IV setup
    byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], 
          iv[ CryptoPP::AES::BLOCKSIZE ];

    ::memset( key, 0x01, CryptoPP::AES::DEFAULT_KEYLENGTH );
    ::memset(  iv, 0x01, CryptoPP::AES::BLOCKSIZE );

    // Message M
    std::string PlainText = "Hello AES World";

    // Debug
    std::cout << "Plain Text:" << std::endl;
    std::cout << "  '" << PlainText << "'" << std::endl;
    std::cout << std::endl;

    // Cipher Text Sink
    std::string CipherText;

    // Encryption
    CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption
        Encryptor( key, sizeof(key), iv );

    CryptoPP::StringSource( PlainText, true,
        new CryptoPP::StreamTransformationFilter( Encryptor,
            new CryptoPP::StringSink( CipherText )
        ) // StreamTransformationFilter
    ); // StringSource
    
    // Debug
    std::cout << "Cipher Text (" << CipherText.size() <<") bytes:" << std::endl;
    for(unsigned int i = 0; i < CipherText.size(); i++ ) 
    {
        if( 0 != i && 10 == i ) { std::cout << std::endl; }
        std::cout << std::hex << "0x";
        std::cout << ( static_cast<unsigned>( 0xFF & CipherText[ i ] ) ) << " ";
    }   
    std::cout << std::endl << std::endl;

    ///////////////////////////////////////
    //                DMZ                //
    ///////////////////////////////////////

    // Recovered Text Sink
    std::string RecoveredText;

    // Decryption
    CryptoPP::CBC_Mode<CryptoPP::AES>::Decryption
        Decryptor( key, sizeof(key), iv );

    CryptoPP::StringSource( CipherText, true,
        new CryptoPP::StreamTransformationFilter( Decryptor,
            new CryptoPP::StringSink( RecoveredText )
        ) // StreamTransformationFilter
    ); // StringSink

    // Debug
    std::cout << "Recovered Text:" << std::endl;
    std::cout << "  '" << RecoveredText << "'" << std::endl;
    std::cout << std::endl;
   
    return 0;
}