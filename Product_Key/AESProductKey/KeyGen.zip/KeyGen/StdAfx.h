// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__27E98366_BDAD_483C_94B0_E8AC1BF3CFA5__INCLUDED_)
#define AFX_STDAFX_H__27E98366_BDAD_483C_94B0_E8AC1BF3CFA5__INCLUDED_

#ifdef _DEBUG
#  pragma comment ( lib, "cryptlibd" )
#else
#  pragma comment ( lib, "cryptlib" )
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__27E98366_BDAD_483C_94B0_E8AC1BF3CFA5__INCLUDED_)
