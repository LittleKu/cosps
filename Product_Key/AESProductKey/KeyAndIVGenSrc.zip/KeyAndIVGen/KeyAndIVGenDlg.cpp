// KeyAndIVGenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "KeyAndIVGen.h"
#include "KeyAndIVGenDlg.h"

#pragma warning(push, 2)
#include "aes.h"
#include "osrng.h"
#pragma warning(pop)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyAndIVGenDlg dialog

CKeyAndIVGenDlg::CKeyAndIVGenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyAndIVGenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeyAndIVGenDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_hIcon32x32 = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_hIcon16x16 = (HICON)::LoadImage(AfxGetResourceHandle(), 
                    MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 
                    16, 16, 0);
}

void CKeyAndIVGenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeyAndIVGenDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKeyAndIVGenDlg, CDialog)
	//{{AFX_MSG_MAP(CKeyAndIVGenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_NEW, OnButtonNew)
	ON_BN_CLICKED(IDCLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyAndIVGenDlg message handlers

BOOL CKeyAndIVGenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon32x32, TRUE);        // Set big icon
	SetIcon(m_hIcon16x16, FALSE);		// Set small icon

    DisplayInstructions();

    OnButtonNew();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CKeyAndIVGenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon16x16);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CKeyAndIVGenDlg::OnQueryDragIcon()
{
	return reinterpret_cast<HCURSOR>(m_hIcon16x16);
}

void CKeyAndIVGenDlg::OnButtonNew() 
{
    CryptoPP::AutoSeededRandomPool rng;
    
    CString szKey( _T("BYTE key[ CryptoPP::AES::DEFAULT_KEYLENGTH ] =\r\n    { ") );
    CString  szIV( _T("BYTE  iv[ CryptoPP::AES::BLOCKSIZE ] =\r\n    { ") );

    CString szValue;

    //
    // Key
    //
    for( INT i = 0; i < CryptoPP::AES::DEFAULT_KEYLENGTH; i++ ) {

        szValue.Format( _T("0x%0.2X"), rng.GenerateByte() );
        szKey += szValue;

        if( i != CryptoPP::AES::DEFAULT_KEYLENGTH - 1 ) {

            szKey += _T(", ");
        
        } else {

            szKey += _T(" ");
        }
    }

    szKey += _T("};");

    //
    // IV
    //
    for( INT j = 0; j < CryptoPP::AES::BLOCKSIZE; j++ ) {

        szValue.Format( _T("0x%0.2X"), rng.GenerateByte() );
        szIV += szValue;

        if( j != CryptoPP::AES::BLOCKSIZE - 1 ) {

            szIV += _T(", ");
        
        } else {

            szIV += _T(" ");
        }
    }

    szIV += _T("};");


    CEdit* pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_RESULT ) );
    if( NULL != pEdit ) {
        pEdit->SetWindowText( szKey + _T("\r\n\r\n") + szIV );

        pEdit->SetSel( 0, -1, FALSE );
    }
}

void CKeyAndIVGenDlg::OnCancel() 
{
	CDialog::OnCancel();
}


VOID CKeyAndIVGenDlg::DisplayInstructions()
{
    CStatic* pStatic = static_cast<CStatic*>( GetDlgItem( IDC_STATIC_INSTRUCTION ) );
    if( NULL != pStatic ) {
        pStatic->SetWindowText( _T("Highlight below, and then press <CTRL> + C to Copy to the clipboard.\r\n") \
                                _T("\r\n") \
                                _T("From the application, press <CTRL> + V to Copy from the clipboard.\r\n") );
    }
}
