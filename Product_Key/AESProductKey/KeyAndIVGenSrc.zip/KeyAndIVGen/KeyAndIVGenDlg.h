// KeyAndIVGenDlg.h : header file
//

#if !defined(AFX_KEYANDIVGENDLG_H__C8E1FA58_9EF1_4B20_B673_DB559E97883E__INCLUDED_)
#define AFX_KEYANDIVGENDLG_H__C8E1FA58_9EF1_4B20_B673_DB559E97883E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CKeyAndIVGenDlg dialog

class CKeyAndIVGenDlg : public CDialog
{
// Construction
public:
	CKeyAndIVGenDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CKeyAndIVGenDlg)
	enum { IDD = IDD_KEYANDIVGEN_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyAndIVGenDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	VOID DisplayInstructions( );
	HICON m_hIcon32x32;
    HICON m_hIcon16x16;

	// Generated message map functions
	//{{AFX_MSG(CKeyAndIVGenDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonNew();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYANDIVGENDLG_H__C8E1FA58_9EF1_4B20_B673_DB559E97883E__INCLUDED_)
