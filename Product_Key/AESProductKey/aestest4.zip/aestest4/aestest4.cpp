// aestest4.cpp
#include "StdAfx.h"

// Runtime Includes
#include <iostream>

// Crypto++ Includes
#include "cryptlib.h"
#include "osrng.h"      // PRNG
#include "Base32.h"     // Base32
#include "aes.h"        // AES
#include "modes.h"      // CBC_Mode< >
#include "filters.h"    // StringSource and
                        // StreamTransformation

int main(int argc, char* argv[]) {
    
    // Key and IV setup
    byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], 
          iv[ CryptoPP::AES::BLOCKSIZE ];

    ::memset( key, 0x01, CryptoPP::AES::DEFAULT_KEYLENGTH );
    ::memset(  iv, 0x01, CryptoPP::AES::BLOCKSIZE );

    // Message M
    const std::string PlainText = "Hello AES";

    // Pseudo Random Number Generator
    CryptoPP::AutoSeededRandomPool rng;

    // Encryptor
    CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption
        Encryptor( key, sizeof(key), iv );

    // Decryptior
    CryptoPP::CBC_Mode<CryptoPP::AES>::Decryption
        Decryptor( key, sizeof(key), iv );

    //////////////////////////////////////////
    //                Output                //
    //////////////////////////////////////////
    
    std::cout << "Algorithm:" << std::endl;
    std::cout << "  " << Encryptor.AlgorithmName() << std::endl;
    std::cout << std::endl;
    
    std::cout << "Plain Text (" << PlainText.length() << " bytes)" << std::endl;
    std::cout << "  '" << PlainText << "'" << std::endl;
    std::cout << std::endl;

    ///////////////////////////////////////////
    //            Generation Loop            //
    ///////////////////////////////////////////

    unsigned int ITERATIONS = 4;
    for( unsigned int i = 0; i < ITERATIONS; i++ )
    {
        std::string EncodedText = "";
        std::string SaltText = "";
        Encryptor.Resynchronize( iv );
        Decryptor.Resynchronize( iv );

        // Salt
        CryptoPP::RandomNumberSource( rng, 4, true,
            new CryptoPP::StringSink( SaltText )
        ); // RandomNumberSource
   
        // Encryption
        CryptoPP::StringSource( SaltText + PlainText, true,
            new CryptoPP::StreamTransformationFilter( Encryptor,
                new CryptoPP::Base32Encoder(
                    new CryptoPP::StringSink( EncodedText ),
                true, 4, "-") // Base32Encoder
            ) // StreamTransformationFilter
        ); // StringSource

        // Add Appendage for Pretty Printing
        EncodedText += "JW";

        //////////////////////////////////////////
        //                Output                //
        //////////////////////////////////////////
        std::cout << EncodedText << std::endl;

        //////////////////////////////////////////
        //                  DMZ                 //
        //////////////////////////////////////////

        // Recovered Text Sink
        std::string RecoveredText = "";

        // Remove Appendage for Pretty Printing
        EncodedText = EncodedText.substr( 0, EncodedText.length() - 2 );

        CryptoPP::StringSource( EncodedText, true,
            new CryptoPP::Base32Decoder(
                new CryptoPP::StreamTransformationFilter( Decryptor,
                    new CryptoPP::StringSink( RecoveredText )
                ) // StreamTransformationFilter
            ) // Base32Decoder
        ); // StringSource

        // Step over Salt
        RecoveredText = RecoveredText.substr( 4 );

        //////////////////////////////////////////
        //                Output                //
        //////////////////////////////////////////
        std::cout << "  '" << RecoveredText << "'" << std::endl;

    } // for( ITERATIONS )
   
    return 0;
}