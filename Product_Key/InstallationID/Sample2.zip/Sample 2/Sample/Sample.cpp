// Sample.cpp
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
    HRESULT hr = E_FAIL;

    /////////////////////////////////////////////////////////
    // COM Intitialization
    hr = CoInitializeEx( NULL , COINIT_MULTITHREADED);
    if( FAILED( hr ) )
    {
        std::tcout << _T("Failed to initialize COM library.");
        std::tcout << _T(" Error code = 0x");
        std::tcout << std::hex << hr << std::endl;

        return hr;
    }

    hr = CoInitializeSecurity( NULL, -1, NULL, NULL,
        RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE,
        NULL, EOAC_NONE, NULL);
    if( FAILED( hr ) )
    {
        std::tcout << _T("Failed to initialize security.");
        std::tcout << _T(" Error code = 0x");
        std::tcout << std::hex << hr << std::endl;

        CoUninitialize();

        return hr;
    }

    /////////////////////////////////////////////////////////
    // Print current User's Name
    ULONG lLength = 128;
    TCHAR szUserName[ 128+1 ] = { 0 };
    std::tcout << std::endl;
    if( TRUE == GetUserNameEx( NameDisplay, szUserName, &lLength ) )
    {
        std::tcout << _T("Username: ");
        std::tcout << szUserName << std::endl;
    }
    else
    {
        std::tcout << _T("Failed to retrieve Username.");
        std::tcout << _T(" Error code = 0x");
        std::tcout << std::hex << GetLastError() << std::endl;
    }
    std::tcout << std::endl;

    /////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////
    // Create a Code Block to ensure Object
    // cleanup occurs before CoUninitialize()
    {
        CComPtr< IWbemLocator > pLocator = NULL;
        HRESULT hr = CoCreateInstance( /* CLSID_WbemLocator, */
            CLSID_WbemAdministrativeLocator,
            NULL, CLSCTX_INPROC_SERVER, IID_IWbemLocator,
            reinterpret_cast< PVOID* >( &pLocator ) );

        if( FAILED( hr ) )
        {
            std::tcout << _T("Failed to create IWbemLocator.");
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

            CoUninitialize();

            return hr;
        }

        CComPtr< IWbemServices > pService = NULL;
        hr = pLocator->ConnectServer( L"root\\cimv2", NULL, NULL, NULL,
            WBEM_FLAG_CONNECT_USE_MAX_WAIT, NULL, NULL, &pService );

        if( FAILED( hr ) )
        {
            std::tcout << _T("Failed to connect to WMI.");
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

            pLocator.Release();
            CoUninitialize();

            return hr;
        }

        /////////////////////////////////////////////////////////
        // BIOS
        CComPtr< IEnumWbemClassObject > pEnumBIOS = NULL;
        hr = pService->ExecQuery( CComBSTR( L"WQL" ),
            CComBSTR( L"Select * from Win32_BIOS" ),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
            NULL, &pEnumBIOS);

        if( FAILED( hr ) )
        {
            std::tcout << "Query BIOS failed.";
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

        } else {

            std::tcout << _T("BIOS") << std::endl;

            for( UINT i = 0; NULL != pEnumBIOS; i++ )
            {
                CComPtr< IWbemClassObject> pObject = NULL;
                ULONG uReturn = 0;

                HRESULT hr = pEnumBIOS->Next( WBEM_INFINITE, 1,
                    &pObject, &uReturn);

                if( FAILED( hr ) || 0 == uReturn ) { break; }

                VARIANT vtProperty;
                VariantClear( &vtProperty );

                // Name - string
                hr = pObject->Get( L"Name", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Name: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }

                // Manufacturer - string
                hr = pObject->Get( L"Manufacturer", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    assert( VT_BSTR == vtProperty.vt );
                    std::tcout << _T(" Manufacturer: ");
                    std::wcout << vtProperty.bstrVal << std::endl;
                }

                // Build Number - string
                hr = pObject->Get( L"BuildNumber", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Build Number: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );

                // Serial Number - string
                hr = pObject->Get( L"SerialNumber", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Serial Number: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );

                // Version - string
                hr = pObject->Get( L"Version", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Version: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );
            }
        } // End - BIOS
        /////////////////////////////////////////////////////////

        std::tcout << std::endl;

        /////////////////////////////////////////////////////////
        // Processor
        CComPtr< IEnumWbemClassObject > pEnumProcessor = NULL;
        hr = pService->ExecQuery( CComBSTR( L"WQL" ),
            CComBSTR( L"Select * from Win32_Processor" ),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
            NULL, &pEnumProcessor);

        if( FAILED( hr ) )
        {
            std::tcout << "Query Processor failed.";
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

        } else {

            for( UINT i = 0; NULL != pEnumProcessor; i++ )
            {
                CComPtr< IWbemClassObject> pObject = NULL;
                ULONG uReturn = 0;

                HRESULT hr = pEnumProcessor->Next( WBEM_INFINITE, 1,
                    &pObject, &uReturn);

                if( FAILED( hr ) || 0 == uReturn ) { break; }

                VARIANT vtProperty;
                VariantClear( &vtProperty );

                // Processor Number
                std::tcout << _T("Processor ");
                std::tcout << i << std::endl;

                // Manufacturer - string
                hr = pObject->Get( L"Manufacturer", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Manufacturer: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }

                // Caption - string
                hr = pObject->Get( L"Caption", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Caption: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }

                // Speed - uint32
                hr = pObject->Get( L"CurrentClockSpeed", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    assert( VT_I4 == vtProperty.vt );

                    std::tcout << _T(" Speed: ");
                    std::wcout << std::dec << vtProperty.uiVal;
                    std::tcout << _T(" MHz") << std::endl;
                }
                VariantClear( &vtProperty );

                // Serial Number - string
                hr = pObject->Get( L"SerialNumber", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Serial Number: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );
            }
        } // End - Processor
        /////////////////////////////////////////////////////////

        std::tcout << std::endl;

        /////////////////////////////////////////////////////////
        // Memory
        CComPtr< IEnumWbemClassObject > pEnumMemory = NULL;
        hr = pService->ExecQuery( CComBSTR( L"WQL" ),
            CComBSTR( L"Select * from Win32_PhysicalMemory" ),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
            NULL, &pEnumMemory );

        if( FAILED( hr ) )
        {
            std::tcout << "Query Memory failed.";
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

        } else {

            for( UINT i = 0; NULL != pEnumMemory; i++ )
            {
                CComPtr< IWbemClassObject> pObject = NULL;
                ULONG uReturn = 0;

                HRESULT hr = pEnumMemory->Next( WBEM_INFINITE, 1,
                    &pObject, &uReturn);

                if( FAILED( hr ) || 0 == uReturn ) { break; }

                VARIANT vtProperty;
                VariantClear( &vtProperty );

                // Bank Number
                std::tcout << _T("Memory Bank ");
                std::tcout << i << _T(": ");

                // Capacity - uint64 per Documentation???
                hr = pObject->Get( L"Capacity", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    assert( VT_BSTR == vtProperty.vt );
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        ULONGLONG lSize = _wtoi64( vtProperty.bstrVal );
                        lSize /= 1024 * 1024;
                        std::wcout << lSize;
                        std::tcout << _T(" MB");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );
            }
        } // End - Memory
        /////////////////////////////////////////////////////////

        std::tcout << std::endl;

        /////////////////////////////////////////////////////////
        // Disk Drive
        CComPtr< IEnumWbemClassObject > pEnumDiskDrive = NULL;
        hr = pService->ExecQuery( CComBSTR( L"WQL" ),
            CComBSTR( L"Select * from Win32_DiskDrive" ),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
            NULL, &pEnumDiskDrive );

        if( FAILED( hr ) )
        {
            std::tcout << "Query Disk Drive failed.";
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

        } else {

            for( UINT i = 0; NULL != pEnumDiskDrive; i++ )
            {
                CComPtr< IWbemClassObject> pObject = NULL;
                ULONG uReturn = 0;

                HRESULT hr = pEnumDiskDrive->Next( WBEM_INFINITE, 1,
                    &pObject, &uReturn);

                if( FAILED( hr ) || 0 == uReturn ) { break; }

                VARIANT vtProperty;
                VariantClear( &vtProperty );

                std::tcout << _T("Disk Drive ");
                std::tcout << i << std::endl;

                // Name
                hr = pObject->Get( L"Model", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Model: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );

                // Description - string
                hr = pObject->Get( L"SerialNumber", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Serial Number: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }

                // Size - uint64???
                hr = pObject->Get( L"Size", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Size: ");
                    // This should be uint64...
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        ULONGLONG lSize = _wtoi64( vtProperty.bstrVal );
                        lSize /= 1024 * 1024;

                        std::tcout << std::dec;
                        if( lSize > 1023 )
                        {
                            std::wcout << lSize / 1024 ;
                            std::tcout << _T(" GB");
                        }
                        else
                        {
                            std::wcout << lSize;
                            std::tcout << _T(" MB");
                        }
                    }
                    std::tcout << std::endl;
                }
            }
        } // End - Physical Media
        /////////////////////////////////////////////////////////

        std::tcout << std::endl;

        /////////////////////////////////////////////////////////
        // Network Adapter
        CComPtr< IEnumWbemClassObject > pEnumNetworkAdapter = NULL;
        hr = pService->ExecQuery( CComBSTR( L"WQL" ),
            CComBSTR( L"Select * from Win32_NetworkAdapter" ),
            WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
            NULL, &pEnumNetworkAdapter );

        if( FAILED( hr ) )
        {
            std::tcout << "Query Network Adapter failed.";
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

        } else {

            for( UINT i = 0; NULL != pEnumNetworkAdapter; )
            {
                CComPtr< IWbemClassObject> pObject = NULL;
                ULONG uReturn = 0;

                HRESULT hr = pEnumNetworkAdapter->Next( WBEM_INFINITE, 1,
                    &pObject, &uReturn);

                if( FAILED( hr ) || 0 == uReturn ) { break; }

                VARIANT vtProperty;
                VariantClear( &vtProperty );

                // Adapter Type
                hr = pObject->Get( L"AdapterTypeID", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    if( VT_I4 != vtProperty.vt ) { continue; }

                    if( 0x0 != vtProperty.iVal && // Ethernet 802.3
                        0x1 != vtProperty.iVal && // Token Ring 802.5
                        0x9 != vtProperty.iVal) // Wireless
                    { continue; }
                }
                VariantClear( &vtProperty );

                std::tcout << _T("Network Adapter ");
                std::tcout << i << std::endl;

                // Name
                hr = pObject->Get( L"Name", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" Name: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );

                // MAC Address
                hr = pObject->Get( L"MACAddress", 0, &vtProperty, 0, 0);
                if( SUCCEEDED( hr ) )
                {
                    std::tcout << _T(" MAC Address: ");
                    if( VT_EMPTY != vtProperty.vt && VT_NULL != vtProperty.vt )
                    {
                        assert( VT_BSTR == vtProperty.vt );
                        std::wcout << vtProperty.bstrVal;
                    }
                    else
                    {
                        std::tcout << _T("Not Available");
                    }
                    std::tcout << std::endl;
                }
                VariantClear( &vtProperty );

                i++;
            }
        } // End - Network Adapter
        /////////////////////////////////////////////////////////

    } // Code Block

    CoUninitialize();

    return 0;
}
