// Sample.cpp
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
    HRESULT hr = E_FAIL;
    hr = CoInitializeEx( NULL , COINIT_MULTITHREADED);

    if( FAILED( hr ) )
    {
        std::tcout << _T("Failed to initialize COM library.");
        std::tcout << _T(" Error code = 0x");
        std::tcout << std::hex << hr << std::endl;

        return hr;
    }

    hr = CoInitializeSecurity( NULL, -1, NULL, NULL,
        RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE,
        NULL, EOAC_NONE, NULL);

    if( FAILED( hr ) )
    {
        std::tcout << _T("Failed to initialize security.");
        std::tcout << _T(" Error code = 0x");
        std::tcout << std::hex << hr << std::endl;

        CoUninitialize();

        return hr;
    }

    // Create a Code Block to ensure Object
    // cleanup occurs before CoUninitialize()
    {
        CComPtr< IWbemLocator > pLocator;
        HRESULT hr = CoCreateInstance( CLSID_WbemLocator,
            /* CLSID_WbemAdministrativeLocator */
            NULL, CLSCTX_INPROC_SERVER, IID_IWbemLocator,
            reinterpret_cast< PVOID* >( &pLocator ) );

        if( FAILED( hr ) )
        {
            std::tcout << _T("Failed to create IWbemLocator.");
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

            CoUninitialize();

            return hr;
        }

        CComPtr< IWbemServices > pService;
        hr = pLocator->ConnectServer( L"root\\cimv2", NULL, NULL, NULL,
            WBEM_FLAG_CONNECT_USE_MAX_WAIT, NULL, NULL, &pService );

        if( FAILED( hr ) )
        {
            std::tcout << _T("Failed to connect to WMI.");
            std::tcout << _T(" Error code = 0x");
            std::tcout << std::hex << hr << std::endl;

            pLocator.Release();

            CoUninitialize();

            return hr;
        }
    }

    CoUninitialize();

    return 0;
}

