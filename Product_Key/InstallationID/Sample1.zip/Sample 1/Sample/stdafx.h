// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

// See http://msdn2.microsoft.com/en-us/library/ms695279.aspx
#define _WIN32_DCOM

// Standard Windows
#include <windows.h>
#include <tchar.h>

// COM
#include <objbase.h>    // CoIntializeEx, CoUnintialize
#include <objidl.h>     // CoInitializeSecurity
#include <atlbase.h>    // CComPtr

// Runtime Library
#include <iostream>

// WMI
#include <wbemidl.h>
#pragma comment(lib, "wbemuuid")

#ifdef UNICODE
#  define tcout wcout
#else
#  define tcout cout
#endif
