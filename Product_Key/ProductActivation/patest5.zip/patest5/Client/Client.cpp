// Client.cpp
#include "stdafx.h"

#include "Base64.h"

bool PipeOpen( HANDLE& pipe );
bool PipeRead( const HANDLE& pipe, std::string& Recieved );
bool PipeWrite( const HANDLE& pipe, const std::string& Message );

void DebugMessage( const std::string& message, bool ExtraCRLF = false );

int main(int argc, char* argv[])
{
    HANDLE pipe = INVALID_HANDLE_VALUE ;

    try {

        if( false == PipeOpen( pipe ) )
            { throw( std::string( _T("Client: PipeOpen returned false") ) ); }

        std::string Message = "X3BA-9NSF-8N9Q-UWQC-U7FX-AZZF-JAJW";
        std::string Base64Encoded;
        CryptoPP::StringSource( Message, true,
                                    new CryptoPP::Base64Encoder( 
                                        new CryptoPP::StringSink( Base64Encoded )
                                    ) // Base64Encoder
                               ); // StringSource

        if( false == PipeWrite( pipe, Base64Encoded ) )
            { throw( std::string( _T("Client: PipeWrite returned false") ) ); }

        std::string Received;
        if( false == PipeRead( pipe, Received ) )
            { throw( std::string( _T("Client: PipeRead returned false") ) ); }

        std::string Base64Decoded;
        CryptoPP::StringSource( Received, true,
                                    new CryptoPP::Base64Decoder( 
                                        new CryptoPP::StringSink( Base64Decoded )
                                    ) // Base64Encoder
                                ); // StringSource

        std::cout << "Received from Server:" << std::endl;
        std::cout << "  " << Base64Decoded << std::endl;


    }    

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    
    catch( std::string& s ) {
        std::cerr << "Error: " << s << std::endl;
    }

    catch( TCHAR* s ) {
        std::cerr << "Error: " << s << std::endl;
    }
    
    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

    if( NULL != pipe ) { CloseHandle( pipe ); }

    return 0;
}

bool PipeWrite( const HANDLE& pipe, const std::string& Message )
{
    DWORD dwWritten = 0;
    bool result = ( TRUE == WriteFile( pipe, Message.c_str(),
                            Message.length() + 1, &dwWritten, NULL ) );

    FlushFileBuffers( pipe ); 

    DebugMessage( "Client: Sent:" );
    DebugMessage( Message );

    return( dwWritten == Message.length() + 1 );
}

bool PipeRead( const HANDLE& pipe, std::string& Received )
{
    byte cbBuffer[ BUFFER_SIZE ];
    DWORD dwRead = -1;
    bool result = ( TRUE == ReadFile( pipe, cbBuffer,
                                     BUFFER_SIZE, &dwRead, NULL ) );
    
    cbBuffer[ dwRead ] = _T( '\0' );
    Received = (char*)cbBuffer;

    DebugMessage(  _T( "Client: Received:" ) );
    DebugMessage( Received );

    return 0 != dwRead;
}

bool PipeOpen( HANDLE& pipe )
{
    // STANDARD_RIGHTS_READ | STANDARD_RIGHTS_WRITE
    //   is too strong - ERROR_ACCESS_DENIED
    pipe = CreateFile( _T("\\\\.\\Pipe\\ProductActivationTest"),
                             GENERIC_READ | GENERIC_WRITE, 0,
                             NULL, OPEN_EXISTING, 0, NULL);

    if( INVALID_HANDLE_VALUE != pipe )
    {
        DebugMessage( "Client: Opened Named Pipe" );
    }

    return( INVALID_HANDLE_VALUE != pipe );
}

void DebugMessage( const std::string& message, bool ExtraCRLF )
{
    std::cout << message << std::endl;

    if( true == ExtraCRLF )
        { std::cout << std::endl; }
}