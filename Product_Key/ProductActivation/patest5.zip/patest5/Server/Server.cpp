// Server.cpp
//
#include "stdafx.h"

#include "Base64.h"

bool PipeCreate( HANDLE& pipe );
bool PipeRead( const HANDLE& pipe, std::string& Recieved );
bool PipeWrite( const HANDLE& pipe, const std::string& Message );

void DebugMessage( const std::string& message, bool ExtraCRLF = false );

int main(int argc, char* argv[])
{
    HANDLE pipe = INVALID_HANDLE_VALUE ;

    try {

        if( false == PipeCreate( pipe ) )
            { throw std::string( "Server: PipeCreate returned false" ); }

        std::string Recieved;;
        if( false == PipeRead( pipe, Recieved ) )
            { throw( std::string( _T("Server: PipeRead returned false") ) ); }

        if( false == PipeWrite( pipe, Recieved ) )
            { throw( std::string( _T("Server: WriteRead returned false") ) ); }

        // If the program exits, the Client will receive
        //    ERROR_FILE_NOT_FOUND.
        while( true ) { 
            Sleep( 5 * 1000 );
        }
    }    

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    
    catch( std::string& s ) {
        std::cerr << "Error: " << s << std::endl;
    }

    catch( TCHAR* s ) {
        std::cerr << "Error: " << s << std::endl;
    }
    
    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

    if( NULL != pipe ) { CloseHandle( pipe ); }

    return 0;
}

bool PipeWrite( const HANDLE& pipe, const std::string& Message )
{
    bool result = ( TRUE == ConnectNamedPipe( pipe, NULL ) );
    if( false == result && ERROR_PIPE_CONNECTED != GetLastError() )
        { return false; }

    DWORD dwWritten = -1;
    result = ( TRUE == WriteFile( pipe, Message.c_str(),
                       Message.length() + 1, &dwWritten, NULL ) );

    FlushFileBuffers( pipe );

    // Do not call DisconnectNamedPipe()
    //   The client will receive ERROR_PIPE_BUSY
    //   or ERROR_PIPE_NOT_CONNECTED

    DebugMessage( "Server: Sent:" );
    DebugMessage( Message );

    return( dwWritten == Message.length() + 1 );
}

bool PipeRead( const HANDLE& pipe, std::string& Received )
{
    DebugMessage( "Server: Waiting for Client Connection"  );

    bool result = ( TRUE == ConnectNamedPipe( pipe, NULL ) );
    if( false == result && ERROR_PIPE_CONNECTED != GetLastError() )
        { return false; }

    byte cbBuffer[ BUFFER_SIZE ];
    DWORD dwRead = -1;
    result = ( TRUE == ReadFile( pipe, cbBuffer,
                       BUFFER_SIZE, &dwRead, NULL ) );
    
    cbBuffer[ dwRead ] = _T( '\0' );
    Received = (char*)cbBuffer;

    DebugMessage(  _T( "Server: Received:" ) );
    DebugMessage( Received );

    FlushFileBuffers( pipe );

    // Do not call DisconnectNamedPipe()
    //   The client will receive ERROR_PIPE_BUSY
    //   or ERROR_PIPE_NOT_CONNECTED

    return( 0 != dwRead );
}

bool PipeCreate( HANDLE& pipe )
{
    pipe = CreateNamedPipe( _T("\\\\.\\Pipe\\ProductActivationTest"),
                            PIPE_ACCESS_DUPLEX, PIPE_TYPE_MESSAGE | PIPE_WAIT,
                            PIPE_UNLIMITED_INSTANCES, BUFFER_SIZE, BUFFER_SIZE,
                            PIPE_TIMEOUT, NULL );

    if( INVALID_HANDLE_VALUE != pipe )
    {
        DebugMessage( "Server: Created Named Pipe" );
    }

    return( INVALID_HANDLE_VALUE != pipe );
}

void DebugMessage( const std::string& message, bool ExtraCRLF )
{
    std::cout << message << std::endl;

    if( true == ExtraCRLF )
        { std::cout << std::endl; }
}