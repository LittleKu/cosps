// patest3.cpp
#include "stdafx.h"

#include "rsa.h"
#include "osrng.h"  // PRNG
#include "hex.h"    // Hex Encoder/Decoder
#include "files.h"  // File Source and Sink

int main(int argc, char* argv[])
{
    try
    {
        std::string PrivateKeyFile = "key.pv";
        std::string PublicKeyFile  = "key.pb";        

        CryptoPP::FileSource pubFile( PublicKeyFile.c_str(),
                                      true, new CryptoPP::HexDecoder );        

        CryptoPP::FileSource privFile( PrivateKeyFile.c_str(),
                                        true, new CryptoPP::HexDecoder);
    
        CryptoPP::RSAES_OAEP_SHA_Decryptor Decryptor( privFile );
        CryptoPP::RSAES_OAEP_SHA_Encryptor Encryptor ( pubFile );
        
        /*
        CryptoPP::AutoSeededRandomPool rng;
        if( true == Encryptor.Validate( rng, 3 ) )
        {
            std::cout << "Public Key passed Validation test" << std::endl;
        }

        if( true == Decryptor.Validate( rng, 3 ) )
        {
            std::cout << "Private Key passed Validation test" << std::endl;
        }
        */

        std::cout << "RSA Parameters" << std:: endl << std:: endl;
        
        std::cout << "modulus: " << Encryptor.GetTrapdoorFunction().GetModulus();
        std::cout << std::endl << std::endl;

        std::cout << "e: " << Encryptor.GetTrapdoorFunction().GetPublicExponent();
        std::cout << std::endl << std::endl;
    
        std::cout << "p: " << Decryptor.GetTrapdoorFunction().GetPrime1();
        std::cout << std::endl << std::endl;

        std::cout << "q: " << Decryptor.GetTrapdoorFunction().GetPrime2();
        std::cout << std::endl << std::endl;

        std::cout << "d: " << Decryptor.GetTrapdoorFunction().GetPrivateExponent();
        std::cout << std::endl << std::endl;

    }

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    
    catch( std::string& s ) {
        std::cerr << "Error: " << s << std::endl;
    }
    
    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

	return 0;
}
