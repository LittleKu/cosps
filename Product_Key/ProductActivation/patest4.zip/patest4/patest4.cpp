// patest4.cpp
#include "stdafx.h"

#include "rsa.h"
#include "osrng.h"  // PRNG
#include "hex.h"    // Hex Encoder/Decoder
#include "files.h"  // File Source and Sink

int main(int argc, char* argv[])
{
    try
    {
        // PRNG
        CryptoPP::AutoSeededRandomPool rng;   

        // Message M
        std::string message = "X3BA-9NSF-8N9Q-UWQC-U7FX-AZZF-JAJW";
        
        // Output (Signed) File
        std::string SignedFile = "message.sig";

        //////////////////////////////////////////
        //                Signing               //
        //////////////////////////////////////////
       
        // Private Key
        std::string PrivateKeyFile = "key.pv"; 
    
        CryptoPP::FileSource privFile( PrivateKeyFile.c_str(), true, new CryptoPP::HexDecoder);
        CryptoPP::RSASSA_PKCS1v15_SHA_Signer priv(privFile);
        CryptoPP::StringSource s1(message, true,
                           new CryptoPP::SignerFilter( rng, priv,
                               new CryptoPP::HexEncoder(
                                   new CryptoPP::FileSink( SignedFile.c_str() )
                               ) // HexEncoder
                           ) // SignerFilter
                       ); // StringSource

        //////////////////////////////////////////
        //                  DMZ                 //
        //////////////////////////////////////////
   
        // Public Key
        std::string PublicKeyFile = "key.pb";

        //////////////////////////////////////////
        //              Validation              //
        //////////////////////////////////////////

        CryptoPP::FileSource pubFile( PublicKeyFile.c_str(), true, new CryptoPP::HexDecoder );
        CryptoPP::RSASSA_PKCS1v15_SHA_Verifier pub(pubFile);
        
        CryptoPP::FileSource signatureFile(SignedFile.c_str(), true, new CryptoPP::HexDecoder);
        if (signatureFile.MaxRetrievable() != pub.SignatureLength())
            { throw std::string( "Signature File Size Problem" ); }

        CryptoPP::SecByteBlock signature(pub.SignatureLength());
        signatureFile.Get(signature, signature.size());
        
        CryptoPP::VerifierFilter *verifierFilter = new CryptoPP::VerifierFilter(pub);
        verifierFilter->Put(signature, pub.SignatureLength());
        CryptoPP::StringSource s2(message, true, verifierFilter);
        
        /*
        The following is not available...

        StringSource s2(message, true,
                            new VerifierFilter( pub,
                                new HexDecoder(
                                    new FileSink( SignedFile.c_str() )
                                ) // HexEncoder
                            ) // VerifierFilter
                        ); // StringSource
        */    
        
	    if( false == verifierFilter->GetLastResult() )
            { throw std::string( "Signature Verification Failed" ); }

        std::cout << "Signature Verified" << std::cout;
    }

    catch( CryptoPP::Exception& e )
        { std::cerr << "Error: " << e.what() << std::endl; }
    
    catch( std::exception& e )
        { std::cerr << "Error: " << e.what() << std::endl; }

    catch( std::string& s )
        { std::cerr << "Error: " << s << std::endl; }
    
    catch (...)
        { std::cerr << "Unknown Error" << std::endl; }

	return 0;
}
