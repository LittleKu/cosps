// Client.cpp
#include "stdafx.h"

#include "Base64.h"
#include "rsa.h"
#include "Files.h"
#include "Hex.h"

bool PipeOpen( HANDLE& pipe );
bool PipeRead( const HANDLE& pipe, std::string& Recieved );
bool PipeWrite( const HANDLE& pipe, const std::string& Message );

void Base64Encode( const std::string& source, std::string& destination );
void Base64Decode( const std::string& source, std::string& destination );

bool VerifySignature( const std::string& PublicKeyFileName, const std::string& Message,
                      const std::string& SignedMessage );

void DebugMessage( const std::string& message, bool ExtraCRLF = false );

int main(int argc, char* argv[])
{
    HANDLE pipe = INVALID_HANDLE_VALUE ;
    std::string ProductKey = "X3BA-9NSF-8N9Q-UWQC-U7FX-AZZF-JAJW";

    try {

        if( false == PipeOpen( pipe ) )
            { throw( std::string( _T("Client: PipeOpen returned false") ) ); }        

        //////////////////////////////////////////
        //             Base64 Encode            //
        //////////////////////////////////////////
        std::string Base64Encoded;
        Base64Encode( ProductKey, Base64Encoded );

        //////////////////////////////////////////
        //             Send to Server           //
        //////////////////////////////////////////
        if( false == PipeWrite( pipe, Base64Encoded ) )
            { throw( std::string( _T("Client: PipeWrite returned false") ) ); }

        std::string Received;
        if( false == PipeRead( pipe, Received ) )
            { throw( std::string( _T("Client: PipeRead returned false") ) ); }

        //////////////////////////////////////////
        //             Base64 Decode            //
        //////////////////////////////////////////
        std::string Base64DecodedSignature;
        Base64Decode( Received, Base64DecodedSignature);

        //////////////////////////////////////////
        //             Verification             //
        //////////////////////////////////////////

        // Public Key
        std::string PublicKeyFile = "key.pb";
        bool result = VerifySignature( PublicKeyFile, ProductKey, 
                                       Base64DecodedSignature );

        if( true == result )
        {
            std::cout << "Signature Verified - Thank You for Your Money" << std::endl;
        }
        else
        {
            std::cout << "Signature Verification Failed - Call Tech Support" << std::endl;
        }

    }    

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    
    catch( std::string& s ) {
        std::cerr << "Error: " << s << std::endl;
    }

    catch( TCHAR* s ) {
        std::cerr << "Error: " << s << std::endl;
    }
    
    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

    if( NULL != pipe ) { CloseHandle( pipe ); }

    return 0;
}

bool VerifySignature( const std::string& PublicKeyFileName, const std::string& Message,
                      const std::string& SignedMessage )
{
    DebugMessage( "Client: Verifying Message using Signature" );

    CryptoPP::FileSource pubFile( PublicKeyFileName.c_str(), true, new CryptoPP::HexDecoder );
    CryptoPP::RSASSA_PKCS1v15_SHA_Verifier pub(pubFile);
    
    // Set Up
    CryptoPP::StringSource signatureFile( SignedMessage, true, new CryptoPP::HexDecoder);
    if (signatureFile.MaxRetrievable() != pub.SignatureLength())
        { throw std::string( "Signature Size Problem" ); }

    CryptoPP::SecByteBlock signature(pub.SignatureLength());
    signatureFile.Get(signature, signature.size());
    
    CryptoPP::VerifierFilter *verifierFilter = new CryptoPP::VerifierFilter(pub);
    verifierFilter->Put(signature, pub.SignatureLength());
    CryptoPP::StringSource s(Message, true, verifierFilter);

	// if( false == verifierFilter->GetLastResult() )
        // { throw std::string( "Signature Verification Failed" ); }

    return( true == verifierFilter->GetLastResult() );
}

void Base64Encode( const std::string& source, std::string& destination )
{
    DebugMessage( std::string("Client: Base64 Encoding") );

    destination = "";

    CryptoPP::StringSource( source, true,
                                new CryptoPP::Base64Encoder( 
                                    new CryptoPP::StringSink( destination )
                                ) // Base64Encoder
                           ); // StringSource
}

void Base64Decode( const std::string& source, std::string& destination )
{
    DebugMessage( std::string("Client: Base64 Decoding") );

    destination = "";
    
    CryptoPP::StringSource( source, true,
                                new CryptoPP::Base64Decoder( 
                                    new CryptoPP::StringSink( destination )
                                ) // Base64Encoder
                            ); // StringSource
}

bool PipeWrite( const HANDLE& pipe, const std::string& Message )
{
    DWORD dwWritten = 0;
    bool result = ( TRUE == WriteFile( pipe, Message.c_str(),
                            Message.length() + 1, &dwWritten, NULL ) );

    FlushFileBuffers( pipe ); 

    DebugMessage( "Client: Sent:" );
    DebugMessage( Message );

    return( dwWritten == Message.length() + 1 );
}

bool PipeRead( const HANDLE& pipe, std::string& Received )
{
    byte cbBuffer[ BUFFER_SIZE ];
    DWORD dwRead = -1;
    bool result = ( TRUE == ReadFile( pipe, cbBuffer,
                                     BUFFER_SIZE, &dwRead, NULL ) );
    
    cbBuffer[ dwRead ] = _T( '\0' );
    Received = (char*)cbBuffer;

    DebugMessage(  _T( "Client: Received:" ) );
    DebugMessage( Received );

    return 0 != dwRead;
}

bool PipeOpen( HANDLE& pipe )
{
    // STANDARD_RIGHTS_READ | STANDARD_RIGHTS_WRITE
    //   is too strong - ERROR_ACCESS_DENIED
    pipe = CreateFile( _T("\\\\.\\Pipe\\ProductActivationTest"),
                             GENERIC_READ | GENERIC_WRITE, 0,
                             NULL, OPEN_EXISTING, 0, NULL);

    if( INVALID_HANDLE_VALUE != pipe )
    {
        DebugMessage( "Client: Opened Named Pipe" );
    }

    return( INVALID_HANDLE_VALUE != pipe );
}

void DebugMessage( const std::string& message, bool ExtraCRLF )
{
    std::cout << message << std::endl;

    if( true == ExtraCRLF )
        { std::cout << std::endl; }
}