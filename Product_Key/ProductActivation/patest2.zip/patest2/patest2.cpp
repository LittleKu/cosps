// patest2.cpp
#include "stdafx.h"

#include "rsa.h"
#include "osrng.h"  // PRNG
#include "hex.h"    // Hex Encoder/Decoder
#include "files.h"  // File Source and Sink

int main(int argc, char* argv[])
{

    try
    {
        std::string PrivateKeyFile = "key.pv";
        std::string PublicKeyFile  = "key.pb";

        CryptoPP::AutoSeededRandomPool rng;

        // Specify 512 bit modulus, accept e = 17
        CryptoPP::RSAES_OAEP_SHA_Decryptor Decryptor( rng, 512 /*, e */ );
        CryptoPP::HexEncoder privFile(new
            CryptoPP::FileSink( PrivateKeyFile.c_str() )
        ); // Hex Encoder

        Decryptor.DEREncode(privFile);
        privFile.MessageEnd();

        CryptoPP:: RSAES_OAEP_SHA_Encryptor Encryptor(Decryptor);
        CryptoPP::HexEncoder pubFile(new
            CryptoPP::FileSink( PublicKeyFile.c_str() )
        ); // Hex Encoder
        Encryptor.DEREncode(pubFile);
	    pubFile.MessageEnd();
    }

    catch( CryptoPP::Exception& e ) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    
    catch( std::string& s ) {
        std::cerr << "Error: " << s << std::endl;
    }
    
    catch (...) {
        std::cerr << "Unknown Error" << std::endl;
    }

	return 0;
}
