//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Registry Encryption.rc
//
#define IDD_REGISTRYENCRYPTION_DIALOG   102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_PLAINTEXT_STR          1000
#define IDC_EDIT_DECRYPTED_STR          1001
#define IDC_ENCRYPT_STR                 1002
#define IDC_DECRYPT_STR                 1003
#define IDC_HKEY                        1004
#define IDC_SUBKEY                      1005
#define IDC_VALUENAME_STR               1006
#define IDC_EDIT_PLAINTEXT_DWORD        1007
#define IDC_EDIT_DECRYPTED_DWORD        1008
#define IDC_ENCRYPT_DWORD               1009
#define IDC_DECRYPT_DWORD               1010
#define IDC_VALUENAME_DWORD             1011
#define IDC_DECRYPT_DWORD2              1012
#define IDC_TEST_BINARY                 1012
#define IDC_VALUENAME_BINARY            1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
