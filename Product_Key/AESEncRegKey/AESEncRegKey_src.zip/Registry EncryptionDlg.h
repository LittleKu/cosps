// Registry EncryptionDlg.h : header file
//

#if !defined(AFX_REGISTRYENCRYPTIONDLG_H__45930D48_DA89_4851_94C5_DEFEEB68F590__INCLUDED_)
#define AFX_REGISTRYENCRYPTIONDLG_H__45930D48_DA89_4851_94C5_DEFEEB68F590__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AESEncRegKey.h"

/////////////////////////////////////////////////////////////////////////////
// CRegistryEncryptionDlg dialog

class CRegistryEncryptionDlg : public CDialog
{
// Construction
public:
    CRegistryEncryptionDlg(CWnd* pParent = NULL);    // standard constructor

// Dialog Data
    //{{AFX_DATA(CRegistryEncryptionDlg)
    enum { IDD = IDD_REGISTRYENCRYPTION_DIALOG };
        // NOTE: the ClassWizard will add data members here
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CRegistryEncryptionDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    HKEY    GetHKey();
    CString GetSubKey();

    CString GetStringValueName();
    CString GetStringData();

    CString GetDWORDValueName();
    DWORD   GetDWORDData();

    CString GetBinaryValueName();

    HICON m_hIcon16x16, m_hIcon32x32;

    CAESEncRegKey _AESEncRegKey;

    // Generated message map functions
    //{{AFX_MSG(CRegistryEncryptionDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEncryptStr();
    afx_msg void OnDecryptStr();
	afx_msg void OnEncryptDword();
	afx_msg void OnDecryptDword();
	afx_msg void OnTestBinary();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGISTRYENCRYPTIONDLG_H__45930D48_DA89_4851_94C5_DEFEEB68F590__INCLUDED_)
