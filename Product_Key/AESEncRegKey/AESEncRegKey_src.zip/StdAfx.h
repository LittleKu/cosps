// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__BA4F6A08_19DF_4A25_BDB7_A48C21B9D4B1__INCLUDED_)
#define AFX_STDAFX_H__BA4F6A08_19DF_4A25_BDB7_A48C21B9D4B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable: 4786)
#pragma warning(disable: 4231)

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls

#ifdef _UNICODE
#  pragma comment( linker, "/ENTRY:wWinMainCRTStartup")
#endif

// Crypto++ Library
#ifdef _DEBUG
#  pragma comment ( lib, "cryptlibd" )
#else
#  pragma comment ( lib, "cryptlib" )
#endif

const TCHAR DEFAULT_SUBKEY[] = _T("Software\\Code Project\\AES Encrypted");

const TCHAR DEFAULT_STR_VALUE_NAME[] = _T("String Data");
const TCHAR DEFAULT_STR_VALUE[] = _T("Now is the time for all good men to come to the aide...");

const TCHAR DEFAULT_DWORD_VALUE_NAME[] = _T("DWORD Data");
const TCHAR DEFAULT_DWORD_VALUE[] = _T("-1999");

const TCHAR DEFAULT_BINARY_VALUE_NAME[] = _T("Binary Data");

const INT MAX_REG_BINARY_SIZE = 2048;

// Debug Libraries
// #pragma comment( linker, "/NODEFAULTLIB:msvcprtd.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:libcmtd.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:msvcrtd.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:libcd.lib" )

// Release Libraries
// #pragma comment( linker, "/NODEFAULTLIB:msvcprt.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:libcmt.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:msvcrt.lib" )
// #pragma comment( linker, "/NODEFAULTLIB:libc.lib" )

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__BA4F6A08_19DF_4A25_BDB7_A48C21B9D4B1__INCLUDED_)
