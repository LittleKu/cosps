#if !defined(AFX_AESHELPER_H__ADDAA2B4_77EB_4E8D_9F60_1E907FA33E6F__INCLUDED_)
#define AFX_AESHELPER_H__ADDAA2B4_77EB_4E8D_9F60_1E907FA33E6F__INCLUDED_

#if _MSC_VER > 1000
#  pragma once
#endif // _MSC_VER > 1000

//
// AESHelper.h : header file
//

//
// Crypto++ Includes
#pragma warning(push, 3)
#  include "aes.h"
#pragma warning(pop)

/////////////////////////////////////////////////////////////////////////////
// AESKey
struct AESKey {

    AESKey::AESKey( BYTE b = 0x00 ) {
        ::memset( _cbKey, b, CryptoPP::AES::DEFAULT_KEYLENGTH );
    }

    AESKey::AESKey(const AESKey& rhs) { *this = rhs; }

    AESKey::~AESKey( ) { }

    AESKey& AESKey::operator=(const AESKey& rhs) {
        if( *this == rhs ) { return *this; }
        ::memcpy( _cbKey, rhs._cbKey, CryptoPP::AES::DEFAULT_KEYLENGTH );
        return *this;
    }

    AESKey& AESKey::operator=(const BYTE* rhs) {
        ::memcpy( _cbKey, rhs, CryptoPP::AES::DEFAULT_KEYLENGTH );
        return *this;
    }

    const BYTE* AESKey::operator BYTE*( ) const { return _cbKey; }
    
          BYTE* AESKey::operator BYTE*( )       { return _cbKey; }

    bool AESKey::operator==(const AESKey& rhs) const {
         return 0 == ::memcmp( _cbKey, rhs._cbKey,
                CryptoPP::AES::DEFAULT_KEYLENGTH ) ? TRUE : FALSE;
    }

    bool AESKey::operator!=(const AESKey& rhs) const {
        return !( operator==(rhs) );
    }

    BYTE _cbKey[ CryptoPP::AES::DEFAULT_KEYLENGTH ];
};

/////////////////////////////////////////////////////////////////////////////
// AESIV
struct AESIV {

    AESIV::AESIV( BYTE b = 0x00 ) {
        ::memset( _cbIV, b, CryptoPP::AES::BLOCKSIZE );
    };

    AESIV::AESIV(const AESIV& rhs) { *this = rhs; };

    AESIV::~AESIV( ) { }

    AESIV& AESIV::operator=(const AESIV& rhs) {
        if( *this == rhs ) { return *this; }
        ::memcpy( _cbIV, rhs._cbIV, CryptoPP::AES::BLOCKSIZE );
        return *this;
    }

    AESIV& AESIV::operator=(const BYTE* rhs) {
        ::memcpy( _cbIV, rhs, CryptoPP::AES::BLOCKSIZE );
        return *this;
    }

    const BYTE* AESIV::operator BYTE*( ) const { return _cbIV; }
    
          BYTE* AESIV::operator BYTE*( )       { return _cbIV; }

    bool AESIV::operator==(const AESIV& rhs) const {
        return 0 == ::memcmp( _cbIV, rhs._cbIV,
               CryptoPP::AES::BLOCKSIZE ) ? TRUE : FALSE;
    }

    bool AESIV::operator!=(const AESIV& rhs) const {
        return !( operator==(rhs) );
    }

    BYTE _cbIV[ CryptoPP::AES::BLOCKSIZE ];
};

#endif // !defined(AFX_AESHELPER_H__ADDAA2B4_77EB_4E8D_9F60_1E907FA33E6F__INCLUDED_)

