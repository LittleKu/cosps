// Registry EncryptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Registry Encryption.h"
#include "Registry EncryptionDlg.h"

#include "AESEncRegKey.h"

// Crypto++ Includes
#pragma warning(push, 3)
#  include "osrng.h"
#pragma warning(pop)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegistryEncryptionDlg dialog

CRegistryEncryptionDlg::CRegistryEncryptionDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CRegistryEncryptionDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CRegistryEncryptionDlg)
        // NOTE: the ClassWizard will add member initialization here
    //}}AFX_DATA_INIT

    m_hIcon32x32 = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_hIcon16x16 = (HICON)::LoadImage(AfxGetResourceHandle(), 
                   MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 
                   16, 16, 0); 
}

void CRegistryEncryptionDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CRegistryEncryptionDlg)
        // NOTE: the ClassWizard will add DDX and DDV calls here
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRegistryEncryptionDlg, CDialog)
    //{{AFX_MSG_MAP(CRegistryEncryptionDlg)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ENCRYPT_STR, OnEncryptStr)
    ON_BN_CLICKED(IDC_DECRYPT_STR, OnDecryptStr)
	ON_BN_CLICKED(IDC_ENCRYPT_DWORD, OnEncryptDword)
	ON_BN_CLICKED(IDC_DECRYPT_DWORD, OnDecryptDword)
	ON_BN_CLICKED(IDC_TEST_BINARY, OnTestBinary)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegistryEncryptionDlg message handlers

BOOL CRegistryEncryptionDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon32x32, TRUE);            // Set big icon
    SetIcon(m_hIcon16x16, FALSE);           // Set small icon
    

    // Initialize KEY ComboBox Control
    CComboBox* pCombo = NULL;
    pCombo = static_cast<CComboBox*>( GetDlgItem( IDC_HKEY ) );

    ASSERT( NULL != pCombo );
    if( NULL != pCombo ) {

        // HKEY_LOCAL_MACHINE
        pCombo->SetCurSel( 3 );
    }

    // Initialize SubKey Edit Control
    CEdit* pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_SUBKEY ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // SubKey
        pEdit->SetWindowText( DEFAULT_SUBKEY );
    }

    // Initialize String ValueName Edit Control
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_STR ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // ValueName
        pEdit->SetWindowText( DEFAULT_STR_VALUE_NAME ); 
    }

    // Initialize String Plain Text Edit Control
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_PLAINTEXT_STR ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // Plain Text to Encrypt and Write to the Registry
        pEdit->SetWindowText( DEFAULT_STR_VALUE );
    }

    // Initialize DWORD ValueName Edit Control
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_DWORD ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // ValueName
        pEdit->SetWindowText( DEFAULT_DWORD_VALUE_NAME ); 
    }

    // Initialize DWORD Plain Text Edit Control
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_PLAINTEXT_DWORD ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // Plain Text to Encrypt and Write to the Registry
        pEdit->SetWindowText( DEFAULT_DWORD_VALUE );
    }

    // Initialize DWORD ValueName Edit Control
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_BINARY ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        // ValueName
        pEdit->SetWindowText( DEFAULT_BINARY_VALUE_NAME ); 
    }

    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRegistryEncryptionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    CDialog::OnSysCommand(nID, lParam);
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CRegistryEncryptionDlg::OnPaint() 
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon16x16);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRegistryEncryptionDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>( m_hIcon16x16 );
}

void CRegistryEncryptionDlg::OnDecryptStr() 
{
    CString szValue;

    // Exercise the Class
    _AESEncRegKey.SetHKEY( GetHKey() );
    _AESEncRegKey.SetSubKey( GetSubKey() );
    _AESEncRegKey.SetValueName( GetStringValueName() );

    _AESEncRegKey.ReadString( szValue, TRUE );


    // Display the Result
    CEdit* pEdit = NULL;
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_DECRYPTED_STR ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->SetWindowText( szValue );
    }
}

CString CRegistryEncryptionDlg::GetStringValueName()
{
    CString szData;
    CEdit* pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_STR ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );
    }

    return szData;
}

CString CRegistryEncryptionDlg::GetStringData()
{
    CString szData;
    CEdit* pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_PLAINTEXT_STR ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );
    }

    return szData;
}

CString CRegistryEncryptionDlg::GetSubKey()
{
    CString szData;
    CEdit*  pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_SUBKEY ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );
    }

    return szData;
}

HKEY CRegistryEncryptionDlg::GetHKey()
{
    HKEY       hKey = NULL;     // Default hKey
    CString    szData;
    CComboBox* pCombo = NULL;

    pCombo = static_cast<CComboBox*>( GetDlgItem( IDC_HKEY ) );

    ASSERT( NULL != pCombo );
    if( NULL != pCombo ) {

        pCombo->GetLBText( pCombo->GetCurSel(), szData );
    }


    if( _T("HKEY_CLASSES_ROOT")== szData ) {

        hKey = HKEY_CLASSES_ROOT;
    } else

    if( _T("HKEY_CURRENT_CONFIG")== szData ) {

        hKey = HKEY_CURRENT_CONFIG;
    } else

    if( _T("HKEY_CURRENT_USER")== szData ) {

        hKey = HKEY_CURRENT_USER;
    } else

    if( _T("HKEY_LOCAL_MACHINE")== szData ) {

        hKey = HKEY_LOCAL_MACHINE;
    } else

    if( _T("HKEY_USERS")== szData ) {

        hKey = HKEY_USERS;
    }

    return hKey;
}

void CRegistryEncryptionDlg::OnEncryptStr() 
{
    // Exercise the Class
    _AESEncRegKey.SetHKEY( GetHKey() );
    _AESEncRegKey.SetSubKey( GetSubKey() );
    _AESEncRegKey.SetValueName( GetStringValueName() );

    _AESEncRegKey.WriteString( GetStringData(), TRUE );


    // Clear the Decryption Edit Box
    CEdit* pEdit = NULL;
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_DECRYPTED_STR ) );
    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->SetWindowText( _T("") );
    }
}

void CRegistryEncryptionDlg::OnEncryptDword() 
{
    // Exercise the Class
    _AESEncRegKey.SetHKEY( GetHKey() );
    _AESEncRegKey.SetSubKey( GetSubKey() );
    _AESEncRegKey.SetValueName( GetDWORDValueName() );

    _AESEncRegKey.WriteDWORD( GetDWORDData(), TRUE );


    // Clear the Decryption Edit Box
    CEdit* pEdit = NULL;
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_DECRYPTED_DWORD ) );
    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->SetWindowText( _T("") );
    }
}

CString CRegistryEncryptionDlg::GetDWORDValueName()
{
    CString szData;
    CEdit* pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_DWORD ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );
    }

    return szData;
}

CString CRegistryEncryptionDlg::GetBinaryValueName()
{
    CString szData;
    CEdit* pEdit = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_VALUENAME_BINARY ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );
    }

    return szData;
}

DWORD CRegistryEncryptionDlg::GetDWORDData()
{
    DWORD   dwResult = 0;
    CString szData   = _T("0");
    CEdit*  pEdit    = NULL;

    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_PLAINTEXT_DWORD ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        pEdit->GetWindowText( szData );

        dwResult = _ttoi( szData );
    }

    return dwResult;
}


void CRegistryEncryptionDlg::OnDecryptDword() 
{
    DWORD dwValue;

    // Exercise the Class
    _AESEncRegKey.SetHKEY( GetHKey() );
    _AESEncRegKey.SetSubKey( GetSubKey() );
    _AESEncRegKey.SetValueName( GetDWORDValueName() );

    _AESEncRegKey.ReadDWORD( dwValue, TRUE );
    
    // Display the Value
    CEdit* pEdit = NULL;
    pEdit = static_cast<CEdit*>( GetDlgItem( IDC_EDIT_DECRYPTED_DWORD ) );

    ASSERT( NULL != pEdit );
    if( NULL != pEdit ) {

        CString szTemp;
        szTemp.Format( _T("%d"), dwValue );
        pEdit->SetWindowText( szTemp );
    }
}

void CRegistryEncryptionDlg::OnTestBinary() 
{
    BYTE data[ MAX_REG_BINARY_SIZE ];

    CryptoPP::AutoSeededRandomPool rng;

    rng.GenerateBlock( data, MAX_REG_BINARY_SIZE );

    // Exercise the Class
    _AESEncRegKey.SetHKEY( GetHKey() );
    _AESEncRegKey.SetSubKey( GetSubKey() );
    _AESEncRegKey.SetValueName( GetBinaryValueName() );

    _AESEncRegKey.WriteBinary( data, MAX_REG_BINARY_SIZE, TRUE );


    DWORD dwSize = MAX_REG_BINARY_SIZE;
    BYTE  decrypted[ MAX_REG_BINARY_SIZE ];

    _AESEncRegKey.ReadBinary( decrypted, &dwSize, TRUE );

    if( 0 == memcmp( data, decrypted, MAX_REG_BINARY_SIZE ) ) {

        CWnd::MessageBox( _T("Binary Encryption Test Passed."),
                          _T("Binary Encryption Test"), MB_OK | MB_ICONASTERISK );

    } else {

        CWnd::MessageBox( _T("Binary Encryption Test Failed."),
                          _T("Binary Encryption Test"), MB_OK | MB_ICONERROR );
    }
}
