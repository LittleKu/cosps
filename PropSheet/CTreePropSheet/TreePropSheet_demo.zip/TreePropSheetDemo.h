// TreePropSheetDemo.h : Haupt-Header-Datei f�r die Anwendung TREEPROPSHEETDEMO
//

#if !defined(AFX_TREEPROPSHEETDEMO_H__14D77A99_4E85_414B_9D5A_A5F52825F5C8__INCLUDED_)
#define AFX_TREEPROPSHEETDEMO_H__14D77A99_4E85_414B_9D5A_A5F52825F5C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CTreePropSheetDemoApp:
// Siehe TreePropSheetDemo.cpp f�r die Implementierung dieser Klasse
//

class CTreePropSheetDemoApp : public CWinApp
{
public:
	CTreePropSheetDemoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CTreePropSheetDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CTreePropSheetDemoApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_TREEPROPSHEETDEMO_H__14D77A99_4E85_414B_9D5A_A5F52825F5C8__INCLUDED_)
