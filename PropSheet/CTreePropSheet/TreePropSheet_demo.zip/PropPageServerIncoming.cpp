// PropPageServerIncoming.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "TreePropSheetDemo.h"
#include "PropPageServerIncoming.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite CPropPageServerIncoming 

IMPLEMENT_DYNCREATE(CPropPageServerIncoming, CPropertyPage)

CPropPageServerIncoming::CPropPageServerIncoming() : CPropertyPage(CPropPageServerIncoming::IDD)
{
	//{{AFX_DATA_INIT(CPropPageServerIncoming)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT
}

CPropPageServerIncoming::~CPropPageServerIncoming()
{
}

void CPropPageServerIncoming::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageServerIncoming)
		// HINWEIS: Der Klassen-Assistent f�gt hier DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageServerIncoming, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageServerIncoming)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CPropPageServerIncoming 

BOOL CPropPageServerIncoming::OnKillActive() 
{
	return CPropertyPage::OnKillActive();
	//return FALSE;
}

BOOL CPropPageServerIncoming::OnSetActive() 
{
	//dynamic_cast<CPropertySheet*>(GetParent())->SetActivePage(4);
	
	return CPropertyPage::OnSetActive();
}

void CPropPageServerIncoming::OnCheck3() 
{
}
