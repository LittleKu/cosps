#if !defined(AFX_PROPPAGESERVEROUTGOING_H__70762E3C_D444_4222_AD09_711338116D87__INCLUDED_)
#define AFX_PROPPAGESERVEROUTGOING_H__70762E3C_D444_4222_AD09_711338116D87__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPageServerOutgoing.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CPropPageServerOutgoing 

class CPropPageServerOutgoing : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageServerOutgoing)

// Konstruktion
public:
	CPropPageServerOutgoing();
	~CPropPageServerOutgoing();

// Dialogfelddaten
	//{{AFX_DATA(CPropPageServerOutgoing)
	enum { IDD = IDD_PROPPAGE_OUTGOING };
		// HINWEIS - Der Klassen-Assistent f�gt hier Datenelemente ein.
		//    Innerhalb dieser generierten Quellcodeabschnitte NICHTS BEARBEITEN!
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CPropPageServerOutgoing)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CPropPageServerOutgoing)
		// HINWEIS: Der Klassen-Assistent f�gt hier Member-Funktionen ein
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_PROPPAGESERVEROUTGOING_H__70762E3C_D444_4222_AD09_711338116D87__INCLUDED_
