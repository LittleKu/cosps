#if !defined(AFX_PROPPAGESERVERINCOMING_H__51C57B53_62F8_43B0_9F8A_D462CA577946__INCLUDED_)
#define AFX_PROPPAGESERVERINCOMING_H__51C57B53_62F8_43B0_9F8A_D462CA577946__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPageServerIncoming.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CPropPageServerIncoming 

class CPropPageServerIncoming : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageServerIncoming)

// Konstruktion
public:
	CPropPageServerIncoming();
	~CPropPageServerIncoming();

// Dialogfelddaten
	//{{AFX_DATA(CPropPageServerIncoming)
	enum { IDD = IDD_PROPPAGE_INCOMING };
		// HINWEIS - Der Klassen-Assistent f�gt hier Datenelemente ein.
		//    Innerhalb dieser generierten Quellcodeabschnitte NICHTS BEARBEITEN!
	//}}AFX_DATA


// �berschreibungen
	// Der Klassen-Assistent generiert virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CPropPageServerIncoming)
	public:
	virtual BOOL OnKillActive();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CPropPageServerIncoming)
	afx_msg void OnCheck3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_PROPPAGESERVERINCOMING_H__51C57B53_62F8_43B0_9F8A_D462CA577946__INCLUDED_
