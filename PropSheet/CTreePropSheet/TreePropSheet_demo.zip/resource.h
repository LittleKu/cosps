//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TreePropSheetDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TREEPROPSHEETDEMO_DIALOG    102
#define IDD_PROPPAGE_INCOMING           107
#define IDD_PROPPAGE_OUTGOING           108
#define IDD_PROPPAGE_APPEARANCE         109
#define IDD_PROPPAGE_FORMATVIEW         110
#define IDD_PROPPAGE_FORMATCOMPOSE      111
#define IDR_MAINFRAME                   128
#define IDB_DEFAULT                     130
#define IDI_INCOMING                    133
#define IDI_OUTGOING                    134
#define IDB_IMAGES                      135
#define IDC_EDIT3                       1004
#define IDC_RADIO1                      1005
#define IDC_RADIO2                      1006
#define IDC_EDIT4                       1007
#define IDC_EDIT5                       1008
#define IDC_CHECK3                      1009
#define IDC_EDIT6                       1010
#define IDC_CHECK1                      1011
#define IDC_RADIO3                      1012
#define IDC_CHECK2                      1023
#define IDC_CHECK4                      1024
#define IDC_CHECK5                      1025
#define IDC_BUTTON1                     1026
#define IDC_EDIT1                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
