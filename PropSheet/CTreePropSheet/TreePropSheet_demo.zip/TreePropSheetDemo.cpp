// TreePropSheetDemo.cpp : Legt das Klassenverhalten f�r die Anwendung fest.
//

#include "stdafx.h"
#include "TreePropSheetDemo.h"
#include "TreePropSheet.h"
#include "PropPageServerIncoming.h"
#include "PropPageServerOutgoing.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreePropSheetDemoApp

BEGIN_MESSAGE_MAP(CTreePropSheetDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CTreePropSheetDemoApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreePropSheetDemoApp Konstruktion

CTreePropSheetDemoApp::CTreePropSheetDemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CTreePropSheetDemoApp-Objekt

CTreePropSheetDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTreePropSheetDemoApp Initialisierung

BOOL CTreePropSheetDemoApp::InitInstance()
{
	// Standardinitialisierung

#ifdef _AFXDLL
	Enable3dControls();			// Diese Funktion bei Verwendung von MFC in gemeinsam genutzten DLLs aufrufen
#else
	Enable3dControlsStatic();	// Diese Funktion bei statischen MFC-Anbindungen aufrufen
#endif

	CPropPageServerOutgoing wndPageOutgoing;
	CPropPageServerIncoming wndPageIncoming;
	CPropertyPage wndPageFormatView(IDD_PROPPAGE_FORMATVIEW);
	CPropertyPage wndPageFormatCompose(IDD_PROPPAGE_FORMATCOMPOSE);
	CPropertyPage wndPageAppearance(IDD_PROPPAGE_APPEARANCE);

	// disable help button
	wndPageOutgoing.m_psp.dwFlags&= ~PSP_HASHELP;
	wndPageIncoming.m_psp.dwFlags&= ~PSP_HASHELP;
	wndPageFormatView.m_psp.dwFlags&= ~PSP_HASHELP;
	wndPageFormatCompose.m_psp.dwFlags&= ~PSP_HASHELP;
	wndPageAppearance.m_psp.dwFlags&= ~PSP_HASHELP;

	// set images
	CImageList	DefaultImages, Images;
	DefaultImages.Create(IDB_DEFAULT, 16, 0, RGB(0x00, 0x80, 0x80));
	Images.Create(IDB_IMAGES, 16, 0, RGB(0x00, 0x80, 0x80));
	
	TreePropSheet::CTreePropSheet::SetPageIcon(&wndPageOutgoing, Images, 0);
	TreePropSheet::CTreePropSheet::SetPageIcon(&wndPageIncoming, Images, 1);

	TreePropSheet::CTreePropSheet sht(_T("Preferences"));
	sht.m_psh.dwFlags&= ~PSH_HASHELP;
	sht.AddPage(&wndPageOutgoing);
	sht.AddPage(&wndPageIncoming);
	sht.AddPage(&wndPageFormatView);
	sht.AddPage(&wndPageFormatCompose);
	sht.AddPage(&wndPageAppearance);

	sht.SetEmptyPageText(_T("Please select a child item of '%s'."));

	sht.SetTreeViewMode(TRUE, TRUE, TRUE);
	sht.SetTreeDefaultImages(&DefaultImages);
	sht.SetActivePage(&wndPageFormatView);

	m_pMainWnd = &sht;

	sht.DoModal();

	sht.DestroyPageIcon(&wndPageOutgoing);
	sht.DestroyPageIcon(&wndPageIncoming);

	// Da das Dialogfeld geschlossen wurde, FALSE zur�ckliefern, so dass wir die
	//  Anwendung verlassen, anstatt das Nachrichtensystem der Anwendung zu starten.
	return FALSE;
}
