// PropPageServerOutgoing.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "TreePropSheetDemo.h"
#include "PropPageServerOutgoing.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Eigenschaftenseite CPropPageServerOutgoing 

IMPLEMENT_DYNCREATE(CPropPageServerOutgoing, CPropertyPage)

CPropPageServerOutgoing::CPropPageServerOutgoing() : CPropertyPage(CPropPageServerOutgoing::IDD)
{
	//{{AFX_DATA_INIT(CPropPageServerOutgoing)
	//}}AFX_DATA_INIT
}

CPropPageServerOutgoing::~CPropPageServerOutgoing()
{
}

void CPropPageServerOutgoing::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageServerOutgoing)
		// HINWEIS: Der Klassen-Assistent f�gt hier DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageServerOutgoing, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageServerOutgoing)
		// HINWEIS: Der Klassen-Assistent f�gt hier Zuordnungsmakros f�r Nachrichten ein
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CPropPageServerOutgoing 
