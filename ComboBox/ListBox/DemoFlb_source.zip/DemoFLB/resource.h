//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DemoFLB.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMOFLB_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_PP_STYLES                   129
#define IDD_PP_MANUAL                   130
#define IDB_BMP_OFF11                   132
#define IDD_PP_MRUSYNC                  134
#define IDD_PP_PERSISTENCE              135
#define IDD_PP_TRANSPARENT              136
#define IDB_BITMAP0                     137
#define IDB_BITMAP1                     139
#define IDC_NB_FONTS                    1000
#define IDC_NB_FONTSMRU                 1001
#define IDC_BTN_ADD                     1001
#define IDC_BTN_REMOVE                  1002
#define IDC_NB_FONTS_FNTDLG             1002
#define IDC_LIST2                       1003
#define IDC_CHECK_GRAPHIC               1004
#define IDC_LIST1                       1004
#define IDC_EDIT1                       1005
#define IDC_CHECK_HASTOOLTIP            1006
#define IDC_CHECK_TRACKING              1007
#define IDC_RADIO1                      1009
#define IDC_RADIO2                      1010
#define IDC_APPLY                       1011
#define IDC_BTN_MRUADD                  1012
#define IDC_CHECK_MRU                   1013
#define IDC_BTN_MRUREMOVE               1013
#define IDC_RADIO_MRU0                  1014
#define IDC_BTN_MRUCLEAR2               1014
#define IDC_BTN_MRUSAVE                 1014
#define IDC_RADIO_MRU1                  1015
#define IDC_BTN_MRUCLEAR1               1015
#define IDC_CMB_LISTSTYLE               1016
#define IDC_BTN_MRULOAD                 1016
#define IDC_RADIO_MRU2                  1017
#define IDC_BTN_MRUPERSISTENCE          1017
#define IDC_CHECK_HEIGHT                1018
#define IDC_BTN_SHOWFNTDLG              1019
#define IDC_EDT_MRUNAME                 1020
#define IDC_BTN_CLEARSEL                1021
#define IDC_CHECK_BMP                   1022
#define IDC_BTN_CLEARMRU                1023
#define IDC_CHK_SELECTED                1025
#define IDC_BTN_MRUCLEAR                1026
#define IDC_LIST                        1027
#define IDC_IMAGE                       1028
#define IDC_BTNCHANGEIMAGE              1029
#define IDC_BTNCLEARSEL                 1030
#define IDC_BTNGRAPHIC                  1031
#define IDC_BTNCLEARLIST                1031
#define IDC_BUTTON1                     1032
#define IDC_TT_MAXITEMS                 1033
#define IDC_SPIN_TT_MAXITEMS            1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
