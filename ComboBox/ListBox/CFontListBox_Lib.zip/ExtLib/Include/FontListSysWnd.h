#if !defined(AFX_FONTLISTSYSWND_H__7EC739FC_1F7A_4689_B132_B1092BAAA8F1__INCLUDED_)
#define AFX_FONTLISTSYSWND_H__7EC739FC_1F7A_4689_B132_B1092BAAA8F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FontListSysWnd.h : header file
//

class CFontListManager;

/////////////////////////////////////////////////////////////////////////////
// CFontListSysWnd window

class CFontListSysWnd : public CWnd
{
	friend class CFontListManager;
// Construction
public:
	CFontListSysWnd();

// Attributes
public:

protected:
	CFontListManager*	m_pListManager;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontListSysWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFontListSysWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFontListSysWnd)
	afx_msg void OnFontChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FONTLISTSYSWND_H__7EC739FC_1F7A_4689_B132_B1092BAAA8F1__INCLUDED_)
