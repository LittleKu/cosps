#if !defined(AFX_TRANSPARENTBITMAP_H__5AC1DCE4_C8F1_437F_B936_1FB6090A5C00__INCLUDED_)
#define AFX_TRANSPARENTBITMAP_H__5AC1DCE4_C8F1_437F_B936_1FB6090A5C00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TransparentBitmap.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CTransparentBitmap command target

class CTransparentBitmap : public CBitmap
{
public:
    CTransparentBitmap();
    ~CTransparentBitmap();
    void Draw(HDC hDC, int x, int y);
    void Draw(CDC* pDC, int x, int y);
    void DrawTransparent(HDC hDC, int x, int y);
    void DrawTransparent(CDC* pDC, int x, int y);
    int GetWidth();
    int GetHeight();

private:
    int m_iWidth;
    int m_iHeight;
    HBITMAP m_hbmMask;    // handle to mask bitmap

    void GetMetrics();
    void CreateMask(HDC hDC);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSPARENTBITMAP_H__5AC1DCE4_C8F1_437F_B936_1FB6090A5C00__INCLUDED_)
