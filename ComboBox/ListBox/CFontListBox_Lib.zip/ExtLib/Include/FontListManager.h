#if !defined(AFX_FONTSYSLIST_H__D7246AC8_5343_4FA2_B99C_FFF2A9990F97__INCLUDED_)
#define AFX_FONTSYSLIST_H__D7246AC8_5343_4FA2_B99C_FFF2A9990F97__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FontListManager.h : header file
//

#include <afxtempl.h>
#include <afxcoll.h>

// 
#ifndef AFX_FONTCHANGESUPPORTED
#define AFX_FONTCHANGESUPPORTED		FALSE
#else
#undef AFX_FONTCHANGESUPPORTED
#define AFX_FONTCHANGESUPPORTED		TRUE
#endif

// Private messages
#define WM_FONTCHANGENOTIFICATION			(WM_USER + 1)
#define WM_FONTMRUCHANGENOTIFICATION		(WM_USER + 2)
//wParam for WM_FONTMRUCHANGENOTIFICATION
#define FM_REMOVEALL			0x1
#define FM_FONTADDED			0x2
#define FM_FONTREMOVED		0x3
#define FM_CHANGEDALL		0x4

#define FM_TYPE_GLOBAL				0
#define FM_TYPE_CUSTOM				1
#define FM_TYPE_LOCAL				3


/* EnumFonts Masks */
#ifndef RASTER_FONTTYPE
#define RASTER_FONTTYPE     0x0001
#define DEVICE_FONTTYPE     0x002
#define TRUETYPE_FONTTYPE   0x004
#endif

// these are extra nFontType bits that are added to what is returned to the
// EnumFonts callback routine
#ifndef SIMULATED_FONTTYPE
#define SIMULATED_FONTTYPE    0x8000
#define PRINTER_FONTTYPE      0x4000
#define SCREEN_FONTTYPE       0x2000
#define BOLD_FONTTYPE         0x0100
#define ITALIC_FONTTYPE       0x0200
#define REGULAR_FONTTYPE      0x0400
#endif

#ifndef PS_OPENTYPE_FONTTYPE
#define PS_OPENTYPE_FONTTYPE  0x10000
#define TT_OPENTYPE_FONTTYPE  0x20000
#define TYPE1_FONTTYPE        0x40000
#endif


#define EX_TT_FONTTYPE_MASK = 0x70000

class  CFontListManager;
class	 CFontDescriptor;
class	 CFontListBox;
class	 CFontTipWnd;

typedef CTypedPtrMap <CMapStringToOb, CString, CFontDescriptor*> CFontMap;
typedef CArray <CFontDescriptor*, CFontDescriptor*> CFontDescriptorArray;

/////////////////////////////////////////////////////////////////////////////
// CFontDescriptor class
class CFontDescriptor : public CObject
{
	friend class	CFontListManager;
	friend class	CFontListBox;
	friend class	CFontTipWnd;
public:
	CFontDescriptor();           // protected constructor used by dynamic creation
	CString	m_strFaceName;
	int		m_nFontType;
	DWORD		m_dwCharSets;
	int		m_nImage;
	CFont*	GetFontObject(int nHeight = 0);
protected:
	~CFontDescriptor();
	CFont*	m_pFont;
	int		m_nFontHeight;

};

/////////////////////////////////////////////////////////////////////////////
// CFontMruList class
class CFontMruList : public CObject
{
	friend class  CFontListManager;
	friend class  CFontListBox;
public:
	CFontMruList();           // protected constructor used by dynamic creation
	BOOL EnablePersistence(BOOL bPersistence = TRUE);
	BOOL IsPersistent();
protected:
	CFontMap						m_mapFaceNames;
	CFontDescriptorArray		m_arFonts;
	UINT							m_type;
	CString						m_name;
	BOOL							m_persistence;
	BOOL							m_persistenceRemoved;
	int GetCount();
	CFontDescriptor* GetFontAt(int i);
	void RemoveAll();
protected:
	~CFontMruList();
	CArray <CWnd*, CWnd*>	m_arWndPtr;
	
};

#include "FontListSysWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CFontListManager class

class CFontListManager
{
	friend class CFontDescriptor;
	friend class CFontListBox;
	friend class CFontListSysWnd;
public:
	CFontListManager();           // protected constructor used by dynamic creation

// Attributes
public:

protected:
	CFontMap						m_mapFaceNames;
	CFontDescriptorArray		m_arFonts;
	DWORD							m_dwEnumCharSet;
	// MRU management
	// allow access by CWnd pointer
	CTypedPtrMap <CMapPtrToPtr, CWnd*, CFontMruList*>		m_mapMru;
	// array of all the defined Mru list
	CArray <CFontMruList*, CFontMruList*>						m_arMru;
	// allow access by the name of the MRU list (only for custom list)
	CTypedPtrMap <CMapStringToOb, CString, CFontMruList*> m_mapNamedMru;
	// the application global MRU list
	CFontMruList		m_gblMruList;
	// default font height
	int					nDefFontHeight;
	// the hidden window to receive the
	CFontListSysWnd*	m_pWndSys;
// Operations
public:
	HBITMAP GetFontTypeBitmap();
	BOOL Refresh();
	void Clear();
	LONG GetCount();
	LPCTSTR GetFaceName(int index);
	CFontDescriptor* GetDescriptor(int index);
	CFontDescriptor* GetDescriptor(LPCTSTR lpszFaceName);
	DWORD GetType(LPCTSTR lpszFaceName);
	DWORD GetType(int index);
	int GetImageIndex(CFontDescriptor* pFont);
	CFontMruList* AttachMruFontList(CWnd* pWnd, LPCTSTR lpszMruListName);
	CFontMruList* DetachMruFontList(CWnd* pWnd);
	CFontMruList* GetMruFontList(CWnd* pWnd);

	int ClearMruFontList(CWnd* pWnd);
	int AddFontsToMruList(CWnd* pWnd, CFontDescriptor* pFont);
	int AddFontsToMruList(CWnd* pWnd, LPCTSTR lpszFontName);
	int AddFontsToMruList(CWnd* pWnd, CFontDescriptorArray* lpFontArray);
	int AddFontsToMruList(CWnd* pWnd, CStringArray* lparFaceNames);
	int RemoveFontsFromMruList(CWnd* pWnd, CFontDescriptor* lpFont);
	int RemoveFontsFromMruList(CWnd* pWnd, CFontDescriptorArray* lpFontArray);
	void LoadFontListSettings();
	void SaveFontListSettings();
	BOOL EnableMruListPersistence (LPCTSTR lpszMruListName, BOOL bPersistence = TRUE);
	BOOL EnableMruListPersistence (CWnd* pWnd, BOOL bPersistence = TRUE);
	BOOL ReloadMruListSettings(LPCTSTR lpszMruListName);
	BOOL SaveMruListSettings(LPCTSTR lpszMruListName);
	BOOL IsMruListPersistent(LPCTSTR lpszMruListName);
	BOOL IsFontInMruList(CWnd* pWnd, CFontDescriptor* pFont);
	BOOL IsFontInMruList(CWnd* pWnd, LPCSTR lpszFaceName);

protected:
	void FillFontList();
	void SortFontArray(CFontDescriptorArray& arFonts);
	void VerifyMruLists();
	BOOL EnableMruListPersistence (CFontMruList* lpMruList, BOOL bPersistence = TRUE);
	CFontMruList* GetMruPtrFromName(LPCTSTR lpszMruListName);
	BOOL ReloadMruListSettings(CFontMruList* lpMruList, CWnd* lpWnd = NULL);
	BOOL ReloadMruListSettings(CWnd* lpWnd);
	BOOL SaveMruListSettings(CFontMruList* lpMruList);
	BOOL SaveMruListSettings(CWnd* lpWnd);
	void BroadCastMruMessage(CFontMruList* pMru, CWnd* pWnd, WPARAM msg, LPARAM lParam=NULL);
	void BroadCastListMessage(CFontMruList* pMru, CWnd* pWnd, WPARAM msg, LPARAM lParam);
	void BroadCastFontListChangeMessage(CFontMruList* pMru, CWnd* pWnd, UINT msgType, WPARAM msg, LPARAM lParam);
	BOOL IsMruListPersistent(CWnd* pWnd);
	int GetProfileMruListList(CStringArray& arMruListList);
	void RefreshMruList(CFontMruList* lpMruList);

public:
	void OnFontChange();
	int Add(CFontDescriptor* lpFntDescriptor);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontListManager)
	//}}AFX_VIRTUAL

// Implementation
protected:
	void Init();

public:
	virtual ~CFontListManager();

	// Generated message map functions
	//{{AFX_MSG(CFontListManager)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

const HBITMAP AFXAPI AfxGetFontTypeBitmap();

/////////////////////////////////////////////////////////////////////////////
// Global functions declarations

#define _AFX_INLINE AFX_INLINE

#if !defined(_AFX_CORE_IMPL) || !defined(_AFXDLL) || defined(_DEBUG)
#define _AFX_PUBLIC_INLINE AFX_INLINE
#else
#define _AFX_PUBLIC_INLINE
#endif

CFontListManager* AFXAPI AfxGetFontList();
CFontListManager& AFXAPI AfxGetFontListRef();
BOOL AFXAPI AfxAddFontToGlobalMruList(LPCTSTR lpszName);
BOOL AFXAPI AfxIsMruFont(LPCTSTR lpszName);
void AFXAPI AfxClearGlobalMruFontList();
BOOL AFXAPI AfxFontChangeSupported(); 
CFontDescriptor* AfxGetFontDescriptor(LPCTSTR lpszName);

// MRU Font list support
#define GLOBAL_MRULIST	(LPCTSTR)(-1)

void LoadFontListSettings();
void SaveFontListSettings();
BOOL EnableMruListPersistence (LPCTSTR lpszMruListName, BOOL bPersistence = TRUE);
BOOL ReloadMruListSettings(LPCTSTR lpszMruListName);
BOOL SaveMruListSettings(LPCTSTR lpszMruListName);
BOOL IsMruListPersistent(LPCTSTR lpszMruListName);

/*
#ifndef AFX_PRIVATE_FONT_DEFINITIONS
#define GetFontDescriptor(name)  \
	AfxGetFontListRef().GetDescriptor((name))
#define AttachMruFontList(name)  \
	AfxGetFontListRef().AttachMruFontList(this, (LPCTSTR)(name))
#define DetachMruFontList()  \
	AfxGetFontListRef().DetachMruFontList(this)
#define GetMruFontList()  \
	AfxGetFontListRef().GetMruFontList(this)
#define ClearMruFontList()  \
	AfxGetFontListRef().ClearMruFontList(this)
#endif
*/
#include "FontListManager.inl"

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.


#endif // !defined(AFX_FONTSYSLIST_H__D7246AC8_5343_4FA2_B99C_FFF2A9990F97__INCLUDED_)
