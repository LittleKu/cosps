#ifndef _MEMDC_H_
#define _MEMDC_H_

#include "extdebug.h"

/////////////////////////////////////////////////////////////////////////////
// CDrawImage class

// this class is used to draw an image (HBITMAP or HICON)

// Flags used by the SetImage() function
//
// Usage :
// DRAWIMG_ICON       - the image is an icon, cannot be used with FEC_BITMAP
// DRAWIMG_BITMAP     - the image is a bitmap, cannot be used with FEC_ICON
// DRAWIMG_AUTODELETE - the image handle is deleted and the memory freed when it is no longer needed
#define DRAWIMG_ICON        0x00000001
#define DRAWIMG_BITMAP      0x00000002
#define DRAWIMG_AUTODELETE  0x00000004

// Flags used by the DrawImage() function
//
// Usage :
// DRAWIMG_TRANSPARENT - used with FEC_BITMAP, the bitmap will be drawn transparently
// DRAWIMG_STRETCHED   - Can not be used with DRAWIMG_CENTERED . The image will be stretched to fit the rectangle in DrawImage()
// DRAWIMG_CENTERED    - Can not be used with DRAWIMG_STRETCHED. The image will be centered on the rectangle
// DRAWIMG_DISABLED    - Can not be used with DRAWIMG_GRAYSCALED. Draws the image as disabled (3D Monochrome)
// DRAWIMG_GRAYSCALED   - Can not be used with DRAWIMG_DISABLED. Draws the image in grayscale
#define DRAWIMG_TRANSPARENT 0x00000010
#define DRAWIMG_STRETCHED   0x00000020
#define DRAWIMG_CENTERED    0x00000040
#define DRAWIMG_DISABLED    0x00000080
#define DRAWIMG_GRAYSCALED   0x00000100

class CDrawImage  
{
public:
//    CDrawImage();                        // constructor
//    virtual ~CDrawImage();               // destructor

//    void DrawImage(CDC *pDC, int x, int y, int w, int h, DWORD DrawFlags = 0); // draws the image
//    CSize GetSize();                          // retreives the dimensions of the image
//    BOOL SetImage(HANDLE Image, DWORD Flags); // setup the image
//    COLORREF SetTransparentColor(COLORREF clr = CLR_DEFAULT); // set the colour to used as the transparent colour
    HANDLE m_hImage;                    // the image

protected:
//    void DitherBlt(CDC *pToDC, int x, int y, int w, int h, CDC *pFromDC);  // draw the bitmap grayed
//    void DrawTransparent(CDC *pToDC, int w, int h, CDC *pFromDC); // draw the bitmap transparently
//    int Gray(int r, int g, int b);
//		HBITMAP GrayScale (CDC *pDC, HBITMAP hBitmap);
//		BOOL IsTransparent(int r, int g, int b);

private:
    DWORD m_ImageFlags;                 // the control flags
    DWORD m_DrawFlags;                  // the drawing flags
//    HANDLE m_hImage;                    // the image
    CSize m_size;                       // the image size
    COLORREF m_TransparentColor;       // the transparent colour

/////////////////////////////////////////////////////////////////////////////
// Implementation
public:
	CDrawImage()
	{
		 m_ImageFlags = 0;
		 m_DrawFlags = 0;
		 m_hImage = NULL;
		 m_size.cx = 0;
		 m_size.cy = 0;
		 m_TransparentColor = CLR_DEFAULT;
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	//  CDrawImage destructor  (public member function)
	//    frees the memory held by the image handle
	//
	//  Parameters :
	//    None
	//
	//  Returns :
	//    Nothing
	//
	/////////////////////////////////////////////////////////////////////////////

	~CDrawImage()
	{
		 if (m_ImageFlags & DRAWIMG_AUTODELETE)
		 {
			  if (m_ImageFlags & DRAWIMG_ICON)
					DestroyIcon((HICON)m_hImage);
			  else
					DeleteObject((HGDIOBJ)m_hImage);
		 }
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	//  DitherBlt  (protected member function)
	//    Draws the image on the FromDC as a disabled (grayed) image onto the pToDC
	//
	//  Parameters :
	//    pToDC  [in] - pointer to the DC to draw the bitmap onto
	//    x      [in] - the left side of the image on the destination DC
	//    y      [in] - the top  of the image on the destination DC
	//    w      [in] - the width of the image on the destination DC
	//    h      [in] - the height of the image on the destination DC
	//    FromDC [in] - The DC containing the bitmap to be grayed
	//
	//  Returns :
	//    Nothing
	//
	//  Note : modified from code found at http://www.codeguru.com/bitmap/dither_blt.shtml
	//         original author Jean-Edouard Lachand-Robert (iamwired@geocities.com)
	//
	/////////////////////////////////////////////////////////////////////////////
protected:
	void DitherBlt(CDC *pToDC, int x, int y, int w, int h, CDC *pFromDC)
	{
		 CDC MonoDC;
		 if (MonoDC.CreateCompatibleDC(pToDC))
		 {
			  struct {
					BITMAPINFOHEADER bmiHeader; 
					RGBQUAD          bmiColors[2]; 
			  } RGBBWBITMAPINFO = { { sizeof(BITMAPINFOHEADER),
					w,
					h,
					1,
					1,
					BI_RGB,
					0,
					0,
					0,
					0,
					0},
			  { { 0x00, 0x00, 0x00, 0x00 },
			  { 0xFF, 0xFF, 0xFF, 0x00 }}};

			  VOID *pbitsBW;
			  HBITMAP hbmBW = CreateDIBSection(MonoDC.m_hDC,
					(LPBITMAPINFO)&RGBBWBITMAPINFO,
					DIB_RGB_COLORS,
					&pbitsBW,
					NULL,
					0);
			  ASSERT(hbmBW);

			  if (hbmBW)
			  {
					int SavedMonoDC = MonoDC.SaveDC();
					int SavedpToDC = pToDC->SaveDC();

					// Attach the monochrome DIB section to the MonoDC
					MonoDC.SelectObject(hbmBW);
            
					// BitBlt the bitmap into the monochrome DIB section
					MonoDC.BitBlt(0, 0, w, h, pFromDC, 0, 0, SRCCOPY);

					// BitBlt the black bits in the monochrome bitmap into COLOR_3DHILIGHT bits in the destination DC
					// The magic ROP comes from the Charles Petzold's book
					HBRUSH hb = CreateSolidBrush(GetSysColor(COLOR_3DHILIGHT));
					pToDC->SelectObject(hb);
					pToDC->BitBlt(x + 1, y + 1, w, h, &MonoDC, 0, 0, 0x00B8074A);
            
					// BitBlt the black bits in the monochrome bitmap into COLOR_3DSHADOW bits in the destination DC
					hb = CreateSolidBrush(GetSysColor(COLOR_3DSHADOW));
					DeleteObject(pToDC->SelectObject(hb));
					pToDC->BitBlt(x, y, w, h, &MonoDC, 0, 0, 0x00B8074A);
            
					pToDC->RestoreDC(SavedpToDC);
					MonoDC.RestoreDC(SavedMonoDC);
					DeleteObject(hb);
			  }
			  DeleteObject(hbmBW);
			  MonoDC.DeleteDC();
		 }
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	//  DrawImage  (public member function)
	//    Draws the image (set with the SetImage() function) on the given device 
	//    context
	//
	//  Parameters :
	//    pDC       [in] - a pointer to the the device context to draw the image on
	//    x         [in] - the left side of the image on the destination DC
	//    y         [in] - the top  of the image on the destination DC
	//    w         [in] - the width of the image on the destination DC
	//    h         [in] - the height of the image on the destination DC
	//    DrawFlags [in] - How to draw the image
	//
	//  Returns :
	//    Nothing
	//
	//  Note :
	//    See the PJAImage.h file for a description of the flags used
	//
	//    The image will be drawn entirely within the rectangle specified by the
	//    x, y, w, and h parameters.
	//
	/////////////////////////////////////////////////////////////////////////////
public:
	void DrawImage(CDC *pDC, int x, int y, int w, int h, DWORD DrawFlags = 0)
	{   // sanity check
		 if (!m_hImage)
			  return;

		 // verify flags
	#ifdef _DEBUG
		 if (DrawFlags & DRAWIMG_DISABLED)
			  ASSERT (!(DrawFlags & DRAWIMG_GRAYSCALED));
		 if (DrawFlags & DRAWIMG_CENTERED)
			  ASSERT (!(DrawFlags & DRAWIMG_STRETCHED));
	#endif

		 m_DrawFlags = DrawFlags;

		 // handle for the grayscale bitmap
		 HBITMAP GrayBmp = NULL;

		 // set the clip region to the specified rectangle
		 CRgn ClipRgn;
		 ClipRgn.CreateRectRgn(x, y, x + w, y + h);
		 pDC->SelectClipRgn(&ClipRgn);
		 ClipRgn.DeleteObject();

		 // create memory DC
		 CDC memDC;
		 memDC.CreateCompatibleDC(pDC);
		 int savedmemDC = memDC.SaveDC();
		 CBitmap memDCBmp;

		 CDC* pOutputDC = &memDC;

		 int left = x;
		 int top = y;
		 int width = m_size.cx;
		 int height = m_size.cy;

		 if (m_DrawFlags & DRAWIMG_CENTERED)
		 {   // center the image on the output rectangle
			  left = x + (w / 2) - (m_size.cx / 2);
			  top = y + (h / 2) - (m_size.cy / 2);
		 }

		 // Get the background image for transparent images
		 CBitmap BackGroundBitmap;
		 BackGroundBitmap.CreateCompatibleBitmap(pDC, w, h);
		 CDC BackGroundDC;
		 BackGroundDC.CreateCompatibleDC(pDC);
		 int savedBackGroundDC = BackGroundDC.SaveDC();
		 BackGroundDC.SelectObject(&BackGroundBitmap);
		 BackGroundDC.BitBlt(0, 0, w, h, pDC, x, y, SRCCOPY);

		 // Create a DC and bitmap for the stretched image
		 CDC StretchDC;
		 int savedStretchDC = 0;
		 CBitmap stretchbmp;
		 if (m_DrawFlags & DRAWIMG_STRETCHED)
		 {   // stretch image to fit output rectangle
			  width = w;
			  height = h;
		 }

		 // Create a DC and bitmap for the transparent image
		 CDC TransparentDC;
		 int savedTransparentDC = 0;
		 CBitmap Transparentbmp;

		 if (m_ImageFlags & DRAWIMG_ICON)
		 {   // draw the icon onto the memory DC
			  HICON TheIcon = (HICON)m_hImage;
			  if (m_DrawFlags & DRAWIMG_GRAYSCALED)
			  {   // convert the colour icon to grayscale
					ICONINFO iconinfo;
					GetIconInfo(TheIcon, &iconinfo);
					if (iconinfo.hbmColor)
					{
						 HBITMAP grayscale = GrayScale(pDC, iconinfo.hbmColor);

						 ::DeleteObject(iconinfo.hbmColor);
						 iconinfo.hbmColor = grayscale;
						 TheIcon = ::CreateIconIndirect(&iconinfo);
						 ::DeleteObject(iconinfo.hbmColor);
						 ::DeleteObject(iconinfo.hbmMask);
					}
			  }

			  memDCBmp.CreateCompatibleBitmap(pDC, width, height);
			  memDC.SelectObject(&memDCBmp);
			  memDC.BitBlt(left, top, width, height, &BackGroundDC, left, top, SRCCOPY);

			  ::DrawIconEx(memDC.m_hDC, 0, 0, TheIcon, width, height, 0, NULL, DI_NORMAL);
        
			  if (TheIcon != m_hImage)
					::DestroyIcon(TheIcon);
		 }
		 else if (m_ImageFlags & DRAWIMG_BITMAP)
		 {   // place bitmap image into the memory DC
			  memDC.SelectObject((HBITMAP)m_hImage);
			  if (m_TransparentColor == CLR_DEFAULT)
					m_TransparentColor = memDC.GetPixel(0, 0);

			  if (m_DrawFlags & DRAWIMG_STRETCHED)
			  {   // stretch the image
					StretchDC.CreateCompatibleDC(pDC);
					savedStretchDC = StretchDC.SaveDC();
					stretchbmp.CreateCompatibleBitmap(pDC, w, h);
					StretchDC.SelectObject(stretchbmp);
					StretchDC.SetStretchBltMode(COLORONCOLOR);
					StretchDC.StretchBlt(0, 0, width, height, &memDC, 0, 0, m_size.cx, m_size.cy, SRCCOPY);
					pOutputDC = &StretchDC;
			  }

			  if (m_DrawFlags & DRAWIMG_TRANSPARENT)
			  {   // draw the image transparently
					TransparentDC.CreateCompatibleDC(pDC);
					savedTransparentDC = TransparentDC.SaveDC();
					Transparentbmp.CreateCompatibleBitmap(pDC, width, height);
					TransparentDC.SelectObject(&Transparentbmp);
					TransparentDC.BitBlt(0, 0, w, h, &BackGroundDC, left, top, SRCCOPY);
					DrawTransparent(&TransparentDC, width, height, pOutputDC);
					pOutputDC = &TransparentDC;
			  }
			  else if (m_DrawFlags & DRAWIMG_GRAYSCALED)
			  {   // convert the image to grayscale
					GrayBmp = GrayScale(pDC, *pOutputDC->GetCurrentBitmap());
					pOutputDC->SelectObject(GrayBmp);
			  }
		 }
		 else
		 {
			  ASSERT (FALSE);  // m_Flags improperly set (should never get here)
		 }

		 if (m_DrawFlags & DRAWIMG_DISABLED && !(m_DrawFlags & DRAWIMG_TRANSPARENT))  // draw the image disabled
			  DitherBlt(pDC, left, top, width, height, pOutputDC);
		 else   // draw the image
			  pDC->BitBlt(left, top, width, height, pOutputDC, 0, 0, SRCCOPY);

		 // clean up after ourselves
		 if (savedTransparentDC)
		 {
			  TransparentDC.RestoreDC(savedTransparentDC);
			  TransparentDC.DeleteDC();
		 }

		 if (savedStretchDC)
		 {
			  StretchDC.RestoreDC(savedStretchDC);
			  StretchDC.DeleteDC();
		 }

		 memDC.RestoreDC(savedmemDC);
		 memDC.DeleteDC();
		 BackGroundDC.RestoreDC(savedBackGroundDC);
		 BackGroundDC.DeleteDC();

		 if (GrayBmp)
			  ::DeleteObject(GrayBmp);
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	//  DrawTransparent  (protected member function)
	//    transparently draws the image in the source device context onto the 
	//    destination device context 
	//
	//  Parameters :
	//    pToDC         [in] - pointer to the destination device context
	//    w             [in] - the width of the image
	//    h             [in] - the height of the image
	//    pFromDC       [in] - pointer to the source DC containing the bitmap to be drawn
	//
	//  Returns :
	//    Nothing
	//
	//  Note :
	//    Uses the 'True Mask' method
	//    Modified from code found at http://www.codeguru.com/bitmap/CISBitmap.shtml
	//    original author Paul Reynolds (Paul.Reynolds@cmgroup.co.uk)
	// 
	/////////////////////////////////////////////////////////////////////////////
protected:
	void DrawTransparent(CDC *pToDC, int w, int h, CDC *pFromDC)
	{
		 // handle for the grayscale image
		 HBITMAP Gray = NULL;

		 CDC *pOutputDC = pFromDC;

		 CDC MonoDC;
		 MonoDC.CreateCompatibleDC(pToDC);

		 CDC DisabledDC;
		 DisabledDC.CreateCompatibleDC(pToDC);
		 CBitmap DisabledBitmap;

		 int savedToDC = pToDC->SaveDC();
		 int savedFromDC = pFromDC->SaveDC();
		 int savedMonoDC = MonoDC.SaveDC();
		 int savedDisabledDC = DisabledDC.SaveDC();

		 pToDC->SetBkColor(RGB(255, 255, 255));
		 pToDC->SetTextColor(RGB(0, 0, 0));
		 pFromDC->SetBkColor(m_TransparentColor);
    
		 if (m_DrawFlags & DRAWIMG_DISABLED)  // draw the image disabled
		 {
			  // First, copy the bitmap from pFromDC to TempFromBmp
			  // Then, draw TempFromBmp transparently onto a white background in WhiteDC
			  // Then, DitherBlt WhiteDC onto DisabledDC which also has a white background
			  // Then DisabledDC becomes the dc that we use for the mask and drawing
			  CDC WhiteDC;
			  WhiteDC.CreateCompatibleDC(pToDC);
			  int savedWhiteDC = WhiteDC.SaveDC();
			  CBitmap WhiteBitmap;
			  WhiteBitmap.CreateCompatibleBitmap(pToDC, w, h);
			  CBitmap TempFromBmp;
			  TempFromBmp.CreateCompatibleBitmap(pToDC, w, h);
			  WhiteDC.SelectObject(&TempFromBmp);
			  WhiteDC.BitBlt(0, 0, w, h, pFromDC, 0, 0, SRCCOPY);
			  WhiteDC.SelectObject(&WhiteBitmap);
			  WhiteDC.FillSolidRect(0, 0, w, h, RGB(255, 255, 255));

			  DisabledBitmap.CreateCompatibleBitmap(pToDC, w, h);
			  DisabledDC.SelectObject(&DisabledBitmap);
			  DisabledDC.FillSolidRect(0, 0, w, h, RGB(255, 255, 255));

			  CDrawImage temp;
			  temp.SetImage(TempFromBmp, DRAWIMG_BITMAP);
			  temp.SetTransparentColor(m_TransparentColor);
			  temp.DrawImage(&WhiteDC, 0, 0, w, h, DRAWIMG_TRANSPARENT);

			  DitherBlt(&DisabledDC, 0, 0, w, h, &WhiteDC);
			  pOutputDC = &DisabledDC;

			  WhiteDC.RestoreDC(savedWhiteDC);
			  WhiteDC.DeleteDC();
		 }

		 // Create the mask
		 CBitmap MonoDCbmp;
		 MonoDCbmp.CreateBitmap(w, h, 1, 1, NULL);
		 MonoDC.SelectObject(&MonoDCbmp);
		 MonoDC.BitBlt(0, 0, w, h, pOutputDC, 0, 0, SRCCOPY);

		 if (m_DrawFlags & DRAWIMG_GRAYSCALED)
		 {   // convert the image to grayscale. We do this here just
			  // in case the bitmap has a grayscale colour as the 
			  // transparent colour
			  Gray = GrayScale(pFromDC, *pFromDC->GetCurrentBitmap());
			  pFromDC->SelectObject(Gray);
		 }

		 // draw the transparent bitmap
		 pToDC->BitBlt(0, 0, w, h, pOutputDC, 0, 0, SRCINVERT);
		 pToDC->BitBlt(0, 0, w, h, &MonoDC, 0, 0, SRCAND);
		 pToDC->BitBlt(0, 0, w, h, pOutputDC, 0, 0, SRCINVERT);

		 DisabledDC.RestoreDC(savedDisabledDC);
		 DisabledDC.DeleteDC();

		 MonoDC.RestoreDC(savedMonoDC);
		 MonoDC.DeleteDC();

		 pFromDC->RestoreDC(savedFromDC);
		 pToDC->RestoreDC(savedToDC);

		 if (Gray)
			  ::DeleteObject(Gray);
	}

	/////////////////////////////////////////////////////////////////////////////
	//
	//  GetSize  (public member function)
	//    Gets the size of the image in pixels
	//
	//  Parameters :
	//    None
	//
	//  Returns :
	//    a CSize containing the size of the image
	//
	/////////////////////////////////////////////////////////////////////////////
public:
	CSize GetSize()
	{
		 return m_size;
	};

	/////////////////////////////////////////////////////////////////////////////
	//
	//  Gray   (protected member function)
	//    Gets the grayscale value of the given colour
	//
	//  Parameters :
	//    r [in] - the red colour
	//    g [in] - the green colour
	//    b [in] - the blue colour
	//
	//  Returns :
	//    the grayscale value
	//
	/////////////////////////////////////////////////////////////////////////////
private:
	int Gray(int r, int g, int b)
	{
		 return (b * 11 + g * 59 + r * 30) / 100;
		 //  grayscale=0.299*rSum + 0.587*gSum + 0.114*bSum
	};
	/////////////////////////////////////////////////////////////////////////////
	//
	//  IsTransparent  (protected member function)
	//    checks if the given colour values make up the transparent colour for the bitmap
	//
	//  Parameters :
	//    r [in] - the red colour
	//    g [in] - the green colour
	//    b [in] - the blue colour
	//
	//  Returns :
	//    TRUE if the colour is the transparent colour
	//    FALSE if not
	//
	/////////////////////////////////////////////////////////////////////////////


	BOOL IsTransparent(int r, int g, int b)
	{
		 if (!(m_DrawFlags & DRAWIMG_TRANSPARENT))
			  return FALSE;
		 COLORREF rgb = RGB(r, g, b);
		 if  (rgb == m_TransparentColor)
			 return TRUE;
		 else return FALSE;
	};

	/////////////////////////////////////////////////////////////////////////////
	//
	//  GrayScale   (protected member function)
	//    Creates a DIBSection that is the grayscale equivalant of the given bitmap
	//
	//  Parameters :
	//    pDC     [in] - a pointer to a DC used to build the colour table
	//    hBitmap [in] - the bitmap to turn grayscale
	//
	//  Returns :
	//    the HBITMAP of the new grayscale DIBSection
	//
	//  Note :
	//    when you are finished with the HBITMAP returned by this function
	//    you have to delete it with a call to ::DeleteObject()
	//
	//    This function does not change the transparent colour to grayscale.
	//
	/////////////////////////////////////////////////////////////////////////////

	HBITMAP GrayScale(CDC *pDC, HBITMAP hBitmap)
	{
		 // get the bitmap's size and colour information
		 BITMAP bm;
		 ::GetObject(hBitmap, sizeof(BITMAP), &bm);

		 // create a DIBSection copy of the original bitmap
		 HBITMAP hDib = (HBITMAP)::CopyImage(hBitmap, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG | LR_CREATEDIBSECTION);
    
		 if (bm.bmBitsPixel < 16)
		 {   // bitmap has a colour table, so we modify the colour table
			  CDC memDC;
			  memDC.CreateCompatibleDC(pDC);
			  int SavedMemDC = memDC.SaveDC();
			  memDC.SelectObject(hDib);
			  int nColours = 1 << bm.bmBitsPixel;

			  RGBQUAD pal[256];

			  // Get the colour table
			  ::GetDIBColorTable(memDC.m_hDC, 0, nColours, pal);

			  // modify the colour table
			  for (int x = 0; x < nColours; x++)
			  {
					if (!IsTransparent(pal[x].rgbRed, pal[x].rgbGreen, pal[x].rgbBlue))
					{
						 BYTE nGray = (BYTE)Gray(pal[x].rgbRed, pal[x].rgbGreen, pal[x].rgbBlue);
						 pal[x].rgbRed = nGray;
						 pal[x].rgbGreen = nGray;
						 pal[x].rgbBlue = nGray;
					}
			  }

			  // set the modified colour tab to the DIBSection bitmap
			  ::SetDIBColorTable(memDC.m_hDC, 0, nColours, pal);
        
			  memDC.RestoreDC(SavedMemDC);
			  memDC.DeleteDC();
			  return hDib;
		 }

		 else
		 {   // the bitmap does not have a colour table, so we modify the bitmap bits directly
			  int Size = bm.bmHeight * bm.bmWidth;
        
			  BITMAPINFO bmi;
			  bmi.bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
			  bmi.bmiHeader.biHeight        = bm.bmHeight;
			  bmi.bmiHeader.biWidth         = bm.bmWidth;
			  bmi.bmiHeader.biPlanes        = 1;
			  bmi.bmiHeader.biBitCount      = bm.bmBitsPixel;
			  bmi.bmiHeader.biCompression   = BI_RGB;
			  bmi.bmiHeader.biSizeImage     = ((bm.bmWidth * bm.bmBitsPixel + 31) & (~31)) / 8 * bm.bmHeight;
			  bmi.bmiHeader.biXPelsPerMeter = 0;
			  bmi.bmiHeader.biYPelsPerMeter = 0;
			  bmi.bmiHeader.biClrUsed       = 0;
			  bmi.bmiHeader.biClrImportant  = 0;
        
			  // Get the bitmaps data bits
			  BYTE *pBits = new BYTE[bmi.bmiHeader.biSizeImage];
			  VERIFY (::GetDIBits(pDC->m_hDC, hDib, 0, bm.bmHeight, pBits, &bmi, DIB_RGB_COLORS));

			  if (bm.bmBitsPixel == 32)
			  {
					DWORD *dst=(DWORD *)pBits;
            
					while (Size--)
					{
						 if (!IsTransparent(GetBValue(*dst), GetGValue(*dst), GetRValue(*dst)))
						 {
							  int nGray = Gray(GetBValue(*dst), GetGValue(*dst), GetRValue(*dst));
							  *dst = (DWORD)RGB(nGray, nGray, nGray);
						 }
						 dst++;
				  }
			  }
        
			  else if (bm.bmBitsPixel == 24)
			  {
					BYTE *dst=(BYTE*)pBits;

					for (int dh = 0; dh < bm.bmHeight; dh++)
					{
						 for (int dw = 0; dw < bm.bmWidth; dw++)
						 {
							  if (!IsTransparent(dst[2], dst[1], dst[0]))
							  {
									int nGray = Gray(dst[2], dst[1], dst[0]);
                    
									dst[0]=(BYTE)nGray;
									dst[1]=(BYTE)nGray;
									dst[2]=(BYTE)nGray;
							  }
							  dst += 3;
						 }

						 // each row is DWORD aligned, so when we reach the end of a row, we
						 // have to realign the pointer to point to the start of the next row
						 int pos = (int)dst - (int)pBits;
						 int rem = pos % 4;
						 if (rem)
							  dst += 4 - rem;
					}
			  }

			  else if (bm.bmBitsPixel == 16)
			  {
					WORD *dst=(WORD*)pBits;
            
					while (Size--)
					{
						 BYTE b = (BYTE)((*dst)&(0x1F));
						 BYTE g = (BYTE)(((*dst)>>5)&(0x1F));
						 BYTE r = (BYTE)(((*dst)>>10)&(0x1F));
                
						 if (!IsTransparent(r, g, b))
						 {
							  int nGray = Gray(r, g, b);
							  *dst = ((WORD)(((BYTE)(nGray)|((WORD)((BYTE)(nGray))<<5))|(((DWORD)(BYTE)(nGray))<<10)));
						 }
						 dst++;
					}
			  }

			  // set the modified bitmap data bits to the DIBSection
			  ::SetDIBits(pDC->m_hDC, hDib, 0, bm.bmHeight, pBits, &bmi, DIB_RGB_COLORS);
			  delete[] pBits;
			  return hDib;
		 }
	};


	/////////////////////////////////////////////////////////////////////////////
	//
	//  SetImage  (public member function)
	//    Sets the image and image flags
	//
	//  Parameters :
	//    Image [in] - a HANDLE of the image to set (either a HBITMAP or a HICON)
	//    Flags [in] - the flags that specify the type of image and how it is drawn
	//
	//  Returns :
	//    TRUE on success
	//    FALSE on failure
	//
	//  Note :
	//    See the PJAImage.h file for a description of the flags used
	//
	/////////////////////////////////////////////////////////////////////////////
public:
	BOOL SetImage(HANDLE Image, DWORD Flags)
	{
		 if (Image)
		 {   // verify flags
			  if (!((Flags & DRAWIMG_BITMAP ? 1 : 0) ^ (Flags & DRAWIMG_ICON ? 1 : 0)))
			  {
					TRACE (_T("DRAWIMG_Image::SetImage() : Must specify either DRAWIMG_BITMAP or DRAWIMG_ICON"));
					ASSERT (FALSE);
					return FALSE;
			  }
		 }

		 if (m_hImage && m_hImage != Image)
		 {
			  if (m_ImageFlags & DRAWIMG_AUTODELETE)
			  {   // remove the old image
					if (m_ImageFlags & DRAWIMG_ICON)
						 DestroyIcon((HICON)m_hImage);
					else
						 DeleteObject((HGDIOBJ)m_hImage);
			  }
			  m_hImage = NULL;
			  m_size.cx = 0;
			  m_size.cy = 0;
			  m_TransparentColor = CLR_DEFAULT;
		 }

		 if (Image)
		 {   // get the image dimensions
			  if (Flags & DRAWIMG_BITMAP)
			  {
					BITMAP bmp;
					if (GetObject((HBITMAP)Image, sizeof(BITMAP), &bmp))
					{
						 m_size.cx = bmp.bmWidth;
						 m_size.cy = bmp.bmHeight;
					}
			  }
			  else if (Flags & DRAWIMG_ICON)
			  {
					ICONINFO iconinfo;
					GetIconInfo((HICON)Image, &iconinfo);
					BITMAP bmp;
					if (GetObject(iconinfo.hbmMask, sizeof(BITMAP), &bmp))
					{
						 m_size.cx = bmp.bmWidth;
						 m_size.cy = iconinfo.hbmColor ? bmp.bmHeight : bmp.bmHeight / 2;
					}
					// prevent a resource leak
					DeleteObject(iconinfo.hbmColor);
					DeleteObject(iconinfo.hbmMask);
			  }
		 }

		 m_hImage = Image;
		 m_ImageFlags = Flags;
		 return TRUE;
	};

	/////////////////////////////////////////////////////////////////////////////
	//
	//  SetTransparentColor  (public member function)
	//    Set the colour to be used as the transparent colour 
	//
	//  Parameters :
	//    clr [in] - the colour to be used as the transparent colour
	//
	//  Returns :
	//    the old transparent colour
	//
	//  Note :
	//    If the colour is CLR_DEFAULT (the default), the colour of the
	//    top left pixel (0,0) is used as the transparent colour.
	//
	/////////////////////////////////////////////////////////////////////////////
public:
	COLORREF SetTransparentColor(COLORREF clr = CLR_DEFAULT)
	{
		 COLORREF oldclr = m_TransparentColor;
		 m_TransparentColor = clr;
		 return oldclr;
	};



};



//////////////////////////////////////////////////////////////////////
// CMemDC - memory DC
//
class CMemDC : public CDC
{
//		DECLARE_DYNCREATE(CMemDC)
public:
	enum MBColors {
		MBC_COMPATIBLE =         0x80000000,
		MBC_COLOR =              0x00000000,
		MBC_COLOR4 =             0x00000004,
		MBC_COLOR8 =             0x00000008,
		MBC_COLOR16 =            0x00000010,
		MBC_COLOR24 =            0x00000018,
		MBC_COLOR32 =            0x00000020
	};
protected:
	CBitmap*		m_pBitmap;       
	CBitmap*		m_oldBitmap;
	CFont*		m_oldFont;
	CBrush*		m_oldBrush;
	CPen*			m_oldPen;
	CPalette*	m_oldPalette;
	CDC*			m_pDC;          
	CRect			m_rect;         
	BOOL			m_bMemDC;    
	BOOL			m_bFinalTransfer;
	// for special drawing (with flags)
	BOOL			m_bTransparent;
	COLORREF		m_clrTransparent;
	DWORD			m_DrawFlags;
   HANDLE		m_hImage;                    // the image
	CSize			m_size;

	void Build( CDC* pDC, MBColors cSchema = MBC_COMPATIBLE)
	{
		ASSERT(pDC != NULL); 
		m_bFinalTransfer = TRUE;
		m_pDC		= pDC;
		m_oldBitmap = NULL;
		m_bMemDC	= !pDC->IsPrinting();
		m_pBitmap = new CBitmap;

		if( m_bMemDC )
		{
			CreateCompatibleDC(pDC);
			pDC->LPtoDP(&m_rect);
			switch (cSchema)
			{
			case MBC_COLOR:
			case MBC_COLOR4:
				m_pBitmap->CreateBitmap(m_rect.Width(), m_rect.Height(), 1, 4, NULL);
				break;
			case MBC_COLOR8:
				m_pBitmap->CreateBitmap(m_rect.Width(), m_rect.Height(), 1, 8, NULL);
				break;
			case MBC_COLOR16:
				m_pBitmap->CreateBitmap(m_rect.Width(), m_rect.Height(), 1, 16, NULL);
				break;
			case MBC_COLOR24:
				m_pBitmap->CreateBitmap(m_rect.Width(), m_rect.Height(), 1, 24, NULL);
				break;
			case MBC_COLOR32:
				m_pBitmap->CreateBitmap(m_rect.Width(), m_rect.Height(), 1, 32, NULL);
				break;
			default:
				m_pBitmap->CreateCompatibleBitmap(pDC, m_rect.Width(), m_rect.Height());
				break;
			}
			m_oldBitmap = SelectObject(m_pBitmap);
			// select the current objects
			m_oldFont = SelectObject(pDC->GetCurrentFont());
			m_oldBrush = SelectObject(pDC->GetCurrentBrush());
			m_oldPen = SelectObject(pDC->GetCurrentPen());
			m_oldPalette = (CPalette*)SelectObject(pDC->GetCurrentPalette());
			SetTextColor(pDC->GetTextColor());
			SetBkMode(pDC->GetBkMode());
			SetMapMode(pDC->GetMapMode());
			pDC->DPtoLP(&m_rect);
			SetWindowOrg(m_rect.left, m_rect.top);
			
			// transfer the current bitmap
//			FillSolidRect( m_rect, pDC->GetBkColor() );
			BitBlt( m_rect.left,
							   m_rect.top,
							   m_rect.Width(),
							   m_rect.Height(),
							   m_pDC,
							   m_rect.left,
							   m_rect.top,
							   SRCCOPY );  
			
		}
		else
		{
			m_bPrinting = pDC->m_bPrinting;
			m_hDC       = pDC->m_hDC;
			m_hAttribDC = pDC->m_hAttribDC;
			FillSolidRect( m_rect, pDC->GetBkColor() );
		}

		
	};

public:
	CMemDC(): CDC() {m_pBitmap = NULL;}

	CMemDC( CDC *pDC, LPCRECT rect, MBColors cSchema = MBC_COMPATIBLE ) 
	   : CDC()
	{
	   m_rect = rect;
	   Build( pDC, cSchema ); 
	};
	void Create(CDC *pDC, LPCRECT rect, MBColors cSchema = MBC_COMPATIBLE)
	{
		m_rect = rect;
		Build( pDC, cSchema ); 
	};
	void Create(HDC hDC, LPCRECT rect, MBColors cSchema = MBC_COMPATIBLE)
	{
		m_rect = rect;
		Build( CDC::FromHandle( hDC ), cSchema ); 
	};
	CMemDC( CDC *pDC, const RECT& rect, MBColors cSchema = MBC_COMPATIBLE ) 
	   : CDC()
	{
	   m_rect = rect;
	   Build( pDC, cSchema ); 
	};
	CMemDC( HDC hDC, const RECT& rect, MBColors cSchema = MBC_COMPATIBLE ) 
	   : CDC()
	{
	   m_rect.CopyRect(&rect);
	   Build( CDC::FromHandle( hDC ), cSchema ); 
	};
	CMemDC( HDC hDC, LPCRECT rect, MBColors cSchema = MBC_COMPATIBLE ) 
	   : CDC()
	{
	   m_rect.CopyRect(rect);
	   Build( CDC::FromHandle( hDC ), cSchema ); 
	};
	CMemDC( CDC *pDC , MBColors cSchema = MBC_COMPATIBLE)
	   : CDC()
	{
	   pDC->GetClipBox( &m_rect );
	   Build( pDC, cSchema );
	};

	CMemDC( HDC hDC , MBColors cSchema = MBC_COMPATIBLE)
	   : CDC()
	{
	   CDC::FromHandle( hDC )->GetClipBox( &m_rect );
	   Build( CDC::FromHandle( hDC ) , cSchema);
	};


	virtual ~CMemDC()
	{
		if (m_bFinalTransfer)
		{
			if( m_bMemDC )
			{
				m_pDC->BitBlt( m_rect.left,
							   m_rect.top,
							   m_rect.Width(),
							   m_rect.Height(),
							   this,
							   m_rect.left,
							   m_rect.top,
							   SRCCOPY );            
				SelectObject(m_oldBitmap);        
			}
			else
			{
				m_hDC = m_hAttribDC = NULL;
			} 
		}
		if (m_pBitmap != NULL)
			delete m_pBitmap;
		SelectObject(m_oldFont);
		SelectObject(m_oldBrush);
		SelectObject(m_oldPen);
		SelectObject(m_oldPalette);
	};

	// Flags for drawing
	typedef enum {
		DRAW_NORMAL = 0,
		DRAW_TRANSPARENT = DRAWIMG_TRANSPARENT,
		DRAW_STRETCHED = DRAWIMG_STRETCHED,
		DRAW_CENTERED = DRAWIMG_CENTERED,
		DRAW_DISABLED = DRAWIMG_DISABLED,
		DRAW_GRAYSCALED = DRAWIMG_GRAYSCALED
	} DRAWFLAGS;
	#define DRAW_SPECIAL  (DRAW_GRAYSCALED | DRAW_DISABLED)

	BOOL SetFinalTransfer(BOOL bFinalTransfer)
	{
		BOOL b = m_bFinalTransfer;
		m_bFinalTransfer = bFinalTransfer;
		return b;
	};

	CMemDC* operator->() 
	{
		return this;
	};    

	operator CMemDC*() 
	{
		return this;
	};

	operator HDC() {return this->m_hDC;};

//	virtual CFont* SelectObject(CFont* pFont) { return CDC::SelectObject(pFont);};
//	CBitmap* SelectObject(CBitmap* pBitmap) { return CDC::SelectObject(pBitmap);};


	//////////////////
	// Get size (width, height) of bitmap.
	// extern fn works for ordinary CBitmap objects.
	//
	CSize GetBitmapSize(CBitmap* pBitmap)
	{
		BITMAP bm;
		return pBitmap->GetBitmap(&bm) ?
			CSize(bm.bmWidth, bm.bmHeight) : CSize(0,0);
	};

	BOOL DrawBitmap(CBitmap* pBitmap, CRect* rcDst, CRect* rcSrc, WORD flags=NULL)
	{ 
		// Compute rectangles where NULL specified
		CRect rc;
		if (!rcSrc) {
			// if no source rect, use whole bitmap
			rc = CRect(CPoint(0,0), GetBitmapSize(pBitmap));
			rcSrc = &rc;
		}
		if (!rcDst) {
			// if no destination rect, use source
			rcDst=rcSrc;
		}

		// Create memory DC
		CDC memdc;
		ASSERT(this->m_pDC != NULL);
		ASSERT(this->m_pDC->GetSafeHdc() != NULL);
		memdc.CreateCompatibleDC(m_pDC);
		CBitmap* pOldBm = memdc.SelectObject(pBitmap);

		// Blast bits from memory DC to target DC.
		// Use StretchBlt if size is different.
		//
		BOOL bRet = FALSE;
/*
		if (rcDst->Size()==rcSrc->Size()) {
			bRet = m_pDC->BitBlt(rcDst->left, rcDst->top, 
			rcDst->Width(), rcDst->Height(),
			&memdc, rcSrc->left, rcSrc->top, SRCCOPY);
		} else {
		m_pDC->SetStretchBltMode(COLORONCOLOR);
		bRet = m_pDC->StretchBlt(rcDst->left, rcDst->top, rcDst->Width(),
				rcDst->Height(), &memdc, rcSrc->left, rcSrc->top, rcSrc->Width(),
				rcSrc->Height(), SRCCOPY);
		}
*/
		if (rcDst->Size()==rcSrc->Size()) {
			bRet = BitBlt(rcDst->left, rcDst->top, 
			rcDst->Width(), rcDst->Height(),
			&memdc, rcSrc->left, rcSrc->top, SRCCOPY);
		} else {
		m_pDC->SetStretchBltMode(COLORONCOLOR);
		bRet = StretchBlt(rcDst->left, rcDst->top, rcDst->Width(),
				rcDst->Height(), &memdc, rcSrc->left, rcSrc->top, rcSrc->Width(),
				rcSrc->Height(), SRCCOPY);
		}
		memdc.SelectObject(pOldBm);

		return bRet;
	};


	BOOL DrawBitmap(CBitmap* pBitmap, CPoint* ptDst, CRect* rcSrc, WORD flags=NULL)
	{ 
		// Compute rectangles where NULL specified
		CRect rc;
		if (rcSrc == NULL) {
			// if no source rect, use whole bitmap
			rc = CRect(CPoint(0,0), GetBitmapSize(pBitmap));
			rcSrc = &rc;
		}
		CPoint	pt;
		if (!ptDst) {
			// if no destination rect, use source
			pt= CPoint(0,0);
		}
		else
			pt = *ptDst;
//		rc = CRect(pt.x, pt.y, pt.x+rcSrc->Width()-1, pt.y+rcSrc->Height()-1);
		CRect	rcDst = rcSrc;
		rcDst.OffsetRect(-rcDst.left, -rcDst.top);
		rcDst.OffsetRect(pt);
		// Create memory DC
		CDC memdc;
		memdc.CreateCompatibleDC(m_pDC);
		CBitmap* pOldBm = memdc.SelectObject(pBitmap);

		// Blast bits from memory DC to target DC.
		// Use StretchBlt if size is different.
		//
		BOOL bRet = FALSE;
			bRet = BitBlt(rcDst.left, rcDst.top, 
			rcDst.Width(), rcDst.Height(),
			&memdc, rcSrc->left, rcSrc->top, SRCCOPY);

		memdc.SelectObject(pOldBm);

		return bRet;
	};



	BOOL DrawTransparentBitmap (CBitmap* pBitmap, CPoint* ptDst, CRect* rcSrc, COLORREF clrTransparent)
	{
		ASSERT(pBitmap);
		ASSERT(pBitmap->GetSafeHandle());

		CBitmap*		pOldBm = NULL;	
		CRect rc;
		if (!rcSrc) {
			// if no source rect, use whole bitmap
			rc = CRect(CPoint(0,0), GetBitmapSize(pBitmap));
			rcSrc = &rc;
		}
		CRect rcDst;
		rcDst.CopyRect(rcSrc);
		if (ptDst != NULL) 
		{
			rcDst.OffsetRect(*ptDst);
		}

		CDC memdc;
		CBitmap bmpTmp;
		memdc.CreateCompatibleDC(m_pDC);
		pOldBm = memdc.SelectObject(pBitmap);
		if ( clrTransparent == CLR_DEFAULT )
			clrTransparent = memdc.GetPixel(0,0);

		BOOL bRet = FALSE;
		
		bRet = TransparentBlt(
					m_hDC,        // handle to destination DC
					rcDst.left,   // x-coord of destination upper-left corner
					rcDst.top,   // y-coord of destination upper-left corner
					rcDst.Width(),     // width of destination rectangle
					rcDst.Height(),    // height of destination rectangle
					memdc.m_hDC,         // handle to source DC
					rcSrc->left,    // x-coord of source upper-left corner
					rcSrc->top,    // y-coord of source upper-left corner
					rcSrc->Width(),      // width of source rectangle
					rcSrc->Height(),     // height of source rectangle
					clrTransparent  // color to make transparent
					);
		memdc.SelectObject(pOldBm);
		return bRet;
	};

	BOOL DrawTransparentBitmap (CBitmap* pBitmap, CPoint* ptDst, CRect* rcSrc)
	{
		return DrawTransparentBitmap(pBitmap, ptDst, rcSrc, CLR_DEFAULT);
	};


};

#endif
