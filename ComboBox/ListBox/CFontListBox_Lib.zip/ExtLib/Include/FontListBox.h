#if !defined(AFX_FONTLISTBOX_H__EB6A110F_8980_4705_A5D9_C767D646B3CC__INCLUDED_)
#define AFX_FONTLISTBOX_H__EB6A110F_8980_4705_A5D9_C767D646B3CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __cplusplus
	#error MFC requires C++ compilation (use a .cpp suffix)
#endif


#include "FontTipWnd.h"
#include "FontListManager.h"
#include <FontCtrlLib.h>

// FontListBox.h : header file
//

#ifndef FNTLB_HAS_TOOLTIPS
#define FNTLB_HAS_TOOLTIPS				0x00000001
#define FNTLB_TOOLTIPTEXT_FONT		0x00000002
#define FNTLB_TOOLTIPTEXT_SAMPLE		0x00000000
#define FNTLB_TOOLTIPSELECTED			0x00000004
#define FNTLB_GRAPHIC					0x00000100
#endif
#define FNTLB_TRACKING_TOOLTIP		0x00000200
#define FNTLB_MRULIST					0x00000400 
#define FNTLB_MRUGLOBALLIST			(0x00000800 | FNTLB_MRULIST)
#define FNTLB_MRUCUSTOMLIST			(0x00001000 | FNTLB_MRULIST)
#define FNTLB_NOTYPEIMAGE				0x00004000
#define FNTLB_ITEMHEIGHTEXPANDED		0x00008000
#define FNTLB_MANUAL						0x00010000

#define FNTLB_MRUSTYLE_MASK			(FNTLB_MRUGLOBALLIST | FNTLB_MRUCUSTOMLIST)

// used in the itemdata of the items		
#define FNTLB_MRU_FONT					0x100
#define FNTLB_SYMBOLFONT				0x200

// to limit the tooltip window height
#define FNTLB_TT_MAXITEMS_DEFAULT	10
#ifndef FNTLB_TT_MAXITEMS
#define FNTLB_TT_MAXITEMS	FNTLB_TT_MAXITEMS_DEFAULT
#endif

/* EnumFonts Masks */
#ifndef RASTER_FONTTYPE
#define RASTER_FONTTYPE			0x0001
#define DEVICE_FONTTYPE			0x0002
#define TRUETYPE_FONTTYPE		0x0004
#endif

// these are extra nFontType bits that are added to what is returned to the
// EnumFonts callback routine
#ifndef SIMULATED_FONTTYPE
#define SIMULATED_FONTTYPE    0x8000
#define PRINTER_FONTTYPE      0x4000
#define SCREEN_FONTTYPE       0x2000
#define BOLD_FONTTYPE         0x0100
#define ITALIC_FONTTYPE       0x0200
#define REGULAR_FONTTYPE      0x0400
#endif

#ifndef PS_OPENTYPE_FONTTYPE
#define PS_OPENTYPE_FONTTYPE  0x10000
#define TT_OPENTYPE_FONTTYPE  0x20000
#define TYPE1_FONTTYPE        0x40000
#endif

#define EX_TT_FONTTYPE_MASK = 0x70000


#define ON_WM_MOUSELEAVE() \
	{ WM_MOUSELEAVE, 0, 0, 0, AfxSig_vv, \
		(AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(void))&OnMouseLeave },
#define ON_WM_MOUSEENTER() \
	{ WM_MOUSEENTER, 0, 0, 0, AfxSig_vv, \
		(AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(void))&OnMouseEnter },
#define ON_WM_MOUSEHOVER() \
	{ WM_MOUSEHOVER, 0, 0, 0, AfxSig_vwp, \
(AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&OnMouseHover },


#include "Transparency.h"

/////////////////////////////////////////////////////////////////////////////
// CFontListBox window

class CFontListBox : public CListBox
{
// Construction
public:
	CFontListBox();
	CFontListBox(DWORD dwStyleFlags, LPCTSTR lpszMruListName=NULL);

// Attributes
public:

protected:
	DWORD					m_dwFlags;
	CFontTipWnd			m_wndTip;
//	UINT					m_TimerId;
	CFontMruList*		m_pMruList;
	CString				m_sMruListName;
	// Mouse tracking support
	BOOL					m_bTracking;
	HBITMAP				m_hBitmap;
	CSize					m_szBitmap;
	// transparency support
//	CFont					m_fontUI;

// Operations
public:
	DWORD	SetFlags(DWORD dwFlags);
	DWORD GetFlags();
	BOOL ModifyFlags(DWORD dwRemove, DWORD dwAdd);
	BOOL ModifyStyle( DWORD dwRemove, DWORD dwAdd, UINT nFlags = 0 );
	int GetFontCount();
	int GetMruFontCount();
	int GetDisplayedMruFontCount();
	int GetSelectedCount();
	int GetSelectedFontNames(CStringArray* pStrArray);
	int GetSelectedFontDescriptors(CFontDescriptorArray* lpArray);
   BOOL SetTopIndex(int Index);
	BOOL IsFontInList(CFontDescriptor* pFont);
	BOOL IsFontInList(LPCTSTR lpszFontName);
	BOOL IsFontInMruList(CFontDescriptor* pFont);
	BOOL IsFontInMruList(LPCTSTR lpszFontName);
	BOOL IsFontInDisplayedMruList(CFontDescriptor* pFont);
	BOOL IsFontInDisplayedMruList(LPCTSTR lpszFontName);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontListBox)
	public:
	virtual BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, DWORD dwExStyle = WS_EX_CLIENTEDGE);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL


// Implementation
public:
	BOOL HasMruList();
	virtual ~CFontListBox();
	BOOL SubclassDlgItem(UINT nID, CWnd* pParent);
	BOOL SubclassWindow(HWND hWnd);
	void SetSampleText(LPCTSTR lpszSampleText);
	CString& GetSampleText();
	BOOL AttachToMruFontList(LPCTSTR lpszMruListName);
	BOOL SetMruFontListName(LPCTSTR lpszMruListName);
	LPCTSTR GetMruFontListName();
	BOOL IsMruListPersistent();
	BOOL DetachFromMruFontList();
	BOOL AddFontsToMruList(LPCTSTR lpszFontName);
	BOOL AddFontsToMruList(CFontDescriptor* lpFont);
	int AddFontsToMruList(CStringArray* lpStrFaceNames);
	int AddFontsToMruList(CFontDescriptorArray* lpFontArray);
	int AddSelectedFontsToMruList();
	BOOL AddFontsToList(LPCTSTR lpszFontName);
	BOOL AddFontsToList(CFontDescriptor* lpFont);
	int AddFontsToList(CStringArray* lpStrFaceNames);
	int AddFontsToList(CFontDescriptorArray* lpFontArray);

	int RemoveFontsFromMruList(LPCTSTR lpStrFaceName);
	int RemoveFontsFromMruList(CFontDescriptor* lpFont);
	int RemoveFontsFromMruList(CStringArray* lpStrFaceNames);
	int RemoveFontsFromMruList(CFontDescriptorArray* lpFontArray);
	int RemoveSelectedFontsFromMruList();
	int RemoveFontsFromList(LPCTSTR lpStrFaceName);
	int RemoveFontsFromList(CFontDescriptor* lpFont);
	int RemoveFontsFromList(CStringArray* lpStrFaceNames);
	int RemoveFontsFromList(CFontDescriptorArray* lpFontArray);
	int RemoveSelectedFontsFromList();
	void ClearList();
	void Initialize();
	void Refresh();
	void RefreshMruList();
	void ClearMruList();
	const CString& GetCustomMruListName();
	virtual	int GetItemHeight(int nIndex);

	int GetTooltipMaxItems();
	int SetTooltipMaxItems(int nNbrMaxItems);
	int InitToolTipMaxItems() { return m_wndTip.SetMaxItems(FNTLB_TT_MAXITEMS);} ;

	int ClearSelection();
	BOOL SetImages(CBitmap* pBitmap);
	BOOL LoadImages(LPCTSTR lpszResourceName);
	BOOL LoadImages(UINT nIDResource);
	void SetStdImages();
	BOOL EnableMruListPersistence (BOOL bPersistence = TRUE);
	BOOL ReloadMruListSettings();
	BOOL SaveMruListSettings();	
	// these two functions allow filtering of displayed fonts
	// on both the true list and the mru list
	virtual BOOL OnAddItem(CFontDescriptor* lpFont);		// return TRUE
	virtual BOOL OnAddMruItem(CFontDescriptor* lpFont);	// return the result of OnAddItem
	virtual BOOL OnRemoveItem(CFontDescriptor* lpFont);		// return TRUE
	virtual BOOL OnRemoveMruItem(CFontDescriptor* lpFont);	// return the result of OnAddItem
	// Overriding these functions allow non standard colors
	virtual COLORREF OnColorHighlight();
	virtual COLORREF OnColorHighlightText();
	virtual COLORREF OnColorWindow();
	virtual COLORREF OnColorText();
	virtual COLORREF OnColorGrayText();
	virtual COLORREF OnColorMruSeparator();
	

protected:
	void SaveSelection(CStringArray& arFaceNames);
	void RestoreSelection(CStringArray& arFaceNames);
	void SaveMruSelection(CStringArray& arFaceNames);
	void RestoreMruSelection(CStringArray& arFaceNames);
	int FindFontInList(LPCTSTR lpszFaceName);
	int FindFontInMruList(LPCTSTR lpszFaceName);
	void UpdateMruList();
	int GetDisplayMruListCount();
	void SortFontNameArray(CStringArray& arFonts);
	int GetImageIndex(CFontDescriptor* pFont);
	void DrawMruSeparator(CDC* pDC, LPDRAWITEMSTRUCT lpDrawItemStruct);

	void UpdateToolTip(BOOL bSelectedChanged = FALSE);
	void RefreshToolTip(BOOL bOnWindow, BOOL bSelectedChanged = FALSE);
	virtual void DrawItemText(CDC* pDC, CRect& rcText, CString& strText, LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void DrawItemTextPart(CDC* pDC, CRect& rcText, CString& strText, LPDRAWITEMSTRUCT lpDrawItemStruct);
	void FillList();
	int CalcItemHeight();
	BOOL RecreateListBox(DWORD dwNewStyle, DWORD dwNewStyleEx = NULL, LPVOID lpParam = NULL);

	int AddString(LPCTSTR lpszItem);
	int AddString(LPCTSTR lpszItem, int iImg);
	int InsertString(int iIndex, LPCTSTR lpszItem);
	int InsertString(int iIndex, LPCTSTR lpszItem, int iImg);
	void SetItemImage(int iIndex, int iImg);

	COLORREF TranslateColor(COLORREF clr, COLORREF clrDefault);
	// Generated message map functions
protected:
	//{{AFX_MSG(CFontListBox)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSelChange();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnMove(int x, int y);
	//}}AFX_MSG
	virtual afx_msg void OnMouseLeave();
	virtual afx_msg void OnMouseEnter(UINT nFlags, CPoint point) {;};
	virtual afx_msg void OnMouseHover(UINT nFlags, CPoint point) {;};
	afx_msg void OnNotifyMruFontListChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnNotifyFontListChanged(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

// Transparency support
	afx_msg int OnUpdateBkgnd(CDC* pDC, UINT bModified);
	DECLARE_TRANSPARENCY()
	BOOL SetBkgnd(CDC* pDC);
	void PaintBkgnd(CDC* pDC, LPCRECT lpRect = NULL);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FONTLISTBOX_H__EB6A110F_8980_4705_A5D9_C767D646B3CC__INCLUDED_)
