///////////////////////////////////////////////////////////////////////////////
// ExacT Soft (tm) 2001														 //
// Author: Vsevolod Gromov email: gromov@eti.co.ru; site: www.ambap.narod.ru //
// CMemBitmap class. implements memory bitmap, is able to copy part of source	 //
// bitmap to MemBm, or copy source DC contents to MemBm (screen capture)	 //
// use _WIN32_WINDOWS for conditional compiles (necessary for proper Brush	 //
// origin adjustment operations	and proper transparent draw calls			 //
///////////////////////////////////////////////////////////////////////////////
#pragma once


//{ memory bitmap class CMemBitmap
class CMemBitmap
{
public:
	enum MBColors {
		MBC_COLOR =              0x00000000,
		MBC_COLOR4 =             0x00000004,
		MBC_COLOR8 =             0x00000008,
		MBC_COLOR16 =            0x00000010,
		MBC_COLOR24 =            0x00000018,
		MBC_COLOR32 =            0x00000020
	};
	// create memory bitmap from source bitmap.
	// !REMEMBER! hbmSrc MUST NOT be selected into any DC before calling this function
	// or following will just create copy of hDC contents, not the hbmSrc.
	bool Create(HDC hDC, HBITMAP hbmSrc, int iLeft, int iTop,
		int iWidth, int iHeight, DWORD dwRop = SRCCOPY );
	// create memory bitmap from explicit data (default is monochrome bitmap)
	bool Create( HDC hDC, int iWidth, int iHeight,
		UINT cPlanes = 1, UINT cBitsPerPel = 1, const void *lpvBits = NULL );
	//copy creation
	bool Create( const CMemBitmap& bmSrc, DWORD dwRop = SRCCOPY );
	//create from bitmap resource by name
	bool Create( HINSTANCE hInst, LPCTSTR pszName );
	//create from bitmap resource by ID
	bool Create( HINSTANCE hInst, UINT nID ){ return Create( hInst, MAKEINTRESOURCE(nID) ); };

	bool Create(CDC* pDC, HBITMAP hbmSrc, int iLeft, int iTop, int iWidth, int iHeight, DWORD dwRop );
	bool Create(CDC* pDC, CBitmap& bmp, int iLeft, int iTop, int iWidth, int iHeight, DWORD dwRop );

	bool Create ( HDC hDC, int iWidth, int iHeight, MBColors nFlags = MBC_COLOR4)
	{
		UINT cPlanes = 1;
		UINT cBitsPerPel = 1;
		Initialize();
		switch (nFlags)
		{
		case MBC_COLOR32:	cBitsPerPel = 32; break;
		case MBC_COLOR24:	cBitsPerPel = 24;  break;
		case MBC_COLOR4:	cBitsPerPel = 4;  break;
		case MBC_COLOR8:	cBitsPerPel = 8;  break;
		case MBC_COLOR16:	cBitsPerPel = 16;  break;
		}
		return Create( hDC, iWidth, iHeight, cPlanes, cBitsPerPel, NULL );
	};

	BOOL SafeBitmap(CBitmap* pbm)
	{
		BITMAP	bm;
		ZeroMemory(&bm, sizeof(BITMAP));
		pbm->CreateBitmapIndirect(&bm);
		pbm->SetBitmapBits(bm.bmWidthBytes*bm.bmHeight, bm.bmBits);
		return TRUE;
	}
	// default constructor
	CMemBitmap(){ Initialize(); };
	// inplace constructor
	CMemBitmap(HDC hDC, HBITMAP hbmSrc, int iLeft, int iTop,
		int iWidth, int iHeight, DWORD dwRop = SRCCOPY )
	{
		Initialize();
		Create(hDC, hbmSrc, iLeft, iTop, iWidth, iHeight, dwRop);
	};
	CMemBitmap(CDC* pDC, HBITMAP hbmSrc, int iLeft, int iTop,
		int iWidth, int iHeight, DWORD dwRop = SRCCOPY )
	{
		Initialize();
		if (pDC != NULL)
			Create(pDC->m_hDC, hbmSrc, iLeft, iTop, iWidth, iHeight, dwRop);
		else
			Create(pDC->m_hDC, hbmSrc, iLeft, iTop, iWidth, iHeight, dwRop);
	};
	 
	//copy constructor
	CMemBitmap( const CMemBitmap& bmSrc, DWORD dwRop = SRCCOPY )
	{
		Initialize();
		Create(bmSrc, dwRop);
	};
	// create memory bitmap from explicit data (default is monochrome bitmap)
	CMemBitmap( HDC hDC, int iWidth, int iHeight,
			UINT cPlanes = 1, UINT cBitsPerPel = 1, const void *lpvBits = NULL )
	{
		Initialize();
		Create( hDC, iWidth, iHeight, cPlanes, cBitsPerPel, lpvBits );
	};
	CMemBitmap( HDC hDC, int iWidth, int iHeight, MBColors nFlags = MBC_COLOR4)
	{
		UINT cPlanes = 1;
		UINT cBitsPerPel = 1;
		Initialize();
		switch (nFlags)
		{
		case MBC_COLOR32:	cBitsPerPel = 32; break;
		case MBC_COLOR24:	cBitsPerPel = 24;  break;
		case MBC_COLOR4:	cBitsPerPel = 4;  break;
		case MBC_COLOR8:	cBitsPerPel = 8;  break;
		case MBC_COLOR16:	cBitsPerPel = 16;  break;
		}
		Create( hDC, iWidth, iHeight, cPlanes, cBitsPerPel, NULL );
	};

	CMemBitmap( CDC* pDC, int iWidth, int iHeight, MBColors nFlags)
	{
		HDC	hdc = NULL;
		Initialize();
		if (pDC != NULL)
			hdc = pDC->m_hDC;
		Create( hdc, iWidth, iHeight, nFlags);
	};

	CMemBitmap( CDC* pDC, int iWidth, int iHeight,
			UINT cPlanes = 1, UINT cBitsPerPel = 1, const void *lpvBits = NULL )
	{
		HDC	hdc = NULL;
		Initialize();
		if (pDC != NULL)
			hdc = pDC->m_hDC;
		Create( hdc, iWidth, iHeight, cPlanes, cBitsPerPel, lpvBits );
	};

	CMemBitmap( CWnd* pWnd, int iWidth, int iHeight,
			UINT cPlanes = 1, UINT cBitsPerPel = 1, const void *lpvBits = NULL )
	{
		HDC	hdc = NULL;
		Initialize();
		CClientDC ccDC(pWnd);
		hdc = ccDC.m_hDC;
		Create( hdc, iWidth, iHeight, cPlanes, cBitsPerPel, lpvBits );
	};

	//construct from resource by name
	CMemBitmap( HINSTANCE hInst, LPCTSTR pszName )
	{
		Initialize();
		Create(hInst, pszName);
	};
	//construct from resource by ID
	CMemBitmap( HINSTANCE hInst, UINT nID )
	{
		Initialize();
		Create(hInst, nID);
	};

	bool CreateCompatible(CDC* pDC, int iWidth, int iHeight);
	bool CreateCompatible(HDC hDC, int iWidth, int iHeight);

	virtual ~CMemBitmap(){	Cleanup();	};

public:
	//cleanup object data
	void Cleanup();
	//get bitmap width
	int GetWidth(void) const;
	//get bitmap height
	int GetHeight(void) const;
	// get bits per pixel for our bitmap
	int GetBpp(void);
	// get color planes for our bitmap
	int GetPlanes(void);
	//return our memory dc with bitmap selected in it
	//(Blt operations - ready)
	operator HDC() const { return m_hdcImg; };
	operator CDC*() { return &m_dcImg; };

	operator HBITMAP() const { return m_hbmImg; };
	operator CBitmap*() {return &m_bmImg;}

	CBitmap* FreeBitmap() {
		if (m_hbmImg != NULL) {
			if (m_bUnlockedBitmap)
				return m_pbmOld;
			else
			{
				m_dcImg.SelectObject(m_pbmOld);
				m_bUnlockedBitmap = TRUE;
				return &m_bmImg;
			}
		}
		return NULL;
	}
	BOOL LockBitmap() {
		if (m_hbmImg != NULL) {
			if (!m_bUnlockedBitmap)
				return TRUE;
			else
			{
				m_pbmOld = (CBitmap*)m_dcImg.SelectObject(m_bmImg);
				m_bUnlockedBitmap = FALSE;
				return TRUE;
			}
		}
		return FALSE;
	}
	//boolean validation operator !
	bool operator !(){ return !m_bCreated; };
	//perform pattern fill, adjusting brush origin if neccessary
	void Fill( HDC hDC, int iLeft, int iTop, int iWidth, int iHeight,
		bool bAdjustBrushOrg = false, DWORD dwRop = PATCOPY );
	void Fill( CDC* pDC, int iLeft, int iTop, int iWidth, int iHeight,
		bool bAdjustBrushOrg = false, DWORD dwRop = PATCOPY );
	//do 1-to-1 draw
	void Draw( CDC* pDC, int iLeft, int iTop, DWORD dwRop );
	void Draw( HDC hDC, int iLeft, int iTop, DWORD dwRop = SRCCOPY );
	//perform draw (simple or stretched)
	void Draw( HDC hDC, int iLeft, int iTop, int iWidth, int iHeight,
		DWORD dwRop = SRCCOPY, int iStretchMode = COLORONCOLOR );
	void Draw( CDC* pDC, int iLeft, int iTop, int iWidth, int iHeight,
		DWORD dwRop = SRCCOPY, int iStretchMode = COLORONCOLOR );
	//do transparent drawing using WinAPI or program emulated code
	void DrawTransparent( HDC hDC, int iLeft, int iTop, int iWidth, int iHeight,
				COLORREF crTransparent );
	//do alpha blending draw (works only when _WIN32_WINDOWS > 0x0400 else do nothing)
	void DrawAlpha( HDC hDC, int iLeft, int iTop, int iWidth, int iHeight,
		const BLENDFUNCTION& blendFunc );

//data members
protected:
	HANDLE	m_hbmOld;
	CBitmap*	m_pbmOld;
	HBITMAP m_hbmImg;
	CBitmap m_bmImg;
	HDC		m_hdcImg;
	CDC		m_dcImg;

	//bitmap dimensions
	int		m_iWidth;
	int		m_iHeight;
	// number of color planes in our bitmap
	int		m_iPlanes;
	// bits per pixel in our bitmap
	int		m_iBpp;
	//"object created" flag
	bool	m_bCreated;

	bool	m_bUnlockedBitmap;
	//reset data members to 0
	void Initialize(){	m_hbmOld = m_hbmImg = NULL;
		m_hdcImg = NULL; m_iWidth = m_iHeight = 0;
		m_iPlanes = m_iBpp = 0; m_bCreated = false; m_bUnlockedBitmap=false;};
	//stretching required
	bool RequireStretch( int iWidth, int iHeight )
	{ return (bool)( (m_iWidth != iWidth) || (m_iHeight != iHeight) ); };
};
	
//} memory bitmap class CMemBitmap
