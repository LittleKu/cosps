
/////////////////////////////////////////////////////////////////////////////
// Win32 libraries

#ifndef __FontCtrl_H__
#define __FontCtrl_H__

#ifndef _AFXDLL
	#ifndef _UNICODE
		#ifdef _DEBUG
			#pragma comment(lib, "FontCtrlnwd.lib")
		#else
			#pragma comment(lib, "FontCtrlnw.lib")
		#endif
	#else
		#ifdef _DEBUG
			#pragma comment(lib, "FontCtrluwd.lib")
		#else
			#pragma comment(lib, "FontCtrluw.lib")
		#endif
	#endif
#else
	#ifndef _UNICODE
		#ifdef _DEBUG
			#pragma comment(lib, "FontCtrld.lib")
		#else
			#pragma comment(lib, "FontCtrl.lib")
		#endif
	#else
		#ifdef _DEBUG
			#pragma comment(lib, "FontCtrlud.lib")
		#else
			#pragma comment(lib, "FontCtrlu.lib")
		#endif
	#endif
#endif

// needed in stdafx.h :
// #include <activscp.h>		// Active Scripting Interfaces
// #include <afxctl.h>			// For Event Map things


#endif	// __FontCtrl_H__