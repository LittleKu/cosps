// FontTipWnd.cpp : implementation file
//

#include "stdafx.h"
#include "FontListBox.h"
#include "FontTipWnd.h"
#include "MemDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define FNTLB_TT_MOREFONTS		_T("...  More selected fonts  ...")

/////////////////////////////////////////////////////////////////////////////
// CFontTipWnd

CFontTipWnd::CFontTipWnd()
{
	m_strSample = _T("abcdeABCDE");
	m_fPrevFlags = NULL;
	m_nMaxItems = FNTLB_TT_MAXITEMS;
	m_pCurrentFont = NULL;
}

CFontTipWnd::~CFontTipWnd()
{
}


BEGIN_MESSAGE_MAP(CFontTipWnd, CWnd)
	//{{AFX_MSG_MAP(CFontTipWnd)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CFontTipWnd::Create(CWnd* pParent)
{
	return 	CWnd::CreateEx(WS_EX_TOOLWINDOW,
		AfxRegisterWndClass(0),
		NULL,
		WS_BORDER|WS_POPUP,
		0,
		0,0,0,
		NULL,
		(HMENU)0);
}

/////////////////////////////////////////////////////////////////////////////
// CFontTipWnd message handlers

BOOL CFontTipWnd::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CFontTipWnd::SetSampleText(LPCTSTR lpszSampleText)
{
	m_strSample = lpszSampleText;
}
CString& CFontTipWnd::GetSampleText()
{
	return m_strSample;
}

void CFontTipWnd::ShowTips(CPoint pt,const CString& str, BOOL bSelectedChanged)
{
	CDC* pDC = GetDC();
	if (m_strFont != str || bSelectedChanged || m_fPrevFlags != m_dwFlags)
	{
		m_strFont = str;
		m_pCurrentFont = AfxGetFontList()->GetDescriptor(m_strFont);
		// get the rectangle
		CRect rcWnd = CRect (0,0,0,0);
		
		DrawItems (pDC, &rcWnd, DT_CALCRECT);
		SetWindowPos(0, pt.x, pt.y, rcWnd.Width(), rcWnd.Height(), SWP_NOCOPYBITS | SWP_SHOWWINDOW | SWP_NOACTIVATE);
		RedrawWindow(); // Force immediate redraw
	}
	else
		ShowWindow(SW_SHOWNOACTIVATE);
	m_fPrevFlags = m_dwFlags;
	ReleaseDC(pDC);
}



void CFontTipWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect rc;
	GetClientRect(rc);
	CBrush brBkGnd;

	CMemDC dcMem(&dc, rc);
	brBkGnd.CreateSolidBrush(::GetSysColor(COLOR_INFOBK));
	rc.InflateRect(0,0,1,1);
	dcMem.FillRect(rc, &brBkGnd);
	rc.DeflateRect(0,0,1,1);
	dcMem.SetBkColor(::GetSysColor(COLOR_INFOBK));
	dcMem.SetTextColor(::GetSysColor(COLOR_INFOTEXT));
	DrawItems (&dcMem, NULL, NULL);
}

int CFontTipWnd::DrawItemTextPart (CDC* pDC, CRect& rc, LPCTSTR lpText, DWORD flags)
{
	pDC->DrawText(lpText, -1, &rc, (flags & DT_CALCRECT ? NULL : DT_VCENTER) | DT_SINGLELINE | flags);
	return 0;
}

int CFontTipWnd::DrawItemText (CDC* pDC, CRect& rc, CFontDescriptor* pFont, DWORD flags, BOOL bGraphic)
{
	CFont*	pOldFont = pDC->GetCurrentFont();
	CString	str1;
	CString	str2;
	CRect		rc1;
	CRect		rc2;
	rc1.CopyRect(&rc);
	if (bGraphic)
	{
		if (m_dwFlags & FNTLB_TOOLTIPTEXT_FONT)
			str1 = str2 = pFont->m_strFaceName;
		else
			str1 = str2 = m_strSample;
		// if we have a symbol font, first display the font name
		// (a priori, not readable)
		if (pFont->m_dwCharSets == SYMBOL_CHARSET)
		{
			str1 = pFont->m_strFaceName;
			pDC->SelectObject(&m_fontUI);
		}
		else
			pDC->SelectObject(pFont->GetFontObject());

		DrawItemTextPart(pDC,rc,str1,flags);
		// if we effectively draw the text on the DC, and in case of symbol fonts
		// we need to calculate the position of the graphic part of the text
		if (!(flags & DT_CALCRECT))
		{
			if (pFont->m_dwCharSets == SYMBOL_CHARSET)
			{
				rc1.right = 1;
				DrawItemTextPart(pDC,rc1,str1,DT_CALCRECT);
			}
		}
		// if it's a Symbol font, now draw the text using the font
		if (pFont->m_dwCharSets == SYMBOL_CHARSET)
		{
			if (flags & DT_CALCRECT)
				rc2 = CRect(0,0,1,1);
			else
			{
				rc2.CopyRect(&rc);
				rc2.left = rc1.right + DEFAULT_FONTTIP_XMARGIN + 1;
			}
			pDC->SelectObject(pFont->GetFontObject());
			DrawItemTextPart (pDC, rc2, str2, flags);
			if (flags & DT_CALCRECT)
			{
				rc.right += rc2.Width() + DEFAULT_FONTTIP_XMARGIN;
				if (rc2.bottom > rc.bottom)
					rc.bottom = rc2.bottom;
			}
		}
	}
	else
	{
		if (m_dwFlags & FNTLB_TOOLTIPTEXT_FONT)
			 str1 = pFont->m_strFaceName;
		else
			str1 = m_strSample;
		pDC->SelectObject(&m_fontUI);
		if (flags & DT_CALCRECT)
			CRect rc(0,0,1,1);
		DrawItemTextPart(pDC,rc,str1,flags);
	}

	pDC->SelectObject(pOldFont);
	return 0;
}

int CFontTipWnd::DrawItems (CDC* pDC, LPRECT lpRect, DWORD flags)
{
	// create a normal text font, if needed
	if (m_fontUI.GetSafeHandle() == NULL)
	{
		CFont fnt;
		fnt.CreateStockObject(DEFAULT_GUI_FONT);
		LOGFONT lf;
		fnt.GetLogFont(&lf);
		lf.lfWeight = FW_NORMAL;
		m_fontUI.CreateFontIndirect(&lf);
	}
	// Get the tooltip rectangle
	CRect	rcItem;
	CRect	rcItems (0,0,1,1);
	if (flags & DT_CALCRECT)
	{
		m_bShowCurrent = (BOOL)((m_dwFlags & FNTLB_TRACKING_TOOLTIP) && m_pCurrentFont != NULL);
		m_bShowSelected = (m_dwFlags & FNTLB_TOOLTIPSELECTED);
		// the tooltip drawing mode (text or graphic) is the inverse one
		// of the listbox
		m_bShowCurrentGraphic = (BOOL) ! (m_dwFlags & FNTLB_GRAPHIC);
		m_bShowSelectedGraphic = m_bShowCurrentGraphic;
		m_nSelected = m_arSelectedFonts.GetSize();
		m_itemRect = CRect(0,0,1,1);
		m_bShowSelected = m_bShowSelected && (m_nSelected > 0);
		if (m_bShowCurrent)
		{
			rcItem = CRect(0,0,1,1);
			DrawItemText (pDC, rcItem, m_pCurrentFont, flags, m_bShowCurrentGraphic);
			m_itemRect.CopyRect(&rcItem);
		}
		if (m_bShowSelected)
		{
			m_nSelected = m_arSelectedFonts.GetSize();
			m_bOverMaxItems = FALSE;
			int nItems = m_nSelected;
			if (nItems > m_nMaxItems)
			{
				nItems = m_nMaxItems;
				m_bOverMaxItems = TRUE;
			}
			for (int i=0; i<nItems; i++)
			{
				rcItem = CRect(0,0,1,1);
				DrawItemText (pDC, rcItem, m_arSelectedFonts[i], flags, m_bShowSelectedGraphic);
				if (rcItem.right > m_itemRect.right)
					m_itemRect.right = rcItem.right;
				if (rcItem.bottom > m_itemRect.bottom)
					m_itemRect.bottom = rcItem.bottom;
			}
			// limit the tooltip height
			if (m_bOverMaxItems)
			{
				// just add the place for the "more .." text
				rcItem = CRect(0,0,1,1);
				CFont* pOldFont = pDC->SelectObject(&m_fontUI);
				pDC->DrawText(FNTLB_TT_MOREFONTS, rcItem, flags);
				if (rcItem.right > m_itemRect.right)
					m_itemRect.right = rcItem.right;
				if (rcItem.bottom > m_itemRect.bottom)
					m_itemRect.bottom = rcItem.bottom;
				pDC->SelectObject(pOldFont);
				m_bOverMaxItems = TRUE;
			}
		}
		else
			m_nSelected = 0;
		m_bSeparator = FALSE;
		if (m_bShowCurrent && m_bShowSelected)
			m_bSeparator = TRUE;
		// here we have the max rectangle needed to display a font
		// now, it's time to get the tooltip rectangle size
		int nSelItems = m_nSelected;
		if (nSelItems > m_nMaxItems)
			nSelItems = m_nMaxItems + 1;	// "+1" for the "More ..."
		lpRect->right = lpRect->left + m_itemRect.Width() + (2*FONTTIP_XMARGIN) + 1;
		lpRect->bottom = (m_itemRect.Height() * ((m_bShowCurrent?1:0) + nSelItems)) +
			(m_bSeparator?(1+(FONTTIP_SEPMARGIN * 2)) : 0) + (2*FONTTIP_YMARGIN) + 1;
		// setup first item rectangle
		m_itemRect.OffsetRect(FONTTIP_XMARGIN, FONTTIP_YMARGIN);
	}
	// Draw Items on DC
	else
	{
		m_nSelected = m_arSelectedFonts.GetSize();
		rcItem.CopyRect(&m_itemRect);
		if (m_bShowCurrent)
		{
			DrawItemText (pDC, rcItem, m_pCurrentFont, NULL, m_bShowCurrentGraphic);
			rcItem.OffsetRect(0, m_itemRect.Height());
		}
		// draw the separator
		if (m_bSeparator)
		{
			CPoint	pt(0,rcItem.top + FONTTIP_SEPMARGIN + 1);
			pDC->MoveTo(pt);
			pDC->LineTo(rcItem.Width() + (2*FONTTIP_XMARGIN) + 1 , pt.y);
			rcItem.OffsetRect(0, (2 * FONTTIP_SEPMARGIN) + 1);
		}
		// draw the selected items
		if (m_bShowSelected)
		{
			int nItems = m_nSelected;
			if (m_bOverMaxItems)
				nItems = m_nMaxItems;
			for (int i=0; i<nItems; i++)
			{
				DrawItemText (pDC, rcItem, m_arSelectedFonts[i], NULL, m_bShowSelectedGraphic);
				rcItem.OffsetRect(0, m_itemRect.Height());
			}
			if (m_bOverMaxItems)
			{
				CFont* pOldFont = pDC->SelectObject(&m_fontUI);
				pDC->DrawText(FNTLB_TT_MOREFONTS, rcItem, flags);
				pDC->SelectObject(pOldFont);
			}
		}
	}
	return 0;
}



BOOL CFontTipWnd::ModifyFlags(DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwNewFlags = (m_dwFlags & ~dwRemove) | dwAdd;
	if (m_dwFlags == dwNewFlags)
		return FALSE;
	return TRUE;
}

DWORD	CFontTipWnd::SetFlags(DWORD dwFlags)
{
	DWORD dwOldFlags = m_dwFlags;
	m_dwFlags = dwFlags;
	return dwOldFlags;
}

DWORD CFontTipWnd::GetFlags()
{
	return m_dwFlags;
}

int CFontTipWnd::SetMaxItems(int nNbrMaxItems)
{
	ASSERT (nNbrMaxItems > 0);
	int nOld = m_nMaxItems;
	m_nMaxItems = nNbrMaxItems;
	// update the tooltip
	return nOld;
}
