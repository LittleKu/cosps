// FontListSysWnd.cpp : implementation file
//

#include "stdafx.h"
#include "FontListSysWnd.h"
#include "FontListManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CFontListManager _afxFontListManager;

/////////////////////////////////////////////////////////////////////////////
// CFontListSysWnd

CFontListSysWnd::CFontListSysWnd()
{
}

CFontListSysWnd::~CFontListSysWnd()
{
}


BEGIN_MESSAGE_MAP(CFontListSysWnd, CWnd)
	//{{AFX_MSG_MAP(CFontListSysWnd)
	ON_WM_FONTCHANGE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFontListSysWnd message handlers

void CFontListSysWnd::OnFontChange() 
{
	CWnd::OnFontChange();
	m_pListManager->OnFontChange();
}
