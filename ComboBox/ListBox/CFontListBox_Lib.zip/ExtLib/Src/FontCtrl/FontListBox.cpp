// FontListBox.cpp : implementation file
//

#include "stdafx.h"
#include "FontListBox.h"
#include <MemDC.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Msimg32.dll
#pragma comment(lib, "Msimg32.lib")

#define GetFontDescriptor(name)  \
	AfxGetFontListRef().GetDescriptor((name))
#define AttachMruFontList(name)  \
	AfxGetFontListRef().AttachMruFontList(this, (LPCTSTR)(name))
#define DetachMruFontList()  \
	AfxGetFontListRef().DetachMruFontList(this)
#define GetMruFontList()  \
	AfxGetFontListRef().GetMruFontList(this)
/*
#define ClearMruFontList()  \
	AfxGetFontListRef().ClearMruFontList(this)
*/
/////////////////////////////////////////////////////////////////////////////
// CFontListBox

CFontListBox::CFontListBox()
{
	m_dwFlags = NULL;
	m_pMruList = NULL;
	m_bTracking = FALSE;
	m_bkModified = TRUE;
}

CFontListBox::CFontListBox(DWORD dwStyleFlags, LPCTSTR lpszMruListName)
{
	m_dwFlags = dwStyleFlags;
	m_pMruList = NULL;
	AttachToMruFontList(lpszMruListName);
	m_bTracking = FALSE;
}

CFontListBox::~CFontListBox()
{
	if (m_pMruList != NULL)
	{
		DetachMruFontList();
		m_pMruList = NULL;
	}
	if (m_hBitmap != AfxGetFontTypeBitmap())
		::DeleteObject(m_hBitmap);
}


BEGIN_MESSAGE_MAP(CFontListBox, CListBox)
	//{{AFX_MSG_MAP(CFontListBox)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SHOWWINDOW()
	ON_WM_MOUSEMOVE()
	ON_CONTROL_REFLECT_EX(LBN_SELCHANGE, OnSelChange)
	ON_WM_MOUSEWHEEL()
	ON_WM_VSCROLL()
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	ON_WM_MOVE()
	//}}AFX_MSG_MAP
	ON_WM_MOUSELEAVE()
	ON_WM_MOUSEHOVER()
	ON_MESSAGE(WM_FONTMRUCHANGENOTIFICATION, OnNotifyMruFontListChanged)
	ON_MESSAGE(WM_FONTCHANGENOTIFICATION, OnNotifyFontListChanged)
	ON_WM_UPDATEBKGND()

END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CFontListBox message handlers

int CFontListBox::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListBox::OnCreate(lpCreateStruct) == -1)
		return -1;
	CWnd* pParent = GetParent();
	if (pParent)
		SetFont(pParent->GetFont());
	// create the window for the WM_FONCHANGE broadcasted message
	AfxGetFontList()->Init();
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CFontListBox functions

void CFontListBox::Initialize()
{
	m_hBitmap = AfxGetFontTypeBitmap();

	ASSERT(m_hBitmap != NULL);
	m_szBitmap = CSize(FNTLB_IMG_XSIZE, FNTLB_IMG_YSIZE);
	FillList();
	InitToolTipMaxItems();
}

void CFontListBox::FillList()
{
	if (m_dwFlags & FNTLB_MANUAL)
		return;
	SetRedraw(FALSE);
	InitStorage(300,LF_FACESIZE);
	CFontListManager* pFL = AfxGetFontList();
	int iImage = 0;
	for (int i=0; i<pFL->GetCount(); i++)
	{
		CFontDescriptor* pFD = pFL->GetDescriptor(i);
		if (OnAddItem(pFD))
		{
			iImage = pFD->m_nImage;
			DWORD dwItemData = (DWORD)(iImage & 0xFF);
			if (pFD->m_dwCharSets == SYMBOL_CHARSET)
				dwItemData |= FNTLB_SYMBOLFONT;
			AddString(pFD->m_strFaceName, dwItemData); 
		}
	}
	SetItemHeight(0, CalcItemHeight());
	SetRedraw(TRUE);
}
void CFontListBox::SetSampleText(LPCTSTR lpszSampleText)
{
	m_wndTip.SetSampleText(lpszSampleText);
}

CString& CFontListBox::GetSampleText()
{
	return m_wndTip.GetSampleText();
}

BOOL CFontListBox::PreCreateWindow(CREATESTRUCT& cs) 
{
	DWORD dwNewStyle = cs.style | WS_CHILD | WS_VISIBLE | LBS_HASSTRINGS;
	dwNewStyle = (dwNewStyle & ~(LBS_MULTICOLUMN | LBS_OWNERDRAWVARIABLE | LBS_NODATA)) | 
		(LBS_HASSTRINGS | LBS_OWNERDRAWFIXED | WS_VSCROLL);
	cs.style = dwNewStyle;
	int nItemHeight = CalcItemHeight();

	return CListBox::PreCreateWindow(cs);
}

BOOL CFontListBox::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, DWORD dwExStyle) 
{
/*
	// TODO: Add your specialized code here and/or call the base class
	INITCOMMONCONTROLSEX icex;

	// Ensure that the common control DLL is loaded. 
	icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icex.dwICC  = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&icex); 
	dwStyle |= LVS_OWNERDRAWFIXED | WS_CHILD | WS_VISIBLE | LVS_SHAREIMAGELISTS | LVS_NOCOLUMNHEADER | LVS_REPORT | LVS_SORTASCENDING | LVS_SINGLESEL;
	
	// allow modification of several common create parameters
	CREATESTRUCT cs;
	cs.dwExStyle = NULL;
	cs.lpszClass = lpszClassName;
	cs.lpszName = lpszWindowName;
	cs.style = dwStyle;
	cs.x = rect.left;
	cs.y = rect.top;
	cs.cx = rect.right - rect.left + 1;
	cs.cy = rect.bottom - rect.top + 1;
	cs.hwndParent = pParentWnd->GetSafeHwnd();
	cs.hMenu = NULL;
	cs.hInstance = AfxGetInstanceHandle();
	cs.lpCreateParams = NULL;

	if (!PreCreateWindow(cs))
	{
		PostNcDestroy();
		return FALSE;
	}
*/
//	return CImageListBox::Create(dwStyle, rect, pParentWnd, nID);
	dwStyle = (dwStyle & ~(LBS_SORT | LBS_MULTICOLUMN | LBS_OWNERDRAWFIXED)) | 
			(LBS_HASSTRINGS | LBS_OWNERDRAWVARIABLE | WS_VSCROLL);
	BOOL bResCreate = CWnd::CreateEx(dwExStyle, _T("LISTBOX"), NULL, dwStyle, rect,  pParentWnd, nID, NULL);

//	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	return bResCreate;
}


void CFontListBox::PreSubclassWindow() 
{
	CListBox::PreSubclassWindow();
	SetFlags(m_dwFlags);
}

BOOL CFontListBox::SubclassDlgItem(UINT nID, CWnd* pParent)
{
	// create the window for the WM_FONCHANGE broadcasted message
	AfxGetFontList()->Init();

	BOOL bRet = CListBox::SubclassDlgItem(nID, pParent);

	if (bRet)
	{
		DWORD dwNewStyle = (GetStyle() & ~(LBS_SORT | LBS_MULTICOLUMN | LBS_OWNERDRAWFIXED)) | 
			(LBS_HASSTRINGS | LBS_OWNERDRAWVARIABLE | WS_VSCROLL);
		ASSERT ((dwNewStyle & LBS_OWNERDRAWFIXED) == 0);
		ASSERT ((dwNewStyle & LBS_OWNERDRAWVARIABLE) != 0);
		if (dwNewStyle != GetStyle())
			RecreateListBox(dwNewStyle);
	}

	SetItemHeight(0, CalcItemHeight());

	return bRet;
}

BOOL CFontListBox::SubclassWindow(HWND hWnd)
{
	BOOL bRet = CListBox::SubclassWindow(hWnd);
	if (bRet)
	{
		DWORD dwNewStyle = (GetStyle() & ~(LBS_MULTICOLUMN)) | 
			(LBS_HASSTRINGS | LBS_OWNERDRAWFIXED | WS_VSCROLL);
		RecreateListBox(dwNewStyle);
	}
	return bRet;
}

///////////////////////////////////////////////////////////

int CFontListBox::CalcItemHeight()
{
	int height;
	CWindowDC dc(NULL);
	TEXTMETRIC tm;
	dc.GetTextMetrics(&tm);
	height = tm.tmHeight - tm.tmInternalLeading;	// as font dialog box
	if ( (m_dwFlags & FNTLB_MRUSTYLE_MASK) || (m_dwFlags & FNTLB_GRAPHIC) || (m_dwFlags & FNTLB_ITEMHEIGHTEXPANDED))
		height += tm.tmInternalLeading;	// as combobox
	return height;
}

void CFontListBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	lpMeasureItemStruct->itemHeight = CalcItemHeight();
}

BOOL CFontListBox::ModifyFlags(DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwOldFlags = m_dwFlags;
	DWORD dwNewFlags = (m_dwFlags & ~dwRemove) | dwAdd;
	if (dwNewFlags == dwOldFlags)
		return FALSE;
	SetFlags(dwNewFlags);
	return TRUE;
}

BOOL CFontListBox::ModifyStyle( DWORD dwRemove, DWORD dwAdd, UINT nFlags)
{
	DWORD dwOldStyle = GetStyle();
	DWORD dwNewStyle = (dwOldStyle & ~dwRemove) | dwAdd;
	dwNewStyle = (dwNewStyle & ~(LBS_MULTICOLUMN | LBS_OWNERDRAWVARIABLE)) | 
		(LBS_HASSTRINGS | LBS_OWNERDRAWFIXED | WS_VSCROLL);
	if (dwNewStyle == (dwOldStyle | WS_VSCROLL))
		return FALSE;
	// need to recreate the listbox
	RecreateListBox(dwNewStyle);
	RedrawWindow();
	UpdateToolTip(TRUE);
	return TRUE;
}

// recreate the list box by copying styles etc, and list items
// and applying them to a newly created control
BOOL CFontListBox::RecreateListBox(DWORD dwNewStyle, DWORD dwNewStyleEx, LPVOID lpParam)
{
	CWaitCursor wc; 
	if (GetSafeHwnd() == NULL)
		return FALSE;

	CWnd* pParent = GetParent();
	if (pParent == NULL)
		return FALSE;

	// get current attributes
	DWORD dwStyle = GetStyle();
	if (dwNewStyle != NULL)
		dwStyle = dwNewStyle;
	DWORD dwStyleEx = GetExStyle() | dwNewStyleEx;
	CRect rc;
	GetWindowRect(&rc);
	pParent->ScreenToClient(&rc);	// map to client co-ords
	UINT nID = GetDlgCtrlID();
	CFont* pFont = GetFont();
	CWnd* pWndAfter = GetNextWindow(GW_HWNDPREV);

	// create the new list box and copy the old list box items 
	// into a new listbox along with each item's data, and selection state
	CFontListBox listNew;
	DWORD dwVisible = (dwStyle & WS_VISIBLE);
	if (! listNew.CreateEx(dwStyleEx, _T("LISTBOX"), _T(""), dwStyle & ~WS_VISIBLE, 
                                rc, pParent, nID, lpParam))
		return FALSE;

	listNew.SetFont(pFont);

	int nNumItems = GetCount();
	BOOL bMultiSel = (dwStyle & LBS_MULTIPLESEL || dwStyle & LBS_EXTENDEDSEL);
	
	for (int n = 0; n < nNumItems; n++)
	{
		CString sText;
		GetText(n, sText);
		int nNewIndex = listNew.AddString(sText);
		listNew.SetItemData(nNewIndex, GetItemData(n));
		if (bMultiSel && GetSel(n))
			listNew.SetSel(nNewIndex);
	}
	if (dwNewStyle & LBS_OWNERDRAWFIXED)
	{
		int nHeight = GetItemHeight(0);
		listNew.SetItemHeight(0, nHeight);
	}
	if (! bMultiSel && nNumItems)
	{
		if (dwNewStyle & LBS_NOSEL)
			listNew.SetCurSel(-1);
		else
		{
			int nCurSel = GetCurSel();
			if (nCurSel != -1)
			{
				CString sSelText;
				// get the selection in the old list
				GetText(nCurSel, sSelText);
				// now find and select it in the new list
				listNew.SetCurSel(listNew.FindStringExact(-1, sSelText));
			}
			else
				listNew.SetCurSel(-1);
		}
	}
	listNew.ModifyStyle(NULL, WS_VSCROLL | dwVisible);
	// destroy the existing window, then attach the new one
	ClearSelection();
	DestroyWindow();
	HWND hwnd = listNew.Detach();
	Attach(hwnd);

	// position correctly in z-order
	SetWindowPos(pWndAfter == NULL ? &CWnd::wndBottom
                                 : pWndAfter, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	return TRUE;
}

DWORD	CFontListBox::SetFlags(DWORD dwFlags)
{
	BOOL bRedrawWindow = FALSE;
	if (GetSafeHwnd() != NULL && ::IsWindow(m_hWnd))
	{
		DWORD dwNewStyle = (GetStyle() & ~(LBS_MULTICOLUMN | LBS_OWNERDRAWVARIABLE)) | 
			(LBS_HASSTRINGS | LBS_OWNERDRAWFIXED | WS_VSCROLL);
		if (dwNewStyle != (GetStyle() | WS_VSCROLL))
		{
			RecreateListBox(dwNewStyle);
			bRedrawWindow = TRUE;
		}
	}
	DWORD dwOldFlags = m_dwFlags;
	m_dwFlags = dwFlags;
	UpdateToolTip();
	if ((dwOldFlags & FNTLB_MRUSTYLE_MASK) != (m_dwFlags & FNTLB_MRUSTYLE_MASK))
	{
		if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == 0)
			DetachMruFontList();				// no more mru list
		else	// Re-attach to a Mru font list
		{
			if ((dwOldFlags & FNTLB_MRUGLOBALLIST) == FNTLB_MRUGLOBALLIST)
				AttachMruFontList(GLOBAL_MRULIST);
			else if ((dwOldFlags & FNTLB_MRUCUSTOMLIST) == FNTLB_MRUCUSTOMLIST)
				AttachMruFontList(m_sMruListName);
			else 
				AttachMruFontList(NULL);
		}
		UpdateMruList();
		bRedrawWindow = FALSE;	// done by the finction
	}
	// change to an other custom mru list
	else if ((m_dwFlags & FNTLB_MRUCUSTOMLIST) == FNTLB_MRUCUSTOMLIST)
	{
		CFontMruList* pMruList = GetMruFontList();
		if (pMruList != NULL)
		{
			if (m_sMruListName.Compare(pMruList->m_name) != 0)
				AttachMruFontList(m_sMruListName);
		}
		else
			AttachMruFontList(m_sMruListName);
		UpdateMruList();
		bRedrawWindow = FALSE;	// done by the finction
	}
	if ((dwOldFlags & FNTLB_GRAPHIC) != (m_dwFlags & FNTLB_GRAPHIC))
	{
		bRedrawWindow = TRUE;
	}	
	// Resize the listbox
	if (::IsWindow(GetSafeHwnd()))
	{
		int nItemHeight = CListBox::GetItemHeight(0);
		int nNewItemHeight = CalcItemHeight();
		SetItemHeight(0, nNewItemHeight);
		if ((GetStyle() & LBS_NOINTEGRALHEIGHT) == NULL)
		{
			CRect rcWnd;
			GetWindowRect(&rcWnd);
			OnSize (NULL, rcWnd.Width(), rcWnd.Height());
		}
	}

	if ((m_dwFlags & FNTLB_MANUAL) != (dwOldFlags & FNTLB_MANUAL))
	{
		if (m_dwFlags & FNTLB_MANUAL)
		{
			if (::IsWindow(m_hWnd))
				ResetContent();
		}
		else
			FillList();
		bRedrawWindow = TRUE;
	}
	if (bRedrawWindow && ::IsWindow(m_hWnd))
		RedrawWindow();
	RefreshToolTip(TRUE, TRUE);
	return dwOldFlags;
}

DWORD CFontListBox::GetFlags()
{
	return m_dwFlags;
}

void CFontListBox::UpdateToolTip(BOOL bSelectedChanged)
{
	m_wndTip.SetFlags(m_dwFlags);
	if ((m_dwFlags & FNTLB_HAS_TOOLTIPS) == NULL)
	{
		if (! :: IsWindow(m_wndTip.m_hWnd))
			return;
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
		return;
	}
	if (! ::IsWindow(GetSafeHwnd()))
		return;
	if (bSelectedChanged)
		GetSelectedFontDescriptors(&m_wndTip.m_arSelectedFonts);
	if (!IsWindowVisible())
	{
		if (! :: IsWindow(m_wndTip.m_hWnd))
			return;
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
	}
	if (! :: IsWindow(m_wndTip.m_hWnd))
		// Yep tip window is created here
		m_wndTip.Create(this);

	if ((m_dwFlags & FNTLB_HAS_TOOLTIPS) && !(GetStyle() & LBS_NOSEL) )
	{
		CWnd* pFocus = GetFocus();
		if (pFocus && (GetSafeHwnd() == pFocus->GetSafeHwnd()))
		{
			m_wndTip.ShowWindow(SW_SHOWNOACTIVATE);
		}
	}
	else
	{
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
	}
}

COLORREF CFontListBox::OnColorHighlight()
{
	return ::GetSysColor(COLOR_HIGHLIGHT);
}

COLORREF CFontListBox::OnColorHighlightText()
{
	return ::GetSysColor(COLOR_HIGHLIGHTTEXT);
}

COLORREF CFontListBox::OnColorWindow()
{
	return ::GetSysColor(COLOR_WINDOW);
}

COLORREF CFontListBox::OnColorText()
{
	return ::GetSysColor(COLOR_WINDOWTEXT);
}

COLORREF CFontListBox::OnColorGrayText()
{
	return ::GetSysColor(COLOR_GRAYTEXT);
}

COLORREF CFontListBox::OnColorMruSeparator()
{
	return OnColorText();
}

COLORREF CFontListBox::TranslateColor(COLORREF clr, COLORREF clrDefault)
{
	COLORREF crRes = clrDefault;
	if (clr & 0x8000000)
	{
		if (GetSysColorBrush(clr & 0xFFFFFF) != NULL)
			crRes = ::GetSysColor(clr & 0xFFFFFF);
	}
	else
		crRes = clr;
	return crRes;
}

void CFontListBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CMemDC memDC(lpDrawItemStruct->hDC, &lpDrawItemStruct->rcItem);
	CRect  rcItem(lpDrawItemStruct->rcItem); // To draw the focus rect.
	CRect  rClient(rcItem); // Rect to highlight the Item
	if (GetExStyle() & WS_EX_TRANSPARENT)
		PaintBkgnd(&memDC, rcItem);

	if ((int)lpDrawItemStruct->itemID < 0)
	{
		// If there are no elements in the List Box 
		// based on whether the list box has Focus or not 
		// draw the Focus Rect or Erase it,
		if ((lpDrawItemStruct->itemAction & ODA_FOCUS) && 
			(lpDrawItemStruct->itemState & ODS_FOCUS))
		{
			memDC.DrawFocusRect(&rcItem);
		}
		else if ((lpDrawItemStruct->itemAction & ODA_FOCUS) &&	
			!(lpDrawItemStruct->itemState & ODS_FOCUS)) 
		{
			memDC.DrawFocusRect(&rcItem); 
		}
		return;
	}

	CRect  rText(&rcItem); // Rect To display the Text
	CPoint Pt( rcItem.left , rcItem.top ); // Point To draw the Image
	CRect	 rBmp(&rcItem);
	// if the Image list exists for the list box
	// adjust the Rect sizes to accomodate the Image for each item.
	if(m_hBitmap)
	{
		// center the bitmap
		rBmp.top +=  (rBmp.Height() - m_szBitmap.cy) / 2;
		rBmp.bottom = rBmp.top + m_szBitmap.cy + 1;
		rText.left += m_szBitmap.cx;
	}

	COLORREF		crText;
	CString		strText;
	BOOL			bIsSelected = FALSE;
	BOOL			bIsFocused = FALSE;
	BOOL			bIsDisabled = FALSE;
	bIsSelected = bIsFocused = !(GetStyle() & LBS_NOSEL);
	bIsSelected = bIsSelected && (lpDrawItemStruct->itemState & ODS_SELECTED);
	bIsFocused = bIsFocused && (lpDrawItemStruct->itemState & ODS_FOCUS);
	bIsDisabled = lpDrawItemStruct->itemState & ODS_DISABLED;

	// Image information in the item data.
	// only 256 images allowed (??...)
	int iImg = (int)(lpDrawItemStruct->itemData & 0xFF);

	// If item selected, draw the highlight rectangle.
	// Or if item deselected, draw the rectangle using the window color.
  // Save these value to restore them when done drawing.
   COLORREF crOldBkColor = memDC.GetBkColor();
	if (!(GetExStyle() & WS_EX_TRANSPARENT))
	{
		if ((lpDrawItemStruct->itemAction | ODA_SELECT) && bIsSelected)
		{
			memDC.SetBkColor(OnColorHighlight());
			memDC.FillSolidRect(&lpDrawItemStruct->rcItem, OnColorHighlight()); 
		}
		else
			memDC.FillSolidRect(&lpDrawItemStruct->rcItem, OnColorWindow());
	}

	// If the item has focus, draw the focus rect.
	// If the item does not have focus, erase the focus rect.
	if ((lpDrawItemStruct->itemAction & ODA_FOCUS) &&  bIsFocused)
	{
		memDC.DrawFocusRect(&rcItem); 
	}
	else if ((lpDrawItemStruct->itemAction & ODA_FOCUS) && ! bIsFocused)
	{
	}

	// To draw the Text set the background mode to Transparent.
	int iBkMode = memDC.SetBkMode(TRANSPARENT);

	if (bIsSelected)
		crText = memDC.SetTextColor(OnColorHighlightText());
	else if (bIsDisabled)
		crText = memDC.SetTextColor(OnColorGrayText());
	else
		crText = memDC.SetTextColor(OnColorText());

	// Get the item text.
	GetText(lpDrawItemStruct->itemID, strText);

	// if the images bitmap exists and there is an associated Image
	// for the Item, draw the Image.
	if (iImg != (int)0xFF)
	{
		int x,y;
		x = iImg * m_szBitmap.cx;
		y = m_szBitmap.cy*(bIsSelected? 1:0);
		CDC mdc;
		mdc.CreateCompatibleDC (&memDC);
		CBitmap* pOldBmp = mdc.SelectObject(CBitmap::FromHandle(m_hBitmap));
		COLORREF clrTransparent = mdc.GetPixel(0, y);
		::TransparentBlt (memDC.GetSafeHdc(),rBmp.left, rBmp.top, m_szBitmap.cx, m_szBitmap.cy,  
				mdc, x, y, m_szBitmap.cx, m_szBitmap.cy, clrTransparent);
	}
	//Draw the Text
	DrawItemText(&memDC, rText, strText, lpDrawItemStruct);
	memDC.SetTextColor(crText); 
	memDC.SetBkColor(crOldBkColor);
	memDC.SetBkMode(iBkMode);
}

void CFontListBox::DrawMruSeparator(CDC* pDC, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (lpDrawItemStruct->itemData & FNTLB_MRU_FONT)
	{
		if ((int)lpDrawItemStruct->itemID == (GetCount()-1) ||
			(GetItemData(lpDrawItemStruct->itemID + 1) & FNTLB_MRU_FONT) == 0 )
		{
			// Draw font MRU separator ==============
			//                         
			TEXTMETRIC tm;
			pDC->GetTextMetrics(&tm);
			CRect rcItem (lpDrawItemStruct->rcItem);
			CPen pen(PS_SOLID, 1, OnColorMruSeparator());
			CPen* pOldPen = pDC->SelectObject(&pen);
			pDC->MoveTo(rcItem.left,rcItem.top+tm.tmHeight);
			pDC->LineTo(rcItem.right,rcItem.top+tm.tmHeight);
			pDC->MoveTo(rcItem.left,rcItem.top+tm.tmHeight+2);
			pDC->LineTo(rcItem.right,rcItem.top+tm.tmHeight+2);
			pDC->SelectObject(pOldPen);
		}
	}
}

void CFontListBox::DrawItemTextPart(CDC* pDC, CRect& rcText, CString& strText, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	// Setup the text format.
	UINT nFormat = DT_LEFT | DT_SINGLELINE | DT_VCENTER;
	if (GetStyle() & LBS_USETABSTOPS)
		nFormat |= DT_EXPANDTABS | DT_NOCLIP;
	//Draw the Text
	CRect rcItem(rcText);
	pDC->DrawText(strText, -1, &rcText, nFormat | DT_CALCRECT);
	rcText.OffsetRect(0, (rcItem.Height() - rcText.Height()) /2);
	pDC->DrawText(strText, -1, &rcText, nFormat);
}

void CFontListBox::DrawItemText(CDC* pDC, CRect& rcText, CString& strText, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (! (m_dwFlags & FNTLB_GRAPHIC	))
	{
		DrawItemTextPart(pDC, rcText, strText, lpDrawItemStruct);
		DrawMruSeparator(pDC, lpDrawItemStruct);
		return;
	}
	// Draw graphic font name
	CRect rc(&rcText);
	if ((DWORD)lpDrawItemStruct->itemData & FNTLB_SYMBOLFONT)
	{
		DrawItemTextPart(pDC, rc, strText, lpDrawItemStruct);
		rc.left += 5 + pDC->GetTextExtent(strText).cx;
	}
	CFont* pf = GetFontDescriptor(strText)->GetFontObject(GetItemHeight(0));
	CFont* pOldFont = pDC->SelectObject(pf);
	DrawItemTextPart(pDC, rc, strText, lpDrawItemStruct);
	pDC->SelectObject(pOldFont);
	// if MruList
	DrawMruSeparator(pDC, lpDrawItemStruct);
}

BOOL CFontListBox::OnAddItem(CFontDescriptor* lpFont)
{
	return TRUE;
}

BOOL CFontListBox::OnAddMruItem(CFontDescriptor* lpFont)
{
	// by default, the same filter
	return OnAddItem(lpFont);
}

BOOL CFontListBox::OnRemoveItem(CFontDescriptor* lpFont)
{
	return TRUE;
}

BOOL CFontListBox::OnRemoveMruItem(CFontDescriptor* lpFont)
{
	// by default, the same filter
	return OnRemoveItem(lpFont);
}

void CFontListBox::UpdateMruList()
{
	if (m_pMruList == NULL)
		return;
	SetRedraw(FALSE);
	if ( ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == 0 && GetDisplayMruListCount() > 0 ) ||
		((m_dwFlags & FNTLB_MRUSTYLE_MASK) != 0 && GetDisplayMruListCount() > 0 && m_pMruList->GetCount() == 0))
	{
		int nToRemove = GetDisplayMruListCount();
		for (int i=0; i < nToRemove; i++)
			DeleteString(0);
		SetRedraw(TRUE);
		UpdateWindow();
		return;
	}

	int nTopIndex = GetTopIndex() - GetDisplayMruListCount();
	// save the selected items
	CStringArray arMruSelFontNames;
	CString	strFont;
	int k, n;
	int nSelected = 0;
	DWORD bIsMultiSelect = (BOOL)(GetStyle() & (LBS_MULTIPLESEL | LBS_EXTENDEDSEL));
	if (bIsMultiSelect)
	{
		for (n=0; n<GetCount(); n++)
		{
			if (GetSel(n))
			{
				nSelected ++;
				GetText(n, strFont);
				if (GetItemData(n) & FNTLB_MRU_FONT)
					arMruSelFontNames.Add(strFont);
				else
					break;
			}
		}
	}
	else
	{
		nSelected ++;
		if ((n = GetCurSel()) != LB_ERR)
		{
			GetText(n, strFont);
			if (GetItemData(n) & FNTLB_MRU_FONT)
				arMruSelFontNames.Add(strFont);
		}
	}

	CFontDescriptor* pFont;
	int nToRemove = GetDisplayMruListCount();
	for (int i=0; i < nToRemove; i++)
		DeleteString(0);
	int kk = 0;
	for (k=0; k< m_pMruList->GetCount(); k++)
	{
		pFont = m_pMruList->GetFontAt(k);
		// we don't add font to Mru list if it is not in the font list part
		if (IsFontInList(pFont))
		{
			if ( OnAddMruItem(pFont) )				// allow filtering
			{
					InsertString(kk, pFont->m_strFaceName);
					DWORD dwItemData = (DWORD)(pFont->m_nImage & 0xFF);
					if (pFont->m_dwCharSets == SYMBOL_CHARSET)
						dwItemData |= FNTLB_SYMBOLFONT;
					SetItemData(kk, dwItemData | FNTLB_MRU_FONT);
					kk++;
			}
		}
	}
	// preserve the top index
	nTopIndex += GetDisplayMruListCount();
	SetTopIndex(nTopIndex);
	// Restore the selected items
	if (nSelected > 0)
	{
		// in the MRU list
		for (n=0; n < arMruSelFontNames.GetSize(); n++)
		{
			if ((k = FindStringExact(-1, arMruSelFontNames[n])) != LB_ERR)
			{
				if (GetItemData(k) & FNTLB_MRU_FONT)
				{
					if (bIsMultiSelect)
						SetSel(k, TRUE);
					else
					{
						SetCurSel(k);
						break;
					}
				}
			}
		}
		// in the true list
		// nothing to do
	}
	SetRedraw(TRUE);
	RedrawWindow();
}

void CFontListBox::ClearMruList()
{
	int nToRemove = GetDisplayMruListCount();
	if (nToRemove == 0)
		return;
	AfxGetFontListRef().ClearMruFontList(this);
	SetRedraw(FALSE);
	for (int i=0; i < nToRemove; i++)
		DeleteString(0);
	SetRedraw(TRUE);
	UpdateWindow();
}

int CFontListBox::ClearSelection()
{
	int iSelected;
	int result = 0;
	DWORD dwStyle = GetStyle();
	if (dwStyle & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL | LBS_NOSEL))
	{
		int nCount;
		if ((nCount = GetSelCount()) > 0)
		{
			// Get the indexes of all the selected items.
			CArray<int,int> arListBoxSel;
			arListBoxSel.SetSize(nCount);
			GetSelItems(nCount, arListBoxSel.GetData());
			for (int i=0; i< arListBoxSel.GetSize(); i++)
				SetSel(arListBoxSel[i], FALSE);
			result = arListBoxSel.GetSize();
		}
	}
	else if ((iSelected = GetCurSel()) != LB_ERR)
	{
		SetCurSel(-1);
		result = 1;
	}
	// update the Tooltip
	RefreshToolTip(TRUE, TRUE);
	return result;
}


int CFontListBox::GetImageIndex(CFontDescriptor* pFont)
{
	switch(pFont->m_nFontType & 0x70007)
	{
	case (TRUETYPE_FONTTYPE | PS_OPENTYPE_FONTTYPE):
	case (TRUETYPE_FONTTYPE | TT_OPENTYPE_FONTTYPE):
	case (TRUETYPE_FONTTYPE | TYPE1_FONTTYPE):
		return 3;
		break;
	case RASTER_FONTTYPE:
	case DEVICE_FONTTYPE:
    case NULL:
		return 0xFF;
		break;
	case TRUETYPE_FONTTYPE:
	default:
		return 0;
		break;
	}
}

void CFontListBox::SaveSelection(CStringArray& arFaceNames)
{
	CString str;
	int iSel;
	arFaceNames.RemoveAll();
	if (GetStyle() & LBS_NOSEL)
		return;
	if (GetStyle() & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL))
	{
		int nCount = GetSelCount();
		CArray<int,int> arListBoxSel;
		arListBoxSel.SetSize(nCount);
		GetSelItems(nCount, arListBoxSel.GetData()); 
		for (int i=0; i<nCount;i++)
		{
			iSel = arListBoxSel[i];
			if ((GetItemData(iSel) & FNTLB_MRU_FONT) == NULL)
			{
				GetText(iSel, str);
				arFaceNames.Add(str);
			}
		}
	}
	else
	{
		if ((iSel = GetCurSel()) != LB_ERR)
		{
			if ((GetItemData(iSel) & FNTLB_MRU_FONT) == NULL)
			{
				GetText(iSel, str);
				arFaceNames.Add(str);
			}
		}
	}
}

void CFontListBox::RestoreSelection(CStringArray& arFaceNames)
{
	CString str;
	int iSel;
	if (GetStyle() & LBS_NOSEL)
		return;
	if (arFaceNames.GetSize() <= 0)
		return;
	if (GetStyle() & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL))
	{
		for (int i = 0; i < arFaceNames.GetSize(); i++)
		{
			str = arFaceNames[i];
			if ((iSel = FindFontInList(str)) != LB_ERR)
				SetSel(iSel, TRUE);
		}
	}
	else
	{
		str = arFaceNames[0];
		if ((iSel = FindFontInList(str)) != LB_ERR)
			SetSel(iSel, TRUE);
	}
}

void CFontListBox::SaveMruSelection(CStringArray& arFaceNames)
{
	CString str;
	arFaceNames.RemoveAll();
	int iSel;
	if (GetStyle() & LBS_NOSEL)
		return;
	if (GetStyle() & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL))
	{
		int nCount = GetSelCount();
		CArray<int,int> arListBoxSel;
		arListBoxSel.SetSize(nCount);
		GetSelItems(nCount, arListBoxSel.GetData()); 
		for (int i=0; i<nCount;i++)
		{
			iSel = arListBoxSel[i];
			if ((GetItemData(iSel) & FNTLB_MRU_FONT) != NULL)
			{
				GetText(iSel, str);
				arFaceNames.Add(str);
			}
		}
	}
	else
	{
		if ((iSel = GetCurSel()) != LB_ERR)
		{
			if ((GetItemData(iSel) & FNTLB_MRU_FONT) != NULL)
			{
				GetText(iSel, str);
				arFaceNames.Add(str);
			}
		}
	}
}

void CFontListBox::RestoreMruSelection(CStringArray& arFaceNames)
{
	CString str;
	int iSel;
	if (GetStyle() & LBS_NOSEL)
		return;
	if (arFaceNames.GetSize() <= 0)
		return;
	if (GetStyle() & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL))
	{
		for (int i = 0; i < arFaceNames.GetSize(); i++)
		{
			str = arFaceNames[i];
			if ((iSel = FindFontInMruList(str)) != LB_ERR)
				SetSel(iSel, TRUE);
		}
	}
	else
	{
		str = arFaceNames[0];
		if ((iSel = FindFontInMruList(str)) != LB_ERR)
			SetSel(iSel, TRUE);
	}
}

void CFontListBox::Refresh()
{
	CWaitCursor wc;
	SetRedraw(FALSE);
	int nTopIndex = GetTopIndex();
	// refresh the list
	if (m_dwFlags & FNTLB_MANUAL)
	{
		CString str;
		SetRedraw(FALSE);
		for (int i = (GetCount()-1); i >= 0; i-- )
		{
			GetText(i, str);
			if (GetFontDescriptor(str) == NULL)
				DeleteString(i);
		}
		UpdateMruList();
		SetRedraw(TRUE);
	}
	else
	{
		CStringArray arFaceNames;
		CStringArray arMruFaceNames;
		// save the selected items;
		SaveSelection(arFaceNames);
		SaveMruSelection(arMruFaceNames);
		SetRedraw(FALSE);
		ResetContent();
		FillList();
		UpdateMruList();
		SetRedraw(TRUE);
		RestoreMruSelection(arMruFaceNames);
		RestoreSelection(arFaceNames);
	}
	// recreate the tooltip
	m_wndTip.DestroyWindow();
	m_wndTip.m_hWnd = NULL;
	RefreshToolTip(TRUE, TRUE);

	SetRedraw(FALSE);
	if (nTopIndex > (GetCount()-1))
		nTopIndex = GetCount()-1;
	SetTopIndex(nTopIndex);
	SetCurSel(-1);
	SetRedraw(TRUE);
	RedrawWindow();
}

void CFontListBox::RefreshMruList()
{
	
}

int CFontListBox::GetItemHeight(int nIndex)
{
	return CalcItemHeight();
}

int CFontListBox::GetDisplayMruListCount()
{
	for (int n=0; n<GetCount(); n++)
	{
		if ((GetItemData(n) & FNTLB_MRU_FONT) == 0)
			break;
	}
	return n;
}

BOOL CFontListBox::IsFontInList(CFontDescriptor* pFont)
{
	ASSERT(pFont != NULL);
	return IsFontInList(pFont->m_strFaceName);
}

BOOL CFontListBox::IsFontInList(LPCTSTR lpszFontName)
{
	int nIndex;
	if ( (nIndex = FindStringExact(GetDisplayMruListCount()-1, lpszFontName)) == LB_ERR)
		return FALSE;
	if (GetItemData(nIndex) & FNTLB_MRU_FONT)
		return FALSE;
	return TRUE;
}

BOOL CFontListBox::IsFontInDisplayedMruList(CFontDescriptor* pFont)
{
	ASSERT(pFont != NULL);
	return IsFontInDisplayedMruList(pFont->m_strFaceName);
}

BOOL CFontListBox::IsFontInDisplayedMruList(LPCTSTR lpszFontName)
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return FALSE;
	if (GetDisplayMruListCount() <= 0)
		return FALSE;
	int nIndex;
	if ( (nIndex = FindStringExact(-1, lpszFontName)) == LB_ERR)
		return FALSE;
	if ((GetItemData(nIndex) & FNTLB_MRU_FONT) == NULL)
		return FALSE;
	return TRUE;
}

BOOL CFontListBox::IsFontInMruList(CFontDescriptor* pFont)
{
	ASSERT(pFont != NULL);
	return IsFontInMruList(pFont->m_strFaceName);
}

BOOL CFontListBox::IsFontInMruList(LPCTSTR lpszFontName)
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return FALSE;
	return AfxGetFontList()->IsFontInMruList(this, lpszFontName);
}


BOOL CFontListBox::AddFontsToMruList(CFontDescriptor* pFont)
{ 
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if (! OnAddMruItem(pFont))
		return FALSE;
	if (! AfxGetFontList()->AddFontsToMruList(this, pFont))
		return FALSE;		// No modification of the MRU list	
	UpdateMruList();
	return TRUE;
}

BOOL CFontListBox::AddFontsToMruList(LPCTSTR lpszFontName)
{ 
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	CFontDescriptor* pFont = GetFontDescriptor(lpszFontName);
	if (pFont == NULL)
		return FALSE;
	if (! OnAddMruItem(pFont))
		return FALSE;
	if (! AfxGetFontList()->AddFontsToMruList(this, pFont))
		return FALSE;		// No modification of the MRU list
	UpdateMruList();
	return TRUE;
}

int CFontListBox::AddFontsToMruList(CStringArray* lpStrFaceNames)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	int nAdded = AfxGetFontList()->AddFontsToMruList(this, lpStrFaceNames);
	if (nAdded > 0)
		UpdateMruList();
	return nAdded;
}

int CFontListBox::AddFontsToMruList(CFontDescriptorArray* lpFontArray)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;

	int nAdded = AfxGetFontList()->AddFontsToMruList(this, lpFontArray);
	if (nAdded > 0)
		UpdateMruList();
	return nAdded;
}

int CFontListBox::AddSelectedFontsToMruList()
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;
	CFontDescriptorArray	arSelected;
	if (GetSelectedFontDescriptors(&arSelected) > 0)
		return AddFontsToMruList(&arSelected);
	return 0;
}

int CFontListBox::RemoveFontsFromMruList(LPCTSTR lpStrFaceName)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	CFontDescriptor* pFont;
	pFont = GetFontDescriptor(lpStrFaceName);
	return RemoveFontsFromMruList(pFont);
}

int CFontListBox::RemoveFontsFromMruList(CFontDescriptor* lpFont)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL || lpFont == NULL)
		return 0;
	return AfxGetFontList()->RemoveFontsFromMruList(this, lpFont);
}

int CFontListBox::RemoveFontsFromMruList(CStringArray* lpStrFaceNames)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL || lpStrFaceNames == NULL)
		return 0;
	CFontDescriptorArray  arFont;
	CFontDescriptor* pFont;
	for (int i=0; i<lpStrFaceNames->GetSize();i++)
	{
		pFont = GetFontDescriptor(lpStrFaceNames->GetAt(i));
		if (pFont != NULL)
			arFont.Add(pFont);
	}
	return RemoveFontsFromMruList(&arFont);
}

int CFontListBox::RemoveFontsFromMruList(CFontDescriptorArray* lpFontDescArray)
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL || lpFontDescArray == NULL)
		return 0;
	int ret = AfxGetFontList()->RemoveFontsFromMruList(this, lpFontDescArray);
	if (ret > 0)
		UpdateMruList();
	return ret;
}

int CFontListBox::RemoveSelectedFontsFromMruList()
{
	ASSERT((m_dwFlags & FNTLB_MRUSTYLE_MASK) != NULL);
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;
	CFontDescriptorArray	arSelected;
	if (GetSelectedFontDescriptors(&arSelected) > 0)
		return RemoveFontsFromMruList(&arSelected);
	return 0;
}

BOOL CFontListBox::AddFontsToList(LPCTSTR lpszFontName)
{
	CFontDescriptor* pFont;
	pFont = GetFontDescriptor(lpszFontName);
	return AddFontsToList(pFont);
}

BOOL CFontListBox::AddFontsToList(CFontDescriptor* lpFont)
{
	CFontDescriptorArray arFonts;
	arFonts.Add(lpFont);
	return (AddFontsToList(&arFonts)>0?TRUE:FALSE);
}

int CFontListBox::AddFontsToList(CStringArray* lpStrFaceNames)
{
	CFontDescriptorArray arFonts;
	CFontDescriptor* pFont;
	for (int i=0; i<lpStrFaceNames->GetSize(); i++)
	{
		if ((pFont = GetFontDescriptor(lpStrFaceNames->GetAt(i))) != NULL)
			arFonts.Add(pFont);
	}
	return AddFontsToList(&arFonts);
}

int CFontListBox::AddFontsToList(CFontDescriptorArray* lpFontArray)
{
	// you cannot manually add fonts to an automatically filled list
	ASSERT((m_dwFlags & FNTLB_MANUAL) != NULL);
	if ((m_dwFlags & FNTLB_MANUAL) == NULL)
		return 0;
	CFontDescriptor* pFont;
	int nAdded = 0;
	BOOL bMruListToUpdate = FALSE;
	for (int i=0; i<lpFontArray->GetSize(); i++)
	{
		pFont = lpFontArray->GetAt(i);
		for (;;)		// not a loop !
		{
			if (pFont == NULL)
				break;
			// verify that's a valid font
			if (::IsBadReadPtr(pFont, sizeof(CFontDescriptor)))
				break;
			// pass through the filter
			if (! OnAddItem(pFont))
				break;
			// add the font to the list
			CString strFontName = pFont->m_strFaceName;
			CString str;
			int index = LB_ERR;
			int cmp;
			for (int m=GetDisplayMruListCount(); m<GetCount(); m++)
			{
				GetText(m, str);
				if ((cmp = strFontName.Compare(str)) <= 0)
				{
					if (cmp == 0)	// already exists
						break;
					index = m;
					break;
				}
			}
			if (m >= GetCount())
				index = GetCount();
			// add it
			if (index != LB_ERR)
			{
				InsertString (index, strFontName);
				DWORD dwItemData = (DWORD)(pFont->m_nImage & 0xFF);
				if (pFont->m_dwCharSets == SYMBOL_CHARSET)
					dwItemData |= FNTLB_SYMBOLFONT;
				SetItemData(index, dwItemData);
			}
			// if the font is in the full referenced Mru list
			// we need to update the Mru list part of the listbox
			if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) && IsFontInMruList(strFontName) && OnAddMruItem(pFont))
				bMruListToUpdate = TRUE;
			nAdded++;
			break;	// not a loop !
		}
	}
	if (bMruListToUpdate)
		UpdateMruList();
	RedrawWindow();
	return nAdded;
}

int CFontListBox::RemoveSelectedFontsFromList()
{
	// Get the indexes of all the selected items.
	int nCount = GetSelCount();
	CArray<int,int> arListBoxSel;

	arListBoxSel.SetSize(nCount);
	GetSelItems(nCount, arListBoxSel.GetData()); 
	CStringArray	arFaceNames;
	CString			str;
	for (int i=0; i< arListBoxSel.GetSize(); i++)
	{
		GetText(arListBoxSel[i], str);
		arFaceNames.Add(str);
	}
	return RemoveFontsFromList(&arFaceNames);
}

void CFontListBox::ClearList()
{
	ResetContent();
	return;
}

int CFontListBox::RemoveFontsFromList(LPCTSTR lpStrFaceName)
{
	CFontDescriptor* pFont;
	pFont = GetFontDescriptor(lpStrFaceName);
	return RemoveFontsFromList(pFont);
}

int CFontListBox::RemoveFontsFromList(CFontDescriptor* lpFont)
{
	CFontDescriptorArray arFonts;
	arFonts.Add(lpFont);
	return RemoveFontsFromList(&arFonts);
}

int CFontListBox::RemoveFontsFromList(CStringArray* lpStrFaceNames)
{
	CFontDescriptorArray arFonts;
	CFontDescriptor* pFont;
	for (int i=0; i<lpStrFaceNames->GetSize(); i++)
	{
		if ((pFont = GetFontDescriptor(lpStrFaceNames->GetAt(i))) != NULL)
			arFonts.Add(pFont);
	}
	return RemoveFontsFromList(&arFonts);
}

int CFontListBox::FindFontInList(LPCTSTR lpszFaceName)
{
	int nIndex;
	if ( (nIndex = FindStringExact(GetDisplayMruListCount()-1, lpszFaceName)) == LB_ERR)
		return LB_ERR;
	if (GetItemData(nIndex) & FNTLB_MRU_FONT)
		return LB_ERR;
	return nIndex;
}

int CFontListBox::FindFontInMruList(LPCTSTR lpszFaceName)
{
	int nIndex;
	if ( (nIndex = FindStringExact(-1, lpszFaceName)) == LB_ERR)
		return LB_ERR;
	if (GetItemData(nIndex) & FNTLB_MRU_FONT)
		return nIndex;
	return LB_ERR;
}

int CFontListBox::RemoveFontsFromList(CFontDescriptorArray* lpFontArray)
{
	ASSERT((m_dwFlags & FNTLB_MANUAL) != NULL);
	if ((m_dwFlags & FNTLB_MANUAL) == NULL)
		return 0;
	CFontDescriptor* pFont;
	int nRemoved = 0;
	BOOL bMruListToUpdate = FALSE;
	SetRedraw(FALSE);
	for (int i=0; i<lpFontArray->GetSize(); i++)
	{
		pFont = lpFontArray->GetAt(i);
		for (;;)		// not a loop !
		{
			if (pFont == NULL)
				break;
			// verify that's a valid font
			if (::IsBadReadPtr(pFont, sizeof(CFontDescriptor)))
				break;
			// pass through the filter
			if (! OnRemoveItem(pFont))
				break;
			// add the font to the list
			CString strFontName = pFont->m_strFaceName;
			int index;
			if (GetCount() > 0)
			{
				if ((index = FindFontInList(strFontName)) != LB_ERR)  // found in the list
				{
					if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) && IsFontInMruList(strFontName) && OnRemoveMruItem(pFont))
						bMruListToUpdate = TRUE;
					nRemoved ++;
					DeleteString(index);
				}	
			}
			break;
		}
	}
	if (bMruListToUpdate)
		UpdateMruList();
	SetRedraw(TRUE);
	UpdateWindow();
	return nRemoved;
}


BOOL CFontListBox::SetMruFontListName(LPCTSTR lpszMruListName)
{
	return AttachToMruFontList(lpszMruListName);
}

LPCTSTR CFontListBox::GetMruFontListName()
{
	if (!HasMruList())
		return NULL;
	if ((m_dwFlags & FNTLB_MRUGLOBALLIST) == FNTLB_MRUGLOBALLIST)
		return GLOBAL_MRULIST;
	else
		return m_sMruListName;
}

BOOL CFontListBox::AttachToMruFontList(LPCTSTR lpszMruListName)
{
	if (lpszMruListName == GLOBAL_MRULIST)
	{
		// attach to the global mru list
		m_dwFlags = (m_dwFlags & ~FNTLB_MRUSTYLE_MASK) | FNTLB_MRUGLOBALLIST;
		m_pMruList = AttachMruFontList(GLOBAL_MRULIST);
	}
	else if (lpszMruListName == NULL)
	{
		// attach to a private mru list
		m_dwFlags = (m_dwFlags & ~FNTLB_MRUSTYLE_MASK) | FNTLB_MRULIST;
		m_pMruList = AttachMruFontList(NULL);
	}
	else
	{
		// attach to a custom mru list
		m_dwFlags = (m_dwFlags & ~FNTLB_MRUSTYLE_MASK) | FNTLB_MRUCUSTOMLIST;
		m_sMruListName = lpszMruListName;
		m_pMruList = AttachMruFontList(lpszMruListName);
	}
	if (m_pMruList != NULL)
	{
		if (GetSafeHwnd() != NULL && ::IsWindow(GetSafeHwnd()))
		{
			SetItemHeight(0, CalcItemHeight());
			UpdateMruList();
		}
		return TRUE;
	}
	return FALSE;
}

const CString& CFontListBox::GetCustomMruListName()
{
	return m_sMruListName;
}

BOOL CFontListBox::IsMruListPersistent()
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return FALSE;
	return AfxGetFontListRef().IsMruListPersistent(this);
}

BOOL CFontListBox::EnableMruListPersistence (BOOL bPersistence)
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;
	return AfxGetFontListRef().EnableMruListPersistence(this, bPersistence);
}

BOOL CFontListBox::ReloadMruListSettings()
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;
	BOOL bRet = AfxGetFontListRef().ReloadMruListSettings(this);
	if (bRet)
		UpdateMruList();
	return bRet;
}

BOOL CFontListBox::SaveMruListSettings()
{
	if ((m_dwFlags & FNTLB_MRUSTYLE_MASK) == NULL)
		return 0;
	return AfxGetFontListRef().SaveMruListSettings(this);
}
	

BOOL CFontListBox::DetachFromMruFontList()
{
	DetachMruFontList();
	m_dwFlags = (m_dwFlags & ~FNTLB_MRUSTYLE_MASK);
	SetItemHeight(0, CalcItemHeight());
	m_pMruList = NULL;
	if (GetSafeHwnd() != NULL && ::IsWindow(GetSafeHwnd()))
		UpdateMruList();
	RedrawWindow();
	return TRUE;
}

int CFontListBox::GetSelectedCount()
{
	if (!::IsWindow(m_hWnd))
		return 0;
	DWORD dwStyle = GetStyle();
	if (dwStyle & (LBS_EXTENDEDSEL | LBS_MULTIPLESEL | LBS_NOSEL))
		return GetSelCount();
	if (GetCurSel() != LB_ERR)
		return 1;
	return 0;
}

int CFontListBox::GetFontCount()
{
	if (!::IsWindow(m_hWnd))
		return 0;
	int count = GetCount();
	if (m_pMruList)
		count -= m_pMruList->GetCount();
	return count;
}

int CFontListBox::GetMruFontCount()
{
	if (!::IsWindow(m_hWnd))
		return 0;
	if (m_pMruList)
		return m_pMruList->GetCount();
	return 0;
}

int CFontListBox::GetDisplayedMruFontCount()
{
	if (!::IsWindow(m_hWnd))
		return 0;
	return GetDisplayMruListCount();
}

// Pay attention : due to the fact the user can have selected font
// not only in the font list but alo in the mru list part,
int CFontListBox::GetSelectedFontNames(CStringArray* pStrArray)
{
	pStrArray->RemoveAll();
	CString strFontName;
	if (GetStyle() & (LBS_MULTIPLESEL | LBS_EXTENDEDSEL))
	{
		for (int i=0; i < GetCount(); i++)
		{
			if (GetSel(i))
			{
				GetText(i, strFontName);
				pStrArray->Add(strFontName);
			}
		}
	}
	else if ((GetStyle() & LBS_NOSEL) == NULL)
	{
		int nCurSel;
		if ((nCurSel=GetCurSel()) != -1)
		{
			GetText(nCurSel, strFontName);
			pStrArray->Add(strFontName);
		}
	}
	// sort the array
	SortFontNameArray (*pStrArray);
	// filter the array (in case of twice the same font were added)
	if (pStrArray->GetSize() > 1)
	{
		CString strLast;
		for (int i=(pStrArray->GetSize()-2); i>= 0; i--)
		{
			strLast = pStrArray->GetAt(i+1);
			if (strLast.Compare(pStrArray->GetAt(i)) == 0)
				pStrArray->RemoveAt(i+1);
		}
	}
	return pStrArray->GetSize();
}

int CFontListBox::GetSelectedFontDescriptors(CFontDescriptorArray* lpArray)
{
	CFontDescriptor* pFont;
	CString strFontName;

	ASSERT (lpArray!=NULL);
	lpArray->RemoveAll();
	if (! ::IsWindow(m_hWnd))
		return 0;
	if (GetStyle() & (LBS_MULTIPLESEL | LBS_EXTENDEDSEL))
	{
		for (int i=0; i < GetCount(); i++)
		{
			if (GetSel(i))
			{
				GetText(i, strFontName);
				pFont = GetFontDescriptor(strFontName);
				if (pFont)
					lpArray->Add(pFont);
			}
		}
	}
	else if ((GetStyle() & LBS_NOSEL) == NULL)
	{
		int nCurSel;
		if ((nCurSel=GetCurSel()) != -1 && nCurSel < GetCount())
		{
			GetText(nCurSel, strFontName);
			pFont = GetFontDescriptor(strFontName);
			if (pFont)
				lpArray->Add(pFont);
		}
	}
	// sort the array
	AfxGetFontList()->SortFontArray(*lpArray);	
	// filter the array (in case of twice the same font were added, 
	// by the mean of Mru list and the true list)
	if (lpArray->GetSize() > 1)
	{
		CFontDescriptor* pLast;
		for (int i=(lpArray->GetSize()-2); i>= 0; i--)
		{
			pLast = lpArray->GetAt(i+1);
			if (pLast == lpArray->GetAt(i))
				lpArray->RemoveAt(i+1);
		}
	}
	return lpArray->GetSize();
}

/////////////////////////////////////////////////////////////////////////////
// Sort function
//#define GTS(x,y)	((x).Compare((y)) > 0)
#define LTS(x,y)	((x).Compare((y)) < 0)
//#define SWAPS(x,y) {temp = (x); (x) = (y); (y) = temp;}

void CFontListBox::SortFontNameArray(CStringArray& arFonts)
{
	int nLow = 0;
	int nHigh = arFonts.GetSize()-1;

	int 	n = arFonts.GetSize();
	if (n<2) 
		return;

	CString temp;
	for (int m=n--/2; m-- || n;)
	{
		temp=arFonts[m];
		int i = m*2+1;
		int j = m;

		for (; i<=n; j=i, i=i*2+1)
		{
			if (i < n) 
				(LTS(arFonts[i],arFonts[i+1]))?i++:0;
			if (LTS(temp,arFonts[i])) 
				arFonts[j]=arFonts[i];
			else 
				break;
		}
		arFonts[j]=temp;
		if (m==0 && n)
		{
			temp=arFonts[0];
			arFonts[0]=arFonts[n];
			arFonts[n--]=temp;++m;
		}
	}
}

//
/////////////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4706)
BOOL CFontListBox::LoadImages(LPCTSTR lpszResourceName)
{
	CBitmap bmp;
	if (!bmp.LoadBitmap(lpszResourceName))
		return FALSE;
	if (bmp.GetSafeHandle() == NULL)
		return FALSE;
	BITMAP bm;
	if (! bmp.GetBitmap(&bm))
		return FALSE;
	// !!! The bitmap MUST BE 100 x 24 pixels
	if (bm.bmWidth != 100 ||  bm.bmHeight != 24)
		return FALSE;
	HBITMAP hBitmap;
	if (!(hBitmap = (HBITMAP)CopyImage(bmp, IMAGE_BITMAP, 100, 24, NULL)))
		return FALSE;
	m_hBitmap = hBitmap;
	RedrawWindow();
	return TRUE;
}
#pragma warning (default : 4706)

BOOL CFontListBox::LoadImages(UINT nIDResource)
{
	return LoadImages(MAKEINTRESOURCE(nIDResource));
}

void CFontListBox:: SetStdImages()
{
	if (m_hBitmap != NULL && m_hBitmap != AfxGetFontTypeBitmap())
		::DeleteObject(m_hBitmap);
	m_hBitmap = AfxGetFontTypeBitmap();
	RedrawWindow();
}

BOOL CFontListBox::OnEraseBkgnd(CDC* pDC) 
{
	// fill the listbox extra items area
	if (!(GetExStyle() & WS_EX_TRANSPARENT))
	{
		COLORREF crBkgnd = OnColorWindow();
		CRect rcClient;
		GetClientRect(rcClient);
		if (GetCount() > 0)
		{
			CRect rcItem;
			GetItemRect(GetCount()-1, rcItem);
			if (rcItem.bottom < rcClient.bottom)
				rcClient.top = rcItem.bottom;
		}
		if (rcClient.top < rcClient.bottom)
			pDC->FillSolidRect(rcClient, crBkgnd);
	}
	return TRUE;	
}

void CFontListBox::OnNotifyMruFontListChanged(WPARAM wParam, LPARAM lParam)
{
	CFontDescriptor* pFont = (CFontDescriptor*)lParam;
	switch(wParam)
	{
	case FM_FONTADDED:
		if (! OnAddMruItem(pFont))
			return;
		UpdateMruList();
		break;
	case FM_FONTREMOVED:
	case FM_CHANGEDALL:
		UpdateMruList();
		break;
	case FM_REMOVEALL:
		UpdateMruList();
		break;
	}
}

void CFontListBox::OnNotifyFontListChanged(WPARAM wParam, LPARAM lParam)
{
	CFontDescriptor* pFont = (CFontDescriptor*)lParam;
	switch(wParam)
	{
	case FM_FONTADDED:
		Refresh();
		break;
	case FM_FONTREMOVED:
	case FM_CHANGEDALL:
		Refresh();
		break;
	case FM_REMOVEALL:
		Refresh();
		break;
	}
}

void CFontListBox::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CListBox::OnShowWindow(bShow, nStatus);
	UpdateToolTip(TRUE);
}

int CFontListBox::GetTooltipMaxItems()
{
	return m_wndTip.m_nMaxItems;
}

int CFontListBox::SetTooltipMaxItems(int nNbrMaxItems)
{
	int nItems = m_wndTip.SetMaxItems(nNbrMaxItems);
	RefreshToolTip(TRUE, TRUE);
	return nItems;
}
// if the tooltip style is TRACKING, then only the current hover font is displayed
// if not, the tooltip display all the selected fonts
void CFontListBox::RefreshToolTip(BOOL bOnWindow, BOOL bSelectedChanged) 
{

	if (bSelectedChanged)
		GetSelectedFontDescriptors(&m_wndTip.m_arSelectedFonts);
	m_wndTip.SetFlags(m_dwFlags);
	if ((m_dwFlags & FNTLB_HAS_TOOLTIPS) == NULL)
	{
		if (! :: IsWindow(m_wndTip.m_hWnd))
			return;
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
		return;
	}
	if (! ::IsWindow(GetSafeHwnd()))
		return;
	if (!IsWindowVisible())
	{
		if (! :: IsWindow(m_wndTip.m_hWnd))
			return;
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
	}
	if (! :: IsWindow(m_wndTip.m_hWnd))
		// Yep tip window is created here
		m_wndTip.Create(this);

	
	if (! bOnWindow )
	{
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
		return;
	}
	CPoint ptCursor;
	GetCursorPos(&ptCursor);
	ScreenToClient(&ptCursor);
	int nSel;
	// if the top window is not active, don't show the tooltip
	if (GetTopLevelParent()->GetSafeHwnd() != GetActiveWindow()->GetSafeHwnd())
	{
		m_wndTip.ShowWindow(SW_HIDE);
		return;
	}

	if (m_dwFlags & FNTLB_TRACKING_TOOLTIP)
	{
		BOOL bOutside;
		nSel = ItemFromPoint(ptCursor, bOutside);
		if (bOutside)
		{
			if (m_wndTip.IsWindowVisible())
				m_wndTip.ShowWindow(SW_HIDE);
			return;
		}
	}
	else if (GetStyle() & LBS_NOSEL)
	{
		if (m_wndTip.IsWindowVisible())
			m_wndTip.ShowWindow(SW_HIDE);
		return;
	}
	else
	{
		CRect rcClient;
		GetClientRect(&rcClient);
		if (! rcClient.PtInRect(ptCursor))
		{
			if (m_wndTip.IsWindowVisible())
				m_wndTip.ShowWindow(SW_HIDE);
			return;
		}
		else
			nSel = GetCurSel();		
	}

	int nFirstVisible = GetTopIndex();
	// Selected
	if (nSel != -1 && nFirstVisible <= nSel)
	{
		CRect rc;

		GetWindowRect(rc);
		int itemHeight = GetItemHeight(0);
		int lastVis = nFirstVisible + ((rc.Height()-itemHeight)/itemHeight);
		if (nSel <= lastVis)
		{
			int nHeight = itemHeight * ((nSel - nFirstVisible) + 1);
			CPoint pt(rc.right + 5,rc.top + nHeight);
			// Show tip in correct position
			CString str;
			GetText(nSel,str);
			m_wndTip.ShowTips(pt,str, bSelectedChanged);
		}
	}	
}

void CFontListBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_bTracking)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.hwndTrack = m_hWnd;
		tme.dwFlags = TME_LEAVE;
		tme.dwHoverTime = HOVER_DEFAULT;

		//Tell Windows that we want to process Leave message
		m_bTracking = _TrackMouseEvent(&tme); 
	}	
	RefreshToolTip(TRUE);
	CListBox::OnMouseMove(nFlags, point);
}

void CFontListBox::OnMouseLeave()
{
	RefreshToolTip(FALSE);
	m_bTracking = FALSE;
}

BOOL CFontListBox::OnSelChange() 
{
	// to manage the LBS_NOSEL style flag 
	if (GetStyle() & LBS_NOSEL)
	{
		SetCurSel(-1);
		return TRUE;
	}
	RefreshToolTip(TRUE, TRUE);
	return FALSE;			// allow the parent window to handle the message
}


int CFontListBox::AddString(LPCTSTR lpszItem)
{
	int iRet = CListBox::AddString(lpszItem);
	if (iRet >= 0)
		SetItemData(iRet, -1);
	return iRet;
}

int CFontListBox::AddString(LPCTSTR lpszItem, int iImg)
{
	int iRet = CListBox::AddString(lpszItem);
	if (iRet >= 0)
		SetItemData(iRet, iImg);
	return iRet;
}

int CFontListBox::InsertString(int iIndex, LPCTSTR lpszItem)
{
	int iRet = CListBox::InsertString(iIndex,lpszItem);
	if (iRet >= 0)
		SetItemData(iRet, -1);
	return iRet;
}

int CFontListBox::InsertString(int iIndex, LPCTSTR lpszItem, int iImg)
{
	int iRet = CListBox::InsertString(iIndex,lpszItem);
	if (iRet >= 0)
		SetItemData(iRet, iImg);
	return iRet;
}

void CFontListBox::SetItemImage(int iIndex, int iImg)
{
	SetItemData(iIndex, iImg);
	CRect rcItem;
	if (GetItemRect(iIndex, &rcItem) != LB_ERR)
	{
		InvalidateRect(&rcItem);
		UpdateWindow();
	}
}

BOOL CFontListBox::HasMruList()
{
	if (m_dwFlags & FNTLB_MRUSTYLE_MASK)
		return TRUE;
	else
		return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Transparency support functions and handlers

BOOL CFontListBox::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	BOOL bRet;
	if (GetExStyle() & WS_EX_TRANSPARENT)
	{
		SetRedraw(FALSE);
		bRet = CListBox::OnMouseWheel(nFlags, zDelta, pt);
		SetRedraw(TRUE);
		RedrawWindow(0,0,RDW_FRAME|RDW_INVALIDATE|RDW_UPDATENOW);
	}
	else
		bRet = CListBox::OnMouseWheel(nFlags, zDelta, pt);
	RefreshToolTip(TRUE);
	return bRet;
}

void CFontListBox::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if (GetExStyle() & WS_EX_TRANSPARENT)
	{
		SetRedraw(FALSE);
		CListBox::OnVScroll(nSBCode,nPos,pScrollBar);
		SetRedraw(TRUE);
		RedrawWindow(0,0,RDW_FRAME|RDW_INVALIDATE|RDW_UPDATENOW);
	}
	else
		CListBox::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CFontListBox::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (GetExStyle() & WS_EX_TRANSPARENT)
	{
		SetRedraw(FALSE);
		CListBox::OnChar(nChar, nRepCnt, nFlags);
		SetRedraw(TRUE);
	}
	else
		CListBox::OnChar(nChar, nRepCnt, nFlags);
}

void CFontListBox::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (GetExStyle() & WS_EX_TRANSPARENT)
	{
		SetRedraw(FALSE);
		CListBox::OnKeyDown(nChar, nRepCnt, nFlags);
		SetRedraw(TRUE);
		RedrawWindow(0,0,RDW_FRAME|RDW_INVALIDATE|RDW_UPDATENOW);
	}
	else	
		CListBox::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CFontListBox::OnMove(int x, int y) 
{
	CListBox::OnMove(x, y);
}

int CFontListBox::SetTopIndex(int Index)
{
	if (GetExStyle() & WS_EX_TRANSPARENT)
	{
		SetRedraw(FALSE);
		int Ret = CListBox::SetTopIndex(Index);
		SetRedraw(TRUE);
		RedrawWindow(0,0,RDW_FRAME|RDW_INVALIDATE|RDW_UPDATENOW);
		return Ret;
	}
	else
		return CListBox::SetTopIndex(Index);
}


int CFontListBox::OnUpdateBkgnd(CDC* pDC, UINT bModified)
{
	if (m_bkModified || bModified)
		SetBkgnd(pDC);
	m_bkModified = FALSE;
	return NULL;
}

BOOL CFontListBox::SetBkgnd(CDC* pDC)
{
	if (pDC)
	{
		// Restore old bitmap (if any)
		if (m_dcBk.m_hDC != NULL && m_pbmpOldBk != NULL)
		{
			m_dcBk.SelectObject(m_pbmpOldBk);
		} // if

		m_bmpBk.DeleteObject();
		m_dcBk.DeleteDC();

		CRect rect;
		CRect rect1;

		GetClientRect(rect);
		rect1.CopyRect(rect);
		ClientToScreen(&rect1);
		GetParent()->ScreenToClient(rect1);

		m_dcBk.CreateCompatibleDC(pDC);
		m_bmpBk.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
		m_pbmpOldBk = m_dcBk.SelectObject(&m_bmpBk);
		m_dcBk.BitBlt(0, 0, rect.Width(), rect.Height(), pDC, rect1.left, rect1.top, SRCCOPY);

		return TRUE;
	} // if

	return FALSE;
}

void CFontListBox::PaintBkgnd(CDC* pDC, LPCRECT lpRect)
{
	CClientDC clDC(GetParent());
	CRect rect;
	CRect rect1;

	GetClientRect(rect);
	rect1.CopyRect(rect);
	ClientToScreen(&rect1);
	GetParent()->ScreenToClient(rect1);

	if (m_dcBk.m_hDC == NULL)
	{
		m_dcBk.CreateCompatibleDC(&clDC);
		m_bmpBk.CreateCompatibleBitmap(&clDC, rect.Width(), rect.Height());
		m_pbmpOldBk = m_dcBk.SelectObject(&m_bmpBk);
		m_dcBk.BitBlt(0, 0, rect.Width(), rect.Height(), &clDC, rect1.left, rect1.top, SRCCOPY);
	} // if
	if (lpRect == NULL)
		// repaint all the client area
		GetClientRect(rect);
	else
		rect.CopyRect(lpRect);

	pDC->BitBlt(rect.left, rect.top, rect.Width(), rect.Height(), &m_dcBk, rect.left, rect.top, SRCCOPY);
} 
