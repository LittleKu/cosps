/////////////////////////////////////////////////////////////////////////////
// Dialog data exchange (DDX_) and validation (DDV_)

#ifndef __TRANSPARENCY__
#define __TRANSPARENCY__

/////////////////////////////////////////////////////////////////////////////
// Transparency support definitions

// Transparency.h


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define DECLARE_TRANSPARENCY() \
	protected: \
	CDC			m_dcBk; \
	CBitmap		m_bmpBk; \
	CBitmap*		m_pbmpOldBk; \
	BOOL			m_bkModified; \
	LRESULT intOnUpdateBkgnd(WPARAM wParam, LPARAM lParam) \
		{return (LRESULT)OnUpdateBkgnd(CDC::FromHandle((HDC)wParam), (BOOL)lParam);};


#ifndef WM_UPDATEBKGND
#define WM_UPDATEBKGND	(0xA001)
#define ON_WM_UPDATEBKGND() \
	{ WM_UPDATEBKGND, 0, 0, 0, AfxSig_lwl, \
		(AFX_PMSG)(AFX_PMSGW)(LRESULT (AFX_MSG_CALL CWnd::*)(WPARAM, LPARAM))&intOnUpdateBkgnd },

#endif
#define UpdateChildrenBackground(pdc,bBkModified) \
			SendMessageToDescendants(WM_UPDATEBKGND, (WPARAM)pdc->GetSafeHdc(), (LPARAM)bBkModified, TRUE, TRUE);
	

#endif