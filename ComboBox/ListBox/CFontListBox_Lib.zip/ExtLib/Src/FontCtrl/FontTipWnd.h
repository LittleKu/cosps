#if !defined(AFX_FONTTIPWND_H__58F911DF_B540_4E23_A161_E149B93422D4__INCLUDED_)
#define AFX_FONTTIPWND_H__58F911DF_B540_4E23_A161_E149B93422D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////

#ifdef _AFX_MINREBUILD
#pragma component(minrebuild, off)
#endif
#ifndef _AFX_FULLTYPEINFO
#pragma component(mintypeinfo, on)
#endif

// FontTipWnd.h : header file
//

/*
#define FNTLB_HAS_TOOLTIPS				1
#define FNTLB_TOOLTIPTEXT_FONT		2
#define FNTLB_TOOLTIPTEXT_SAMPLE		0
#define FNTLB_TOOLTIPSELECTED			4
#define FNTLB_GRAPHIC					0x100
*/
#define DEFAULT_FONTTIP_HEIGHT			14
#define DEFAULT_FONTTIP_XMARGIN		4
#define DEFAULT_FONTTIP_YMARGIN		4
#define DEFAULT_FONTTIP_MARGIN		4
#define DEFAULT_FONTTIP_SEPMARGIN	2

#ifndef FONTTIP_HEIGHT
#define FONTTIP_HEIGHT DEFAULT_FONTTIP_HEIGHT
#endif

#ifndef FONTTIP_XMARGIN
#define FONTTIP_XMARGIN DEFAULT_FONTTIP_XMARGIN
#endif
#ifndef FONTTIP_YMARGIN
#define FONTTIP_YMARGIN DEFAULT_FONTTIP_YMARGIN
#endif

#ifndef FONTTIP_SEPMARGIN
#define FONTTIP_SEPMARGIN DEFAULT_FONTTIP_SEPMARGIN
#endif

#include "FontListManager.h"
//#include "FontListBox.h"
class CFontListBox;

/////////////////////////////////////////////////////////////////////////////
// CFontTipWnd window

class CFontTipWnd : public CWnd
{
	friend class CFontListBox;
// Construction
public:
	CFontTipWnd();
	
// Attributes
public:
	DWORD		m_dwFlags;
protected:
	int		m_nMaxItems;
	BOOL		m_bOverMaxItems;
	CFont		m_font;
	CFont		m_fontUI;
	CFont*	m_pfontCurrent;
	CString  m_strSample;
	CString	m_strFont;						// the font under the cursor

	CFontDescriptorArray		m_arSelectedFonts;	// the selected fonts
	CFontDescriptor*			m_pCurrentFont;	// the current font
	BOOL			m_bShowCurrent;
	BOOL			m_bShowSelected;
	BOOL			m_bShowCurrentGraphic;
	BOOL			m_bShowSelectedGraphic;
	BOOL			m_bSeparator;
	int			m_itemHeight;
	CRect			m_itemRect;
	int			m_nSelected;
	DWORD			m_fPrevFlags;

// Operations
public:
	BOOL Create(CWnd* pParent);
	void ShowTips(CPoint pt, const CString& str, BOOL bSelectedChanged = FALSE);
	void SetSampleText(LPCTSTR lpszSampleText);
	int SetMaxItems(int nNbrMaxItems);
	CString& GetSampleText();
	
protected:
	int DrawItemTextPart (CDC* pDC, CRect& rc, LPCTSTR lpText, DWORD flags);
	int DrawItemText (CDC* pDC, CRect& rc, CFontDescriptor* pFont, DWORD flags, BOOL bGraphic);
	int DrawItems (CDC* pDC, LPRECT lpRect, DWORD flags);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontTipWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFontTipWnd();
	DWORD	SetFlags(DWORD dwFlags);
	DWORD GetFlags();
	BOOL ModifyFlags(DWORD dwRemove, DWORD dwAdd);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFontTipWnd)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FONTTIPWND_H__58F911DF_B540_4E23_A161_E149B93422D4__INCLUDED_)
