// FontListManager.cpp : implementation file
//

#include "stdafx.h"
#define AFX_PRIVATE_FONT_DEFINITIONS
#include "FontListManager.h"

#ifndef NTM_PS_OPENTYPE
#define NTM_PS_OPENTYPE     0x00020000
#endif
#ifndef NTM_TT_OPENTYPE
#define NTM_TT_OPENTYPE     0x00040000
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

AFX_STATIC_DATA HBITMAP _afxFntTypeBitmap = NULL;

const static HBITMAP _afxLoadFntTypeBitmap() {	if (_afxFntTypeBitmap != NULL)
		return _afxFntTypeBitmap;
	// the icons for the different types of font are loaded from the
	// COMDLG32.DLL library resources
	HMODULE hModule = ::LoadLibraryEx(_T("COMDLG32.DLL"), NULL, DONT_RESOLVE_DLL_REFERENCES);
	ASSERT (hModule != NULL);
	_afxFntTypeBitmap = (HBITMAP)::LoadImage(hModule, MAKEINTRESOURCE(38), IMAGE_BITMAP, 100, 24, LR_DEFAULTCOLOR);
	ASSERT(_afxFntTypeBitmap != NULL);
	::FreeLibrary(hModule);
	return _afxFntTypeBitmap;
}
// special functions
const HBITMAP AFXAPI AfxGetFontTypeBitmap()
	{ return _afxLoadFntTypeBitmap(); }
static AFX_COMDAT CFontListManager _afxFontListManager;
CFontListManager* AFXAPI AfxGetFontList() {return &_afxFontListManager;};
CFontListManager& AFXAPI AfxGetFontListRef() {return _afxFontListManager;};

CFontDescriptor* AfxGetFontDescriptor(LPCTSTR lpszName)
{
	return _afxFontListManager.GetDescriptor(lpszName);
}

// global MRU list management
static AFX_COMDAT CTypedPtrMap <CMapStringToOb, CString, CFontDescriptor*> _afxFontGlobalMruList;

void AFXAPI AfxClearGlobalMruFontList()
{
	_afxFontGlobalMruList.RemoveAll();
}

BOOL AFXAPI AfxAddFontToGlobalMruList(LPCTSTR lpszName)
{
	CFontDescriptor*	pDescriptor = NULL;
	if (! _afxFontGlobalMruList.Lookup(lpszName, pDescriptor))
		return FALSE;
	if ((pDescriptor = _afxFontListManager.GetDescriptor(lpszName)) == NULL)
		return FALSE;			// unknow facename
	ASSERT(pDescriptor != NULL);
	_afxFontGlobalMruList.SetAt(pDescriptor->m_strFaceName, pDescriptor);
	return TRUE;
}

BOOL AFXAPI AfxIsMruFont(LPCTSTR lpszName)
{
	CFontDescriptor*	pDescriptor = NULL;
	if (! _afxFontGlobalMruList.Lookup(lpszName, pDescriptor))
		return TRUE;
	return FALSE;
}

void LoadFontListSettings()
{
	_afxFontListManager.LoadFontListSettings();
}

void SaveFontListSettings()
{
	_afxFontListManager.SaveFontListSettings();
}

BOOL EnableMruListPersistence (LPCTSTR lpszMruListName, BOOL bPersistence)
{
	return _afxFontListManager.EnableMruListPersistence(lpszMruListName, bPersistence);
}

BOOL ReloadMruListSettings(LPCTSTR lpszMruListName)
{
	return _afxFontListManager.ReloadMruListSettings(lpszMruListName);
}

BOOL SaveMruListSettings(LPCTSTR lpszMruListName)
{
	return _afxFontListManager.SaveMruListSettings(lpszMruListName);
}

BOOL IsMruListPersistent(LPCTSTR lpszMruListName)
{
	return _afxFontListManager.IsMruListPersistent(lpszMruListName);
}


/////////////////////////////////////////////////////////////////////////////
// CFontDescriptor

CFontDescriptor::CFontDescriptor()
{
	m_nFontType = NULL;
	m_dwCharSets = NULL;
	m_nImage = -1;
	m_pFont = NULL;
}

CFontDescriptor::~CFontDescriptor()
{
	if (m_pFont != NULL)
		delete m_pFont;
}

CFont* CFontDescriptor::GetFontObject(int nHeight)
{
	if (m_pFont != NULL && (nHeight == 0 || nHeight == m_nFontHeight))
		return m_pFont;
	else
	{
		if (m_pFont != NULL)
		{
			delete m_pFont;
			m_pFont = NULL;
		}
	}
	if (nHeight == 0)
		nHeight = _afxFontListManager.nDefFontHeight;
	m_nFontHeight = nHeight;
	if (m_pFont == NULL)
		m_pFont = new CFont;
	if (!m_pFont->CreateFont(nHeight,0,0,0,FW_NORMAL,FALSE, FALSE, 
				FALSE,DEFAULT_CHARSET ,OUT_DEFAULT_PRECIS,
				CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,
				DEFAULT_PITCH, m_strFaceName))
	{
		ASSERT(0);
		return NULL;
	}
	return m_pFont;
}


/////////////////////////////////////////////////////////////////////////////
// CFontMruList implementation

CFontMruList::CFontMruList()
{
	m_persistence = FALSE;
	m_persistenceRemoved = FALSE;
}

CFontMruList::~CFontMruList()
{
	m_mapFaceNames.RemoveAll();
	m_arFonts.RemoveAll();
	m_arWndPtr.RemoveAll();
}

int CFontMruList::GetCount()
{
	return m_arFonts.GetSize();
}

CFontDescriptor* CFontMruList::GetFontAt(int i)
{
	return m_arFonts.GetAt(i);
}

BOOL CFontMruList::EnablePersistence(BOOL bPersistence)
{
	BOOL b = m_persistence;
	m_persistence = bPersistence;
	if (b && !bPersistence)				// to remove the keys when saving sttings
		m_persistenceRemoved = TRUE;
	return b;
}

BOOL CFontMruList::IsPersistent()
{
	return m_persistence;
}


void CFontMruList::RemoveAll()
{
	m_arFonts.RemoveAll();
	m_mapFaceNames.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////
// CFontListManager


#define	FNTMRUSECTION				_T("FontMruLists")
#define	FNTMRUENTRYFORMAT			_T("Fml%d")
#define	FNTMRUSECTIONFORMAT		_T("MRUFL:%s")
#define	FNTMRUFNTENTRYFORMAT		_T("Fnt%d")
#define	FNTMRUGLOBALNAME			_T("$$GLOBALMRULIST$$")

CFontListManager::CFontListManager()
{
	AfxGetFontTypeBitmap(); 
	m_gblMruList.m_name = FNTMRUGLOBALNAME;
	FillFontList();
	m_pWndSys = NULL;
}

CFontListManager::~CFontListManager()
{
	// allow access by CWnd pointer
	m_mapMru.RemoveAll();
	// array of all the defined Mru list
	for (int i=m_arMru.GetSize()-1; i>= 0;i--)
		delete m_arMru.GetAt(i);
	m_arMru.RemoveAll();
	Clear();
	if (m_pWndSys != NULL && ::IsWindow(m_pWndSys->GetSafeHwnd()))
	{
		m_pWndSys->DestroyWindow();
		delete m_pWndSys;
	}
}


	//{{AFX_MSG_MAP(CFontListManager)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP

/////////////////////////////////////////////////////////////////////////////
// CFontListManager functions

// this function is called during the CFontListBox creation or subclassing
void CFontListManager::Init()
{
	if (m_pWndSys!= NULL)
		return;
	if (AfxFontChangeSupported())
	{
		m_pWndSys = new CFontListSysWnd;
		m_pWndSys->m_pListManager = this;
		// don't create the window before this function is called
		// because,at class instance creation, there is no application instance handle available
		m_pWndSys->CreateEx(WS_EX_TOOLWINDOW, AfxRegisterWndClass(NULL), NULL, WS_OVERLAPPED, CRect(0,0,1,1), NULL, 0, NULL);
	}
}

HBITMAP CFontListManager::GetFontTypeBitmap()
{
	return AfxGetFontTypeBitmap();
}

void CFontListManager::Clear()
{
	m_mapFaceNames.RemoveAll();
	for (int i=0; i<m_arFonts.GetSize(); i++)
		delete m_arFonts[i];
	m_arFonts.RemoveAll();
}

void CFontListManager::OnFontChange()
{
	Refresh();
	// Update all the Mru List to see if the fonts are valid
	VerifyMruLists();
	RefreshMruList(&m_gblMruList);
	for (int i=0; i< m_arMru.GetSize(); i++)
		RefreshMruList(m_arMru[i]);
}

void CFontListManager::RefreshMruList(CFontMruList* lpMruList)
{
	lpMruList->m_arFonts.RemoveAll();
	CString strFontName;
   POSITION pos;
	CFontDescriptor* pFont;
	// use the m_mapFaceNames to get the facenames of the fonts in the MRU list
   for( pos = lpMruList->m_mapFaceNames.GetStartPosition(); pos != NULL; )
   {
	   lpMruList->m_mapFaceNames.GetNextAssoc(pos, strFontName, pFont);
		// replace, if exists, by the new descriptor pointer
		if ((pFont = GetDescriptor(strFontName)) != NULL)
			lpMruList->m_arFonts.Add(pFont);
	}
	// recreate the map
	lpMruList->m_mapFaceNames.RemoveAll();
	for (int i=0; i<lpMruList->m_arFonts.GetSize(); i++)
	{
		pFont = lpMruList->m_arFonts[i];
		lpMruList->m_mapFaceNames.SetAt(pFont->m_strFaceName, pFont);
	}
	// sort the fonts
	SortFontArray(lpMruList->m_arFonts);
	// Update all the controls
	BroadCastListMessage(lpMruList, NULL, FM_CHANGEDALL, NULL);
}

BOOL CFontListManager::Refresh()
{
	Clear();
	FillFontList();
	return TRUE;
}

LONG CFontListManager::GetCount()
{
	return m_arFonts.GetSize();
}

LPCTSTR CFontListManager::GetFaceName(int index)
{
	return m_arFonts[index]->m_strFaceName;
}

CFontDescriptor* CFontListManager::GetDescriptor(int index)
{
	return m_arFonts[index];
}

CFontDescriptor* CFontListManager::GetDescriptor(LPCTSTR lpszFaceName)
{
	CFontDescriptor* lpDescriptor;
	if (m_mapFaceNames.Lookup(lpszFaceName, lpDescriptor))
		return lpDescriptor;
	else
		return NULL;
}

DWORD CFontListManager::GetType(LPCTSTR lpszFaceName)
{
	CFontDescriptor* lpDescriptor;

	if ((lpDescriptor = GetDescriptor(lpszFaceName)) != NULL)
		return lpDescriptor->m_nFontType;
	else
		return NULL;
}

DWORD CFontListManager::GetType(int index)
{
	return m_arFonts[index]->m_nFontType;
}

int CFontListManager::Add(CFontDescriptor* lpFntDescriptor)
{
	CFontDescriptor* pFntDescriptor;
	if (m_mapFaceNames.Lookup(lpFntDescriptor->m_strFaceName, pFntDescriptor))
	{
		ASSERT (pFntDescriptor != NULL);
		ASSERT (pFntDescriptor != lpFntDescriptor);
		pFntDescriptor->m_dwCharSets |= m_dwEnumCharSet;
		delete lpFntDescriptor;
		return -1;
	}
	
	int nNewIndex = m_arFonts.Add(lpFntDescriptor);

	if (nNewIndex != -1)
	{
		lpFntDescriptor->m_dwCharSets = m_dwEnumCharSet;
		m_mapFaceNames.SetAt(lpFntDescriptor->m_strFaceName, lpFntDescriptor);
	}
	return nNewIndex;
}




/////////////////////////////////////////////////////////////////////////////
// Sort function
#define GT(x,y)	((x)->m_strFaceName.CompareNoCase((y)->m_strFaceName) > 0)
#define LT(x,y)	((x)->m_strFaceName.CompareNoCase((y)->m_strFaceName) < 0)
#define SWAP(x,y) {temp = (x); (x) = (y); (y) = temp;}

void CFontListManager::SortFontArray(CFontDescriptorArray& arFonts)
{
	int nLow = 0;
	int nHigh = arFonts.GetSize()-1;

	int 	n = arFonts.GetSize();
	if (n<2) 
		return;

	CFontDescriptor* temp;
	for (int m=n--/2; m-- || n;)
	{
		temp=arFonts[m];
		int i = m*2+1;
		int j = m;

		for (; i<=n; j=i, i=i*2+1)
		{
			if (i < n) 
				(LT(arFonts[i],arFonts[i+1]))?i++:0;
			if (LT(temp,arFonts[i])) 
				arFonts[j]=arFonts[i];
			else 
				break;
		}
		arFonts[j]=temp;
		if (m==0 && n)
		{
			temp=arFonts[0];
			arFonts[0]=arFonts[n];
			arFonts[n--]=temp;++m;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// CFontListManager font enumeration functions

#define BoolToStr(x)	((x)?_T("TRUE"):_T("FALSE"))

// EnumFontProc
static int CALLBACK EnumFontProc(
  ENUMLOGFONTEX *lpelfe,    // logical-font data
  NEWTEXTMETRICEX *lpntme,  // physical-font data
  DWORD FontType,           // type of font
  LPARAM lParam             // application-defined data
)
{
	CFontListManager *pThis = reinterpret_cast<CFontListManager*>(lParam);
	BOOL bFonType = TRUE;
	BOOL bOpenType = FALSE;
	BOOL bTrueType = FALSE;
//	TCHAR szWinDir[_MAX_PATH*2];
//	::GetWindowsDirectory(szWinDir, _MAX_PATH);
TRACE("%s\n", lpelfe->elfFullName);
	DWORD dwFontType = FontType;
	if (FontType & TRUETYPE_FONTTYPE)
	{
		// In this case(TrueType,lpntme points to a NEWTEXTMETRICEX structure
		// (in the other cases, it points to a TEXTMETRIC structure)
		DWORD dwFontFlags = lpntme->ntmTm.ntmFlags;
/*
	 new in NT 5.0 
		#define NTM_NONNEGATIVE_AC  0x00010000
		#define NTM_PS_OPENTYPE     0x00020000
		#define NTM_TT_OPENTYPE     0x00040000
		#define NTM_MULTIPLEMASTER  0x00080000
		#define NTM_TYPE1           0x00100000
		#define NTM_DSIG            0x00200000

	interesting set bits for us :
		17 NTM_PS_OPENTYPE Windows 2000: PostScript OpenType font 
		18 NTM_TT_OPENTYPE Windows 2000: TrueType OpenType font 
		19 NTM_MULTIPLEMASTER Windows 2000: multiple master font 
		20 NTM_TYPE1 Windows 2000: Type 1 font 
*/
		dwFontType |= (dwFontFlags & NTM_PS_OPENTYPE ? PS_OPENTYPE_FONTTYPE : 0);
		dwFontType |= (dwFontFlags & NTM_TT_OPENTYPE ? TT_OPENTYPE_FONTTYPE : 0);
		dwFontType |= (dwFontFlags & NTM_TYPE1 ? TYPE1_FONTTYPE : 0);
	}

	// create a new font descriptor
	CFontDescriptor* pNewDescriptor = new CFontDescriptor;
	pNewDescriptor->m_nFontType = dwFontType;
	pNewDescriptor->m_strFaceName = lpelfe->elfLogFont.lfFaceName;
	pNewDescriptor->m_nImage = pThis->GetImageIndex(pNewDescriptor);

	/*
if( pNewDescriptor->m_strFaceName.CompareNoCase(_T("Modern")) == 0 ||
   pNewDescriptor->m_strFaceName.CompareNoCase(_T("Roman")) == 0 ||
   pNewDescriptor->m_strFaceName.CompareNoCase(_T("Script")) == 0
*/
if( pNewDescriptor->m_strFaceName.CompareNoCase(_T("shruti")) == 0
   )
{
	TRACE("%s FontType=%08lX (FontType & TRUETYPE_FONTTYPE) = %s imageindex=%d\n", pNewDescriptor->m_strFaceName, FontType, BoolToStr(FontType & TRUETYPE_FONTTYPE), pNewDescriptor->m_nImage );
}
	pThis->Add(pNewDescriptor);
	return TRUE;
}


void CFontListManager::FillFontList()
{
	CDC* pDesktopDC = CWnd::GetDesktopWindow()->GetWindowDC();
	HDC dc = pDesktopDC->GetSafeHdc();
	LOGFONT lf;

	::ZeroMemory(&lf, sizeof(lf));
	lf.lfCharSet = DEFAULT_CHARSET;
	m_dwEnumCharSet = DEFAULT_CHARSET;
	::EnumFontFamiliesEx (dc,&lf, (FONTENUMPROC)EnumFontProc,(LPARAM)this, NULL);
	CWnd::GetDesktopWindow()->ReleaseDC(pDesktopDC);

	SortFontArray(m_arFonts);
	// Get Default font height
	nDefFontHeight = 16;
}

int CFontListManager::GetImageIndex(CFontDescriptor* pFont)
{
	switch(pFont->m_nFontType & 0x70007)
	{
	case (TRUETYPE_FONTTYPE | PS_OPENTYPE_FONTTYPE):
	case (TRUETYPE_FONTTYPE | TT_OPENTYPE_FONTTYPE):
	case (TRUETYPE_FONTTYPE | TYPE1_FONTTYPE):
		return 3;
		break;
	case RASTER_FONTTYPE:
	case DEVICE_FONTTYPE:
    case NULL:
		return 0xFF;
		break;
	case TRUETYPE_FONTTYPE:
	default:
		return 0;
		break;
	}
}

CFontMruList* CFontListManager::AttachMruFontList(CWnd* pWnd, LPCTSTR lpszMruListName)
{
	VerifyMruLists();

	CFontMruList*	pMru = GetMruFontList(pWnd);
	UINT	nNewType;
	if (lpszMruListName == NULL)
		nNewType = FM_TYPE_LOCAL;
	else if (lpszMruListName == GLOBAL_MRULIST)
		nNewType = FM_TYPE_GLOBAL;
	else
		nNewType = FM_TYPE_CUSTOM;

	// to avoid already made attachment
	if (pMru != NULL)
	{
		if (nNewType != pMru->m_type || (nNewType == FM_TYPE_CUSTOM && pMru->m_name.Compare(lpszMruListName) != 0))
			DetachMruFontList(pWnd);
	}
	// Now, we can do the attachment
	switch(nNewType)
	{
	case FM_TYPE_LOCAL:
		pMru = new CFontMruList;
		pMru->m_type = FM_TYPE_LOCAL;
		m_arMru.Add(pMru);
		pMru->m_arWndPtr.Add(pWnd);
		break;
	case FM_TYPE_GLOBAL:
		m_mapMru.SetAt(pWnd, &m_gblMruList);
		m_gblMruList.m_arWndPtr.Add(pWnd);
		pMru = &m_gblMruList;
		break;
	case FM_TYPE_CUSTOM:
		// try to found the named Mru list
		if (!m_mapNamedMru.Lookup(lpszMruListName, pMru))
		{
			// create a new named Mru list
			pMru = new CFontMruList;
			pMru->m_type = FM_TYPE_CUSTOM;
			pMru->m_name = lpszMruListName;
			m_mapNamedMru.SetAt(lpszMruListName, pMru);
			m_arMru.Add(pMru);
		}
		pMru->m_arWndPtr.Add(pWnd);
		break;
	}
	m_mapMru.SetAt(pWnd, pMru);
	return pMru;
}

CFontMruList* CFontListManager::GetMruPtrFromName(LPCTSTR lpszMruListName)
{
	if (lpszMruListName == NULL)
		return NULL;
	if (lpszMruListName == GLOBAL_MRULIST)
		return &m_gblMruList;
	CFontMruList* pMruList = NULL;
	if (m_mapNamedMru.Lookup(lpszMruListName, pMruList) != 0)
	{
		ASSERT(pMruList != NULL);
		return pMruList;
	}
	return NULL;
}

CFontMruList* CFontListManager::DetachMruFontList(CWnd* pWnd)
{
	// return NULL in two cases :
	// - if error occurs
	// - the Mru list is a private one
	CFontMruList*	pMru = GetMruFontList(pWnd);
	if (pMru != NULL)
	{
		if (pMru->m_type == FM_TYPE_LOCAL)
		{
			// remove it from the list of mru lists
			for (int i=0; i<m_arMru.GetSize(); i++)
			{
				if (m_arMru[i] == pMru)
				{
					m_arMru.RemoveAt(i);
					break;
				}
			}
			// delete the mru list object
			delete pMru;
			pMru = NULL;
		}
		else
		{
			// the custom Mru lists are never removed
			// remove CWnd pointer from the list of the attached listboxes
			for (int i=0; i<pMru->m_arWndPtr.GetSize(); i++)
			{
				if (pMru->m_arWndPtr[i] == pWnd)
				{
					pMru->m_arWndPtr.RemoveAt(i);
					break;
				}
			}
		}
		m_mapMru.RemoveKey(pWnd);
	}
	return pMru;
}

CFontMruList* CFontListManager::GetMruFontList(CWnd* pWnd)
{
	CFontMruList* pMruList = NULL;
	if (m_mapMru.Lookup(pWnd, pMruList))
	{
		ASSERT(pMruList != NULL);
		return pMruList;
	}
	return NULL;
}

int CFontListManager::ClearMruFontList(CWnd* pWnd)
{
	VerifyMruLists();
	CFontMruList* pMru = GetMruFontList(pWnd);
	if (pMru == NULL)
		return 0;
	int nRemovedItems = pMru->GetCount();
	if (nRemovedItems == 0)
		return 0;
	pMru->RemoveAll();
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	for (int i=0; i< pMru->m_arWndPtr.GetSize(); i++)
	{
		CWnd* pWndDest = pMru->m_arWndPtr.GetAt(i);
		if (pWndDest != pWnd)
		{
			HWND hWnd = pWndDest->GetSafeHwnd();
			if (hWnd != NULL && ::IsWindow(hWnd))
				::PostMessage(hWnd, WM_FONTMRUCHANGENOTIFICATION, FM_FONTREMOVED, (LPARAM)NULL);
		}
	}
	return nRemovedItems;
}

void CFontListManager::VerifyMruLists()
{
	// validate all the CWnd pointers to delete the private Mru lists 
	// and remove pointers from Global and custom lists
	POSITION			pos;
	CWnd*				pWnd;
	CFontMruList*	pMru;

   for( pos = m_mapMru.GetStartPosition(); pos != NULL; )
   {
		m_mapMru.GetNextAssoc(pos, pWnd, pMru);
		if (::IsBadReadPtr(pWnd, sizeof(CWnd)))
		{
			// delete the private list
			if (pMru->m_type == FM_TYPE_LOCAL)
				delete pMru;
			else
			{
				// the custom Mru lists are never removed
				// remove item from the list
				for (int i=0; i<pMru->m_arWndPtr.GetSize(); i++)
				{
					if (pMru->m_arWndPtr[i] == pWnd)
					{
						pMru->m_arWndPtr.RemoveAt(i);
						break;
					}
				}
			}
			m_mapMru.RemoveKey(pWnd);
		}
   }
}

BOOL CFontListManager::IsFontInMruList(CWnd* pWnd, CFontDescriptor* pFont)
{
	ASSERT (pFont != NULL);
	return IsFontInMruList(pWnd, pFont->m_strFaceName);
}

BOOL CFontListManager::IsFontInMruList(CWnd* pWnd, LPCSTR lpszFaceName)
{
	VerifyMruLists();
	CFontMruList* pMru = GetMruFontList(pWnd);
	if (pMru == NULL)
		return FALSE;
	// in list ?
	CFontDescriptor* pMruFont;
	if (pMru->m_mapFaceNames.Lookup(lpszFaceName, pMruFont))
		return TRUE;
	return FALSE;
}

int CFontListManager::AddFontsToMruList(CWnd* pWnd, CFontDescriptorArray* lpFontArray)
{
	VerifyMruLists();
	CFontMruList* pMru = GetMruFontList(pWnd);
	if (pMru == NULL)
		return FALSE;
	// Already in list ?
	CFontDescriptor* pMruFont;
	CFontDescriptor* pFont;
	int nAdded = 0;
	for (int i=0; i<lpFontArray->GetSize(); i++)
	{
		pFont = lpFontArray->GetAt(i);
		if (pFont == NULL)
			continue;
		// Already in list ?
		if (pMru->m_mapFaceNames.Lookup(pFont->m_strFaceName, pMruFont))
			continue;
		// If not, add it
		pMru->m_arFonts.Add(pFont);
		pMru->m_mapFaceNames.SetAt(pFont->m_strFaceName, pFont);
		nAdded ++;
	}
	if (nAdded > 0)
	{
		SortFontArray(pMru->m_arFonts);
		// broadcast a message
		BroadCastMruMessage(pMru, pWnd, FM_CHANGEDALL);
	}
	return nAdded;
}

int CFontListManager::AddFontsToMruList(CWnd* pWnd, CStringArray* lparFaceNames)
{
	CFontDescriptorArray arFontArray;
	CFontDescriptor* pFont;
	for (int i=0; i<lparFaceNames->GetSize(); i++)
	{
		pFont = GetDescriptor(lparFaceNames->GetAt(i));
		if (pFont == NULL)
			continue;
		arFontArray.Add(pFont);
	}
	return AddFontsToMruList(pWnd, &arFontArray);
}

int CFontListManager::AddFontsToMruList(CWnd* pWnd, CFontDescriptor* pFont)
{
	CFontDescriptorArray arFontArray;
	if (pFont == NULL)
		return 0;
	arFontArray.Add(pFont);
	return AddFontsToMruList(pWnd, &arFontArray);
}

int CFontListManager::AddFontsToMruList(CWnd* pWnd, LPCTSTR lpszFontName)
{
	CFontDescriptor* pFont = GetDescriptor(lpszFontName);
	if (pFont == NULL)
		return FALSE;
	return AddFontsToMruList(pWnd, pFont);
}

int CFontListManager::RemoveFontsFromMruList(CWnd* pWnd, CFontDescriptor* lpFont)
{
	VerifyMruLists();
	CFontMruList* pMru = GetMruFontList(pWnd);
	if (pMru == NULL)
		return 0;
	// In list ?
	CFontDescriptor* pMruFont;
	if (pMru->m_mapFaceNames.Lookup(lpFont->m_strFaceName, pMruFont) == 0)
		return 0;
	// If yes, remove it
	for (int n=0; n<pMru->m_arFonts.GetSize(); n++)
	{
		if (pMru->m_arFonts[n] == lpFont)
		{
			pMru->m_arFonts.RemoveAt(n);
			break;
		}
	}
	pMru->m_mapFaceNames.RemoveKey(lpFont->m_strFaceName);
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	for (int i=0; i< pMru->m_arWndPtr.GetSize(); i++)
	{
		CWnd* pWndDest = pMru->m_arWndPtr.GetAt(i);
		if (pWndDest != pWnd)
		{
			HWND hWnd = pWndDest->GetSafeHwnd();
			if (hWnd != NULL && ::IsWindow(hWnd))
				::PostMessage(hWnd, WM_FONTMRUCHANGENOTIFICATION, FM_FONTREMOVED, (LPARAM)lpFont);
		}
	}
	return 1;
}

int CFontListManager::RemoveFontsFromMruList(CWnd* pWnd, CFontDescriptorArray* lpFontArray)
{
	VerifyMruLists();
	CFontMruList* pMru = GetMruFontList(pWnd);
	if (pMru == NULL)
		return 0;
	if (lpFontArray == NULL || lpFontArray->GetSize() == 0)
		return 0;
	int nRemovedItems = 0;
	CFontDescriptor* pFont;

	for (int k=0; k<lpFontArray->GetSize(); k++)
	{
		pFont = lpFontArray->GetAt(k);
		// In list ?
		CFontDescriptor* pMruFont;
		if (pMru->m_mapFaceNames.Lookup(pFont->m_strFaceName, pMruFont) == 0)
			continue;
		
		// If yes, remove it
		for (int n=0; n<pMru->m_arFonts.GetSize(); n++)
		{
			if (pMru->m_arFonts[n] == pFont)
			{
				pMru->m_arFonts.RemoveAt(n);
				pMru->m_mapFaceNames.RemoveKey(pFont->m_strFaceName);
				nRemovedItems ++;
				break;
			}
		}
	}
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	if (nRemovedItems > 0)
	{
		for (int i=0; i< pMru->m_arWndPtr.GetSize(); i++)
		{
			CWnd* pWndDest = pMru->m_arWndPtr.GetAt(i);
			if (pWndDest != pWnd)
			{
				HWND hWnd = pWndDest->GetSafeHwnd();
				if (hWnd != NULL && ::IsWindow(hWnd))
					::PostMessage(hWnd, WM_FONTMRUCHANGENOTIFICATION, FM_FONTREMOVED, (LPARAM)NULL);
			}
		}
	}
	return nRemovedItems;
}

void CFontListManager::LoadFontListSettings()
{
	// create the window for the WM_FONCHANGE broadcasted message
	// (if needed)
	AfxGetFontList()->Init();

	CString	strSection;
	CString	strEntry;
	CString	strFontList;

	strSection.Format(FNTMRUSECTION);
	CWinApp* pApp = AfxGetApp();
	// read the key
	int count;
	count = pApp->GetProfileInt(strSection, _T("count"), -1);
	if (count == -1)
		return;
	CFontMruList* pMruList;
	for (int i=0; i<count ;i++)
	{
		strEntry.Format(FNTMRUENTRYFORMAT, i);
		strFontList = pApp->GetProfileString(strSection, strEntry, NULL);  
		if (! strFontList.IsEmpty())
		{
			if (strFontList.Compare(FNTMRUGLOBALNAME) == 0)
				pMruList = &m_gblMruList;
			else
			{
				// verify if the Mru list already exists
				pMruList = _afxFontListManager.GetMruPtrFromName(strFontList);
				if (pMruList == NULL)
				{
					// create a new named Mru list
					pMruList = new CFontMruList;
					pMruList->m_type = FM_TYPE_CUSTOM;
					pMruList->m_name = strFontList;
					m_mapNamedMru.SetAt(strFontList, pMruList);
					m_arMru.Add(pMruList);
				}
			}
			ASSERT(pMruList!=NULL);
			pMruList->m_persistence = TRUE;
			ReloadMruListSettings(pMruList, NULL);
		}
	}
	
}

void CFontListManager::SaveFontListSettings()
{
	VerifyMruLists();
	CString	strSection;
	CString	strEntry;
	CString	strFontList;
	CFontMruList* pMruList;

	strSection.Format(FNTMRUSECTION);
	CWinApp* pApp = AfxGetApp();
	int count = 0;
	// remove the key
	pApp->WriteProfileString(strSection, NULL, NULL);
	if (m_gblMruList.m_persistence)
		count++;
	for (int i=0; i<m_arMru.GetSize() ;i++)
	{
		pMruList = m_arMru[i];
		if (pMruList->m_persistence)
		{
			strEntry.Format(FNTMRUENTRYFORMAT, count);
			pApp->WriteProfileString(strSection, strEntry, pMruList->m_name);  
			count++;
		}
		// to remove the key of now not permanent MRU list
		// we must do this
		if (pMruList->m_persistence || pMruList->m_persistenceRemoved)
		{
			SaveMruListSettings(pMruList);
			pMruList->m_persistenceRemoved = FALSE;
		}
	}
	pApp->WriteProfileInt(strSection, _T("count"), count);
}

BOOL CFontListManager::EnableMruListPersistence (LPCTSTR lpszMruListName, BOOL bPersistence)
{
	CFontMruList* pMruList = _afxFontListManager.GetMruPtrFromName(lpszMruListName);
	if (pMruList == NULL)
		return FALSE;
	return pMruList->EnablePersistence(bPersistence);
}

BOOL CFontListManager::EnableMruListPersistence (CFontMruList* lpMruList, BOOL bPersistence)
{	if (lpMruList == NULL)
		return FALSE;
	return lpMruList->EnablePersistence(bPersistence);
}

BOOL CFontListManager::EnableMruListPersistence (CWnd* pWnd, BOOL bPersistence)
{
	VerifyMruLists();
	if (pWnd == NULL)
		return FALSE;
	CFontMruList* pMruList = GetMruFontList(pWnd);
	if (pMruList == NULL || pMruList->m_type == FM_TYPE_LOCAL)
		return FALSE;
	return pMruList->EnablePersistence(bPersistence);
}

BOOL CFontListManager::ReloadMruListSettings(LPCTSTR lpszMruListName)
{
	CFontMruList* pMruList = _afxFontListManager.GetMruPtrFromName(lpszMruListName);
	if (pMruList == NULL)
		return FALSE;
	return ReloadMruListSettings(pMruList);
}

BOOL CFontListManager::ReloadMruListSettings(CWnd* lpWnd)
{
	VerifyMruLists();
	if (lpWnd == NULL)
		return FALSE;
	CFontMruList* pMruList = GetMruFontList(lpWnd);
	if (pMruList == NULL || pMruList->m_type == FM_TYPE_LOCAL || ! pMruList->m_persistence)
		return FALSE;
	return ReloadMruListSettings(pMruList, lpWnd);
}

BOOL CFontListManager::ReloadMruListSettings(CFontMruList* lpMruList, CWnd* lpWnd)
{
	ASSERT (lpMruList != NULL);
	CString	strSection;
	CString	strEntry;
	CString	strFont;
	strSection.Format(FNTMRUSECTIONFORMAT, lpMruList->m_name);
	CWinApp* pApp = AfxGetApp();
	// read the key
	int count;
	count = pApp->GetProfileInt(strSection, _T("count"), -1);
	if (count == -1)
	{
		lpMruList->m_persistence = FALSE;
		return FALSE;
	}
	lpMruList->RemoveAll();
	lpMruList->m_persistence = TRUE;
	lpMruList->m_persistenceRemoved = FALSE;
	CFontDescriptor* pFontDesc;
	for (int i=0; i<count ;i++)
	{
		strEntry.Format(FNTMRUFNTENTRYFORMAT, i);
		strFont = pApp->GetProfileString(strSection, strEntry, NULL);  
		if (! strFont.IsEmpty())
		{
			// get a font descriptor for this font
			pFontDesc = GetDescriptor(strFont);
			if (pFontDesc != NULL)
			{
				// add the font to the Mru list
				lpMruList->m_arFonts.Add(pFontDesc);
				lpMruList->m_mapFaceNames.SetAt(strFont, pFontDesc);
			}
		}
	}
	// broadcast a message
	BroadCastMruMessage(lpMruList, lpWnd, FM_CHANGEDALL);
	return TRUE;
}

BOOL CFontListManager::SaveMruListSettings(LPCTSTR lpszMruListName)
{
	CFontMruList* pMruList = _afxFontListManager.GetMruPtrFromName(lpszMruListName);
	if (pMruList == NULL)
		return FALSE;
	return SaveMruListSettings(pMruList);
}

BOOL CFontListManager::SaveMruListSettings(CFontMruList* lpMruList)
{
	CString	strSection;
	CString	strEntry;
	strSection.Format(FNTMRUSECTIONFORMAT, lpMruList->m_name);
	CWinApp* pApp = AfxGetApp();
	// delete the key
	pApp->WriteProfileString(strSection, NULL, NULL);
	// write the key
	if (lpMruList->m_persistence)
	{
		pApp->WriteProfileInt(strSection, _T("count"), lpMruList->m_arFonts.GetSize());
		for (int i=0; i<lpMruList->m_arFonts.GetSize() ;i++)
		{
			strEntry.Format(FNTMRUFNTENTRYFORMAT, i);
			pApp->WriteProfileString(strSection, strEntry, lpMruList->m_arFonts.GetAt(i)->m_strFaceName);  
		}
	}
	return TRUE;
}

int CFontListManager::GetProfileMruListList(CStringArray& arMruListList)
{
	CString	strSection;
	CString	strEntry;
	CString	strFontList;

	strSection.Format(FNTMRUSECTION);
	CWinApp* pApp = AfxGetApp();
	// read the key
	int count;
	count = pApp->GetProfileInt(strSection, _T("count"), -1);
	if (count == -1)
		return 0;
	for (int i=0; i<count ;i++)
	{
		strEntry.Format(FNTMRUENTRYFORMAT, i);
		strFontList = pApp->GetProfileString(strSection, strEntry, NULL);  
		if (! strFontList.IsEmpty())
			arMruListList.Add(strFontList);
	}
	return arMruListList.GetSize();
}

BOOL CFontListManager::SaveMruListSettings(CWnd* lpWnd)
{
	VerifyMruLists();
	if (lpWnd == NULL)
		return FALSE;
	CFontMruList* pMruList = GetMruFontList(lpWnd);
	if (pMruList == NULL || pMruList->m_type == FM_TYPE_LOCAL)
		return FALSE;
	// The Mru list can be a newly permanent one, so it can have no entry in the
	// list of permanent Mru lists in the inifile.
	// We must verify it to add it
	// The Mru list can be a newly persistent removed one, so it can have an entry in the
	// list of permanent Mru lists in the inifile.
	// We must remove it
	CString strMruName = pMruList->m_name;
	CStringArray arMruListList;
	BOOL bFound = FALSE;
	int nbList = 0;
	nbList = GetProfileMruListList(arMruListList);
	for (int i=0; i<nbList;i++)
	{
		if (strMruName.Compare(arMruListList[i]) == 0)
		{
			bFound = TRUE;
			break;
		}
	}
	CString	strSection;
	CString	strEntry;
	CString	strFontList;

	strSection.Format(FNTMRUSECTION);
	CWinApp* pApp = AfxGetApp();

	if (pMruList->m_persistence && !bFound)
	{
		// add it
		pApp->WriteProfileInt(strSection, _T("count"), (nbList+1));
		strEntry.Format(FNTMRUENTRYFORMAT, (nbList+1));
		pApp->WriteProfileString(strSection, strEntry, pMruList->m_name);  
	}
	if (!pMruList->m_persistence && bFound)
	{
		// add it
		pApp->WriteProfileInt(strSection, _T("count"), (nbList-1));
		strEntry.Format(FNTMRUENTRYFORMAT, (nbList-1));
		pApp->WriteProfileString(strSection, strEntry, NULL);  
	}

	return SaveMruListSettings(pMruList);
}

BOOL CFontListManager::IsMruListPersistent(LPCTSTR lpszMruListName)
{
	CFontMruList* pMruList = GetMruPtrFromName(lpszMruListName);
	if (pMruList == NULL)
		return FALSE;
	return pMruList->IsPersistent();
}

BOOL CFontListManager::IsMruListPersistent(CWnd* pWnd)
{
	VerifyMruLists();
	if (pWnd == NULL)
		return FALSE;
	CFontMruList* pMruList = GetMruFontList(pWnd);
	if (pMruList == NULL || pMruList->m_type == FM_TYPE_LOCAL || ! pMruList->m_persistence)
		return FALSE;
	return pMruList->IsPersistent();
}

void CFontListManager::BroadCastFontListChangeMessage(CFontMruList* pMru, CWnd* pWnd, UINT msgType, WPARAM msg, LPARAM lParam)
{
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	HWND hWnd;
	for (int i=0; i< pMru->m_arWndPtr.GetSize(); i++)
	{
		CWnd* pWndDest = pMru->m_arWndPtr.GetAt(i);
		if (pWndDest != pWnd)
		{
			hWnd = pWndDest->GetSafeHwnd();
			if (hWnd != NULL && ::IsWindow(hWnd))
				::PostMessage(hWnd, msgType, msg, (LPARAM)lParam);
		}
	}
}

void CFontListManager::BroadCastMruMessage(CFontMruList* pMru, CWnd* pWnd, WPARAM msg, LPARAM lParam)
{
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	BroadCastFontListChangeMessage(pMru, pWnd, WM_FONTMRUCHANGENOTIFICATION, msg, (LPARAM)lParam);
}

void CFontListManager::BroadCastListMessage(CFontMruList* pMru, CWnd* pWnd, WPARAM msg, LPARAM lParam)
{
	// Post a message to all the windows connected to this MRU list
	// except the calling one.
	BroadCastFontListChangeMessage(pMru, pWnd, WM_FONTCHANGENOTIFICATION, msg, (LPARAM)lParam);
}
