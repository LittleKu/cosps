// SepComboTestDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "SepComboBox.h"


// CSepComboTestDlg dialog
class CSepComboTestDlg : public CDialog
{
// Construction
public:
   CSepComboTestDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
   enum { IDD = IDD_SEPCOMBOTEST_DIALOG };

   protected:
   virtual void DoDataExchange(CDataExchange* pDX);   // DDX/DDV support


// Implementation
protected:
   HICON m_hIcon;

   // Generated message map functions
   virtual BOOL OnInitDialog();
   afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
   afx_msg void OnPaint();
   afx_msg HCURSOR OnQueryDragIcon();
   afx_msg LONG OnSelectionChanged(UINT wParam, LONG lParam);
   DECLARE_MESSAGE_MAP()

public:

   CSeparatorComboBox m_ctrlCombo;
   afx_msg void OnCbnSelchangeCombo1();
   afx_msg void OnCbnEditchangeCombo1();
};
