// SepComboTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SepComboTest.h"
#include "SepComboTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ID_DROP_BUTTON 200

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
   CAboutDlg();

// Dialog Data
   enum { IDD = IDD_ABOUTBOX };

   protected:
   virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
   DECLARE_MESSAGE_MAP()
public:
//   afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//   ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


// CSepComboTestDlg dialog



CSepComboTestDlg::CSepComboTestDlg(CWnd* pParent /*=NULL*/)
   : CDialog(CSepComboTestDlg::IDD, pParent)
{
   m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSepComboTestDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_COMBO1, m_ctrlCombo);
}

BEGIN_MESSAGE_MAP(CSepComboTestDlg, CDialog)
   ON_WM_SYSCOMMAND()
   ON_WM_PAINT()
   ON_WM_QUERYDRAGICON()
   ON_CBN_SELCHANGE(IDC_COMBO1, OnCbnSelchangeCombo1)
   ON_CBN_EDITCHANGE(IDC_COMBO1, OnCbnEditchangeCombo1)
END_MESSAGE_MAP()


// CSepComboTestDlg message handlers


void CSepComboTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
   if ((nID & 0xFFF0) == IDM_ABOUTBOX)
   {
      CAboutDlg dlgAbout;
      dlgAbout.DoModal();
   }
   else
   {
      CDialog::OnSysCommand(nID, lParam);
   }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSepComboTestDlg::OnPaint() 
{
   if (IsIconic())
   {
      CPaintDC dc(this); // device context for painting

      SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

      // Center icon in client rectangle
      int cxIcon = GetSystemMetrics(SM_CXICON);
      int cyIcon = GetSystemMetrics(SM_CYICON);
      CRect rect;
      GetClientRect(&rect);
      int x = (rect.Width() - cxIcon + 1) / 2;
      int y = (rect.Height() - cyIcon + 1) / 2;

      // Draw the icon
      dc.DrawIcon(x, y, m_hIcon);
   }
   else
   {
      CDialog::OnPaint();
   }
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSepComboTestDlg::OnQueryDragIcon()
{
   return static_cast<HCURSOR>(m_hIcon);
}


BOOL CSepComboTestDlg::OnInitDialog()
{
   CDialog::OnInitDialog();

   // Add "About..." menu item to system menu.

   // IDM_ABOUTBOX must be in the system command range.
   ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
   ASSERT(IDM_ABOUTBOX < 0xF000);

   CMenu* pSysMenu = GetSystemMenu(FALSE);
   if (pSysMenu != NULL)
   {
      CString strAboutMenu;
      strAboutMenu.LoadString(IDS_ABOUTBOX);
      if (!strAboutMenu.IsEmpty())
      {
         pSysMenu->AppendMenu(MF_SEPARATOR);
         pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
      }
   }

   // Set the icon for this dialog.  The framework does this automatically
   //  when the application's main window is not a dialog
   SetIcon(m_hIcon, TRUE);         // Set big icon
   SetIcon(m_hIcon, FALSE);      // Set small icon

   // TODO: Add extra initialization here
   m_ctrlCombo.AddString("All Fruits");
   m_ctrlCombo.AddString("Banana");
   m_ctrlCombo.AddString("Orange");
   m_ctrlCombo.AddString("Apple");
   m_ctrlCombo.AddString("Pear");
   m_ctrlCombo.AddString("Watermelon");
   m_ctrlCombo.AddString("*Add/Edit Fruit");

   m_ctrlCombo.SetSeparator(0);
   m_ctrlCombo.SetSeparator(5);  //-1);
//   m_ctrlCombo.AdjustItemHeight(-1);

   m_ctrlCombo.SetSepLineStyle(PS_SOLID);
   m_ctrlCombo.SetSepLineColor(0);
   m_ctrlCombo.SetHorizontalMargin(1);         

   m_ctrlCombo.SetCurSel(0);
   OnCbnSelchangeCombo1();

   return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSepComboTestDlg::OnCbnSelchangeCombo1()
{
   int nSel = m_ctrlCombo.GetCurSel();
   if (-1 !=nSel)
   {
      CString str;
      m_ctrlCombo.GetLBText(nSel, str);
      SetDlgItemText(IDC_STATIC1, "Selected: "+str);
   }
}


void CSepComboTestDlg::OnCbnEditchangeCombo1()
{
   CString str;
   m_ctrlCombo.GetWindowText(str);
   SetDlgItemText(IDC_STATIC1, "Changed to: "+str);
}
