#if !defined(AFX_TREECOMBOBOX_H__B9544E92_7215_4D8B_9DF2_67F232BA4014__INCLUDED_)
#define AFX_TREECOMBOBOX_H__B9544E92_7215_4D8B_9DF2_67F232BA4014__INCLUDED_

#include "ComboTreeCtrl.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TreeComboBox.h : header file
//

#ifndef	COLOR_RED
#define COLOR_RED			RGB(220,0,0)
#endif	//COLOR_RED
#ifndef	COLOR_ALERT
#define COLOR_ALERT			RGB(255,180,180)
#endif	//COLOR_ALERT
/////////////////////////////////////////////////////////////////////////////
// CTreeComboBox window

class CTreeComboBox : public CComboBox
{
// Construction
public:
	CTreeComboBox();

// Attributes
public:
	BOOL m_bTree;

// Operations
public:
	void DisplayTree();
	void SetTitle(CString sTitle);
	BOOL IsAlertBkg(){return m_bAlertBkg;}
	BOOL IsAlertText(){return m_bAlertText;}
	CTreeCtrl& GetTreeCtrl(){return m_Tree;}
	int GetDroppedWidth(){return m_droppedWidth;};
	int GetDroppedHeight(){return m_droppedHeight;};
	void SetDroppedWidth(int nWidth){m_droppedWidth = nWidth;};
	void SetDroppedHeight(int nHeight){m_droppedHeight = nHeight;};
	void AlertBkg(BOOL bAlert = TRUE){m_bAlertBkg = bAlert;Invalidate();};
	void AlertText(BOOL bAlert = TRUE){m_bAlertText = bAlert;Invalidate();};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTreeComboBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	UINT GetTreeCount();
	void TreeCtrlDone();
	virtual ~CTreeComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTreeComboBox)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG
	afx_msg LRESULT OnCloseControl(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

private:
	BOOL m_bAlertBkg;
	BOOL m_bAlertText;
	int m_droppedWidth;
	int m_droppedHeight;
	HBRUSH m_hBrushAlert;
	CComboTreeCtrl m_Tree;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TREECOMBOBOX_H__B9544E92_7215_4D8B_9DF2_67F232BA4014__INCLUDED_)
