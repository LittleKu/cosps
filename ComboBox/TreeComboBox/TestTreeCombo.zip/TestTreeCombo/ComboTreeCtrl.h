#if !defined(AFX_COMBOTREECTRL_H__FE1D96F3_B70F_4E65_8203_B37AE69DB82D__INCLUDED_)
#define AFX_COMBOTREECTRL_H__FE1D96F3_B70F_4E65_8203_B37AE69DB82D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ComboTreeCtrl.h : header file
//

#define TREECTRL_CHECK_STATE_CHANGE (WM_USER + 100)
#define WMU_CLOSE_CONTROL			(WM_USER + 101)
/////////////////////////////////////////////////////////////////////////////
// CComboTreeCtrl window

class CTreeComboBox;

class CComboTreeCtrl : public CTreeCtrl
{
// Construction
public:
	CComboTreeCtrl();

// Attributes
public:

// Operations
public:
	void Display(CRect rc);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboTreeCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	void Init(CTreeComboBox* pCombo){m_pCombo = pCombo;};
	virtual ~CComboTreeCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CComboTreeCtrl)
	afx_msg void OnKillfocus(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydown(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg LRESULT OnTreeCtrlCheckStateChange(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	CTreeComboBox* m_pCombo;
	int UncheckChilds(HTREEITEM hItem = NULL, BOOL bRecurse = TRUE);
	void GetTreeHierarchy(HTREEITEM hItem, CString &sTreeHierarchy, const BOOL bTopToBottom);
	HTREEITEM FindItem(const CString& sName, HTREEITEM hRoot);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBOTREECTRL_H__FE1D96F3_B70F_4E65_8203_B37AE69DB82D__INCLUDED_)
