// TestTreeComboView.cpp : implementation of the CTestTreeComboView class
//

#include "stdafx.h"
#include "TestTreeCombo.h"

#include "TestTreeComboDoc.h"
#include "TestTreeComboView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboView

IMPLEMENT_DYNCREATE(CTestTreeComboView, CFormView)

BEGIN_MESSAGE_MAP(CTestTreeComboView, CFormView)
	//{{AFX_MSG_MAP(CTestTreeComboView)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboView construction/destruction

CTestTreeComboView::CTestTreeComboView()
	: CFormView(CTestTreeComboView::IDD)
{
	//{{AFX_DATA_INIT(CTestTreeComboView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CTestTreeComboView::~CTestTreeComboView()
{
}

void CTestTreeComboView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestTreeComboView)
	DDX_Control(pDX, IDC_COMBO1, m_Combo);
	//}}AFX_DATA_MAP
}

BOOL CTestTreeComboView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CTestTreeComboView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	CTreeCtrl& Tree = m_Combo.GetTreeCtrl();
	Tree.InsertItem("One");
	HTREEITEM hTwo = Tree.InsertItem("Two");
	Tree.InsertItem("TwentyTwo",hTwo);
	HTREEITEM hChild = Tree.InsertItem("Three");
	Tree.InsertItem("ThirtyTwo",hChild);
	Tree.InsertItem("ThirtyThree",hChild);
	Tree.InsertItem("ThirtyFour",hChild);
	Tree.InsertItem("Four");
	hChild = Tree.InsertItem("Five");
	Tree.InsertItem("FiftyTwo",hChild);
	Tree.InsertItem("FiftyThree",hChild);
	Tree.InsertItem("FiftyFour",hChild);
	hChild = Tree.InsertItem("FiftyFive",hChild);
	Tree.InsertItem("FiveHundredOne",hChild);

	m_Combo.SetTitle("Click here for options");
	Tree.ModifyStyle(TVS_CHECKBOXES,0);
	Tree.ModifyStyle(0,TVS_CHECKBOXES);
//	m_Combo.AlertBkg();
//	m_Combo.AlertText();

	CString sTemp;
	sTemp.Format("Number of combo item %d",m_Combo.GetCount());
	SetDlgItemText(IDC_EDIT1,sTemp);
}

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboView printing

BOOL CTestTreeComboView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestTreeComboView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTestTreeComboView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CTestTreeComboView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboView diagnostics

#ifdef _DEBUG
void CTestTreeComboView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTestTreeComboView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CTestTreeComboDoc* CTestTreeComboView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestTreeComboDoc)));
	return (CTestTreeComboDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboView message handlers

void CTestTreeComboView::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here

	TRACE0("\n The user has done with treectrl \n");
}
