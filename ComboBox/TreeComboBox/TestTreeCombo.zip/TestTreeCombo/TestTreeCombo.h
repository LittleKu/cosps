// TestTreeCombo.h : main header file for the TESTTREECOMBO application
//

#if !defined(AFX_TESTTREECOMBO_H__C08058C4_169B_4B9D_B6F1_AA4714875E89__INCLUDED_)
#define AFX_TESTTREECOMBO_H__C08058C4_169B_4B9D_B6F1_AA4714875E89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestTreeComboApp:
// See TestTreeCombo.cpp for the implementation of this class
//

class CTestTreeComboApp : public CWinApp
{
public:
	CTestTreeComboApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestTreeComboApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTestTreeComboApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTTREECOMBO_H__C08058C4_169B_4B9D_B6F1_AA4714875E89__INCLUDED_)
