// TreeComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "TreeComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeComboBox

CTreeComboBox::CTreeComboBox()
	:m_bTree(FALSE)
	,m_bAlertBkg(FALSE)
	,m_bAlertText(FALSE)
	,m_droppedHeight(150)
	,m_droppedWidth(100)
{
	m_hBrushAlert =	CreateSolidBrush(COLOR_ALERT);
}

CTreeComboBox::~CTreeComboBox()
{
	DeleteObject(m_hBrushAlert);
}


BEGIN_MESSAGE_MAP(CTreeComboBox, CComboBox)
	//{{AFX_MSG_MAP(CTreeComboBox)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WMU_CLOSE_CONTROL,OnCloseControl)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeComboBox message handlers

void CTreeComboBox::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class

	CComboBox::PreSubclassWindow();

	CRect rect(0, 0, 0, 0);
	DWORD dwStyle =  WS_POPUP | WS_BORDER | TVS_DISABLEDRAGDROP | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | TVS_FULLROWSELECT | TVS_CHECKBOXES;
	m_Tree.CreateEx(0, WC_TREEVIEW, NULL, dwStyle, rect, GetParent(), 0, NULL);
	m_Tree.Init(this);

	GetClientRect(rect);
	SetDroppedWidth(rect.Width());
	SetDroppedHeight(m_droppedHeight);

	dwStyle = 0x03 & GetStyle();
	ASSERT(dwStyle == CBS_DROPDOWNLIST);
}

BOOL CTreeComboBox::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class

	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_DOWN)
	{
		DisplayTree();
		return TRUE;
	}

	return CComboBox::PreTranslateMessage(pMsg);
}

void CTreeComboBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	m_bTree = ! m_bTree;
	if(m_bTree)DisplayTree();

//	CComboBox::OnLButtonDown(nFlags, point);
}

void CTreeComboBox::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	OnLButtonDown(nFlags,point);

//	CComboBox::OnLButtonDblClk(nFlags, point);
}

void CTreeComboBox::TreeCtrlDone()
{
	CWnd* pParent = GetParent();

	if(pParent != NULL)
	{
		WPARAM wParam = MAKEWPARAM(GetDlgCtrlID(),CBN_CLOSEUP);
		pParent->SendMessage(WM_COMMAND,wParam,(LPARAM)m_hWnd);
	}
}

LRESULT CTreeComboBox::OnCloseControl(WPARAM wParam, LPARAM lParam)
{
	TreeCtrlDone();
	m_Tree.ShowWindow(SW_HIDE);
	m_bTree = FALSE;
	if(GetCount())SetCurSel(0);
	AlertBkg(FALSE);

	return 1;
}

HBRUSH CTreeComboBox::CtlColor(CDC* pDC, UINT nCtlColor)
{
	HBRUSH hbr = NULL;

	// TODO: Change any attributes of the DC here

	if(nCtlColor == CTLCOLOR_EDIT)
	{
		if(! m_bAlertText)pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
		else pDC->SetTextColor(COLOR_RED);
		if(! m_bAlertBkg)pDC->SetBkColor(GetSysColor(COLOR_WINDOW));
		else pDC->SetBkColor(COLOR_ALERT);
		if(m_bAlertText || m_bAlertBkg)hbr = m_hBrushAlert;
		pDC->SetBkMode(TRANSPARENT);
	}

	// TODO: Return a different brush if the default is not desired

	return hbr;
}

void CTreeComboBox::DisplayTree()
{
	CRect rc;
	GetWindowRect(rc);
	rc.top = rc.bottom + 1;
	rc.right = GetDroppedWidth();
	rc.bottom = GetDroppedHeight();
	m_Tree.Display(rc);
	SetCurSel(-1);
}

void CTreeComboBox::SetTitle(CString sTitle)
{
	if(GetCount())
	{
		SetCurSel(0);
		return;
	}

	ResetContent();
	AddString(sTitle);
	SetCurSel(0);
}
