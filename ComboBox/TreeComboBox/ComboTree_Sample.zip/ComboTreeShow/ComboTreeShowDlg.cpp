/* Standard Disclaimer: 
Copyright (C) 2000  Dennis Howard
This file is free software; you can redistribute it and/or
modify it without any conditions. There is no warranty,
implied or expressed, as to validity or fitness for a particular purpose.
*/


// ComboTreeShowDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ComboTreeShow.h"
#include "ComboTreeShowDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CComboTreeShowDlg dialog

CComboTreeShowDlg::CComboTreeShowDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CComboTreeShowDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComboTreeShowDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CComboTreeShowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComboTreeShowDlg)
	DDX_Control(pDX, IDC_LIST_CHECKED, m_listChecked);
	DDX_Control(pDX, IDC_PATH, m_Path);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CComboTreeShowDlg, CDialog)
	//{{AFX_MSG_MAP(CComboTreeShowDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELENDOK(IDC_COMBO_TREE, OnSelendokComboTree)
	ON_CBN_SELENDCANCEL(IDC_COMBO_TREE, OnSelendcancelComboTree)
	ON_CBN_KILLFOCUS(IDC_COMBO_TREE, OnKillfocusComboTree)
	ON_CBN_SELCHANGE(IDC_COMBO_TREE, OnSelchangeComboTree)
	ON_CBN_DBLCLK(IDC_COMBO_TREE, OnDblclkComboTree)
	ON_CBN_SETFOCUS(IDC_COMBO_TREE, OnSetfocusComboTree)
	ON_CBN_CLOSEUP(IDC_COMBO_TREE, OnCloseupComboTree)
	ON_CBN_DROPDOWN(IDC_COMBO_TREE, OnDropdownComboTree)
	//}}AFX_MSG_MAP
	ON_CONTROL  (NOTIFY_TREECOMBO_CHECK, IDC_COMBO_TREE, OnComboTreeCheck)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboTreeShowDlg message handlers

BOOL CComboTreeShowDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_ComboTree.SetHasCheckboxes (TRUE); //Must set before tree is created
	m_ComboTree.SubclassDlgItem (IDC_COMBO_TREE, this);
	PopulateCombo ();

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CComboTreeShowDlg::PopulateCombo()
{
    HTREEITEM hNode = NULL;
	HTREEITEM hCheckedNode = NULL;

	//Test Data

	hNode = m_ComboTree.AddString ("Plants/Trees");
	hCheckedNode = m_ComboTree.AddString ("Plants/Flowers/Daisy");
	

	hNode = m_ComboTree.AddString ("Plants/Flowers/Violet");
	hNode = m_ComboTree.AddString ("Plants/Flowers/Rose");
	hNode = m_ComboTree.AddString ("Plants/Trees/Oak");
	hNode = m_ComboTree.AddString ("Animals/Mammals/Bear");
	hNode = m_ComboTree.AddString ("Animals/Mammals/Monotremes/Platypus");
	hNode = m_ComboTree.AddString ("Animals/Mammals/Bear");
	hNode = m_ComboTree.AddString ("Plants/Fungi/Mushrooms/Common/Boletes/Queen Bolete");
	hNode = m_ComboTree.AddString ("Plants/Fungi/Mushrooms/Common/Boletes/North America/Red-Stemmed Bitter Bolete"); //long to test tooltips

	hNode = m_ComboTree.AddString ("Plants/Fungi/Slime Molds/Dictyostelium");


	hNode = m_ComboTree.AddString ("Animals/Mammals/Rodents/Chipmunk/Eastern Striped");
	hNode = m_ComboTree.AddString ("Animals/Mammals/Rodents/Chipmunk/Western Spotted");
	hNode = m_ComboTree.AddString ("Animals/Mammals/Rodents/Aplodontia rufa (Mountain Beaver)");


	hNode = m_ComboTree.FindString ("Animals/Mammals/Giraffe");
	hNode = m_ComboTree.FindString ("Animals/Mammals");
	
	hNode = m_ComboTree.FindString ("Plants/Fungi/Mushrooms/Giant Puffball");
	hNode = m_ComboTree.AddString ("Plants/Fungi/Mushrooms/Giant Puffball");

	hNode = m_ComboTree.SelectString ("Plants/Flowers/Violet");
	m_ComboTree.DeleteString (hNode);

	hNode = m_ComboTree.SelectString ("Animals/Mammals/Monotremes/Platypus");

	if (m_ComboTree.GetHasCheckboxes())
	{
		m_ComboTree.SetCheck (hCheckedNode);
	}

}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CComboTreeShowDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CComboTreeShowDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CComboTreeShowDlg::OnSelendokComboTree() 
{
	TRACE0("CComboTreeShowDlg::Combo box selection\n");	
	CString Path = m_ComboTree.GetCurrentTreePath ();
	m_Path.SetWindowText (Path);
}

void CComboTreeShowDlg::OnSelendcancelComboTree() 
{
	TRACE0("Combo box cancelled\n");	

	CString Path = m_ComboTree.GetCurrentTreePath ();
	m_Path.SetWindowText (Path);
}

void CComboTreeShowDlg::OnKillfocusComboTree() 
{
	TRACE0("Combo box kill focus\n");	
	
}

void CComboTreeShowDlg::OnSelchangeComboTree() 
{
	TRACE0("Combo box selection change\n");	
	CString Path = m_ComboTree.GetCurrentTreePath ();
	m_Path.SetWindowText (Path);

}

void CComboTreeShowDlg::OnDblclkComboTree() 
{
	TRACE0("Combo box double click\n");	
	
}

void CComboTreeShowDlg::OnSetfocusComboTree() 
{
	TRACE0("Combo box set focus\n");	
}

void CComboTreeShowDlg::OnCloseupComboTree() 
{
	TRACE0("Combo box dropdown closed\n");	
	
}

void CComboTreeShowDlg::OnDropdownComboTree() 
{
	TRACE0("Combo box dropdown open\n");	
}



void CComboTreeShowDlg::OnComboTreeCheck ()
{
	TRACE0("Combo box checked\n");	

	m_listChecked.ResetContent ();
	CString path;
	HTREEITEM hItem = m_ComboTree.GetFirstCheckedItem();
	while (hItem)
	{
		path = m_ComboTree.GetTreePath (hItem);
		m_listChecked.AddString (path);
		hItem = m_ComboTree.GetNextCheckedItem( hItem );
	}

}
