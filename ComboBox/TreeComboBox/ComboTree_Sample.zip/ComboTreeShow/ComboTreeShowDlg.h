/* Standard Disclaimer: 
Copyright (C) 2000  Dennis Howard
This file is free software; you can redistribute it and/or
modify it without any conditions. There is no warranty,
implied or expressed, as to validity or fitness for a particular purpose.
*/

// ComboTreeShowDlg.h : header file
//
#if !defined(AFX_COMBOTREESHOWDLG_H__E8095C42_EA34_458C_8A1D_100E838109C3__INCLUDED_)
#define AFX_COMBOTREESHOWDLG_H__E8095C42_EA34_458C_8A1D_100E838109C3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "ComboTree.h"

/////////////////////////////////////////////////////////////////////////////
// CComboTreeShowDlg dialog

class CComboTreeShowDlg : public CDialog
{
// Construction
public:
	CComboTreeShowDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CComboTreeShowDlg)
	enum { IDD = IDD_COMBOTREESHOW_DIALOG };
	CListBox	m_listChecked;
	CStatic	m_Path;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboTreeShowDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	void PopulateCombo();


// Implementation
protected:
	HICON m_hIcon;

//ComboBox with tree drop down
	ComboTree m_ComboTree;

	// Generated message map functions
	//{{AFX_MSG(CComboTreeShowDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelendokComboTree();
	afx_msg void OnSelendcancelComboTree();
	afx_msg void OnKillfocusComboTree();
	afx_msg void OnSelchangeComboTree();
	afx_msg void OnDblclkComboTree();
	afx_msg void OnSetfocusComboTree();
	afx_msg void OnCloseupComboTree();
	afx_msg void OnDropdownComboTree();
	//}}AFX_MSG
	afx_msg void OnComboTreeCheck ();

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBOTREESHOWDLG_H__E8095C42_EA34_458C_8A1D_100E838109C3__INCLUDED_)
