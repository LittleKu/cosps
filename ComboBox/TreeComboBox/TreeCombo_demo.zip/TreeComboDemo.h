// TreeComboDemo.h : main header file for the TREECOMBODEMO application
//

#if !defined(AFX_TREECOMBODEMO_H__45D55A5B_996A_4882_9099_BDB5A2720C02__INCLUDED_)
#define AFX_TREECOMBODEMO_H__45D55A5B_996A_4882_9099_BDB5A2720C02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTreeComboDemoApp:
// See TreeComboDemo.cpp for the implementation of this class
//

class CTreeComboDemoApp : public CWinApp
{
public:
	CTreeComboDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTreeComboDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTreeComboDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TREECOMBODEMO_H__45D55A5B_996A_4882_9099_BDB5A2720C02__INCLUDED_)
