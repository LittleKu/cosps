

#pragma once

class CComboTree : public CTreeCtrl
{

public:
	CComboTree()
	{
		m_pCombo = NULL;
		m_allowfolders = TRUE;
	}

	virtual ~CComboTree()
	{
	}


	void SetCombo(CComboBox *pCombo)
	{
		m_pCombo = pCombo;
	}

	CComboBox * GetCombo()
	{
		return m_pCombo;
	}

	void AllowFolders(BOOL allow)
	{
		m_allowfolders = allow;
	}

	

private:
	CComboBox *m_pCombo;
	BOOL m_allowfolders;

	//{{AFX_VIRTUAL(CComboTree)
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CComboTree)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

