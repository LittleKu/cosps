


#include "stdafx.h"
#include "ComboEdit.h"
#include "TreeComboBox.h"


BEGIN_MESSAGE_MAP(CComboEdit, CEdit)
	//{{AFX_MSG_MAP(CComboEdit)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CComboEdit::OnChange() 
{
	if (m_pCombo)
	{
		((CTreeComboBox*)m_pCombo)->UpdateIcon(0);	
		UpdateTooltip();
	}
}


void CComboEdit::SelectText(BOOL multi, int pos)
{
	if (multi)
	{
		if (pos==-1)
			SetSel(LineIndex(GetLineCount()-1),-1);
		else
		{
			CString str;
			GetWindowText(str);
			int end = str.Find("\r\n",pos);
			SetSel(pos,end);
		}
	}
	else
		SetSel(0,-1);
}


int CComboEdit::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CEdit::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_tooltip.Create(this);
	m_tooltip.AddTool(this, "");
	m_tooltip.SetMaxTipWidth(500);
	m_tooltip.SetMargin(CRect(1,1,1,1));
	
	return 0;
}

BOOL CComboEdit::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message==WM_MOUSEMOVE)
	{
		if (((CTreeComboBox*)m_pCombo)->IsMultiline())
		{
			m_tooltip.Activate(TRUE);
			m_tooltip.RelayEvent(pMsg);		
		}
	}
	if (pMsg->message == WM_KEYDOWN ||
		pMsg->message == WM_LBUTTONDOWN)
		((CTreeComboBox*)m_pCombo)->HideDropDown();


	if (pMsg->message == WM_SYSKEYDOWN && pMsg->wParam==VK_DOWN)
		((CTreeComboBox*)m_pCombo)->ShowDropDown();

	if (pMsg->message == WM_KEYDOWN && pMsg->wParam==VK_TAB)
	{
		if (GetKeyState(VK_SHIFT)<0)
			((CDialog*)((CTreeComboBox*)m_pCombo)->GetParent())->PrevDlgCtrl();
		else
			((CDialog*)((CTreeComboBox*)m_pCombo)->GetParent())->NextDlgCtrl();
	}

	return CEdit::PreTranslateMessage(pMsg);
}

