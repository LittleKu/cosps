
#pragma once

class CComboEdit : public CEdit
{

public:

	CComboEdit()
	{
		m_pCombo = NULL;
	}

	virtual ~CComboEdit()
	{
	}

	void UpdateTooltip()
	{
		CString str;
		GetWindowText(str);
		m_tooltip.UpdateTipText(str,this);
		m_pCombo->SetWindowText(str);
	}


	void SetCombo(CComboBox * pCombo)
	{
		m_pCombo = pCombo;
	}

	void SelectText(BOOL multi, int pos=-1);


private:
	CToolTipCtrl m_tooltip;
	CComboBox * m_pCombo;

	//{{AFX_VIRTUAL(CComboEdit)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CComboEdit)
	afx_msg void OnChange();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

