// no_flicker_resize_grpbox.h
