// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__89E91691_CAF7_4ABB_8DA4_530E150636E5__INCLUDED_)
#define AFX_MAINDLG_H__89E91691_CAF7_4ABB_8DA4_530E150636E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "nfresize.h"
#include "atldlgs.h"

class CMainDlg : 
	public CDialogImpl<CMainDlg>, 
	public CNoFlickerDialogResize<CMainDlg>,
	public CUpdateUI<CMainDlg>,
	public CMessageFilter, 
	public CIdleHandler
{
public:
	enum { IDD = IDD_MAINDLG };
	
	CFont m_Font;
	CListBox m_ListBox;
	CTreeViewCtrl m_Tree;

	virtual BOOL PreTranslateMessage(MSG* pMsg)
	{
		return IsDialogMessage(pMsg);
	}

	virtual BOOL OnIdle()
	{
		return FALSE;
	}

	BEGIN_UPDATE_UI_MAP(CMainDlg)
	END_UPDATE_UI_MAP()

	BEGIN_MSG_MAP(CMainDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		COMMAND_HANDLER(IDC_CHECK_DAF, BN_CLICKED, OnClickedCheck_daf)
		CHAIN_MSG_MAP(CNoFlickerDialogResize<CMainDlg>)
		COMMAND_HANDLER(IDC_BUTTON_CHANGE_FONT, BN_CLICKED, OnClickedButton_change_font)
		COMMAND_HANDLER(IDC_CHECK_XPGB, BN_CLICKED, OnClickedCheck_xpgb)
	END_MSG_MAP()

	BEGIN_DLGRESIZE_MAP(CMainDlg)

		DLGRESIZE_CONTROL(IDC_GRP_TR,				DLSZ_SIZE_X)
			DLGRESIZE_CONTROL(IDC_LIST_TR,			DLSZ_SIZE_X)

		DLGRESIZE_CONTROL(IDC_GRP_BL,				DLSZ_SIZE_Y)
			DLGRESIZE_CONTROL(IDC_GRP_BL2,			DLSZ_SIZE_Y)
			DLGRESIZE_CONTROL(IDC_GRP_BL3,			DLSZ_SIZE_Y)

		DLGRESIZE_CONTROL(IDC_GRP_BR,				DLSZ_SIZE_X|DLSZ_SIZE_Y)
			DLGRESIZE_CONTROL(IDC_TREE_BR,			DLSZ_SIZE_X|DLSZ_SIZE_Y)

		DLGRESIZE_CONTROL(IDOK,						DLSZ_MOVE_X|DLSZ_MOVE_Y)
		DLGRESIZE_CONTROL(IDC_CHECK_DAF,			DLSZ_MOVE_Y)
		DLGRESIZE_CONTROL(IDC_BUTTON_CHANGE_FONT,	DLSZ_MOVE_Y)
		DLGRESIZE_CONTROL(IDC_CHECK_XPGB,			DLSZ_MOVE_Y)
		
    END_DLGRESIZE_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		DlgResize_Init();
		
		SetMinTrackSize(440,350);
		SetMaxTrackSize(800,600);

		// center the dialog on the screen
		CenterWindow();

		// set icons
		HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		SetIcon(hIcon, TRUE);
		HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		SetIcon(hIconSmall, FALSE);

		// register object for message filtering and idle updates
		CMessageLoop* pLoop = _Module.GetMessageLoop();
		ATLASSERT(pLoop != NULL);
		pLoop->AddMessageFilter(this);
		pLoop->AddIdleHandler(this);

		UIAddChildWindowContainer(m_hWnd);
	
		SendMessage(GetDlgItem(IDC_CHECK_XPGB), BM_SETCHECK, GetXPStyleGroupBoxes()?BST_CHECKED:BST_UNCHECKED, 0L);

		m_ListBox.Attach(GetDlgItem(IDC_LIST_TR));
		m_ListBox.AddString(_T("Dylan"));
		m_ListBox.AddString(_T("Florence"));
		m_ListBox.AddString(_T("Zebedee"));
		m_ListBox.AddString(_T("Mr. MacHenry"));
		m_ListBox.AddString(_T("Ermintrude"));
		m_ListBox.AddString(_T("Dougal"));
		m_ListBox.AddString(_T("Brian"));

		m_Tree.Attach(GetDlgItem(IDC_TREE_BR));
		m_Tree.ModifyStyle(0,TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS);

		HTREEITEM mrroot = m_Tree.InsertItem(_T("Magic Roundabout"), TVI_ROOT, TVI_FIRST);
		m_Tree.InsertItem(_T("Dylan"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Florence"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Zebedee"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Mr. MacHenry"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Ermintrude"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Dougal"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Brian"), mrroot, TVI_FIRST);
		mrroot = m_Tree.InsertItem(_T("Flowerpot Men"), TVI_ROOT, TVI_FIRST);
		m_Tree.InsertItem(_T("Bill"), mrroot, TVI_FIRST);
		m_Tree.InsertItem(_T("Ben"), mrroot, TVI_FIRST);

		return TRUE;
	}

	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CAboutDlg dlg;
		dlg.DoModal();
		return 0;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// TODO: Add validation code 
		CloseDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CloseDialog(wID);
		return 0;
	}

	void CloseDialog(int nVal)
	{
		DestroyWindow();
		::PostQuitMessage(nVal);
	}

	LRESULT OnClickedCheck_daf(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		DisableFlicker(SendMessage(hWndCtl, BM_GETCHECK, 0, 0L)!=BST_CHECKED);
		ShowWindow(SW_HIDE);
		ShowWindow(SW_SHOW);
		return 0;
	}

	LRESULT OnClickedButton_change_font(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		LOGFONT LogFont;
		CFontHandle font = GetFont();
		font.GetLogFont(&LogFont);

		CFontDialog FontDialog(&LogFont);
		if(FontDialog.DoModal() == IDOK)
		{
			if (!m_Font.IsNull()) m_Font.DeleteObject();
			m_Font.CreateFontIndirect(&FontDialog.m_lf);
			EnumChildWindows(m_hWnd,EnumSetAllChildFonts,(LPARAM)&m_Font);
			Invalidate();
		}
		return 0;
	}

	static BOOL __stdcall EnumSetAllChildFonts(HWND hwnd, LPARAM lParam)
	{
		CFont* pFont = (CFont*)lParam;
		CWindow(hwnd).SetFont(*pFont);
		return TRUE;
	}

	LRESULT OnClickedCheck_xpgb(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		SetXPStyleGroupBoxes(SendMessage(hWndCtl, BM_GETCHECK, 0, 0L)==BST_CHECKED);
		Invalidate(TRUE);
		return 0;
	}
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__89E91691_CAF7_4ABB_8DA4_530E150636E5__INCLUDED_)
