//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by no_flicker_resize_grpbox.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_BITMAP_DOUGAL               204
#define IDC_GRP_TL                      1002
#define IDC_CHECK_DAF                   1003
#define IDC_GRP_TR                      1004
#define IDC_GRP_BL                      1005
#define IDC_GRP_BR                      1006
#define IDC_EDIT_TL                     1007
#define IDC_LIST_TR                     1009
#define IDC_CHECK_GB_TRANS              1013
#define IDC_GRP_BL2                     1014
#define IDC_BUTTON_CHANGE_FONT          1015
#define IDC_TREE_BR                     1018
#define IDC_STATIC_TL                   1020
#define IDC_CHECK_XPGB                  1021
#define IDC_GRP_BL3                     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
