// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Demo.h"

#include "MainFrm.h"

#include "InputDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

#define IDM_FIRST_SHELLMENUID	10000
#define IDM_LAST_SHELLMENUID	(IDM_FIRST_SHELLMENUID+1000)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_TEST_SETITEMASROOT, OnTestSetitemasroot)
	ON_COMMAND(ID_TEST_SETITEMASROOTWITHFILES, OnTestSetitemasrootwithfiles)
	ON_COMMAND(ID_TEST_ADDITEMTOROOT, OnTestAdditemtoroot)
	ON_COMMAND(ID_TEST_ADDITEMTOROOTWITHFILES, OnTestAdditemtorootwithfiles)
	ON_WM_INITMENUPOPUP()
	ON_WM_INITMENU()
	ON_COMMAND(ID_TEST_REFRESHITEM, OnTestRefreshitem)
	ON_COMMAND(ID_TEST_TEXTCALLBACK, OnTestTextcallback)
	ON_COMMAND(ID_TEST_IMAGECALLBACK, OnTestImagecallback)
	ON_COMMAND(ID_TEST_CHILDRENCALLBACK, OnTestChildrencallback)
	ON_UPDATE_COMMAND_UI(ID_TEST_TEXTCALLBACK, OnUpdateTestTextcallback)
	ON_UPDATE_COMMAND_UI(ID_TEST_IMAGECALLBACK, OnUpdateTestImagecallback)
	ON_UPDATE_COMMAND_UI(ID_TEST_CHILDRENCALLBACK, OnUpdateTestChildrencallback)
	ON_COMMAND(ID_TEST_FINDITEMFROMPATH, OnTestFinditemfrompath)
	ON_COMMAND(ID_TEST_DELETEITEM, OnTestDeleteitem)
	ON_COMMAND(ID_TEST_FINDITEMFROMPIDL, OnTestFinditemfrompidl)
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(IDM_FIRST_SHELLMENUID, IDM_LAST_SHELLMENUID, OnShellCommand)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create status bar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// create a splitter to occupy the client area of the frame
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
	{
		TRACE0("Failed to create splitter window\n");
		return FALSE;
	}

	CRect rect;
	GetClientRect(rect);

	// left view: tree
	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CChildView), CSize(rect.right/3,0), pContext))
	{
		TRACE0("Failed to create tree view\n");
		return FALSE;
	}
	m_pTreeView = (CChildView*)m_wndSplitter.GetPane(0, 0);

	// right view: edit
	if (!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CEditView), CSize(0,0), pContext))
	{
		TRACE0("Failed to create edit view\n");
		return FALSE;
	}

	// populate root and expand My Computer
	m_pTreeView->AddRootFolderContent(NULL);
	m_pTreeView->Expand(m_pTreeView->FindItemByPidl(CShellPidl(CSIDL_DRIVES)), TVE_EXPAND);

	return CFrameWnd::OnCreateClient(lpcs, pContext);
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	// avoid repainting when resized by changing the class style
	WNDCLASS wc;
	GetClassInfo(AfxGetInstanceHandle(), cs.lpszClass, &wc);
	cs.lpszClass = AfxRegisterWndClass(0, wc.hCursor, 0, wc.hIcon);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// forward focus to the view window
	m_wndSplitter.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndSplitter.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

// TEST commands

void CMainFrame::OnTestSetitemasroot() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
	{
		// copy returned Pidl, because it will be destroyed
		CShellPidl pidl(m_pTreeView->GetItemIDList(hItem));
		SetRedraw(FALSE);
		m_pTreeView->DeleteAllItems();
		SetRedraw(TRUE);
		m_pTreeView->AddRootFolderContent(pidl);
	}
}

void CMainFrame::OnTestSetitemasrootwithfiles() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
	{
		// copy returned Pidl, because it will be destroyed
		CShellPidl pidl(m_pTreeView->GetItemIDList(hItem));
		SetRedraw(FALSE);
		m_pTreeView->DeleteAllItems();
		SetRedraw(TRUE);
		m_pTreeView->AddRootFolderContent(pidl, STCF_INCLUDEALL);
	}
}

void CMainFrame::OnTestAdditemtoroot() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
		m_pTreeView->AddRootItem(m_pTreeView->GetItemIDList(hItem), STCF_SHOWFULLPATH);
}

void CMainFrame::OnTestAdditemtorootwithfiles() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
		m_pTreeView->AddRootItem(m_pTreeView->GetItemIDList(hItem),
			STCF_SHOWFULLPATH|STCF_INCLUDEALL);
}

void CMainFrame::OnTestDeleteitem() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
		m_pTreeView->DeleteItem(hItem);
}

void CMainFrame::OnTestRefreshitem() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem != NULL)
		m_pTreeView->RefreshSubItems(hItem);
}

void CMainFrame::OnTestFinditemfrompath() 
{
	CInputDlg dlg;
	if (dlg.DoModal() != IDOK)
		return;

	HTREEITEM hItem = NULL;

	if (dlg.m_nSpecial >= 0)
	{
		UINT nCSIDL = (UINT)dlg.m_nSpecial;
// 		if (dlg.m_bNoAlias)
// 			nCSIDL |= CSIDL_FLAG_NO_ALIAS;
// 		if (dlg.m_bNoVerify)
// 			nCSIDL |= CSIDL_FLAG_DONT_VERIFY;
		CShellPidl pidl(nCSIDL);
		if (!pidl.IsValid())
		{
			AfxMessageBox("An error occurred while creating a PIDL!");
			return;
		}
		hItem = m_pTreeView->FindItemByPidl(pidl);
	}
	else
	switch (dlg.m_iChoice)
	{
	case 0:
		hItem = m_pTreeView->FindItemByPath(dlg.m_sInput);
		break;

	case 1:
		CShellPidl pidl(dlg.m_sInput);
		if (!pidl.IsValid())
		{
			AfxMessageBox("Invalid path or an error occurred while parsing!");
			return;
		}
		hItem = m_pTreeView->FindItemByPidl(pidl);
		break;
	}

	if (hItem == NULL)
	{
		AfxMessageBox("No matching item found!");
		return;
	}
	m_pTreeView->SelectItem(hItem);
}

void CMainFrame::OnTestFinditemfrompidl() 
{
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("Invalid item!");
		return;
	}
	LPCITEMIDLIST pidl = m_pTreeView->GetItemIDList(hItem);

	hItem = m_pTreeView->FindItemByPidl(pidl);

	if (hItem == NULL)
	{
		AfxMessageBox("No matching item found!");
		return;
	}
	m_pTreeView->SelectItem(hItem);
}

void CMainFrame::OnTestTextcallback() 
{
	m_pTreeView->SetCallbackMask(m_pTreeView->GetCallbackMask() ^ TVIF_TEXT);
}

void CMainFrame::OnTestImagecallback() 
{
	m_pTreeView->SetCallbackMask(m_pTreeView->GetCallbackMask()
		^ (TVIF_IMAGE | TVIF_SELECTEDIMAGE));
}

void CMainFrame::OnTestChildrencallback() 
{
	m_pTreeView->SetCallbackMask(m_pTreeView->GetCallbackMask() ^ TVIF_CHILDREN);
}

void CMainFrame::OnUpdateTestTextcallback(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((m_pTreeView->GetCallbackMask() & TVIF_TEXT) ? 1 : 0);
}

void CMainFrame::OnUpdateTestImagecallback(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((m_pTreeView->GetCallbackMask() & TVIF_IMAGE) ? 1 : 0);
}

void CMainFrame::OnUpdateTestChildrencallback(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((m_pTreeView->GetCallbackMask() & TVIF_CHILDREN) ? 1 : 0);
}

// menu handling functions

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	UpdateShellMenu(pPopupMenu);

	CFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
}

void CMainFrame::OnShellCommand(UINT nID) 
{
	// shell command
	m_shellMenu.InvokeCommand(nID);
}

void CMainFrame::UpdateShellMenu(CMenu *pPopupMenu)
{
	static HTREEITEM hOldItem = NULL;

	// check if it's the right popup menu
	if (!IsMenuId(pPopupMenu, ID_SHELLMENU))
		return;

	// check the selected tree item
	HTREEITEM hItem = m_pTreeView->GetSelectedItem();
	if (hOldItem == hItem)
		return;	// same item, no changes

	hOldItem = hItem;

	// delete old menu
	int count = (int)pPopupMenu->GetMenuItemCount();
	while (--count >= 0)
		pPopupMenu->DeleteMenu(count, MF_BYPOSITION);

	if (hItem == NULL || !m_pTreeView->GetItemContextMenu(hItem, m_shellMenu))
	{
		pPopupMenu->AppendMenu(MF_GRAYED, ID_SHELLMENU, _T("(empty)"));
	}
	else
	{
		m_shellMenu.SetOwner(this);
		m_shellMenu.FillMenu(pPopupMenu, 1, IDM_FIRST_SHELLMENUID,
			IDM_LAST_SHELLMENUID, CMF_EXPLORE|CMF_NODEFAULT);
	}
	
	// update the menu identification
	SetMenuId(pPopupMenu, ID_SHELLMENU);
}

void CMainFrame::OnInitMenu(CMenu* pMenu) 
{
	CFrameWnd::OnInitMenu(pMenu);
	
	CMenu *pPopupMenu = pMenu->GetSubMenu(4);	// "Shell" menu
	SetMenuId(pPopupMenu, ID_SHELLMENU);
}

void CMainFrame::SetMenuId(CMenu *pPopupMenu, DWORD id)
{
	// save id in the first item's data
	MENUITEMINFO mii;
	ZeroMemory(&mii, sizeof(MENUITEMINFO));
	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_DATA;
	mii.dwItemData = id;
	::SetMenuItemInfo(pPopupMenu->GetSafeHmenu(), 0, TRUE, &mii);
}

BOOL CMainFrame::IsMenuId(CMenu *pPopupMenu, DWORD id)
{
	// compare id from the first item's data
	MENUITEMINFO mii;
	ZeroMemory(&mii, sizeof(MENUITEMINFO));
	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_DATA;
	pPopupMenu->GetMenuItemInfo(0, &mii, TRUE);
	return (mii.dwItemData == id);
}
