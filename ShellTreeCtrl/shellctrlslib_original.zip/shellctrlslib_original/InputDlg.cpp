// InputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "demo.h"
#include "InputDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInputDlg dialog


CInputDlg::CInputDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInputDlg)
	m_iChoice = 0;
	m_sInput = _T("");
	m_bNoVerify = FALSE;
	m_bNoAlias = FALSE;
	//}}AFX_DATA_INIT
	m_nSpecial = -1;
}


void CInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputDlg)
	DDX_Control(pDX, IDC_COMBO_NAME, m_wndCombo);
	DDX_Radio(pDX, IDC_RADIO1, m_iChoice);
	DDX_CBString(pDX, IDC_COMBO_NAME, m_sInput);
	DDX_Check(pDX, IDC_CHECK1, m_bNoVerify);
	DDX_Check(pDX, IDC_CHECK2, m_bNoAlias);
	//}}AFX_DATA_MAP
	if (pDX->m_bSaveAndValidate)
		m_nSpecial = m_wndCombo.GetCurSel();
}


BEGIN_MESSAGE_MAP(CInputDlg, CDialog)
	//{{AFX_MSG_MAP(CInputDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputDlg message handlers
