//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HOURGLASS                   130
#define IDR_TESTMENU                    130
#define IDD_INPUTBOX                    131
#define IDR_USERIMAGELIST               132
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_COMBO_NAME                  1005
#define IDC_CHECK1                      1007
#define IDC_CHECK2                      1008
#define ID_TEST_SETITEMASROOT           32771
#define ID_TEST_SETITEMASROOTWITHFILES  32772
#define ID_TEST_ADDITEMTOROOT           32773
#define ID_TEST_ADDITEMTOROOTWITHFILES  32774
#define ID_TESTITEM1                    32775
#define ID_TESTITEM2                    32776
#define ID_SHELLMENU                    32777
#define ID_TESTITEM3                    32778
#define ID_TESTITEM4                    32779
#define ID_TEST_REFRESHITEM             32781
#define ID_TEST_TEXTCALLBACK            32782
#define ID_TEST_IMAGECALLBACK           32783
#define ID_TEST_CHILDRENCALLBACK        32784
#define ID_TEST_FINDITEMFROMPATH        32785
#define ID_TEST_DELETEITEM              32786
#define ID_TEST_FINDITEMFROMPIDL        32787
#define ID_BUTTON32788                  32788
#define ID_BUTTON32789                  32789
#define ID_BUTTON32790                  32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
