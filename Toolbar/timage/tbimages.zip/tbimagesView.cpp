// tbimagesView.cpp : implementation of the CTbimagesView class
//

#include "stdafx.h"
#include "tbimages.h"

#include "tbimagesDoc.h"
#include "tbimagesView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView

IMPLEMENT_DYNCREATE(CTbimagesView, CEditView)

BEGIN_MESSAGE_MAP(CTbimagesView, CEditView)
	//{{AFX_MSG_MAP(CTbimagesView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView construction/destruction

CTbimagesView::CTbimagesView()
{
	// TODO: add construction code here

}

CTbimagesView::~CTbimagesView()
{
}

BOOL CTbimagesView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView drawing

void CTbimagesView::OnDraw(CDC* pDC)
{
	CTbimagesDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView printing

BOOL CTbimagesView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CTbimagesView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CTbimagesView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView diagnostics

#ifdef _DEBUG
void CTbimagesView::AssertValid() const
{
	CEditView::AssertValid();
}

void CTbimagesView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CTbimagesDoc* CTbimagesView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTbimagesDoc)));
	return (CTbimagesDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTbimagesView message handlers
