//   Author:      Lucian Barbulescu      lucian@xts.ro
//
//   Disclaimer
//   ----------
//   THIS SOFTWARE AND THE ACCOMPANYING FILES ARE DISTRIBUTED "AS IS" AND WITHOUT
//   ANY WARRANTIES WHETHER EXPRESSED OR IMPLIED. NO REPONSIBILITIES FOR POSSIBLE
//   DAMAGES OR EVEN FUNCTIONALITY CAN BE TAKEN. THE USER MUST ASSUME THE ENTIRE
//   RISK OF USING THIS SOFTWARE.
//
//   Terms of use
//   ------------
//   THIS SOFTWARE IS FREE FOR PERSONAL USE OR FREEWARE APPLICATIONS.
//   IF YOU USE THIS SOFTWARE IN COMMERCIAL OR SHAREWARE APPLICATIONS YOU
//   MUST HAVE THE PERMISION OF THE AUTHOR.
//
//
//	 History
//   -------
//
//   v1.0.0 - 7 April 2004		- First release
//	
//   v1.0.1 - 8 April 2004		- FIXED BUG: when toolbar is attached to the right or 
//                              the left no dragging possible by clicking on the handle
//                              (thanks to ReorX for informing me about this bug)
//
//                              - FIXED BUG: when the floating toolbar is docked the 
//                              parent dialog does not receives the focus
//
//   v1.0.2 - 9 April 2004      - ADDED: VC6 compatibility
//                              - ADDED: Tooltips support 
//                              (thanks to Randy More for his article about adding 
//                              tooltips to toolbars in dialogs)
//                              - FIXED BUG: UPDATE_COMMAND_UI does not work 
//                              (thanks to =[ Abin ]= for informing me about this bug)
                            

#pragma once
#define TDM_BUTTONDOWN		WM_USER+1
#define TDM_MOUSEMOVE		WM_USER+2
#define TDM_BUTTONUP		WM_USER+3
#define TDM_FLOATCLOSE		WM_USER+4
#define TDM_TOOLBTNPRESS	WM_USER+5


#define TS_HIDDEN		0x0000

#define TS_LEFT			CBRS_ALIGN_LEFT			//0x1000
#define TS_TOP			CBRS_ALIGN_TOP			//0x2000
#define TS_RIGHT		CBRS_ALIGN_RIGHT		//0x4000
#define TS_BOTTOM		CBRS_ALIGN_BOTTOM		//0x8000

#define TS_FLOATING		0x0001

//this style is for internal use only!!!! Do not define a toolbar with this style
#define TS_FIXED		CBRS_ALIGN_ANY			//0xF000

// CSmartToolbar

class CSmartToolbar : public CToolBar
{
	DECLARE_DYNAMIC(CSmartToolbar)

public:
	CSmartToolbar();
	virtual ~CSmartToolbar();

	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);


	void SetTolbarState(DWORD bState)
	{
		m_bState = bState;
	}

	void SetMessageReceiver(CWnd* pMessageReceiver)
	{
		m_pMessageReceiver = pMessageReceiver;
	}

	void UpdateToolbarStyle(DWORD dwStyle);
	void Initialize(CWnd* pParent, UINT uTemplateID);

protected:
	// Generated message map functions
	//{{AFX_MSG(CSmartToolbar)
	afx_msg LRESULT OnIdleUpdateCmdUI(WPARAM wParam, LPARAM);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	DWORD m_bState;
	bool m_bNoMove;
	CWnd* m_pMessageReceiver;
};

class CFloatToolbarDlg : public CWnd
{
	DECLARE_DYNAMIC(CFloatToolbarDlg)

public:
	CFloatToolbarDlg(CSmartToolbar* pToolbar);
	virtual ~CFloatToolbarDlg();

	BOOL ShowWindow(int nCmdShow);
	void CreateToolDlg(CWnd* pParent);
	afx_msg void OnClose();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);


protected:
	afx_msg LRESULT OnIdleUpdateCmdUI(WPARAM wParam, LPARAM);
	afx_msg BOOL OnToolTipText(UINT nID, NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

private:
	CSmartToolbar*	m_pToolbar;
	bool			m_bMoving;
};



class CToolbarDialog : public CDialog
{
	DECLARE_DYNAMIC(CToolbarDialog)

public:
	CToolbarDialog(UINT uID, CWnd* pParent, UINT uToolbarID, DWORD dwToolbarState = TS_HIDDEN);   // standard constructor
	virtual ~CToolbarDialog();

	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	void PositionToolbar(DWORD dwPosition);

	afx_msg LONG OnToolbarLButtonDown(WPARAM wParam, LPARAM lParam);
	afx_msg LONG OnToolbarLButtonUp(WPARAM wParam, LPARAM lParam);
	afx_msg LONG OnToolbarMouseMove(WPARAM wParam, LPARAM lParam);
	afx_msg LONG OnFloatToolbarClose(WPARAM wParam, LPARAM lParam);
	afx_msg LONG OnToolbarButtonPressed(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnKickIdle(WPARAM, LPARAM);
	
	virtual LONG ToolbarButtonCommand(UINT uButtonID);


protected:
	void ComputeToolbarRect(CPoint ptPoint, CRect* pRect);
	void DrawToolRect(CRect rcToolRect);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

private:
	CSmartToolbar*		m_pToolbar;
	UINT				m_uToolbarID;
	DWORD				m_dwToolbarState;
	CFloatToolbarDlg*	m_pFloatToolbar;
	CPoint				m_ptOffset;
	CPoint				m_ptDialogOffset;
	CBrush				m_brBrush;
	CRect				m_rcOldToolRect;
};
