//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TraceWin.rc
//
#define IDR_MAINFRAME                   2
#define IDD_ABOUTBOX                    100
#define IDB_MAINFRAME                   103
#define IDC_URLPD                       1001
#define IDC_URLICON                     1002
#define IDC_URLUPDATE                   1003
#define IDC_VERSION                     1004
#define ID_OUTPUT_TO_WINDOW             32771
#define ID_OUTPUT_TO_FILE               32772
#define ID_OUTPUT_OFF                   32773
#define ID_KEEP_ON_TOP                  32774
#define ID_EDIT_FONT                    32775
#define ID_ROTATING_BUF                 32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
