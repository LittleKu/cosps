#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#ifndef _UNICODE
#error TraceWin requires _UNICODE!
#endif
#include <afxwin.h>

#include <PixieLib.h>

