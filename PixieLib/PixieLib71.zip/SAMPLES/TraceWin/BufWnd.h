////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// Buffer window for TRACEWIN.
// CBufWnd implements the trace buffer. 
// Implements its own editing commands: Copy, Clear, Select All. 
// In order to work, the CBufWnd must be connected to the app's command 
// route by overriding CMainFrame::OnCmdMsg.
//
class CBufWnd : public CEdit {
public:
	CBufWnd();
	virtual ~CBufWnd();
	BOOL Create(CWnd* pParentWnd, UINT nID);
	BOOL IsEmpty();
protected:
	afx_msg void OnEditClearAll();
	afx_msg void OnEditCopy();
	afx_msg void OnEditSelectAll();
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditSelectAll(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};
