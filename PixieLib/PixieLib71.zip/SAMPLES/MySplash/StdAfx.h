#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define USE_PIXIE_DLL	// use PixieLib DLL
#include <afxwin.h>		// MFC
#include <PixieLib.h>	// PixieLib

