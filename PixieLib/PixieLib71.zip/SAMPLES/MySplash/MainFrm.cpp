////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "stdafx.h"
#include "resource.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// private message to send text string from subclass hook
const UINT WM_MYHOOKMESSAGE = WM_APP;

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_KBDMSG,		OnViewKbd)
	ON_COMMAND(ID_VIEW_MOUSEMSG,	OnViewMouse)
	ON_COMMAND(ID_VIEW_CLEAR,	OnViewClear)
	ON_UPDATE_COMMAND_UI(ID_VIEW_KBDMSG,	OnUpdateViewKbd)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MOUSEMSG, OnUpdateViewMouse)
	ON_MESSAGE(WM_MYHOOKMESSAGE, OnHookMessage)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if(!CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.style |= WS_CLIPCHILDREN;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.cx = 400;
	cs.cy = 300;
	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	TRACE(_T("CMainFrame::OnCreate\n"));

	// create window and control bars
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);

	VERIFY(m_wndView.Create(AFX_WS_DEFAULT_VIEW|WS_VSCROLL|ES_READONLY|ES_MULTILINE,
		CRect(0,0,0,0),this,AFX_IDW_PANE_FIRST));
	m_nMaxChars = m_wndView.GetLimitText() - 255;

	VERIFY(m_wndToolBar.CreateEx(this) &&
		m_wndToolBar.LoadToolBar(IDR_MAINFRAME));
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	VERIFY(m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR));

	VERIFY(m_wndStatusBar.Create(this) &&
		m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)));

	// add windows to rebar
	VERIFY(m_wndReBar.Create(this));
	VERIFY(m_wndReBar.AddBar(&m_wndToolBar));
	VERIFY(m_wndReBar.AddBar(&m_wndDlgBar));

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	// Install menu tip manager--that's all!
	m_menuTipManager.Install(this);

	return 0;
}

////////////////////////////////////////////////////////////////
// Command and UI handlers for view/unview commands
//
void CMainFrame::OnViewKbd() 
{
	m_kbdHook.Install(m_kbdHook.IsHooked() ? NULL : &m_wndView, WM_MYHOOKMESSAGE);
}

void CMainFrame::OnUpdateViewKbd(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_kbdHook.IsHooked());
}

void CMainFrame::OnViewMouse() 
{
	m_mouseHook.Install(m_mouseHook.IsHooked() ? NULL : &m_wndView, WM_MYHOOKMESSAGE);	
}

void CMainFrame::OnUpdateViewMouse(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_mouseHook.IsHooked());	
}

void CMainFrame::OnViewClear() 
{
	m_wndView.SetWindowText(NULL);
}

LRESULT CMainFrame::OnHookMessage(WPARAM /* wp */, LPARAM lp)
{
	int iLen = m_wndView.GetWindowTextLength();
	if (iLen>m_nMaxChars) {
		m_wndView.SetSel(0, iLen);				// no more space: clear all
	} else {
		m_wndView.SetSel(iLen, iLen);			// end of edit text
	}
	m_wndView.ReplaceSel((LPCTSTR)lp);		// append string..
	m_wndView.SendMessage(EM_SCROLLCARET);	// ..and show caret

	return 0;
}
