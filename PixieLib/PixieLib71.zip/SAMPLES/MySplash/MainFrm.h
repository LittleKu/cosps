////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

////////////////
// Msg hook to spy on mouse messages
//
class CMouseHook : public CSubclassWnd {
protected:
	UINT	m_uCbMsg;							 // callback message ID

	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp)
	{
		if (WM_MOUSEFIRST <= msg && msg <= WM_MOUSELAST) {
			CString s;
			s.Format(_T("CMouseHook::%s, pt=(%d,%d)\r\n"),_TR(msg),LOWORD(lp),HIWORD(lp));
			SendMessage(::GetParent(m_hWnd), m_uCbMsg, 0, (LPARAM)(LPCTSTR)s);
		}
		return CSubclassWnd::WindowProc(msg, wp, lp);	// Important!!
	}

public:
	BOOL Install(CWnd* pWnd, UINT uCbMsg) {
		m_uCbMsg = uCbMsg;			// use caller's message
		return HookWindow(pWnd);	// hook window
	}
};

////////////////
// Msg hook to spy on kbd messages
//
class CKbdHook : public CSubclassWnd {
protected:
	UINT m_uCbMsg;
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp)
	{
		if (WM_KEYFIRST <= msg && msg <= WM_KEYLAST) {
			CString s;
			s.Format(_T("CKbdHook::%s, vkey=%d(0x%x)\r\n"),_TR(msg),wp,wp);
			SendMessage(::GetParent(m_hWnd), m_uCbMsg, 0, (LPARAM)(LPCTSTR)s);
		}
		return CSubclassWnd::WindowProc(msg, wp, lp);	// Important!!
	}

public:
	BOOL Install(CWnd* pWnd, UINT uCbMsg) {
		m_uCbMsg = uCbMsg;			// use caller's message
		return HookWindow(pWnd);	// hook window
	}
};

class CMainFrame : public CFrameWnd {
public:
	CMainFrame()			 { }
	virtual ~CMainFrame() { }

protected:
	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// child windows/control bars
	CCoolMenuManager	m_menuManager;		 // manages menus for entire app + views
	CMenuTipManager	m_menuTipManager;	 // managed menu tips
	CStatusBar			m_wndStatusBar;	 // status bar
	CFlatToolBar		m_wndToolBar;		 // toolbar
	CDialogBar			m_wndDlgBar;		 // dialog bar--empty
	CReBar				m_wndReBar;			 // MFC rebar (coolbar)
	CEdit					m_wndView;			 // main view (edit control)
	int					m_nMaxChars;		 // max number of chars edit control can hold
	CMouseHook			m_mouseHook;		 // mouse message hook
	CKbdHook				m_kbdHook;			 // keyboard message hook
	
	// message handlers
	afx_msg void OnPaint();
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewKbd();
	afx_msg void OnUpdateViewKbd(CCmdUI* pCmdUI);
	afx_msg void OnViewMouse();
	afx_msg void OnUpdateViewMouse(CCmdUI* pCmdUI);
	afx_msg void OnViewClear();
	afx_msg LRESULT OnHookMessage(WPARAM wp, LPARAM lp);

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
