////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// MySplash shows how to use CSplash to implement a splash screen in MFC.
//
#include "StdAfx.h"
#include "resource.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Typical MFC App
//
class CMyApp : public CWinApp {
public:
	CMyApp();
	~CMyApp();
protected:
	GdiplusStartupInput  m_gdiplusStartupInput;
	ULONG_PTR m_gdiplusToken;
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	afx_msg void OnViewSplash();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMyApp)
} theApp;

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT,	OnAppAbout)
	ON_COMMAND(ID_VIEW_SPLASH, OnViewSplash)
END_MESSAGE_MAP()

CMyApp::CMyApp()
{
	VERIFY(GdiplusStartup(&m_gdiplusToken, &m_gdiplusStartupInput, NULL)==Ok);
}

CMyApp::~CMyApp()
{
	GdiplusShutdown(m_gdiplusToken);
}

BOOL CMyApp::InitInstance()
{
	// VERY IMPORTANT: If you use a local variable as a back pointer
	// (last arg to new CSplash), you MUST kill before leaving scope
	// or else CSplash may try to set a variable that doesn't exist!
	// that's why pSplash is static, just to be safe.
	//
	TRACE(_T("MySplash: creating splash screen."));
	static CSplash *pSplash = new CSplash(IDB_SPLASH, 500, 0, &pSplash);

	// simulate work
	TRACE(_T("MySplash: computing...."));
	Sleep(4000); // sleep 4 seconds
	TRACE(_T("MySplash: done.\n"));

	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;
	pFrame->LoadFrame(IDR_MAINFRAME);
	m_pMainWnd->CenterWindow();
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	// The splash window will automatically kill itself as soon as the main
	//	window comes up (or timeout expires); if so, it will set your back
	// pointer (pSplash) to NULL. If you want to kill the splash sooner,
	//	can call CSplash::Kill as below. This is safe if pSplash=NULL, Kill
	//	won't do anything.
	//
	CSplash::Kill(pSplash);

	return TRUE;
}

//////////////////
// Show splash screen.
//
void CMyApp::OnViewSplash()
{
	new CSplash(IDB_SPLASH, 2000, CSplash::KillOnClick|CSplash::IgnoreCmdLine);
}

//////////////////
// Custom dialog uses CStaticLink for hyperlinks.
// Same dialog class works for both applets (resource ID determines dialog)
//
class CAboutDialog : public CDialog {
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	virtual BOOL OnInitDialog() {
		m_wndLink1.SubclassDlgItem(IDC_PIXIEURL, this);
		m_wndLink2.SubclassDlgItem(IDC_PDURL,  this);
		return CDialog::OnInitDialog();
	}
};

void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg;
	dlg.DoModal();
}
