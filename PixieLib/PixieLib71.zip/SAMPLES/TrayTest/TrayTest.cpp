////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// TrayTest illustrates how to use CTrayIcon to display your own icon in the
// system tray. All the action happens in MainFrm.cpp.

#include "stdafx.h"
#include "TrayTest.h"
#include "mainfrm.h"

CMyApp theApp;

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
END_MESSAGE_MAP()

BOOL CMyApp::InitInstance()
{
	// Create main frame window (don't use doc/view stuff)
	// 
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	pMainFrame->ShowWindow(SW_HIDE);
	pMainFrame->UpdateWindow();
	m_pMainWnd = pMainFrame;
	OnAppAbout();
	return TRUE;
}

//////////////////
// Custom about dialog uses CStatLink for hyperlinks.
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	CStaticLink	m_wndLink3;
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX) { }
	virtual BOOL OnInitDialog()
	{
		// subclass hyperlinks
		m_wndLink1.SubclassDlgItem(IDC_URLPD,this);
		m_wndLink2.SubclassDlgItem(IDC_URLBANANA,this);
		m_wndLink3.SubclassDlgItem(IDC_URLTOILET,this);
		return CDialog::OnInitDialog();
	}
};

void CMyApp::OnAppAbout()
{
	CAboutDialog().DoModal();
}
