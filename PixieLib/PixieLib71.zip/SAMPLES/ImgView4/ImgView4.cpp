////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// ImgView implements an image viewer that shows how to use CPictureCtrl to
// display GIF, JPG, BMP, TIF and all the other image formats supported by
// CPicture/GDI+. It also shows how to use CFolderView to implement
// Excel-style folder tabs. ImgView uses CHtmlCtrl to display an HTML-based
// About dialog, and uses CStringDialog to generate an input dialog on the fly
// to get a URL from the user.
//
#include "StdAfx.h"
#include "resource.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include <TraceWin.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Application class
//
class CMyApp : public CWinApp {
public:
	CMyApp();
	~CMyApp();
protected:
	GdiplusStartupInput  m_gdiplusStartupInput;
	ULONG_PTR m_gdiplusToken;
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
} theApp;

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	ON_COMMAND(ID_FILE_NEW,  CWinApp::OnFileNew)
END_MESSAGE_MAP()

CMyApp::CMyApp()
{
	VERIFY(GdiplusStartup(&m_gdiplusToken, &m_gdiplusStartupInput, NULL)==Ok);
}

CMyApp::~CMyApp()
{
	GdiplusShutdown(m_gdiplusToken);
}

BOOL CMyApp::InitInstance()
{
//	SetRegistryKey("MSDNMag");	// Save settings in registry, not INI file -- NOT!
	LoadStdProfileSettings(8); // 8 files in MRU list

	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CPictureDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CPictureView)));

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	return ProcessShellCommand(cmdInfo);
}

//////////////////
// About dialog uses HTML control to display contents.
//
class CAboutDialog : public CDialog {
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
protected:
	CHtmlCtrl m_wndHtml;
	virtual BOOL OnInitDialog(); 
	DECLARE_DYNAMIC(CAboutDialog)
};

IMPLEMENT_DYNAMIC(CAboutDialog, CDialog)

////////////////
// HTML commands: map "app:ok" to IDOK
//
BEGIN_HTML_COMMAND_MAP(MyHtmlCmds)
	HTML_COMMAND(_T("ok"), IDOK)
END_HTML_COMMAND_MAP()

BOOL CAboutDialog::OnInitDialog()
{
	VERIFY(CDialog::OnInitDialog());
	VERIFY(m_wndHtml.CreateFromStatic(IDC_HTMLVIEW, this));
	m_wndHtml.LoadFromResource(_T("about.htm"));
	m_wndHtml.SetCmdMap(MyHtmlCmds);
	return TRUE;
}

void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}
