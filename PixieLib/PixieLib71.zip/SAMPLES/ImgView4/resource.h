//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ImgView3.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYDOCTYPE                   130
#define IDR_FOLDERTABS                  131
#define IDC_PDURL                       1000
#define IDC_MSDNURL                      1001
#define IDC_MSDNURL2                     1002
#define IDC_HTMLVIEW                    1003
#define ID_VIEW_FONT                    32771
#define ID_VIEW_FONT_SMALLER            32772
#define ID_VIEW_FONT_BIGGER             32773
#define ID_VIEW_TOFIT                   32820
#define ID_VIEW25                       32821
#define ID_VIEW33                       32822
#define ID_VIEW50                       32823
#define ID_VIEW75                       32824
#define ID_VIEW100                      32825
#define ID_VIEW_ROTATE                  32826
#define ID_VIEW_FULLSCREEN              32827
#define ID_FILE_OPEN_URL                32830
#define ID_FILE_OPEN_BUILTIN				 32831
#define ID_VIEW_PAGE1						 32835
#define ID_VIEW_PAGE2						 32836
#define ID_VIEW_PAGE3						 32837
#define ID_VIEW_PAGE4						 32838
#define ID_VIEW_PAGE5						 32839

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32840
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
