#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define USE_PIXIE_DLL	// use PixieLib DLL
#include <afxwin.h>		// MFC
#include <afxpriv.h>		// MFC private stuff (WM_INITIALUPDATE)

#include <PixieLib.h>	// PixieLib -- must be first
#include <PLFolderTab.h>// PixieLib folder tabs


