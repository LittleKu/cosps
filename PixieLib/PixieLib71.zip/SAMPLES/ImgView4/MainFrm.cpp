////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_GETMINMAXINFO()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_VIEW_FULLSCREEN, OnViewFullScreen)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FULLSCREEN, OnUpdateViewFullScreen)
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR				// status line indicator
};

CMainFrame::CMainFrame()
{
	m_rcRestore.SetRectEmpty();
}

CMainFrame::~CMainFrame()
{
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with coolbars, but it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
	cs.style |= WS_CLIPCHILDREN;
   return CFrameWnd::PreCreateWindow(cs);
}

/////////////////
// Allow maximum size larger than screen for full-screen mode.
//
void CMainFrame::OnGetMinMaxInfo(MINMAXINFO* lpmmi)
{
	CRect rc(0,0, GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN));
	rc.InflateRect(100,100);
	lpmmi->ptMaxSize = CPoint(rc.Size());
	lpmmi->ptMaxTrackSize = CPoint(rc.Size());
}

//////////////////
// Create standard windows.
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	VERIFY(m_wndToolBar.Create(this) &&
		m_wndToolBar.LoadToolBar(IDR_MAINFRAME));

	VERIFY(m_wndStatusBar.Create(this) &&
		m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)));

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	// Install menu tip manager--that's all!
	m_menuTipManager.Install(this);

	// Append my own items to the system menu & init sys cmd router
	CMenu* pMenu = GetSystemMenu(FALSE);
	ASSERT(pMenu);
	pMenu->AppendMenu(MF_SEPARATOR);
	pMenu->AppendMenu(MF_STRING,(UINT_PTR)ID_APP_ABOUT, _T("&About ImgView..."));
	m_sysCmdRouter.Init(this);

	DragAcceptFiles(TRUE);

	return 0;
}

////////////////
// Create client: Create CFolderFrame in main frame.
//
BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT, CCreateContext* pcc)
{
	return m_wndFolderFrame.Create(this,
		RUNTIME_CLASS(CPictureView),
		pcc,
		IDR_FOLDERTABS);
}

//////////////////
// Display context menu.
//
void CMainFrame::OnContextMenu(CWnd* /* pWnd */, CPoint p)
{
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MAINFRAME));
	CMenu* pSubMenu = menu.GetSubMenu(1);
	pSubMenu->TrackPopupMenu(0, p.x, p.y, this);
}

//////////////////
// View full screen mode: resize so client area = whole screen, or restore to
// normal if already zoomed.
//
void CMainFrame::OnViewFullScreen()
{
	CRect rc;
	if (IsFullScreen()) {
		// restore to original size/position
		rc = m_rcRestore;
		m_rcRestore.SetRectEmpty();

	} else {
		// enter full-screen mode
		CView* pView = GetActiveView();
		if (!pView)
			return;
		CRect rcView;
		pView->GetWindowRect(&rcView);
		GetWindowRect(&m_rcRestore);
		rc.SetRect(0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN));
		rc.left  += m_rcRestore.left  - rcView.left;
		rc.top   += m_rcRestore.top   - rcView.top;
		rc.right += m_rcRestore.right - rcView.right;
		rc.bottom+= m_rcRestore.bottom- rcView.bottom;

	}
	SetWindowPos(NULL,rc.left,rc.top,rc.Width(),rc.Height(),SWP_NOZORDER);
}

void CMainFrame::OnUpdateViewFullScreen(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(IsFullScreen());
}
