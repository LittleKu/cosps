////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "resource.h"
#include "Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CPictureDoc, CDocument)

BEGIN_MESSAGE_MAP(CPictureDoc, CDocument)
	ON_COMMAND(ID_FILE_OPEN_BUILTIN, OnFileOpenBuiltin)
	ON_COMMAND(ID_FILE_OPEN_URL, OnFileOpenURL)
END_MESSAGE_MAP()

CPictureDoc::CPictureDoc()
{
}

CPictureDoc::~CPictureDoc()
{
}

//////////////////
// Load document from file. Bypass MFC serialization stuff.
//
BOOL CPictureDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	return m_pict.Load(lpszPathName);
}

//////////////////
// Load picture from resource
//
void CPictureDoc::OnFileOpenBuiltin()
{
	m_pict.Load(IDR_MAINFRAME);
	m_strPathName = "(Internal)";
	UpdateAllViews(NULL);
}

//////////////////
// Open picture from web: run input dialog to get URL, then try to open it.
//
void CPictureDoc::OnFileOpenURL()
{
	CStringDialog dlg;
	dlg.m_bRequired = TRUE;		 // URL is required
	dlg.m_str = _T("www.dilascia.com/images/cookie.jpg");
	VERIFY(dlg.Create(_T("Open URL"), _T("Enter the URL of an image:"),NULL));
	if (dlg.DoModal()==IDOK) {
		CHourglass wait;
		CString url = dlg.m_str;
		if (url.Left(7)!=_T("http://"))
			url = _T("http://") + url;
		if (m_pict.LoadURL(url)) {
			m_strPathName = url;
			UpdateAllViews(NULL);
		} else {
			CString msg;
			msg.Format(_T("Couldn't open '%s'"), url);
			AfxMessageBox(msg);
		}
	}
}

void CPictureDoc::DeleteContents()
{
	m_pict.DestroyPicture();
}

void CPictureDoc::SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU)
{
	CString path = lpszPathName;
	if (path.Left(7)==_T("http://")) {
		m_strPathName = path;
		m_bEmbedded = FALSE;
		ASSERT_VALID(this);
		SetTitle(path);
		
	} else {
		CDocument::SetPathName(lpszPathName, bAddToMRU);
	}
}
