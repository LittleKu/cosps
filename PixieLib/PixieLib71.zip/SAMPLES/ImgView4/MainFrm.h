////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "resource.h"

////////////////
// Main frame window.
// 
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

protected:
	CCoolMenuManager	m_menuManager;		 // managed menus for entire app
	CMenuTipManager	m_menuTipManager;	 // managed menu tips
	CStatusBar			m_wndStatusBar;	 // status bar
	CFlatToolBar		m_wndToolBar;		 // tool (button) bar
	CFolderFrame		m_wndFolderFrame;	 // folder frame
	CSysCmdRouter		m_sysCmdRouter;	 // route system commands through MFC
	CRect					m_rcRestore;		 // size to restore after full-screen mode
	
	// helper
	BOOL IsFullScreen() { return !m_rcRestore.IsRectEmpty(); }

	// override to create folder frame
	virtual BOOL OnCreateClient( LPCREATESTRUCT, CCreateContext* pcc);

	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	afx_msg void OnViewFullScreen();
	afx_msg void OnUpdateViewFullScreen(CCmdUI* pCmdUI);

	DECLARE_MESSAGE_MAP()
};

