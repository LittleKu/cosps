////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "doc.h"

//////////////////
// Picture view class.
// A scroll view that draws images.
//
class CPictureView : public CFolderView {
public:
	DECLARE_DYNCREATE(CPictureView)
	CPictureView();
	virtual ~CPictureView();

	CPictureDoc* GetDocument()	{ return (CPictureDoc*)m_pDocument; }
	CPicture* GetPicture();
	void SetZoom(int iZoom);

protected:
	static CFont g_font;	// current display font, global for all views
	BOOL m_rcImage;		// rect to display image in
	UINT m_iHowScale;		// how to scale image

	void GetImageRect(CRect& rc);

	// folder tab functions
	enum { PAGE_IMAGE=0, PAGE_INFO, PAGE_HEX };
	int	m_iPage;			// which page selected
	virtual void OnChangedFolder(int iPage);

	int  DrawInfo(CDC& dc, CPicture* p, UINT nFormat=0);
	int  DrawHex(CDC& dc, CPicture* p);
	void UpdateScrollSizes();

	virtual void OnDraw(CDC* pDC);
	virtual void OnInitialUpdate();

	DECLARE_MESSAGE_MAP()

	// command/message handlers
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnViewRotate();
	afx_msg void OnViewScale(UINT nID);
	afx_msg void OnFontChange(UINT nID);
	afx_msg void OnUpdateFontChange(CCmdUI* pCmdUI);
	afx_msg void OnViewPage(UINT nID);
	afx_msg void OnUpdateViewCmd(CCmdUI* pCmdUI);
};
