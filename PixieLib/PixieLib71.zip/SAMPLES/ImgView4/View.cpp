////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "Doc.h"
#include "View.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const TCHAR SETTINGS[] = _T("Settings");
#define ID_VIEW_PAGELAST ID_VIEW_PAGE5

// internal helper functions
CString GetPixelFormatName(PixelFormat pf);
CString GetUnitName(Unit unit);
CString FormatFlags(UINT flags);
CString GetPropertyName(const PropertyItem& prop);

IMPLEMENT_DYNCREATE(CPictureView, CFolderView)
BEGIN_MESSAGE_MAP(CPictureView, CFolderView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_COMMAND_RANGE(ID_VIEW_TOFIT, ID_VIEW100, OnViewScale)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_TOFIT,ID_VIEW_ROTATE,OnUpdateViewCmd)
	ON_COMMAND(ID_VIEW_ROTATE, OnViewRotate)
	ON_COMMAND_RANGE(ID_VIEW_FONT, ID_VIEW_FONT_BIGGER, OnFontChange)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_FONT, ID_VIEW_FONT_BIGGER, OnUpdateFontChange)
	ON_COMMAND_RANGE(ID_VIEW_PAGE1,ID_VIEW_PAGELAST, OnViewPage)
END_MESSAGE_MAP()

CFont CPictureView::g_font;

CPictureView::CPictureView()
{
	m_iHowScale = ID_VIEW100;
	m_iPage = PAGE_IMAGE;
	if (!g_font.m_hObject) {
		// Restore font from profile
		if (!CFontUI().GetProfileFont(SETTINGS, _T("Font"), g_font)) {
			// Use 8pt Courier (monospaced) default
			g_font.CreatePointFont(100,_T("Courier"));
		}
	}
}

CPictureView::~CPictureView()
{
	CFontUI().WriteProfileFont(SETTINGS, _T("Font"), g_font);
}

//////////////////
// Get the picture.
//
CPicture* CPictureView::GetPicture()
{
	CPictureDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CPicture* ppic = pDoc->GetPicture();
	return ppic->GetImage() ? ppic : NULL;
}

//////////////////
// Initial update: set scroll sizes.
//
void CPictureView::OnInitialUpdate()
{
	CFolderView::OnInitialUpdate();
	CPicture* pic = GetPicture();

	// Compute size/position of text rectangle
	UpdateScrollSizes();

	// Show folder view controls
	GetFolderFrame()->ShowControls(pic ? CFolderFrame::bestFit : CFolderFrame::hide);

	if (pic) {
		// size window perfectly around frame
		GetParentFrame()->RecalcLayout();
	}
}

//////////////////
// Compute scroll sizes based on new font/image
//
void CPictureView::UpdateScrollSizes()
{
	CPicture* pic = GetPicture();
	CRect rcClient;
	GetClientRect(&rcClient);
	CSize szTotal = rcClient.Size();
	CSize szPage  = rcClient.Size();
	CSize szLine  = szPage;
	szLine.cx /= 10;
	szLine.cy /= 10;

	if (pic) {
		if (m_iPage==PAGE_IMAGE) {
			CRect rcImage;
			GetImageRect(rcImage);
			szTotal = rcImage.Size();

		} else if (m_iPage==PAGE_INFO) {
			CClientDC cdc(this);
			CDC dc;
			dc.CreateCompatibleDC(&cdc);
			szTotal.cy = DrawInfo(dc, pic, DT_CALCRECT);
		}
	}
	
	CScrollView::SetScrollSizes(MM_TEXT, szTotal, szPage, szLine);
	Invalidate();
}

//////////////////
// Draw the bitmap. Be careful to specify foreground/background.
// Following bitmap, display fields in BITMAPINFOHEADER
//
void CPictureView::OnDraw(CDC* pDC)
{
	CDC& dc = *pDC;
	CPicture* pic = GetPicture();
	if (m_iPage==PAGE_IMAGE) {
		if (pic) {
			CRect rc;
			GetImageRect(rc);
			pic->Render(pDC,rc);
		}

	} else if (m_iPage==PAGE_INFO) {
		DrawInfo(dc, pic);

	} else {
		DrawHex(dc, pic);
	}
}

//////////////////
// Get image rectangle, scaled for current zoom factor.
//
void CPictureView::GetImageRect(CRect& rc)
{
	CPictureDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CPicture* ppic = pDoc->GetPicture();
	ASSERT(ppic);

	if (!ppic || !*ppic) {
		rc.SetRect(0,0,0,0);
	} else if (m_iHowScale==ID_VIEW_TOFIT) {
		GetClientRect(&rc);
	} else {
		CSize sz = ppic->GetImageSize();
		switch (m_iHowScale) {
		case ID_VIEW25:
			sz.cx >>= 2;
			sz.cy >>= 2;
			break;
		case ID_VIEW33:
			sz.cx /= 3;
			sz.cy /= 3;
			break;
		case ID_VIEW50:
			sz.cx >>= 1;
			sz.cy >>= 1;
			break;
		case ID_VIEW75:
			sz.cx = (sz.cx * 3)/4;
			sz.cy = (sz.cy * 3)/4;
			break;
		}
		rc.SetRect(0,0,sz.cx,sz.cy);
	}
}

//////////////////
// Rotate image 90 degrees.
//
void CPictureView::OnViewRotate()
{
	CPictureDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CPicture* ppic = pDoc->GetPicture();
	if (*ppic) {
		ppic->Rotate(Rotate90FlipNone);
		Invalidate();
	}
}

//////////////////
// Handle zoom command.
//
void CPictureView::OnViewScale(UINT nID)
{
	if (m_iHowScale != nID) {
		m_iHowScale = nID;
		if (GetPicture()) {
			ScrollToPosition(CPoint(0,0));
			UpdateScrollSizes();
			Invalidate();
		}
	}
}

//////////////////
// Update zoom menu -- check the whichever zoom factor I'm at now.
//
void CPictureView::OnUpdateViewCmd(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID == m_iHowScale);
	pCmdUI->Enable(m_iPage==PAGE_IMAGE && GetPicture()!=NULL);
}

//////////////////
// Helper fn to draw the formatted BITMAPINFOHEADER text.
// Because Windows is so brain damaged, this requires manually
// outputting each line with TabbedTextOut. DrawText is what I would ideally
// use here, but Windows doesn't let you use DT_CALCRECT and DT_TABSTOP at
// the same time. I need both, because I'm setting a custom tab stop to make
// my text align, but also need to calculate the size of the text in advance
// so I can set my scroll ranges.
//
int CPictureView::DrawInfo(CDC& dc, CPicture* pic, UINT nFormat)
{
	CString info, temp;
	
	if (pic) {
		// Filename, type, size
		CPictureDoc* pDoc = GetDocument();
		ImageType type = pic->GetType();
		LPCTSTR stype = type == ImageTypeBitmap ? _T("bitmap") :
			type==ImageTypeMetafile ? _T("metafile") : _T("unknown");
		CSize sz = pic->GetImageSize();
		temp.Format(_T("File: %s\nType: %s (%s)\nSize: %d(w) x %d(h)\n"),
			(LPCTSTR)pDoc->GetPathName(),
			(LPCTSTR)stype,
			(LPCTSTR)pic->GetFormatName(),
			sz.cx, sz.cy);
		info += temp;

		// Pixel Format
		temp.Format(_T("PixelFormat: %s\n"), GetPixelFormatName(pic->GetPixelFormat()));
		info += temp;

		// Resolution
		SizeF res = pic->GetResolution();
		temp.Format(_T("Horz Resolution: %.0f dpi\nVert Resolution: %.0f dpi\n"),
			res.Width, res.Height);
		info += temp;	

		// Bounds
		RectF bounds;
		Unit unit;
		pic->GetBounds(bounds, unit);
		temp.Format(_T("Bounds: (%.2f, %.2f) x (%.2f, %.2f) %s\n"),
			bounds.X, bounds.Y, bounds.Width, bounds.Height, GetUnitName(unit));
		info += temp;	

		// Flags
		UINT flags = pic->GetFlags();
		temp.Format(_T("Flags: 0x%08x\n%s"), flags, FormatFlags(flags));
		info += temp;

		// Properties
		PropertyItem* props;
		UINT nProp = pic->GetAllPropertyItems(props);
		if (nProp>0) {
			info += _T("Properties:\n");
			for (UINT i=0; i<nProp; i++) {
				temp.Format(_T("\t0x%04X\t%s\n"), props[i].id, GetPropertyName(props[i]));
				info += temp;
			}
		}
	} else {
		info = _T("No image open.");
	}

	// Now draw info using current font
	CFont *pOldFont = dc.SelectObject(&g_font);	// select my font
	DRAWTEXTPARAMS dtp;
	memset(&dtp,0,sizeof(dtp));
	dtp.cbSize = sizeof(dtp); // size of struct
	dtp.iTabLength = 3;		  // avg chars per tab
	CRect rc;
	GetClientRect(&rc);
	dc.DrawTextEx(info, &rc, nFormat|DT_EXPANDTABS|DT_TABSTOP, &dtp);
	dc.SelectObject(pOldFont);
	return rc.Height();
}

CString GetPixelFormatName(PixelFormat pf)
{
	static struct {
		PixelFormat val;
		LPCTSTR name;
	} PixelFormatNames[] = {
		{ PixelFormatIndexed, _T("Indexed") },
		{ PixelFormatGDI, _T("GDI") },
		{ PixelFormatAlpha, _T("Alpha") },
		{ PixelFormatPAlpha, _T("PAlpha") },
		{ PixelFormatExtended, _T("Extended") },
		{ PixelFormatCanonical, _T("Canonical") },
		{ PixelFormat1bppIndexed, _T("1bpp Indexed") },
		{ PixelFormat4bppIndexed, _T("4bpp Indexed") },
		{ PixelFormat8bppIndexed, _T("8bpp Indexed") },
		{ PixelFormat16bppGrayScale, _T("16bpp GrayScale") },
		{ PixelFormat16bppRGB555, _T("16bpp RGB555") },
		{ PixelFormat16bppRGB565, _T("16bpp RGB565") },
		{ PixelFormat16bppARGB1555, _T("16bpp ARGB1555") },
		{ PixelFormat24bppRGB, _T("24bpp RGB") },
		{ PixelFormat32bppRGB, _T("32bpp RGB") },
		{ PixelFormat32bppARGB, _T("32bpp ARGB") },
		{ PixelFormat32bppPARGB, _T("32bpp PARGB") },
		{ PixelFormat48bppRGB, _T("48bpp RGB") },
		{ PixelFormat64bppARGB, _T("64bpp ARGB") },
		{ PixelFormat64bppPARGB, _T("64bpp PARGB") },
		{ PixelFormatUndefined, _T("Undefined") },
	};
	for (int i=0; PixelFormatNames[i].val; i++) {
		if (pf==PixelFormatNames[i].val) {
			return PixelFormatNames[i].name;
		}
	}
	return _T("Undefined");
}

CString FormatFlags(UINT flags)
{
	CString fmt,temp;
	static struct {
		UINT val;
		LPCTSTR name;
	} Flags[] = {
		{ ImageFlagsScalable, _T("ImageFlagsScalable") },
		{ ImageFlagsHasAlpha, _T("ImageFlagsHasAlpha") },
		{ ImageFlagsHasTranslucent, _T("ImageFlagsHasTranslucent") },
		{ ImageFlagsPartiallyScalable, _T("ImageFlagsPartiallyScalable") },
		{ ImageFlagsColorSpaceRGB, _T("ImageFlagsColorSpaceRGB") },
		{ ImageFlagsColorSpaceCMYK, _T("ImageFlagsColorSpaceCMYK") },
		{ ImageFlagsColorSpaceGRAY, _T("ImageFlagsColorSpaceGRAY") },
		{ ImageFlagsColorSpaceYCBCR, _T("ImageFlagsColorSpaceYCBCR") },
		{ ImageFlagsColorSpaceYCCK, _T("ImageFlagsColorSpaceYCCK") },
		{ ImageFlagsHasRealDPI, _T("ImageFlagsHasRealDPI") },
		{ ImageFlagsHasRealPixelSize, _T("ImageFlagsHasRealPixelSize") },
		{ ImageFlagsReadOnly, _T("ImageFlagsReadOnly") },
		{ ImageFlagsCaching, _T("ImageFlagsCaching") },
		{ 0, NULL },
	};
	for (int i=0; Flags[i].val; i++) {
		if (flags & Flags[i].val) {
			temp.Format(_T("\t%s\n"), Flags[i].name);
			fmt += temp;
		}
	}
	return fmt;
}

CString GetUnitName(Unit unit)
{
	static struct {
		Unit val;
		LPCTSTR name;
	} UnitNames[] = {
		{ UnitWorld, _T("World coordinate (non-physical) units") },
		{ UnitDisplay, _T("Display") },
		{ UnitPixel, _T("Pixels") },
		{ UnitPoint, _T("Points") },
		{ UnitInch, _T("Inches") },
		{ UnitDocument, _T("Document units (1/300 inch)") },
		{ UnitMillimeter, _T("Millimeters") },
		{ (Unit)0, NULL },
	};
	for (int i=0; UnitNames[i].name; i++) {
		if (unit==UnitNames[i].val) {
			return UnitNames[i].name;
		}
	}
	return _T("Unknown units");
}

CString GetPropertyName(const PropertyItem& prop)
{
	static struct {
		PROPID id;
		LPCTSTR name;
	} PropNames[] = {
		{ PropertyTagExifIFD,_T("ExifIFD") },
		{ PropertyTagGpsIFD,_T("GpsIFD") },
		{ PropertyTagNewSubfileType,_T("NewSubfileType") },
		{ PropertyTagSubfileType,_T("SubfileType") },
		{ PropertyTagImageWidth,_T("ImageWidth") },
		{ PropertyTagImageHeight,_T("ImageHeight") },
		{ PropertyTagBitsPerSample,_T("BitsPerSample") },
		{ PropertyTagCompression,_T("Compression") },
		{ PropertyTagPhotometricInterp,_T("PhotometricInterp") },
		{ PropertyTagThreshHolding,_T("ThreshHolding") },
		{ PropertyTagCellWidth,_T("CellWidth") },
		{ PropertyTagCellHeight,_T("CellHeight") },
		{ PropertyTagFillOrder,_T("FillOrder") },
		{ PropertyTagDocumentName,_T("DocumentName") },
		{ PropertyTagImageDescription,_T("ImageDescription") },
		{ PropertyTagEquipMake,_T("EquipMake") },
		{ PropertyTagEquipModel,_T("EquipModel") },
		{ PropertyTagStripOffsets,_T("StripOffsets") },
		{ PropertyTagOrientation,_T("Orientation") },
		{ PropertyTagSamplesPerPixel,_T("SamplesPerPixel") },
		{ PropertyTagRowsPerStrip,_T("RowsPerStrip") },
		{ PropertyTagStripBytesCount,_T("StripBytesCount") },
		{ PropertyTagMinSampleValue,_T("MinSampleValue") },
		{ PropertyTagMaxSampleValue,_T("MaxSampleValue") },
		{ PropertyTagXResolution,_T("XResolution") },
		{ PropertyTagYResolution,_T("YResolution") },
		{ PropertyTagPlanarConfig,_T("PlanarConfig") },
		{ PropertyTagPageName,_T("PageName") },
		{ PropertyTagXPosition,_T("XPosition") },
		{ PropertyTagYPosition,_T("YPosition") },
		{ PropertyTagFreeOffset,_T("FreeOffset") },
		{ PropertyTagFreeByteCounts,_T("FreeByteCounts") },
		{ PropertyTagGrayResponseUnit,_T("GrayResponseUnit") },
		{ PropertyTagGrayResponseCurve,_T("GrayResponseCurve") },
		{ PropertyTagT4Option,_T("T4Option") },
		{ PropertyTagT6Option,_T("T6Option") },
		{ PropertyTagResolutionUnit,_T("ResolutionUnit") },
		{ PropertyTagPageNumber,_T("PageNumber") },
		{ PropertyTagTransferFuncition,_T("TransferFuncition") },
		{ PropertyTagSoftwareUsed,_T("SoftwareUsed") },
		{ PropertyTagDateTime,_T("DateTime") },
		{ PropertyTagArtist,_T("Artist") },
		{ PropertyTagHostComputer,_T("HostComputer") },
		{ PropertyTagPredictor,_T("Predictor") },
		{ PropertyTagWhitePoint,_T("WhitePoint") },
		{ PropertyTagPrimaryChromaticities,_T("PrimaryChromaticities") },
		{ PropertyTagColorMap,_T("ColorMap") },
		{ PropertyTagHalftoneHints,_T("HalftoneHints") },
		{ PropertyTagTileWidth,_T("TileWidth") },
		{ PropertyTagTileLength,_T("TileLength") },
		{ PropertyTagTileOffset,_T("TileOffset") },
		{ PropertyTagTileByteCounts,_T("TileByteCounts") },
		{ PropertyTagInkSet,_T("InkSet") },
		{ PropertyTagInkNames,_T("InkNames") },
		{ PropertyTagNumberOfInks,_T("NumberOfInks") },
		{ PropertyTagDotRange,_T("DotRange") },
		{ PropertyTagTargetPrinter,_T("TargetPrinter") },
		{ PropertyTagExtraSamples,_T("ExtraSamples") },
		{ PropertyTagSampleFormat,_T("SampleFormat") },
		{ PropertyTagSMinSampleValue,_T("SMinSampleValue") },
		{ PropertyTagSMaxSampleValue,_T("SMaxSampleValue") },
		{ PropertyTagTransferRange,_T("TransferRange") },
		{ PropertyTagJPEGProc,_T("JPEGProc") },
		{ PropertyTagJPEGInterFormat,_T("JPEGInterFormat") },
		{ PropertyTagJPEGInterLength,_T("JPEGInterLength") },
		{ PropertyTagJPEGRestartInterval,_T("JPEGRestartInterval") },
		{ PropertyTagJPEGLosslessPredictors,_T("JPEGLosslessPredictors") },
		{ PropertyTagJPEGPointTransforms,_T("JPEGPointTransforms") },
		{ PropertyTagJPEGQTables,_T("JPEGQTables") },
		{ PropertyTagJPEGDCTables,_T("JPEGDCTables") },
		{ PropertyTagJPEGACTables,_T("JPEGACTables") },
		{ PropertyTagYCbCrCoefficients,_T("YCbCrCoefficients") },
		{ PropertyTagYCbCrSubsampling,_T("YCbCrSubsampling") },
		{ PropertyTagYCbCrPositioning,_T("YCbCrPositioning") },
		{ PropertyTagREFBlackWhite,_T("REFBlackWhite") },
		{ PropertyTagICCProfile,_T("ICCProfile") },
		{ PropertyTagGamma,_T("Gamma") },
		{ PropertyTagICCProfileDescriptor,_T("ICCProfileDescriptor") },
		{ PropertyTagSRGBRenderingIntent,_T("SRGBRenderingIntent") },
		{ PropertyTagImageTitle,_T("ImageTitle") },
		{ PropertyTagCopyright,_T("Copyright") },
		{ PropertyTagResolutionXUnit,_T("ResolutionXUnit") },
		{ PropertyTagResolutionYUnit,_T("ResolutionYUnit") },
		{ PropertyTagResolutionXLengthUnit,_T("ResolutionXLengthUnit") },
		{ PropertyTagResolutionYLengthUnit,_T("ResolutionYLengthUnit") },
		{ PropertyTagPrintFlags,_T("PrintFlags") },
		{ PropertyTagPrintFlagsVersion,_T("PrintFlagsVersion") },
		{ PropertyTagPrintFlagsCrop,_T("PrintFlagsCrop") },
		{ PropertyTagPrintFlagsBleedWidth,_T("PrintFlagsBleedWidth") },
		{ PropertyTagPrintFlagsBleedWidthScale,_T("PrintFlagsBleedWidthScale") },
		{ PropertyTagHalftoneLPI,_T("HalftoneLPI") },
		{ PropertyTagHalftoneLPIUnit,_T("HalftoneLPIUnit") },
		{ PropertyTagHalftoneDegree,_T("HalftoneDegree") },
		{ PropertyTagHalftoneShape,_T("HalftoneShape") },
		{ PropertyTagHalftoneMisc,_T("HalftoneMisc") },
		{ PropertyTagHalftoneScreen,_T("HalftoneScreen") },
		{ PropertyTagJPEGQuality,_T("JPEGQuality") },
		{ PropertyTagGridSize,_T("GridSize") },
		{ PropertyTagThumbnailFormat,_T("ThumbnailFormat") },
		{ PropertyTagThumbnailWidth,_T("ThumbnailWidth") },
		{ PropertyTagThumbnailHeight,_T("ThumbnailHeight") },
		{ PropertyTagThumbnailColorDepth,_T("ThumbnailColorDepth") },
		{ PropertyTagThumbnailPlanes,_T("ThumbnailPlanes") },
		{ PropertyTagThumbnailRawBytes,_T("ThumbnailRawBytes") },
		{ PropertyTagThumbnailSize,_T("ThumbnailSize") },
		{ PropertyTagThumbnailCompressedSize,_T("ThumbnailCompressedSize") },
		{ PropertyTagColorTransferFunction,_T("ColorTransferFunction") },
		{ PropertyTagThumbnailData,_T("ThumbnailData") },
		{ PropertyTagThumbnailImageWidth,_T("ThumbnailImageWidth") },
		{ PropertyTagThumbnailImageHeight,_T("ThumbnailImageHeight") },
		{ PropertyTagThumbnailBitsPerSample,_T("ThumbnailBitsPerSample") },
		{ PropertyTagThumbnailCompression,_T("ThumbnailCompression") },
		{ PropertyTagThumbnailPhotometricInterp,_T("ThumbnailPhotometricInterp") },
		{ PropertyTagThumbnailImageDescription,_T("ThumbnailImageDescription") },
		{ PropertyTagThumbnailEquipMake,_T("ThumbnailEquipMake") },
		{ PropertyTagThumbnailEquipModel,_T("ThumbnailEquipModel") },
		{ PropertyTagThumbnailStripOffsets,_T("ThumbnailStripOffsets") },
		{ PropertyTagThumbnailOrientation,_T("ThumbnailOrientation") },
		{ PropertyTagThumbnailSamplesPerPixel,_T("ThumbnailSamplesPerPixel") },
		{ PropertyTagThumbnailRowsPerStrip,_T("ThumbnailRowsPerStrip") },
		{ PropertyTagThumbnailStripBytesCount,_T("ThumbnailStripBytesCount") },
		{ PropertyTagThumbnailResolutionX,_T("ThumbnailResolutionX") },
		{ PropertyTagThumbnailResolutionY,_T("ThumbnailResolutionY") },
		{ PropertyTagThumbnailPlanarConfig,_T("ThumbnailPlanarConfig") },
		{ PropertyTagThumbnailResolutionUnit,_T("ThumbnailResolutionUnit") },
		{ PropertyTagThumbnailTransferFunction,_T("ThumbnailTransferFunction") },
		{ PropertyTagThumbnailSoftwareUsed,_T("ThumbnailSoftwareUsed") },
		{ PropertyTagThumbnailDateTime,_T("ThumbnailDateTime") },
		{ PropertyTagThumbnailArtist,_T("ThumbnailArtist") },
		{ PropertyTagThumbnailWhitePoint,_T("ThumbnailWhitePoint") },
		{ PropertyTagThumbnailPrimaryChromaticities,_T("ThumbnailPrimaryChromaticities") },
		{ PropertyTagThumbnailYCbCrCoefficients,_T("ThumbnailYCbCrCoefficients") },
		{ PropertyTagThumbnailYCbCrSubsampling,_T("ThumbnailYCbCrSubsampling") },
		{ PropertyTagThumbnailYCbCrPositioning,_T("ThumbnailYCbCrPositioning") },
		{ PropertyTagThumbnailRefBlackWhite,_T("ThumbnailRefBlackWhite") },
		{ PropertyTagThumbnailCopyRight,_T("ThumbnailCopyRight") },
		{ PropertyTagLuminanceTable,_T("LuminanceTable") },
		{ PropertyTagChrominanceTable,_T("ChrominanceTable") },
		{ PropertyTagFrameDelay,_T("FrameDelay") },
		{ PropertyTagLoopCount,_T("LoopCount") },
		{ PropertyTagPixelUnit,_T("PixelUnit") },
		{ PropertyTagPixelPerUnitX,_T("PixelPerUnitX") },
		{ PropertyTagPixelPerUnitY,_T("PixelPerUnitY") },
		{ PropertyTagPaletteHistogram,_T("PaletteHistogram") },
		{ PropertyTagExifExposureTime,_T("ExifExposureTime") },
		{ PropertyTagExifFNumber,_T("ExifFNumber") },
		{ PropertyTagExifExposureProg,_T("ExifExposureProg") },
		{ PropertyTagExifSpectralSense,_T("ExifSpectralSense") },
		{ PropertyTagExifISOSpeed,_T("ExifISOSpeed") },
		{ PropertyTagExifOECF,_T("ExifOECF") },
		{ PropertyTagExifVer,_T("ExifVer") },
		{ PropertyTagExifDTOrig,_T("ExifDTOrig") },
		{ PropertyTagExifDTDigitized,_T("ExifDTDigitized") },
		{ PropertyTagExifCompConfig,_T("ExifCompConfig") },
		{ PropertyTagExifCompBPP,_T("ExifCompBPP") },
		{ PropertyTagExifShutterSpeed,_T("ExifShutterSpeed") },
		{ PropertyTagExifAperture,_T("ExifAperture") },
		{ PropertyTagExifBrightness,_T("ExifBrightness") },
		{ PropertyTagExifExposureBias,_T("ExifExposureBias") },
		{ PropertyTagExifMaxAperture,_T("ExifMaxAperture") },
		{ PropertyTagExifSubjectDist,_T("ExifSubjectDist") },
		{ PropertyTagExifMeteringMode,_T("ExifMeteringMode") },
		{ PropertyTagExifLightSource,_T("ExifLightSource") },
		{ PropertyTagExifFlash,_T("ExifFlash") },
		{ PropertyTagExifFocalLength,_T("ExifFocalLength") },
		{ PropertyTagExifMakerNote,_T("ExifMakerNote") },
		{ PropertyTagExifUserComment,_T("ExifUserComment") },
		{ PropertyTagExifDTSubsec,_T("ExifDTSubsec") },
		{ PropertyTagExifDTOrigSS,_T("ExifDTOrigSS") },
		{ PropertyTagExifDTDigSS,_T("ExifDTDigSS") },
		{ PropertyTagExifFPXVer,_T("ExifFPXVer") },
		{ PropertyTagExifColorSpace,_T("ExifColorSpace") },
		{ PropertyTagExifPixXDim,_T("ExifPixXDim") },
		{ PropertyTagExifPixYDim,_T("ExifPixYDim") },
		{ PropertyTagExifRelatedWav,_T("ExifRelatedWav") },
		{ PropertyTagExifInterop,_T("ExifInterop") },
		{ PropertyTagExifFlashEnergy,_T("ExifFlashEnergy") },
		{ PropertyTagExifSpatialFR,_T("ExifSpatialFR") },
		{ PropertyTagExifFocalXRes,_T("ExifFocalXRes") },
		{ PropertyTagExifFocalYRes,_T("ExifFocalYRes") },
		{ PropertyTagExifFocalResUnit,_T("ExifFocalResUnit") },
		{ PropertyTagExifSubjectLoc,_T("ExifSubjectLoc") },
		{ PropertyTagExifExposureIndex,_T("ExifExposureIndex") },
		{ PropertyTagExifSensingMethod,_T("ExifSensingMethod") },
		{ PropertyTagExifFileSource,_T("ExifFileSource") },
		{ PropertyTagExifSceneType,_T("ExifSceneType") },
		{ PropertyTagExifCfaPattern,_T("ExifCfaPattern") },
		{ PropertyTagGpsVer,_T("GpsVer") },
		{ PropertyTagGpsLatitudeRef,_T("GpsLatitudeRef") },
		{ PropertyTagGpsLatitude,_T("GpsLatitude") },
		{ PropertyTagGpsLongitudeRef,_T("GpsLongitudeRef") },
		{ PropertyTagGpsLongitude,_T("GpsLongitude") },
		{ PropertyTagGpsAltitudeRef,_T("GpsAltitudeRef") },
		{ PropertyTagGpsAltitude,_T("GpsAltitude") },
		{ PropertyTagGpsGpsTime,_T("GpsGpsTime") },
		{ PropertyTagGpsGpsSatellites,_T("GpsGpsSatellites") },
		{ PropertyTagGpsGpsStatus,_T("GpsGpsStatus") },
		{ PropertyTagGpsGpsMeasureMode,_T("GpsGpsMeasureMode") },
		{ PropertyTagGpsGpsDop,_T("GpsGpsDop") },
		{ PropertyTagGpsSpeedRef,_T("GpsSpeedRef") },
		{ PropertyTagGpsSpeed,_T("GpsSpeed") },
		{ PropertyTagGpsTrackRef,_T("GpsTrackRef") },
		{ PropertyTagGpsTrack,_T("GpsTrack") },
		{ PropertyTagGpsImgDirRef,_T("GpsImgDirRef") },
		{ PropertyTagGpsImgDir,_T("GpsImgDir") },
		{ PropertyTagGpsMapDatum,_T("GpsMapDatum") },
		{ PropertyTagGpsDestLatRef,_T("GpsDestLatRef") },
		{ PropertyTagGpsDestLat,_T("GpsDestLat") },
		{ PropertyTagGpsDestLongRef,_T("GpsDestLongRef") },
		{ PropertyTagGpsDestLong,_T("GpsDestLong") },
		{ PropertyTagGpsDestBearRef,_T("GpsDestBearRef") },
		{ PropertyTagGpsDestBear,_T("GpsDestBear") },
		{ PropertyTagGpsDestDistRef,_T("GpsDestDistRef") },
		{ PropertyTagGpsDestDist,_T("GpsDestDist") },
		{ 0, NULL },
	};
	for (int i=0; PropNames[i].name; i++) {
		if (prop.id==PropNames[i].id) {
			return PropNames[i].name;
		}
	}
	return _T("Unknown property");
}

//////////////////
// Draw hex mode display
//
int CPictureView::DrawHex(CDC& dc, CPicture* /* pic */)
{
	CRect rc;
	GetClientRect(&rc);
	CString s;
	if (m_iPage==PAGE_HEX) {
		s = _T("[Under construction.]");
	} else {
		CFolderTabCtrl& ftab = GetFolderFrame()->GetFolderTabCtrl();
		s.Format(_T("%s"), ftab.GetTab()->GetText());
	}
	CFont *pOldFont = dc.SelectObject(&g_font);	// select my font
	dc.DrawText(s, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
	dc.SelectObject(pOldFont);
	return rc.Height();
}

//////////////////
// user selected a new page: change it and repaint
//
void CPictureView::OnChangedFolder(int iPage)
{
	m_iPage = iPage;
	UpdateScrollSizes();
	Invalidate();
}

////////////////////////////////////////////////////////////////
// Handle font change (bigger/smaller/dialog)
//
void CPictureView::OnFontChange(UINT nID)
{
	CFontUI fui;
	if (fui.ChangeFont(g_font,
		nID==ID_VIEW_FONT_BIGGER ? 1 : nID==ID_VIEW_FONT_SMALLER ? -1 : 0,
		this,
		CF_SCREENFONTS|CF_FORCEFONTEXIST)) {

		// For all views to recompute scroll sizes and repaint
		GetTopLevelFrame()->SendMessageToDescendants(WM_INITIALUPDATE);
	}
}

////////////////////////////////////////////////////////////////
// Enable/disable font commands (bigger/smaller/dialog)
//
void CPictureView::OnUpdateFontChange(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_iPage==PAGE_INFO||m_iPage==PAGE_HEX);
}

////////////////////////////////////////////////////////////////
// Handle view page (Ctrl-1, etc)
//
void CPictureView::OnViewPage(UINT nID)
{
	CFolderTabCtrl& ftab = GetFolderFrame()->GetFolderTabCtrl();
	ftab.SelectTab(nID-ID_VIEW_PAGE1);
}

//////////////////
// View was sized: readjust scroll sizes if I'm in "zoom to fit" mode
//
void CPictureView::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);
	if (m_iHowScale==ID_VIEW_TOFIT) {
		UpdateScrollSizes();
	}
}

//////////////////
// Erase the background. This is required in case the image is smaller than
// the client area, to paint the extra background. Use clipping to avoid
// flicker.
//
BOOL CPictureView::OnEraseBkgnd(CDC* pDC)
{
	if (m_iPage!=PAGE_IMAGE)
		return CFolderView::OnEraseBkgnd(pDC);

	CPictureDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// get client rectangle
	CRect rcClient;
	GetClientRect(&rcClient);
	CRect rc = rcClient;

	// get image rectangle
	CRect rcImage;
	GetImageRect(rcImage);
	rc = rcImage;

	CPoint pt = pDC->GetViewportOrg();
	CSize sz = GetTotalSize();

	// create clipping region
	CRgn clipRgn;
	clipRgn.CreateRectRgnIndirect(&rcClient);
	pDC->SelectClipRgn(&clipRgn);
	pDC->ExcludeClipRect(&rcImage);

	// paint excess black
	pDC->FillSolidRect(rcClient,RGB(0,0,0));

	pDC->SelectClipRgn(NULL);

	return TRUE;
}


