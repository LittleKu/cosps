//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CoolEdit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAMESDI                128
#define IDR_MAINFRAMEMDI                129
#define IDR_MYDOCTYPE                   130
#define IDB_COOLBARBG                   132
#define ID_BUTTONTEST                   134
#define IDR_TOOLBAR1                    136
#define IDR_FILEDROPDOWN                137
#define IDR_VIEWCONTEXTMENU             138
#define IDR_FRAMECONTEXTMENU            139
#define IDC_STATICURLPD                 1000
#define IDC_STATICURLMSDN               1001
#define IDC_COMCTL32VER                 1002
#define IDC_PIXIEBMP                    1003
#define ID_VIEW_MENU_BUTTONS            32772
#define ID_DISABLED                     32773
#define ID_VIEW_WINDOW                  32774
#define ID_VIEW_3DFACE                  32775
#define ID_VIEW_RED                     32776
#define ID_VIEW_GREEN                   32777
#define ID_VIEW_BLUE                    32778
#define ID_VIEW_BGCOLOR                 32790
#define ID_VIEW_FLAT                    32810
#define ID_VIEW_CBBITMAP                32811
#define ID_USE_TOOLBAR                  32817
#define ID_COLOR_DISABLE                32818
#define ID_VIEW_LOCKBARS					 32819

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
