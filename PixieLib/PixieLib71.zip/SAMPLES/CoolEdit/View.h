////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "Doc.h"

//////////////////
// Standard edit view lets user select background and also
// shows how to use CCoolMenuWindow.
//
class CMyView : public CEditView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }

	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	void OnSysColorChange();		  // called by main frame
	void SetColor(COLORREF color);  // change bg color

protected:
	CMyView();

	CBrush m_brush;							 // background brush
	COLORREF m_color;							 // current BG color
	CMenu		m_contextMenu;					 // right-button context menu
	CCoolMenuWindow m_coolMenuHandler;	 // handles cool menus
	
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnViewCustomColor();
	afx_msg void OnViewColor(UINT nID);
	afx_msg void OnUpdateViewColor(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMyView)
};
