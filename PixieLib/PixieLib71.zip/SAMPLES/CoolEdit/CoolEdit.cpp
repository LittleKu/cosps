////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CoolEdit is a text editor that illustrates how to use many of the "Cool UI"
// classes in PixieLib: coolbars, menu bars, cool menus (with bitmap buttons
// and accelerator mnemonics), menu tips, toolbar lock and so on. You can
// build CoolEdit either as and SDI or MDI app, depending on the setting of
// the preprocessor symbol _MDIAPP.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "resource.h" // main symbols

class CMyApp : public CWinApp {
public:
	CMyApp();
	~CMyApp();
protected:
	GdiplusStartupInput m_gdiplusStartupInput;
	ULONG_PTR m_gdiplusToken;
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
} theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

CMyApp::CMyApp()
{
	VERIFY(GdiplusStartup(&m_gdiplusToken, &m_gdiplusStartupInput, NULL)==Ok);
}

CMyApp::~CMyApp()
{
	GdiplusShutdown(m_gdiplusToken);
}

BOOL CMyApp::InitInstance()
{
//	SetRegistryKey(_T("PixieLib")); // Save settings in registry, not INI file-NOT!
	LoadStdProfileSettings(8);  // Load standard INI file options (8 MRU files)
	VERIFY(GdiplusStartup(&m_gdiplusToken, &m_gdiplusStartupInput, NULL)==Ok);

#ifdef NEVER // _DEBUG
	// turn on extra diagnostics
	CFlatToolBar::bTRACE = TRUE;
	CCoolBar::bTRACE = TRUE;
	CCoolMenuManager::bTRACE = TRUE;
	CMenuBar::bTRACE = TRUE;
#endif

#ifdef _MDIAPP
	AddDocTemplate(new CMultiDocTemplate(IDR_MYDOCTYPE,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMDIChildWnd),
		RUNTIME_CLASS(CMyView)));
#else
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView)));
#endif
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

#ifdef _MDIAPP
	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

#else // SDI app
	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
#endif
	return TRUE;
}

//////////////////
// Custom about dialog uses CStatLink for hyperlinks and its
// own CStatic to display the comctl32.dll version number
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	CPictureCtrl m_wndPict;
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX) { }
	CStatic m_wndComCtl32Version;	 // comctl32.dll version message
	virtual BOOL OnInitDialog();
};

/////////////////
// Initialize dialog: subclass static text/icon controls
//
BOOL CAboutDialog::OnInitDialog()
{
	// subclass hyperlinks
	m_wndLink1.SubclassDlgItem(IDC_STATICURLPD,this);
	m_wndLink2.SubclassDlgItem(IDC_STATICURLMSDN,this);
	m_wndPict.SubclassDlgItem(IDC_PIXIEBMP,this);

	// Fill in comctl32.dll version
	m_wndComCtl32Version.SubclassDlgItem(IDC_COMCTL32VER, this);

	CModuleVersion ver;
	DLLVERSIONINFO dvi;
	if (ver.DllGetVersion(_T("comctl32.dll"), dvi)) {
		CString s;
		s.Format(_T("ComCtl32.dll version is %d.%d.%d"),
			dvi.dwMajorVersion, dvi.dwMinorVersion, dvi.dwBuildNumber);
		m_wndComCtl32Version.SetWindowText(s);
	}
	return CDialog::OnInitDialog();
}

void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}
