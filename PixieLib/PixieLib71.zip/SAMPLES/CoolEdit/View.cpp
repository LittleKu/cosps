////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "View.h"
#include "MainFrm.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_VCOLOR_FIRST ID_VIEW_WINDOW
#define ID_VCOLOR_LAST  ID_VIEW_BLUE

IMPLEMENT_DYNCREATE(CMyView, CEditView)

BEGIN_MESSAGE_MAP(CMyView, CEditView)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_VIEW_BGCOLOR,										 OnViewCustomColor)
	ON_COMMAND_RANGE(ID_VCOLOR_FIRST,ID_VCOLOR_LAST,			 OnViewColor)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VCOLOR_FIRST,ID_VCOLOR_LAST,OnUpdateViewColor)
END_MESSAGE_MAP()

// These are the different colors used
static COLORREF colors[5] = {
	0, // window color, filled in at runtime
	0,	// 3dface color, filled in at runtime
	RGB(255,0,0), // red
	RGB(0,255,0), // green
	RGB(0,0,255), // blue
};

CMyView::CMyView()
{
	m_color = (COLORREF)-1;		// set bg color invalid
	OnSysColorChange();			// compute window, 3d face colors
	SetColor(colors[0]);			// set color to window color
}

CMyView::~CMyView()
{
}

/////////////////
// Set background color for edit control
//
void CMyView::SetColor(COLORREF color)
{
	m_brush.DeleteObject();					 // delete old brush
	m_brush.CreateSolidBrush(color);		 // create a new one
	m_color = color;							 // set color
	if (m_hWnd)									 // and..
		Invalidate();							 // .. repaint
}

//////////////////
// Handle WM_CTLCOLOR: set background color
//
HBRUSH CMyView::CtlColor(CDC* pDC, UINT /* nCtlColor */)
{
	pDC->SetBkColor(m_color);
	return m_brush;
}

/////////////////
// Called by CMainFrame when system colors change: recompute
// COLOR_WINDOW and COLOR_3DFACE
//
void CMyView::OnSysColorChange()
{
	// First, remember if current color is same as window or 3d face
	int iCurrentColor = -1;
	if (m_color == colors[0])
		iCurrentColor = 0;
	else if (m_color == colors[1])
		iCurrentColor = 1;

	// update colors
	colors[0] = GetSysColor(COLOR_WINDOW);
	colors[1] = GetSysColor(COLOR_3DFACE);

	// if bg color was window or 3d face, restore it
	if (iCurrentColor>=0)
		SetColor(colors[iCurrentColor]);
}

//////////////////
// Draw: nothing to do
//
void CMyView::OnDraw(CDC* /* pDC */)
{
}

//////////////////
// Since edit controls normally generate a popup menu on their own, and
// DON'T send WM_INITMENUPOPUP (they call TrackPopupMenu with TPM_NONOTIFY),
// You need to do your own context menu if you want bitmaps in them.
//
void CMyView::OnContextMenu(CWnd* /* pWnd */, CPoint p)
{
	// load context menu if not already. Menu is 1st submenu in resource menu
	if (!m_contextMenu) {
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_VIEWCONTEXTMENU));
		m_contextMenu.Attach(::GetSubMenu(menu, 0));
		menu.Detach(); // otherwise destructor will destroy my menu!
	}

	// install cool menu handler if not already
	if (!m_coolMenuHandler.IsHooked()) {
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT_VALID(pFrame);
		ASSERT_KINDOF(CMainFrame, pFrame);
		m_coolMenuHandler.Install(this, pFrame->GetMenuManager());
	}

	ASSERT_VALID(&m_contextMenu);

	// Note that I use AfxGetMainWnd as the window to send notifications
	// too. This will ensure that the menu items are initialized through
	// MFC's normal WM_INITMENUPOPUP mechanisms.
	m_contextMenu.TrackPopupMenu(0, p.x, p.y, AfxGetMainWnd());
}

//////////////////
// Command handler: run color dialog to set arbitrary background color
//
void CMyView::OnViewCustomColor()
{
	CColorDialog dlg;
	if (dlg.DoModal() != IDCANCEL)
		SetColor(dlg.GetColor());
}

//////////////////
// Command and UI update handler: set predefined background color
//
void CMyView::OnViewColor(UINT nID)
{
	SetColor(colors[nID - ID_VCOLOR_FIRST]);
}
void CMyView::OnUpdateViewColor(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_color == colors[pCmdUI->m_nID - ID_VCOLOR_FIRST]);
}

