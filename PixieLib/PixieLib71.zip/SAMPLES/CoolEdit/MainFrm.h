////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#ifdef _MDIAPP
#define CBaseFrameWnd CMDIFrameWnd
#define IDR_MAINFRAME IDR_MAINFRAMEMDI
#else
#define CBaseFrameWnd CFrameWnd
#define IDR_MAINFRAME IDR_MAINFRAMESDI
#endif

////////////////
// Special combo box in cool bar used to select which views are displayed
//
class CMyComboBox : public CComboBox {
protected:
	DECLARE_DYNAMIC(CMyComboBox)
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropDown();
};

/////////////////
// My cool bar. Contains toolbar, menu bar and combo box
//
class CMyCoolBar : public CCoolBar {
protected:
	DECLARE_DYNAMIC(CMyCoolBar)
	CFlatToolBar	m_wndToolBar;			 // toolbar
	CMenuBar			m_wndMenuBar;			 // menu bar
	CMyComboBox		m_wndCombo;				 // combo box
	virtual BOOL   OnCreateBands();		 // fn to create the bands
};

/////////////////
// Main frame window has menu manager, cool bar, status bar
//
class CMainFrame : public CBaseFrameWnd {
public:
	CMainFrame();
	~CMainFrame();
	CCoolMenuManager* GetMenuManager() { return &m_menuManager; }

protected:
	CCoolMenuManager	m_menuManager;		 // manages menus for entire app + views
	CMenuTipManager	m_menuTipManager;	 // managed menu tips
	CMenu					m_contextMenu;		 // right-click menu
	CStatusBar			m_wndStatusBar;	 // standard status bar
	CLockBars			m_lockToolbars;	 // toolbar lock

	// Stuff for painting custom title bar:
	CCaptionPainter m_captionPainter;	 // caption painter
	CFont m_fontCaption;						 // normal system font for active caption
	CFont m_fontAppName;						 // "CoolEdit" font (same active/inactive)

	// Note: because this particular app can use two kinds of toolbars
	// (CFlatToolBar or CMyCoolBar), the objects are allocated rather than
	// stored as members. In a normal app, you would instantiate one or the
	// other as m_wndToolBar or m_wndCoolBar. That is:
	//
	//			CMyCoolBar		m_wndCoolBar;	// for coolbar (rebar)
	// or
	//			CMenuBar			m_wndMenuBar;	// for menu bar + toolbar
	//			CFlatToolBar	m_wndToolBar;
	//
	// then, throughout the code, you would replace m_pToolBar->foo
	// with m_wndToolBar.foo, and get rid of all the code for the other
	// kind of toolbar. Got it?
	//
	CMyCoolBar*				m_pCoolBar;		 // if using coolbar (rebar)
	CMenuBar*				m_pMenuBar;		 // if using menu bar/toolbar
	CFlatToolBar*			m_pToolBar;		 // ...
	CBitmap				   m_bmCoolBar;	 // coolbar bitmap
	int						m_iVerComCtl;	 // version of comctl32.dll (eg 471)

	// helpers
	BOOL CreateCoolBar();
	BOOL CreateToolBar();
	void ShowCoolbarBitmap(BOOL bShow);
	CFlatToolBar* GetToolBar() {
		return m_pCoolBar ? &m_pCoolBar->m_wndToolBar : m_pToolBar;
	}
	CMenuBar* GetMenuBar() {
		return m_pCoolBar ? &m_pCoolBar->m_wndMenuBar : m_pMenuBar;
	}
	CString GetDocTitle();
	void    CreateFonts();

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	afx_msg void OnSysColorChange();

	// command handlers
	afx_msg void OnUseToolbar();
	afx_msg void OnUpdateUseToolbar(CCmdUI* pCmdUI);
	afx_msg void OnColorDisabled();
	afx_msg void OnUpdateColorDisabled(CCmdUI* pCmdUI);
	afx_msg void OnViewMenuButtons();
	afx_msg void OnUpdateViewMenuButtons(CCmdUI* pCmdUI);
	afx_msg void OnFlatTB();
	afx_msg void OnUpdateFlatTB(CCmdUI* pCmdUI);
	afx_msg void OnHideShowCoolBarBitmap();
	afx_msg void OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI);
	afx_msg void OnComboChange();
	afx_msg void OnLockBars();
	afx_msg void OnUpdateLockBars(CCmdUI* pCmdUI);
	afx_msg LRESULT OnPaintMyCaption(WPARAM wp, LPARAM lp);

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
