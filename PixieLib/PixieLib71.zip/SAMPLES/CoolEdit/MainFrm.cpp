////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// stuff for shaded caption
#define COLOR_WHITE RGB(255,255,255)
#define COLOR_BLACK RGB(0,0,0)
#define NCOLORSHADES 64		// this many shades in caption gradient

// Use for older Windows:
//#define COLOR_RIGHTMOST COLOR_ACTIVECAPTION

// Use for modern Windows (Windows 2000 and recent Win 98):
#define COLOR_GRADIENTACTIVECAPTION 27
#define COLOR_RIGHTMOST COLOR_GRADIENTACTIVECAPTION

// ID and minimum size of combo box in coolbar band
const IDCOMBO = 1001;
const COMBO_CXMIN = 150;

// callback message ID for caption painter
const UINT WM_PAINTMYCAPTION = WM_USER;

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CBaseFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CBaseFrameWnd)
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	ON_WM_SYSCOLORCHANGE()
	ON_COMMAND(ID_USE_TOOLBAR,				 OnUseToolbar)
	ON_UPDATE_COMMAND_UI(ID_USE_TOOLBAR, OnUpdateUseToolbar)
	ON_COMMAND(ID_COLOR_DISABLE,				 OnColorDisabled)
	ON_UPDATE_COMMAND_UI(ID_COLOR_DISABLE,  OnUpdateColorDisabled)
	ON_COMMAND(ID_VIEW_MENU_BUTTONS,				 OnViewMenuButtons)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MENU_BUTTONS, OnUpdateViewMenuButtons)
	ON_COMMAND(ID_VIEW_FLAT,			  OnFlatTB)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FLAT, OnUpdateFlatTB)
	ON_COMMAND(ID_VIEW_CBBITMAP,			   OnHideShowCoolBarBitmap)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CBBITMAP, OnUpdateHideShowCoolbarBitmap)
	ON_CBN_SELCHANGE(IDCOMBO, OnComboChange)
	ON_COMMAND(ID_VIEW_LOCKBARS, OnLockBars)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOCKBARS, OnUpdateLockBars)
	ON_MESSAGE(WM_PAINTMYCAPTION, OnPaintMyCaption)
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
	m_pCoolBar = NULL;
	m_pToolBar = NULL;
	m_pMenuBar = NULL;
	m_iVerComCtl = CFlatToolBar::iVerComCtl32;
	ASSERT(m_iVerComCtl > 0);
}

CMainFrame::~CMainFrame()
{
	// one of these will be NULL, but OK to delete NULL
	delete m_pCoolBar;
	delete m_pToolBar;
	delete m_pMenuBar;
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with coolbars, but it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
   return CBaseFrameWnd::PreCreateWindow(cs);
}

//////////////////
// Create handler creates control bars
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CBaseFrameWnd::OnCreate(lpCreateStruct) == 0);

	OnUseToolbar(); // first time will create coolbar
	ShowCoolbarBitmap(TRUE);

	// Create status bar
	static UINT indicators[] = {
		ID_SEPARATOR, ID_INDICATOR_CAPS, ID_INDICATOR_NUM, ID_INDICATOR_SCRL };

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(indicators[0])));
		
	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_TOOLBAR1);

	// Install menu tip manager--that's all!
	m_menuTipManager.Install(this);

	// Install caption painter
	m_captionPainter.Install(this, WM_PAINTMYCAPTION);

	return 0;
}

//////////////////
// Create coolbar
//
BOOL CMainFrame::CreateCoolBar()
{
	ASSERT(m_pCoolBar==NULL);
	m_pCoolBar = new CMyCoolBar;
	ASSERT(m_pCoolBar);
	CMyCoolBar& cb = *m_pCoolBar;

	VERIFY(cb.Create(this,
		WS_CHILD|WS_VISIBLE|WS_BORDER|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			RBS_TOOLTIPS|RBS_BANDBORDERS|RBS_VARHEIGHT));

	cb.SetColors(GetSysColor(COLOR_BTNTEXT),
		GetSysColor(COLOR_3DFACE));

	cb.SetBackgroundBitmap(&m_bmCoolBar);
	cb.Invalidate();

	return TRUE;
}

//////////////////
// Create flat style toolbar
//
BOOL CMainFrame::CreateToolBar()
{
	// First create the menu bar
	ASSERT(m_pMenuBar==NULL);
	m_pMenuBar = new CMenuBar;
	ASSERT(m_pMenuBar);
	CMenuBar& mb = *m_pMenuBar;

	VERIFY(mb.Create(this));
	CFrameWnd* pFrame = GetActiveFrame();
	mb.LoadMenu(MAKEINTRESOURCE(pFrame != this ?
		IDR_MYDOCTYPE : IDR_MAINFRAME));
	mb.SetBarStyle(mb.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC | CBRS_GRIPPER);

	CRect rc;
	mb.GetItemRect(0, &rc);

	// enable docking for menu bar
	mb.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&mb);

	// Now create the toolbar
	ASSERT(m_pToolBar==NULL);
	m_pToolBar = new CFlatToolBar;
	ASSERT(m_pToolBar);
	CFlatToolBar& tb = *m_pToolBar;
	VERIFY(tb.Create(this));
	VERIFY(tb.LoadToolBar(IDR_TOOLBAR1));
	tb.SetBarStyle(tb.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC | CBRS_GRIPPER);

	// enable docking for toolbar
	tb.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&tb);

	// Install toolbar lock
	m_lockToolbars.Install(this);

	return TRUE;
}

//////////////////
// User changed system colors: update view, coolbar, menu manager
//
void CMainFrame::OnSysColorChange()
{
	CBaseFrameWnd::OnSysColorChange();

	CFrameWnd* pFrame = GetActiveFrame();
	ASSERT(pFrame);
	CMyView* pView = (CMyView*)pFrame->GetActiveView();
	if (pView) {
		ASSERT_KINDOF(CMyView, pView);
		pView->OnSysColorChange();				 // tell view too
	}

	if (m_pCoolBar) {
		// Set fg/bg color of coolbar to new values
		m_pCoolBar->SetColors(GetSysColor(COLOR_BTNTEXT),
			GetSysColor(COLOR_3DFACE));

		// If using coolbar bitmap, refresh
		if (m_bmCoolBar.GetSafeHandle()) {
			ShowCoolbarBitmap(FALSE);		 // hide
			ShowCoolbarBitmap(TRUE);		 // show
		}
	}
	GetToolBar()->Invalidate(); // repaint 
}

//////////////////
// User right-clicked: display a context menu.
//
void CMainFrame::OnContextMenu(CWnd* /* pWnd */, CPoint p)
{
	// TODO: change context menu
	if (!m_contextMenu) {
		// one-time load: context menu is 1st submenu in resource menu
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_FRAMECONTEXTMENU));
		m_contextMenu.Attach(::GetSubMenu(menu, 0));
		menu.Detach(); // otherwise destructor will destroy my menu!
	}
	ASSERT_VALID(&m_contextMenu);
	m_contextMenu.TrackPopupMenu(0, p.x, p.y, this);
}

//////////////////
// Command handlers for View | Hide/Show Menu Buttons
//
void CMainFrame::OnViewMenuButtons()
{
	m_menuManager.m_bShowButtons = !m_menuManager.m_bShowButtons;
}

void CMainFrame::OnUpdateViewMenuButtons(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_menuManager.m_bShowButtons);
	pCmdUI->SetText(m_menuManager.m_bShowButtons ?
		_T("Hide &Menu Buttons") : _T("Show &Menu Buttons"));
}

//////////////////
// Command: toggle toolbar locked state
//
void CMainFrame::OnLockBars()
{
	m_lockToolbars.SetLocked(!m_lockToolbars.GetLocked()); // toggle lock
}

//////////////////
// Command update: display checkmark for toolbar locked state
//
void CMainFrame::OnUpdateLockBars(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pToolBar && !m_pToolBar->IsFloating()); // disable if not docked
	pCmdUI->SetCheck(m_lockToolbars.GetLocked());
}

//////////////////
// Command handlers for View | Flat Toolbar
//
void CMainFrame::OnFlatTB()
{
	CFlatToolBar* tb[2];
	tb[0]=GetToolBar();
	tb[1]=GetMenuBar();
	for (int i=0; i<2; i++) {
		tb[i]->SetFlatStyle(!tb[i]->GetFlatStyle());
		tb[i]->Invalidate();
	}
}

void CMainFrame::OnUpdateFlatTB(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetToolBar()->GetFlatStyle());
}

//////////////////
// Toggle coolbar Bitmap
//
void CMainFrame::OnHideShowCoolBarBitmap()
{
	ShowCoolbarBitmap(m_bmCoolBar.GetSafeHandle() ? FALSE : TRUE);
}

void CMainFrame::OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pCoolBar != NULL);
	pCmdUI->SetText(m_bmCoolBar.GetSafeHandle() ?
		_T("Hide Coolbar &Bitmap") : _T("Show Coolbar &Bitmap"));
}

void CMainFrame::ShowCoolbarBitmap(BOOL bShow)
{
	if (bShow) {
		// show bitmap: load if needed
		if (!m_bmCoolBar.GetSafeHandle()) {

			// load bitmap
			HBITMAP hbm = (HBITMAP)::LoadImage(AfxGetResourceHandle(),
				MAKEINTRESOURCE(IDB_COOLBARBG),
				IMAGE_BITMAP,
				0, 0,
				LR_LOADMAP3DCOLORS|LR_LOADTRANSPARENT);
			ASSERT(hbm);
			m_bmCoolBar.Attach(hbm);
		}
	} else {
		// hide bitmap: delete if needed
		if (m_bmCoolBar.GetSafeHandle()) {
			m_bmCoolBar.DeleteObject();		 // delete bitmap
		}
	}
	if (m_pCoolBar) {
		m_pCoolBar->SetBackgroundBitmap(&m_bmCoolBar);
		m_pCoolBar->Invalidate();
	}
}

//////////////////
// Flip between coolbar and toolbar. Note that if comctl32.dd version is < 470
// there is no rebar control, so don't even attempt to create it.
//
void CMainFrame::OnUseToolbar()
{
	if (m_pCoolBar || m_iVerComCtl < 470) {
		if (m_pCoolBar) {
			delete m_pCoolBar;
			m_pCoolBar = NULL;
		}
		if (!m_pToolBar)
			CreateToolBar();

	} else {
		delete m_pToolBar;
		m_pToolBar = NULL;
		delete m_pMenuBar;
		m_pMenuBar = NULL;
		if (!m_pCoolBar)
			CreateCoolBar();		
	}

	// add dropdown button, but only if comctl32 version >= 4.71 (IE 4)
	//
	if (m_iVerComCtl >= 471) {
		CFlatToolBar& tb = *GetToolBar();
		tb.AddDropDownButton(ID_FILE_OPEN, IDR_FILEDROPDOWN, TRUE);
	}

	RecalcLayout();
}

void CMainFrame::OnUpdateUseToolbar(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_iVerComCtl >= 470);
	pCmdUI->SetText(m_pCoolBar ? _T("&Use Toolbar") : _T("&Use Coolbar"));
}

////////////////
// Toggle whether to draw disabled buttons in color
//
void CMainFrame::OnColorDisabled()
{
	CFlatToolBar& tb = *GetToolBar();
	BOOL b = !tb.m_bDrawDisabledButtonsInColor;
	tb.m_bDrawDisabledButtonsInColor = b;
	m_menuManager.m_bDrawDisabledButtonsInColor = b;
	tb.Invalidate();
}

void CMainFrame::OnUpdateColorDisabled(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetToolBar()->m_bDrawDisabledButtonsInColor);
}

// Private MFC function only sets the title if it's different
//
extern void AFXAPI AfxSetWindowText(HWND, LPCTSTR);

//////////////////
// Override to change title--app name first, then doc name, which is
// the opposite of the normal MFC way.
//
void CMainFrame::OnUpdateFrameTitle(BOOL /* bAddToTitle */)
{
	AfxSetWindowText(m_hWnd, m_strTitle + " " + GetDocTitle());
}

//////////////////
// Get doc title: I use full path name or "untitled"
//
CString CMainFrame::GetDocTitle()
{
	CString s;
	CFrameWnd *pFrame = GetActiveFrame();
	ASSERT(pFrame);
	CDocument * pDoc = pFrame->GetActiveDocument();
	if (pDoc)
		s = pDoc->GetTitle();
	return s;
}

//////////////////
// Helper function to compute the luminosity for an RGB color.
// Measures how bright the color is. I use this so I can draw the caption
// text using the user's chosen color, unless it's too dark. See MSDN for
// definition of luminosity and how to compute it.
//
static int GetLuminosity(COLORREF color)
{
#define HLSMAX 240	// This is what Display Properties uses
#define RGBMAX 255	// max r/g/b value is 255
	int r = GetRValue(color);
	int g = GetGValue(color);
	int b = GetBValue(color);
	int rgbMax = max( max(r,g), b);
	int rgbMin = min( min(r,g), b);
	return (((rgbMax+rgbMin) * HLSMAX) + RGBMAX ) / (2*RGBMAX);
}

//////////////////
// Helper to paint rectangle with a color.
//
static void PaintRect(CDC& dc, const CRect& rc, COLORREF color)
{
	CBrush brush(color);
	CBrush* pOldBrush = dc.SelectObject(&brush);
	dc.PatBlt(rc.left, rc.top, rc.Width(), rc.Height(), PATCOPY);
	dc.SelectObject(pOldBrush);
}

//////////////////
// Paint custom caption.
// This is the function that actually does the shading. It creates a
// bitmap that's used to paint the caption. It looks horrible, but it's
// just a lot of bit-twiddling GDI stuff.
//
LRESULT CMainFrame::OnPaintMyCaption(WPARAM bActive, LPARAM lParam)
{
	if (lParam == 0) {
		// lParam = 0 means system setting change: invalidate fonts.
		m_fontCaption.DeleteObject();
		m_fontAppName.DeleteObject();
		return 0;
	}

	const PAINTCAP& pc = *((PAINTCAP*)lParam);
	ASSERT(pc.m_pDC);
	CDC& dc = *pc.m_pDC;

	int cxCap = pc.m_szCaption.cx;
	int cyCap = pc.m_szCaption.cy;
	CRect rc(0,0,cxCap,cyCap);

	if (!bActive) {
		// Inactive caption: don't do shading, just fill w/bg color
		PaintRect(dc, rc, GetSysColor(COLOR_INACTIVECAPTION));

	} else {
		// Active caption: do shading
		COLORREF clrBG = GetSysColor(COLOR_RIGHTMOST);

		int r = GetRValue(clrBG);				// red..
		int g = GetGValue(clrBG);				// ..green
		int b = GetBValue(clrBG);				// ..blue color vals
		int w = 5*cxCap/6;						// width of area to shade = 5/6 of caption

		// Paint far right 1/6 of caption the background color
		rc.left = rc.right - rc.Width()/6;
		PaintRect(dc, rc, clrBG);

		// Compute new color brush for each band from x to x + xDelta.
		// Excel uses a linear algorithm from black to normal, i.e.
		//
		//		color = CaptionColor * r
		//
		// where r is the ratio x/w, which ranges from 0 (x=0, left)
		// to 1 (x=w, right). This results in a mostly black title bar,
		// since we humans don't distinguish dark colors as well as light
		// ones. So instead, I use the formula
		//
		//		color = CaptionColor * [1-(1-r)^2]
		//
		// which still equals black when r=0 and CaptionColor when r=1,
		// but spends more time near CaptionColor. For example, when r=.5,
		// the multiplier is [1-(1-.5)^2] = .75, closer to 1 than .5.
		// I leave the algebra to the reader to verify that the above formula
		// is equivalent to
		//
		//		color = CaptionColor - (CaptionColor*(w-x)*(w-x))/(w*w)
		//
		// The computation looks horrendous, but it's only done once each
		// time the caption changes size, thereafter BitBlt'ed to the screen.
		//
		int xDelta= max(w/NCOLORSHADES,1); // width of one shade band
		rc.left = rc.right - xDelta;
		while (rc.left > xDelta) {			 // paint bands right to left
			rc -= CPoint(xDelta,0);			 // next band
			const int &x = rc.left;			 // x-coord
			int wmx2 = (w-x)*(w-x);			 // w minus x squared
			int w2  = w*w;						 // w squared
			PaintRect(dc, rc, RGB(r-(r*wmx2)/w2, g-(g*wmx2)/w2, b-(b*wmx2)/w2));
		}
		rc.right = rc.left;
		rc.left = 0;
		PaintRect(dc,rc, COLOR_BLACK);	 // whatever's left ==> black
	}

	// Use caption painter to draw icon and buttons
	int cxIcon  = m_captionPainter.DrawIcon(pc);
	int cxButns = m_captionPainter.DrawButtons(pc);

	// Now draw text. First Create fonts if needed
	//
	if (!m_fontCaption.m_hObject)
		CreateFonts();

	// Paint "CoolEdit TEXT" using CoolEdit font, always white
	CString s = m_strTitle + " ";					// app title
	rc = CRect(CPoint(0,0),pc.m_szCaption);	// text rectangle
	rc.left  += cxIcon+2;							// start after icon
	rc.right -= cxButns;								// don't draw past buttons
	dc.SetBkMode(TRANSPARENT);						// draw on top of our shading
	dc.SetTextColor(COLOR_WHITE);					// always white
	CFont* pOldFont = dc.SelectObject(&m_fontAppName);
	dc.DrawText(s, &rc, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);

	// Now paint window title (caption)
	rc.left += dc.GetTextExtent(s).cx;		// move past "CoolEdit EDIT "
	if (rc.right > rc.left) {					// if still room:
		COLORREF clrText;							// text color
		if (bActive) {
			// Excel always uses white for title color, but I use the user's
			// selected color--unless it's too dark, then I use white.
			//
			clrText = GetSysColor(COLOR_CAPTIONTEXT);
			if (GetLuminosity(clrText) < 90) // good from trial & error
				clrText = COLOR_WHITE;
		} else
			clrText = GetSysColor(COLOR_INACTIVECAPTIONTEXT);

		// Paint the text. Use DT_END_ELLIPSIS to draw ellipsis if text
		// won't fit. Win32 sure is friendly!
		//
		dc.SetTextColor(clrText);
		dc.SelectObject(&m_fontCaption);
		dc.DrawText(GetDocTitle(), &rc,
			DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
	} 
	dc.SelectObject(pOldFont);	// Restore DC
	return 0;
}

//////////////////
// Helper function to build the fonts I need.
//
void CMainFrame::CreateFonts()
{
	// Get current system caption font, just to get its size
	//
	CNonClientMetrics ncm;
	m_fontCaption.CreateFontIndirect(&ncm.lfCaptionFont);

	// Create "CoolEdit" font same size as caption font, but diff face
	m_fontAppName.CreatePointFont(120, _T("Book Antiqua")); // 12 pt for now
	LOGFONT lf;
	m_fontAppName.GetLogFont(&lf);				// get font info
	m_fontAppName.DeleteObject();				// I don't really want 12 pt
	lf.lfWeight|=FW_BOLD;							// make bold
	lf.lfHeight = ncm.lfCaptionFont.lfHeight; // same height as caption font
	m_fontAppName.CreateFontIndirect(&lf);	// create font
}

//////////////////
// Command handler for combo box select
//
void CMainFrame::OnComboChange()
{
	ASSERT(m_pCoolBar); // should be here if I got combo message
	CString s;
	m_pCoolBar->m_wndCombo.GetWindowText(s);
	AfxGetApp()->OpenDocumentFile(s);
}

//////////////////
// Give Menu bar a chance to pre-translate messages. This is CRITICAL!
// You MUST call CMenuBar::TranslateFrameMessage() to translate mnemonics.
//
BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	CMenuBar* pMenuBar = m_pCoolBar ?
		&m_pCoolBar->m_wndMenuBar : m_pMenuBar;
	return pMenuBar->TranslateFrameMessage(pMsg) ?
		TRUE : CBaseFrameWnd::PreTranslateMessage(pMsg);
}

////////////////////////////////////////////////////////////////
// CMyCoolBar
//
IMPLEMENT_DYNAMIC(CMyCoolBar, CCoolBar)

////////////////
// This is the virtual function you have to override to add bands
//
BOOL CMyCoolBar::OnCreateBands()
{
	//////////////////
	// Create menu bar
	CMenuBar& mb = m_wndMenuBar;
	VERIFY(mb.CreateEx(this,
		WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
		CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY|CBRS_TOP));

	mb.ModifyStyle(0, TBSTYLE_TRANSPARENT);

	// Load doc or main menu. Only required since this app flips
	// between coolbar/toolbars.
	CFrameWnd *pParent = GetParentFrame();
	CFrameWnd* pFrame = pParent->GetActiveFrame();
	mb.LoadMenu(MAKEINTRESOURCE(pFrame != pParent ?
		IDR_MYDOCTYPE : IDR_MAINFRAME));

	CRect rc;
	mb.GetItemRect(0, &rc);
	CSize szMenu = mb.CalcDynamicLayout(-1, LM_HORZ); // get min horz size

	// create menu bar band.
	if (!InsertBand(&mb, CSize( szMenu.cx, rc.Height()), 0x7ff))
		return FALSE;

	//////////////////
	// Create tool bar
	CFlatToolBar& tb = m_wndToolBar;
	VERIFY(tb.CreateEx(this,
		WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
			CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY|CBRS_TOP));
	VERIFY(tb.LoadToolBar(IDR_TOOLBAR1)); 
	// use transparent so coolbar bitmap will show through
	tb.ModifyStyle(0, TBSTYLE_TRANSPARENT);

	// Get minimum size of toolbar, which is basically size of one button
	CSize szHorz = tb.CalcDynamicLayout(-1, LM_HORZ); // get min horz size
	tb.GetItemRect(0, &rc);
	CSize szMin( szHorz.cx, rc.Height());

	// create toolbar band. Use largest size possible
	if (!InsertBand(&tb, szMin, 0x7fff, NULL, -1, TRUE))
		return FALSE;

	//////////////////
	// Create combo box and fill with data
	CRect rcCombo(0,0,0,0);
	m_wndCombo.Create(WS_VISIBLE|WS_CHILD|WS_VSCROLL|CBS_DROPDOWNLIST|
		WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rcCombo, this, IDCOMBO);
	m_wndCombo.SetFont(GetFont());

	static LPCTSTR data[] = {		// initial combo data
		_T("c:\\autoexec.bat"),
		_T("c:\\config.sys"),
		_T("c:\\bootlog.txt"),
		NULL
	};
	for (LPCTSTR *p=data; *p; p++)
		m_wndCombo.AddString(*p);
	m_wndCombo.SetCurSel(-1);

	// create combo band
	szMin.cx = COMBO_CXMIN;
	if (!InsertBand(&m_wndCombo, szMin, 0, _T("System files:")))
		return FALSE;

	return TRUE; // OK
}

////////////////////////////////////////////////////////////////
// CMyComboBox
//
IMPLEMENT_DYNAMIC(CMyComboBox, CComboBox)

BEGIN_MESSAGE_MAP(CMyComboBox, CComboBox)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropDown)
END_MESSAGE_MAP()

//////////////////
// Must resize the combo when I get CBN_DROPDOWN
//		
void CMyComboBox::OnDropDown()
{
	CRect rc;
	GetWindowRect(&rc);
	SetWindowPos(NULL,0,0,rc.Width(),200, // use same width but taller height
		SWP_NOMOVE|SWP_NOACTIVATE);
}
