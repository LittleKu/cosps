#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define USE_PIXIE_DLL	// use PixieLib DLL
#include <afxwin.h>		// MFC
#include <afxpriv.h>		// for WM_KICKIDLE

#include <PixieLib.h>	// PixieLib
#include <PLRegex.h>		// PixieLib regular expressions
