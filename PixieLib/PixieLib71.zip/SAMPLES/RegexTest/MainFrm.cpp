////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "resource.h"
#include "MainFrm.h"
#include "DlgTest.h"
#include "DlgForm.h"
#include "DlgWordMess.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_FILE_RGTEST,OnRegexTest)
	ON_COMMAND(ID_FILE_RGFORM,OnRegexForm)
	ON_COMMAND(ID_FILE_WORDMESS,OnWordMess)
END_MESSAGE_MAP()

// Command map for app: commands in main window HTML.
BEGIN_HTML_COMMAND_MAP(MyHtmlCmds)
	HTML_COMMAND(_T("rgtest"), ID_FILE_RGTEST)
	HTML_COMMAND(_T("rgform"), ID_FILE_RGFORM)
	HTML_COMMAND(_T("rgword"), ID_FILE_WORDMESS)
	HTML_COMMAND(_T("about"), ID_APP_ABOUT)
	HTML_COMMAND(_T("exit"),  ID_APP_EXIT)
END_HTML_COMMAND_MAP()

//////////////////
// Pre-create: set window size to something nice.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	TRACE(_T("CMainFrame::PreCreateWindow\n"));
	VERIFY(CFrameWnd::PreCreateWindow(cs));
	cs.cx = 700;
	cs.cy = 450;
	return TRUE;
}

//////////////////
// Main frame created: create child windows--toolbar, status bar, view etc.
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);
	
	// create/init toolbar
	VERIFY(m_wndToolBar.Create(this));
	m_wndToolBar.LoadToolBar(IDR_MAINFRAME);
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// create/init status bar
	static UINT indicators[] = { ID_SEPARATOR };
	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)));

	// create/init html control as view
	VERIFY(m_wndView.Create(CRect(), this, AFX_IDW_PANE_FIRST));
	m_wndView.SetHideContextMenu(TRUE);				// hide context menu
	m_wndView.SetCmdMap(MyHtmlCmds);					// set commands
	m_wndView.Navigate(_T("about:blank"));			// create document
	m_wndView.LoadFromResource(_T("main.htm"));
	SetActiveView(&m_wndView);							// set as active view for MFC

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	// Install menu tip manager--that's all!
	m_menuTipManager.Install(this);

	return 0;
}

//////////////////
// Handle context menu command.
// Don't do anything, just display TRACE to prove i was called.
//
void CMainFrame::OnContextMenu(CWnd* /* pWnd */, CPoint /* p */)
{
	TRACE(_T("CMainFrame::OnContextMenu\n"));
}

void CMainFrame::OnRegexTest()
{
	CDlgTest dlg;
	dlg.DoModal();
}

void CMainFrame::OnRegexForm()
{
	TRACE(_T("CMainFrame::OnRegexForm\n"));
	CDlgForm dlg;
	dlg.DoModal();
}

void CMainFrame::OnWordMess()
{
	CDlgWordMess dlg;
	dlg.DoModal();
}
