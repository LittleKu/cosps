////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#include "resource.h"
#include "DlgBase.h"

//////////////////
// Regex form validation test dialog.
//
class CDlgForm : public CDlgBase {
public:
	CDlgForm(CWnd* pParent = NULL) : CDlgBase(IDD, pParent) { }
	virtual ~CDlgForm() { }
	enum { IDD = IDD_DLGFORM };

protected:
	CRegexForm	m_rgxForm;				// regex form manager
	CStatic		m_wndFeedback;			// feedback window

	// overrides
	virtual void OnOK();					// user pressed OK
	virtual BOOL OnInitDialog();		// initialize dialog
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// message/command update handlers
	afx_msg void OnPopulate();
	afx_msg LRESULT OnKickIdle(WPARAM, LPARAM);
	afx_msg void OnShowHints();
	afx_msg void OnUpdateShowHints(CCmdUI* pCmdUI);
	afx_msg void OnValidateImmed();
	afx_msg void OnUpdateValidateImmed(CCmdUI* pCmdUI);
	afx_msg LRESULT OnRgxFormMessage(WPARAM, LPARAM);

	DECLARE_DYNAMIC(CDlgForm)
	DECLARE_MESSAGE_MAP()
};
