////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "stdafx.h"
#include "DlgTest.h"

IMPLEMENT_DYNAMIC(CDlgTest, CDlgBase)
BEGIN_MESSAGE_MAP(CDlgTest, CDlgBase)
	ON_COMMAND(IDC_POPULATE, OnPopulate)
END_MESSAGE_MAP()

static LPCTSTR errbeep(LPCTSTR errstr)
{
	MessageBeep(0);
	return errstr;
}

BOOL CDlgTest::OnInitDialog()
{
	return CDlgBase::OnInitDialog();
}

//////////////////
// Handle OK: display results, but don't call base class to end dialog.
//
void CDlgTest::OnOK()
{
	UpdateData(TRUE);							 // get dlg data
	m_sResult = LF2CRLF(FormatResults());
	UpdateData(FALSE);						 // set dlg data (result)
}

//////////////////
// Populate command: fill fields with sample data.
// Shows how to use SetFieldValue to set the values in your form.
//
void CDlgTest::OnPopulate()
{
	m_sRegex = _T("{a+}{b+}");
	m_sInput = _T("zaabgaak abbbfcg bb cfaaabbbx?");
	UpdateData(FALSE); 	// set dialog data 
}

//////////////////
// Standard MFC dialog data exchange
//
void CDlgTest::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PROMPT, m_sRegex);
	DDX_Text(pDX, IDC_INPUT,  m_sInput);
	DDX_Text(pDX, IDC_RESULT, m_sResult);
}

////////////////
// Format match results into MFC CString.
//
CString CDlgTest::FormatResults()
{
	if (m_sRegex.IsEmpty())
		return errbeep(_T("Please enter a regular expression!"));
	if (m_sInput.IsEmpty())
		return errbeep(_T("Please enter an input string!"));

	CString result;
	CString temp;

	CRegex re(m_sRegex);
	if (re.m_err!=REPARSE_ERROR_OK) {
		result.Format(_T("Oops! Error parsing regex: %s\n"), re.GetErrorName(re.m_err));
		MessageBeep(0);
		return result;
	}

	LPCTSTR szInput = m_sInput;
	int count=0;
	re.SetInput(szInput);
	while (re.NextMatch()) {
		int offset=0;
		CString match = re.GetMatch(&offset);
		temp.Format(_T("Match at %d: %s\n"), offset, match);
		result += temp;

		temp.Format(_T(" Number of groups: %d\n"), re.GetNumGroups());
		result += temp;

		UINT nGroups = re.GetNumGroups();
		for (UINT m=0; m<nGroups; m++) {
			CString group = re.GetGroup(m, &offset);
			temp.Format(_T(" Group %d at %d: %s\n"), m, offset, group);
			result += temp;
		}
		count++;
	}
	if (count<=0)
		result.Format(_T("No match!"));

	return result;
}

