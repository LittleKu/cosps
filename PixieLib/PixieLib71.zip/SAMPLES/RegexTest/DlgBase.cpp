////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "stdafx.h"
#include "DlgBase.h"

IMPLEMENT_DYNAMIC(CDlgBase, CDialog)
BEGIN_MESSAGE_MAP(CDlgBase, CDialog)
END_MESSAGE_MAP()

////////////////
// Handy helper converts \n to \r\n for brain-damaged edit controls--one line of code!
//
CString LF2CRLF(LPCTSTR lpsz)
{
	return CRegex::Replace(lpsz,_T("\n"),_T("\r\n"),TRUE);
}

CDlgBase::CDlgBase(UINT nResID, CWnd* pParent) : CDialog(nResID, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CDlgBase::~CDlgBase()
{
}

BOOL CDlgBase::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	// when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// subclass web links
	m_wndLink1.SubclassDlgItem(IDC_PDURL,this);
	m_wndLink2.SubclassDlgItem(IDC_PXURL,this);

	return TRUE;
}

