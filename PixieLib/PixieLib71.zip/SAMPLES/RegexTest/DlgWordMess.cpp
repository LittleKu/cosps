////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "stdafx.h"
#include "DlgWordMess.h"
#include <algorithm>
#include <string>
using namespace std;

#ifdef _UNICODE
typedef wstring tstring;
#else
typedef string tstring;
#endif

IMPLEMENT_DYNAMIC(CDlgWordMess, CDlgBase)
BEGIN_MESSAGE_MAP(CDlgWordMess, CDlgBase)
END_MESSAGE_MAP()

BOOL CDlgWordMess::OnInitDialog()
{
	return CDlgBase::OnInitDialog();
}

//////////////////
// Match evaluator callback: This function receives a match and returns the
// text to replace it with. The algorithm is: scramble the middle of the word.
//
// - Words with fewer than four letters are unchanged.
// - Four letter words have their middle two letters swapped.
// - Five letter words preserve their first and last letters.
// - Longer words preserve the second letter as well.
//
// Look how easy this is with STL algorithms!!--swap and random_shuffle.
// Scrambler reports its activity in a CString passed as the void* param.
//
CString CALLBACK Scrambler(const CRegex& re, const CString& match, void* param)
{
	tstring word = re.GetMatch();	// STL string easier to manipulate than CString
	TRACE(_T("Scrambler: match = %s\n"), match);
	size_t len = word.size();
	if (len>=4) {
		if (len==4) {
			swap(word[1],word[2]);			 // use STL swap algorithm!
		} else {
			random_shuffle(word.begin()+(len <=5 ? 1 : 2), word.end()-1); // STL shuffle algorithm!
		}
	}
	if (param) {
		CString temp;
		temp.Format(_T("Scramble: '%s' -> '%s'\n"), match, word.c_str());
		(*(CString*)param) += temp;
	}
	return word.c_str();
}

//////////////////
// Handle OK: display results, but don't call base class to end dialog.
//
void CDlgWordMess::OnOK()
{
	static CRegex MyRegex(_T("\\w+"));

	UpdateData(TRUE); 	// get dialog data

	CString report;
	m_sResult = MyRegex.Replace(m_sInput, &Scrambler, &report);
	m_sResult += "\n\n";
	m_sResult += report;
	m_sResult = LF2CRLF(m_sResult);

	UpdateData(FALSE); 	// set dialog data
}

//////////////////
// Standard MFC dialog data exchange
//
void CDlgWordMess::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_INPUT, m_sInput);
	DDX_Text(pDX, IDC_RESULT, m_sResult);
}

