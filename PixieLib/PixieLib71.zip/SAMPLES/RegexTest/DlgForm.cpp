////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "stdafx.h"
#include "resource.h"
#include "DlgForm.h"

// feedback window error color
const COLORREF COLOR_ERROR = RGB(0xff,0x00,0x99); // hot pink

// callback message for CRegexForm notifications (not used)
const MYWM_RGXFORM_MESSAGE = WM_APP + 0;

IMPLEMENT_DYNAMIC(CDlgForm, CDlgBase)
BEGIN_MESSAGE_MAP(CDlgForm, CDlgBase)
	ON_COMMAND(IDC_POPULATE, OnPopulate)
	ON_COMMAND(IDC_SHOWHINTS, OnShowHints)
	ON_UPDATE_COMMAND_UI(IDC_SHOWHINTS, OnUpdateShowHints)
	ON_COMMAND(IDC_IMMEDVAL, OnValidateImmed)
	ON_UPDATE_COMMAND_UI(IDC_IMMEDVAL, OnUpdateValidateImmed)
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
	ON_MESSAGE(MYWM_RGXFORM_MESSAGE, OnRgxFormMessage)
END_MESSAGE_MAP()

//////////////////
// This table defines the fields CRegexForm will validate.
// All must be edit controls.
// 
BEGIN_REGEX_FORM(MyRegexForm)
	RGXFIELD(IDC_ZIP,RGXF_REQUIRED,0)
	RGXFIELD(IDC_SSN,0,0)
	RGXFIELD(IDC_PHONE,0,0)
	RGXFIELD(IDC_TOKEN,0,0)
	RGXFIELD(IDC_AGE,0,0)
	RGXFIELD(IDC_PRIME,RGXF_CALLBACK,0)
	RGXFIELD(IDC_FAVCOL,0,TRUE)
END_REGEX_FORM()

//////////////////
// Initialize dialog
//
BOOL CDlgForm::OnInitDialog()
{
	CDlgBase::OnInitDialog();

	// subclass feedback window
	m_wndFeedback.SubclassDlgItem(IDC_FEEDBACK,this);

	// initialize regex form manager
	m_rgxForm.Init(MyRegexForm, this, IDS_MYREGEXFORM, MYWM_RGXFORM_MESSAGE);
	m_rgxForm.SetFeedbackWindow(&m_wndFeedback, COLOR_ERROR);
	
	return TRUE;
}

//////////////////
// This is required to update dialog controls and receive button notifications
// using MFC's command routing mechanism (ON_COMMAND and ON_UPDATE_COMMAND_UI).
//
LRESULT CDlgForm::OnKickIdle(WPARAM, LPARAM)
{
	UpdateDialogControls(this, TRUE);
	return 0;
}

//////////////////
// Populate command: fill fields with sample data.
// Shows how to use SetFieldValue to set the values in your form.
//
void CDlgForm::OnPopulate()
{
	static struct {
		UINT id;
		LPCTSTR val;
	} PopVals[] = {
		{ IDC_ZIP,		_T("10025") },
		{ IDC_SSN,		_T("123-45-6789") },
		{ IDC_PHONE,	_T("(212) 555-1212") },
		{ IDC_AGE,	   _T("99") },
		{ IDC_TOKEN,	_T("_a_val1d_t0ken") },
		{ IDC_PRIME,	_T("9973") },
		{ IDC_FAVCOL,	_T("Matt Pietrek") },
		{ 0, NULL },
	};
	for (int i=0; PopVals[i].id; i++) {
		m_rgxForm.SetFieldValue(PopVals[i].id, PopVals[i].val);
	}
	UpdateData(FALSE); 	// set dialog data in case trimmed
}

//////////////////
// User pressed OK: validate form and display results: error message
// or field values--but don't call base class to end dialog.
//
void CDlgForm::OnOK()
{
	UpdateData(TRUE); 	// get dialog data

	int nBad = m_rgxForm.Validate();	// validate
	CString msg;
	if (nBad>0) {
		vector<UINT> badFields = m_rgxForm.GetBadFields();
		BOOL beep = TRUE;
		if (nBad>1) {
			// Multiple bad fields: show message box with bad fields.
			msg = _T("The following fields are bad:\n\n");
			vector<UINT>::iterator it;
			for (it = badFields.begin(); it!=badFields.end(); it++) {
				UINT nID = *it;
				CString s;
				s.Format(_T("%s: %s\n"), m_rgxForm.GetFieldName(nID),
					m_rgxForm.GetFieldErrorMsg(nID));
				msg += s;
			}
			MessageBox(msg,_T("Oops--Some fields are bad."),MB_ICONEXCLAMATION);
			beep = FALSE;	// message box already beeped; don't beep again below
		}
		// fall through to hilite 1st bad field whether one or many
		UINT nID = badFields[0];
		m_rgxForm.ShowBadField(nID, beep, TRUE);

	} else {
		// all fields OK: show feedback
		msg = _T("You Entered:\n\n");
		for (int i=0; MyRegexForm[i].id; i++) {
			CString name = m_rgxForm.GetFieldName(MyRegexForm[i].id);
			CString val  = m_rgxForm.GetFieldValue(MyRegexForm[i].id);
			if (val.IsEmpty())
				val = _T("(nothing)");
			CString temp;
			temp.Format(_T("%s = %s\n"), name, val);
			msg += temp;
		}
		MessageBox(msg,_T("Congratulations! All fields OK."),MB_OK);
		m_rgxForm.Feedback(_T(" All fields OK or empty!"));
	}
}

//////////////////
// Do dialog data exchange: call form manager to do the work.
// Note input strings are stored in the regex form manager.
//
void CDlgForm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	m_rgxForm.DoDataExchange(pDX);
}

//////////////////
// This brute-force algorithm won't win any math prizes, but it works and
// it's plenty fast for small numbers (<10,000).
//
static BOOL IsPrime(int p)
{
	int max = p/2;
	for (int f=2; f<=max; f++) {
		if (p%f==0)
			return FALSE;
	}
	return TRUE;
}

//////////////////
// Handle notification from Regex Form Manager:
// Do custom validation.
// 
LRESULT CDlgForm::OnRgxFormMessage(WPARAM wp, LPARAM lp)
{
	UINT nID = LOWORD(wp);
	UINT nCode = HIWORD(wp);
	if (nCode==RGXNM_VALIDATEFIELD) { // custom validation:
		if (nID==IDC_PRIME) {
			const CString& val = *(CString*)lp;
			if (val.IsEmpty())
				return RGXERR_OK;
			int p = _tstoi(val);
			return IsPrime(p) ?  RGXERR_OK : RGXERR_NOMATCH;
		}
		ASSERT(FALSE); // shouldn't happen
	}
	return 0;
}

//////////////////
// Standard MFC user interface commands/UI update handlers
//
void CDlgForm::OnShowHints()
{
	m_rgxForm.SetShowHints(!m_rgxForm.GetShowHints());
}

void CDlgForm::OnUpdateShowHints(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_rgxForm.GetShowHints());
}

void CDlgForm::OnValidateImmed()
{
	m_rgxForm.SetValidateImmed(!m_rgxForm.GetValidateImmed());
}

void CDlgForm::OnUpdateValidateImmed(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_rgxForm.GetValidateImmed());
}

