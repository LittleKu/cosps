//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RegexTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DLGTEST                     101
#define IDD_DLGFORM                     102
#define IDD_DLGWORDMESS                 103
#define IDR_MAINFRAME                   128
#define IDB_PIXIELIB                    129
#define IDS_MYREGEXFORM                 130
#define IDC_HTMLVIEW                    1001
#define IDC_PDURL                       1002
#define IDC_PXURL                       1003
#define IDC_PROMPT                      1004
#define IDC_INPUT                       1005
#define IDC_RESULT                      1006
#define IDC_ZIP                         1007
#define IDC_SSN                         1008
#define IDC_PHONE                       1009
#define IDC_AGE                         1010
#define IDC_TOKEN                       1011
#define IDC_PRIME                       1012
#define IDC_FAVCOL                      1013
#define IDC_POPULATE                    1014
#define IDC_SHOWHINTS                   1015
#define IDC_IMMEDVAL                    1016
#define IDC_FEEDBACK                    1017
#define ID_FILE_RGTEST                  32775
#define ID_FILE_WORDMESS                32776
#define ID_FILE_RGFORM                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
