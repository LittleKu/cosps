////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#include "resource.h"

//////////////////
// Common base for all dialogs.
//
class CDlgBase : public CDialog {
public:
	CDlgBase(UINT nResID, CWnd* pParent = NULL);
	virtual ~CDlgBase();

protected:
	HICON m_hIcon;
	CStaticLink m_wndLink1;		// static web links
	CStaticLink m_wndLink2;		// ...
	virtual BOOL OnInitDialog();

	DECLARE_DYNAMIC(CDlgBase)
	DECLARE_MESSAGE_MAP()
};

////////////////
// Handy helper converts \n to \r\n for brain-damaged edit controls--one line of code!
//
CString LF2CRLF(LPCTSTR lpsz);

