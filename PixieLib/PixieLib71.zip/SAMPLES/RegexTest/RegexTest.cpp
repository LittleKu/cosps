////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// RegexTest shows how to use CRegex to do regular expression matching and
// CRegexForm to do regex-based form validation for MFC dialogs. The program
// has three dialogs to illustrate different uses of CRegex:
//
//		1) A test dialog where you can enter a regular expression and input string and see the Match
//		results;
//
//		2) a WordMess dialog that uses dynamic regex-replace with a callback
//		function to implement a dynamic replace algorithm; and
//
//		3) a Form Test dialog that uses CRegexForm to validate user input
//		using regular expressions in a table.
//
#include "StdAfx.h"
#include "resource.h"
#include "MainFrm.h"
#include "TraceWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CMyApp : public CWinApp {
public:
	virtual BOOL InitInstance();
protected:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
} theApp;

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
END_MESSAGE_MAP()

BOOL CMyApp::InitInstance()
{
   // Create main frame window (don't use doc/view stuff)
   CMainFrame* pMainFrame = new CMainFrame;
   if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
      return FALSE;
   pMainFrame->ShowWindow(m_nCmdShow);
   pMainFrame->UpdateWindow();
   m_pMainWnd = pMainFrame;

	return TRUE;
}

//////////////////
// About dialog uses HTML control to display contents.
//
class CAboutDialog : public CDialog {
protected:
	CHtmlCtrl m_page;			// HTML control
	virtual BOOL OnInitDialog(); 
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
	DECLARE_DYNAMIC(CAboutDialog)
};
IMPLEMENT_DYNAMIC(CAboutDialog, CDialog)

//////////////////
// init about dialog
//
BOOL CAboutDialog::OnInitDialog()
{
	// cmd map for CHtmlCtrl handles "app:ok"
	static HTMLCMDMAP AboutCmds[] = {
		{ _T("ok"), IDOK },
		{ NULL, 0  },
	};
	VERIFY(CDialog::OnInitDialog());
	VERIFY(m_page.CreateFromStatic(IDC_HTMLVIEW, this)); // create HTML ctrl
	m_page.SetHideContextMenu(TRUE);							  // hide context menu
	m_page.SetCmdMap(AboutCmds);								  // set command table
	m_page.LoadFromResource(_T("about.htm"));				  // load HTML from resource
	return TRUE;
}

//////////////////
// run about dialog
//
void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}

