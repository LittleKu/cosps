////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// Typical main frame...
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame(){ }
	virtual ~CMainFrame() { }
protected:
	CHtmlCtrl			m_wndView;			 // CHtmlCtrl as main view
	CStatusBar			m_wndStatusBar;	 // status line
	CFlatToolBar		m_wndToolBar;		 // toolbar
	CCoolMenuManager	m_menuManager;		 // manages menus for entire app + views
	CMenuTipManager	m_menuTipManager;	 // managed menu tips

	// virtual overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	afx_msg void OnRegexTest();
	afx_msg void OnRegexForm();
	afx_msg void OnWordMess();

	// helper to format main window HTML
	CString FormatWindowListHTML();

	DECLARE_DYNCREATE(CMainFrame)
	DECLARE_MESSAGE_MAP()
};

