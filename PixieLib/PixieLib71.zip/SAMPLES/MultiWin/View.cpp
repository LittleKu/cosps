////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "resource.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Command map for HTML commands. Maps <A HREF="app:cmdname"> to command ID.
BEGIN_HTML_COMMAND_MAP(MyHtmlCmds)
	HTML_COMMAND(_T("about"),	ID_APP_ABOUT)
	HTML_COMMAND(_T("exit"),	ID_APP_EXIT)
	HTML_COMMAND(_T("open"),	ID_FILE_OPEN)
	HTML_COMMAND(_T("help"),	ID_HELP_MULTIWIN)
	HTML_COMMAND(_T("dlg"),		ID_VIEW_DIALOG)
	HTML_COMMAND(_T("refresh"),ID_VIEW_REFRESH)
	HTML_COMMAND(_T("winlist"),ID_VIEW_WINLIST)
	HTML_COMMAND(_T("prolist"),ID_VIEW_PROCESSLIST)
END_HTML_COMMAND_MAP()

/////////////////
// window map tells WinMgr how to position the child windows
//
BEGIN_WINDOW_MAP(MyViewMap)
 BEGINCOLS(WRCT_REST,0,RCMARGINS(4,4)) // whole view: 4 pixel margins
  BEGINROWS(WRCT_TOFIT,0,0)				//   left pane
   RCTOFIT(ID_WIN_LOGO2)					//     bitmap
   RCTOFIT(ID_WIN_LOGO1)					//     bitmap
   RCREST(ID_WIN_LICENSE)					//     text
  ENDGROUP()
  RCFIXED(ID_WIN_SIZERBAR_VERT,4)		//   vertical sizer bar
  BEGINROWS(WRCT_REST,0,0)					//   right half
   RCREST(ID_WIN_HTML)						//     html view
   RCFIXED(ID_WIN_SIZERBAR_HORZ,4)		//     horizontal sizer bar
   RCTOFIT(ID_WIN_DOPEY)					//     dopey pane
  ENDGROUP()
 ENDGROUP()
END_WINDOW_MAP()

IMPLEMENT_DYNCREATE(CMyView, CView)
BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SETFOCUS()
	ON_REGISTERED_MESSAGE(WM_WINMGR, OnWinMgr)
	ON_COMMAND(ID_HELP_MULTIWIN, OnHelp)
	ON_COMMAND(ID_VIEW_REFRESH, OnRefresh)
	ON_COMMAND(ID_VIEW_WINLIST, OnViewWindowList)
	ON_COMMAND(ID_VIEW_PROCESSLIST, OnViewProcessList)
	ON_UPDATE_COMMAND_UI(ID_VIEW_REFRESH, OnUpdateRefresh)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WINLIST, OnUpdateViewWindowList)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PROCESSLIST, OnUpdateViewProcessList)
END_MESSAGE_MAP()

CMyView::CMyView() : m_winMgr(MyViewMap)
{
	m_idCurWin = 0;
}

CMyView::~CMyView()
{
}

void CMyView::OnDraw(CDC* /* pDC */)
{
	// Dopey view doesn't draw; it's just a container for child windows
}

////////////////
// Override for flicker-free drawing: set WS_CLIPCHILDREN.
//
BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;
   return CView::PreCreateWindow(cs);
}

//////////////////
// Create view: create child windows.
//
int CMyView::OnCreate(LPCREATESTRUCT lpcs)
{
	VERIFY(CView::OnCreate(lpcs)==0);
	CRect rc(0,0,0,0);

	// create html control
	VERIFY(m_wndHtml.Create(rc, this, ID_WIN_HTML));
	m_wndHtml.SetCmdMap(MyHtmlCmds, GetParent()); // send commands to parent frame

	// Create logo windows
	VERIFY(m_wndLogo.Create(NULL, WS_VISIBLE|WS_CHILD|
		SS_BITMAP|SS_SUNKEN|SS_CENTERIMAGE, 
		this, ID_WIN_LOGO1, IDB_MSDNMAG, _T("http://msdn.microsoft.com/msdnmag")));
	VERIFY(m_wndLogo2.Create(NULL, WS_VISIBLE|WS_CHILD|
		SS_BITMAP|SS_SUNKEN, 
		this, ID_WIN_LOGO2, IDB_PIXIELIB, _T("http://www.dilascia.com")));

	// Create license window
	VERIFY(m_wndLicense.Create(NULL, WS_VISIBLE|WS_CHILD, 
		rc, this, ID_WIN_LICENSE));
	if (m_fontLic.CreatePointFont(80,"Verdana") ||
		 m_fontLic.CreatePointFont(80,"Arial"))
		m_wndLicense.SetFont(&m_fontLic);
	CString s;
	VERIFY(s.LoadString(IDS_MYCOPYRIGHT));
	m_wndLicense.SetWindowText(s);

	// Create sizer bar for license/logo group
	VERIFY(m_wndSizerBarVert.Create(WS_VISIBLE|WS_CHILD,
		this, m_winMgr, ID_WIN_SIZERBAR_VERT));

	// Create dopey pane & sizer bar
	VERIFY(m_wndDopey.Create(this,ID_WIN_DOPEY));
	VERIFY(m_wndSizerBarHorz.Create(WS_VISIBLE|WS_CHILD,
		this, m_winMgr, ID_WIN_SIZERBAR_HORZ));

	return 0;
}

////////////////
// Paint background areas not occupied by any window.
// WS_CLIPCHILDREN guarantees no flicker.
//
BOOL CMyView::OnEraseBkgnd(CDC* pDC)
{
	CBrush brush(GetSysColor(COLOR_3DFACE));
	CRect rc;
	GetClientRect(&rc);
	pDC->FillRect(&rc,&brush);
	return TRUE;
}

/////////////////
// User sized the window: recalc entire layout. WinMgr makes it easy.
//
void CMyView::OnSize(UINT /* nType */, int cx, int cy)
{
	m_winMgr.CalcLayout(cx,cy,this);
	m_winMgr.SetWindowPositions(this);
}

// I got focus: set focus to HTML control
void CMyView::OnSetFocus(CWnd* /* pOldWnd */)
{
	m_wndHtml.SetFocus();
}

//////////////////
// Handle WM_WINMGR
//
LRESULT CMyView::OnWinMgr(WPARAM wp, LPARAM lp)
{
	ASSERT(lp);
	NMWINMGR& nmw = *(NMWINMGR*)lp;
	if (nmw.code==NMWINMGR::GET_SIZEINFO) {
		if (wp==(WORD)GetDlgCtrlID()) {
			// Parent frame is requesting my size info. Report min size.
			m_winMgr.GetMinMaxInfo(this, nmw.sizeinfo);
			return TRUE; // handled--important!
		}

	} else if (nmw.code==NMWINMGR::SIZEBAR_MOVED) {
		// User moved a sizer bar: call WinMgr to do it!
		m_winMgr.MoveRect(wp, nmw.sizebar.ptMoved, this);
		m_winMgr.SetWindowPositions(this);
		return TRUE;
	}
	return FALSE; // not handled
}

//////////////////
// Display help file.
//
void CMyView::OnHelp()
{
	m_idCurWin = 0;
	m_wndHtml.LoadFromResource(_T("help.htm"));
	GetDocument()->SetPathName(_T("help"),FALSE);
}

//////////////////
// Display window list: generate HTML on the fly.
//
void CMyView::OnViewWindowList()
{
	m_idCurWin = ID_VIEW_WINLIST;

	// start w/header
	CString html = GenHTMLHeader(_T("Window List"));
	html += _T("<TR><TD><B>hwnd</B></TD><TD><B>classname</B></TD>\
<TD WIDTH=\"75%\"><B>title</B></TD><TR>\n");

	// generate a row for each window
	CWinList wl;
	for (CWinList::iterator it=wl.begin(); it!=wl.end(); it++) {
		HWND hwnd = *it;
		DWORD style = GetWindowLong(hwnd, GWL_STYLE);
		if (style & WS_VISIBLE) {
			TCHAR classname[256];
			GetClassName(hwnd, classname, countof(classname));
			TCHAR text[1024];
			::GetWindowText(hwnd, text, countof(text));
			CString temp;
			temp.Format(_T("<TR><TD VALIGN=\"top\">%p&nbsp;</TD>\
<TD VALIGN=\"top\">%s&nbsp;</TD><TD>%s</TD></TR>\n"),
				hwnd, classname, text);
			html += temp;
		}
	}
	html += GenHTMLFooter();									// add footer. 
	GetDocument()->SetPathName(_T("winlist"),FALSE);	// set doc name, no MRU
	m_wndHtml.SetHTML(html);									// set contents from string
	SetFocus();														// set focus to me!
}

//////////////////
// Display process list: generate HTML on the fly.
//
void CMyView::OnViewProcessList()
{
	m_idCurWin = ID_VIEW_PROCESSLIST;

	// start w/header
	CString html = GenHTMLHeader(_T("Process List"));
	html += _T("<TR><TD><B>PID</B></TD><TD><B>main module</B></TD>\
<TD WIDTH=\"75%\"><B>user</B></TD><TR>\n");

	// add a table row for each process
	CProcessList pl;
	pl.Fill();
	for (CProcessList::iterator it=pl.begin(); it!=pl.end(); it++) {
		DWORD pid = *it;
		CProcessModuleList pml(pid);
		pml.Fill();
		if (!pml.empty()) {
			HANDLE hProc = pml.GetProcessHandle();
			HMODULE hMod = pml[0];
			CString filename;
			GetModuleBaseName(hProc, hMod, filename.GetBuffer(MAX_PATH), MAX_PATH);
			filename.ReleaseBuffer();

			CString username = _T("unknown"),domain;
			HANDLE hToken=NULL;
			if (OpenProcessToken(hProc, TOKEN_QUERY, &hToken)) {
				DWORD len = 0;
				GetTokenInformation(hToken, TokenUser, NULL, 0, &len);
				TOKEN_USER *ptu = (TOKEN_USER*)new BYTE[len];
				if (GetTokenInformation(hToken, TokenUser, ptu, len, &len)) {
					len = MAX_PATH;
					SID_NAME_USE snu;
					memset(&snu,0,sizeof(snu));
					DWORD dlen=len;
					LookupAccountSid(NULL, ptu->User.Sid,
						username.GetBuffer(len), &len,
						domain.GetBuffer(dlen), &dlen,
						&snu);
					username.ReleaseBuffer();
					domain.ReleaseBuffer();
				}
				delete [] ptu;
				CloseHandle(hToken);
			}
			CString temp;
			temp.Format(_T("<TR><TD VALIGN=\"top\">%p&nbsp;</TD>\
<TD VALIGN=\"top\">%s&nbsp;</TD><TD>%s&nbsp;</TD></TR>\n"),
				pid, filename, username);
			html += temp;
		}
	}
	html += GenHTMLFooter();									// add footer.
	GetDocument()->SetPathName(_T("proclist"),FALSE);	// set doc name, no MRU
	m_wndHtml.SetHTML(html);									// set contents from string
	SetFocus();														// set focus to me!
}

//////////////////
// Refresh page: re-execute current command.
//
void CMyView::OnRefresh()
{
	SendMessage(WM_COMMAND,m_idCurWin);
}

void CMyView::OnUpdateRefresh(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_idCurWin!=0);
}

void CMyView::OnUpdateViewWindowList(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_idCurWin == ID_VIEW_WINLIST);
}

void CMyView::OnUpdateViewProcessList(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_idCurWin == ID_VIEW_PROCESSLIST);
}

//////////////////
// Build common HTML footer.
//
CString CMyView::GenHTMLHeader(LPCTSTR title)
{
	CString html = _T("<HTML>\n\
<STYLE>\
BODY { font-size:83%;font-family:Verdana; }\
TD   { font-size:83%; }\
A:hover { color:#FF00C0 }\
</STYLE>\
<BODY link=\"#02B7B7\" vlink=\"#02B7B7\" BGCOLOR=\"#eeeeee\">\n\
<TABLE CELLSPACING=\"0\" CELLPADDING=\"0\" WIDTH=\"100%\">\n\
<TR><TD COLSPAN=\"3\" VALIGN=\"top\"><B>MultiWin &#8212; ");
	html += title;
	html += _T("</B></TD></TR>\n\
<TR><TD COLSPAN=\"3\">This page generated dynamically on the fly. Click \
<A HREF=\"app:refresh\">Refresh</A> to update.</TD></TR>\
<TR><TD>&nbsp;</TD></TR>");
	return html;
}

//////////////////
// Build common HTML footer.
//
CString CMyView::GenHTMLFooter()
{
	return _T("<TR><TD></TD><TD COLSPAN=\"3\"><BR>[ \
<B><A HREF=\"app:winlist\">Window List</A></B> | \
<B><A HREF=\"app:prolist\">Process List</A></B> | \
<B><A HREF=\"app:help\">Help</A></B> | \
<B><A HREF=\"app:about\">About</A></B> | \
<B><A HREF=\"app:exit\">Exit</A></B> ]\n\
</TD></TR>\
</TABLE>\
</BODY>\n\
</HTML>");
}
