////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// MultiWin illustrates how to use CWinMgr, a class that implements rule-based
// window sizing. MultiWin has a view class that comprises with several panes
// and splitters, all automatically managed by CWinMgr. MultiWin also has a
// dialog that uses CWinMgr to automatically resize its child controls as the
// user sizes the dialog. MultiWin's main view includes a CHtmlCtrl that shows
// how to generate HTML on the fly. You can open any HTML file, or press a
// button to have it generate a list of top-level windows as HTML, or press
// another button to read HTML help from the resource file.
//
#include "StdAfx.h"
#include "TraceWin.h"
#include "resource.h"
#include "MainFrm.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Standard MFC application class
//
class CDopeyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CDopeyApp)
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
} theApp;

IMPLEMENT_DYNAMIC(CDopeyApp, CWinApp)
BEGIN_MESSAGE_MAP(CDopeyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_NEW,  OnFileNew)
END_MESSAGE_MAP()

BOOL CDopeyApp::InitInstance()
{
//	SetRegistryKey("MultiWin");	// Save settings in registry, not INI file -- NOT!
	LoadStdProfileSettings(8); // Load standard INI file options (8 MRU files)

	// Create standard doc/frame/view
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView)));

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	return ProcessShellCommand(cmdInfo);
}

//////////////////
// About dialog uses HTML control to display contents.
//
class CAboutDialog : public CDialog {
protected:
	CHtmlCtrl m_page;	// HTML control
	virtual BOOL OnInitDialog(); 
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
	DECLARE_DYNAMIC(CAboutDialog)
};
IMPLEMENT_DYNAMIC(CAboutDialog, CDialog)

//////////////////
// init about dialog
//
BOOL CAboutDialog::OnInitDialog()
{
	// cmd map for CHtmlCtrl handles "app:ok"
	static BEGIN_HTML_COMMAND_MAP(AboutCmds)
		HTML_COMMAND(_T("ok"), IDOK)
	END_HTML_COMMAND_MAP()

	VERIFY(CDialog::OnInitDialog());
	VERIFY(m_page.CreateFromStatic(IDC_HTMLVIEW, this)); // create HTML ctrl
	m_page.SetHideContextMenu(TRUE);							  // hide context menu
	m_page.SetCmdMap(AboutCmds);								  // set command table
	m_page.LoadFromResource(_T("about.htm"));				  // load HTML from resource
	return TRUE;
}

//////////////////
// run about dialog
//
void CDopeyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}
