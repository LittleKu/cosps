////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

//////////////////
// Generic logo window displays a bitmap and allows clicking for
// web link. Handles WM_WINMGR to report min/desired size = size of bitmap.
//
class CLogoWnd : public CStaticLink {
public:
	CLogoWnd();
	virtual ~CLogoWnd();

	BOOL Create(LPCTSTR lpszText, DWORD dwStyle, CWnd* pParentWnd,
		UINT nID = 0xffff, UINT nIDBitmap = 0,
		LPCTSTR lpszLink=NULL, RECT rc=CRect(0,0,0,0));

protected:
	CBitmap m_bitmap;		// bitmap logo
	CSize m_szMinimum;	// min size
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CLogoWnd)
};

