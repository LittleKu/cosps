////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

//////////////////
// Dopey dialog derived from sizeable one.
// Handles WM_WINMGR to provide min size for OK/Cancel buttons.
//
class CDopeyDialog : public CSizeableDlg {
public:
	CDopeyDialog(CWnd* pParent);
	~CDopeyDialog();
protected:
	SIZE m_szMinButton; // min button size
	virtual BOOL OnInitDialog();
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CDopeyDialog)
};
