////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "LogoWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CLogoWnd, CStaticLink)
BEGIN_MESSAGE_MAP(CLogoWnd, CStaticLink)
	ON_REGISTERED_MESSAGE(WM_WINMGR, OnWinMgr)
END_MESSAGE_MAP()

CLogoWnd::CLogoWnd()
{
}

CLogoWnd::~CLogoWnd()
{
}

//////////////////
// Create logo window: load bitmap, save min size, etc.

BOOL CLogoWnd::Create(LPCTSTR lpszText, DWORD dwStyle, CWnd* pParentWnd,
	UINT nID, UINT nIDBitmap, LPCTSTR lpszLink, RECT rc)
{
	VERIFY(m_bitmap.LoadBitmap(nIDBitmap));
	BITMAP bm;
	m_bitmap.GetBitmap(&bm);
	m_szMinimum = CSize(bm.bmWidth, bm.bmHeight);
	m_szMinimum.cx += 2*GetSystemMetrics(SM_CXEDGE);
	m_szMinimum.cy += 2*GetSystemMetrics(SM_CYEDGE);
	if (CStaticLink::Create(lpszText,dwStyle,pParentWnd,nID,lpszLink,rc)) {
		SetBitmap(m_bitmap);
		return TRUE;
	}
	return FALSE;
}

//////////////////
// Handle WM_WINMGR: report min size
//
LRESULT CLogoWnd::OnWinMgr(WPARAM /* wp */, LPARAM lp)
{
	ASSERT(lp);
	NMWINMGR& nmw = *(NMWINMGR*)lp;
	if (nmw.code==NMWINMGR::GET_SIZEINFO) {
		nmw.sizeinfo.szMin = m_szMinimum;
		return TRUE; // handled
	}
	return 0;
}

