////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "Resource.h"
#include "DopeyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Window map tells CWinMgr how to position dialog controls
//
BEGIN_WINDOW_MAP(MyDialogMap)
BEGINROWS(WRCT_REST,0,RCMARGINS(8,8))
 BEGINCOLS(WRCT_REST,0,0)
  BEGINROWS(WRCT_REST,4,RCMARGINS(-4,-4))
   RCTOFIT(IDC_STATIC1)
   RCSPACE(-4)
	BEGINROWS(WRCT_TOFIT,IDC_GROUP1,RCMARGINS(-8,-8))
	 RCSPACE(-10)
    RCTOFIT(IDC_RADIO1)
    RCTOFIT(IDC_RADIO2)
	ENDGROUP()
  ENDGROUP()
  RCPERCENT(IDC_EDIT1,50)
 ENDGROUP()
 RCSPACE(-4)
 RCTOFIT(IDC_STATIC2)
 RCTOFIT(IDC_SLIDER1)
 BEGINCOLS(WRCT_TOFIT,0,0)
  RCREST(0)
  BEGINROWS(WRCT_TOFIT,0,0)
    RCTOFIT(IDOK)
    RCSPACE(-2)
    RCTOFIT(IDCANCEL)
  ENDGROUP()
 ENDGROUP()
ENDGROUP()
END_WINDOW_MAP()

IMPLEMENT_DYNAMIC(CDopeyDialog, CSizeableDlg)
BEGIN_MESSAGE_MAP(CDopeyDialog, CSizeableDlg)
	ON_REGISTERED_MESSAGE(WM_WINMGR, OnWinMgr)
END_MESSAGE_MAP()

CDopeyDialog::CDopeyDialog(CWnd* pParent)
	: CSizeableDlg(IDD_DIALOG, pParent, MyDialogMap)
{
	m_szMinButton = SIZEZERO;
}

CDopeyDialog::~CDopeyDialog()
{
}

//////////////////
// Init dialog: save current OK/Cancel button size as min size.
//
BOOL CDopeyDialog::OnInitDialog()
{
	BOOL bRet = CSizeableDlg::OnInitDialog();

	// save min size for OK/Cancel buttons
	CSize sz = m_winMgr.GetRect(IDOK).Size();
	m_szMinButton = CSize(sz.cx/2,sz.cy); // use half width
	return bRet;
}

///////////////////
// Handle WM_WINMGR: return min size for OK/Cancel buttons
//
LRESULT CDopeyDialog::OnWinMgr(WPARAM wp, LPARAM lp)
{
	ASSERT(lp);
	NMWINMGR& nmw = *(NMWINMGR*)lp;
	if (nmw.code==NMWINMGR::GET_SIZEINFO) {
		if (wp==IDOK || wp==IDCANCEL) {
			nmw.sizeinfo.szMin = m_szMinButton;
			return TRUE;
		}
	}
	return 0;
}
