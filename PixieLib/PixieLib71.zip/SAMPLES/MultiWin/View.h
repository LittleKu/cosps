////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

#include "Doc.h"
#include "DopeyWnd.h"
#include "LogoWnd.h"

//////////////////
// IDs of child windows in the view.
//
enum {
	ID_WIN_HTML = 1,
	ID_WIN_LOGO1,
	ID_WIN_LOGO2,
	ID_WIN_LICENSE,
	ID_WIN_DOPEY,
	ID_WIN_SIZERBAR_VERT,
	ID_WIN_SIZERBAR_HORZ,
};

/////////////////
// Main View contains several window, including CHtmlCtrl.
//
class CMyView : public CView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
	CHtmlCtrl* GetHtmlCtrl() { return &m_wndHtml; }

protected:
	CMyView();									 // ctor

	CWinMgr		m_winMgr;					 // window manager
	CHtmlCtrl   m_wndHtml;					 // HTML control
	CFont			m_fontEdit;					 // font for edit view
	CLogoWnd		m_wndLogo;					 // first bitmap/logo
	CLogoWnd		m_wndLogo2;					 // second bitmap/logo
	CStatic		m_wndLicense;				 // license agreement
	CFont			m_fontLic;					 // font for license agreement
	CDopeyWnd	m_wndDopey;					 // "dopey" pane
	CSizerBar	m_wndSizerBarVert;		 // vertical sizer bar for license pane
	CSizerBar	m_wndSizerBarHorz;		 // horizontal sizer bar for dopey window
	UINT			m_idCurWin;					 // current window

	// helpers to generate HTML header/footer 
	CString GenHTMLHeader(LPCTSTR title);
	CString GenHTMLFooter();

	// overrides
	virtual void OnDraw(CDC* pDC);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// message handlers
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);
	afx_msg void OnViewWindowList();
	afx_msg void OnUpdateViewWindowList(CCmdUI* pCmdUI);
	afx_msg void OnViewProcessList();
	afx_msg void OnUpdateViewProcessList(CCmdUI* pCmdUI);
	afx_msg void OnRefresh();
	afx_msg void OnUpdateRefresh(CCmdUI* pCmdUI);
	afx_msg void OnHelp();

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMyView)
};


