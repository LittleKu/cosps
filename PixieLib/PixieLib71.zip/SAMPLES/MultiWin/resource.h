//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MultiWin.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FILEDROPDOWN                130
#define IDB_MSDNMAG                     134
#define IDB_PIXIELIB                    135
#define IDD_DIALOG                      136
#define IDC_PDURL                       1000
#define IDC_MSDNURL                     1001
#define IDC_PIXIELOGO                   1002
#define IDC_STATIC1                     1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_SLIDER1                     1006
#define IDC_STATIC2                     1007
#define IDC_GROUP1                      1008
#define IDC_EDIT1                       1009
#define IDC_HTMLVIEW                    1010
#define ID_VIEW_DIALOG                  32820
#define ID_VIEW_WINLIST                 32822
#define ID_VIEW_PROCESSLIST             32823
#define ID_VIEW_REFRESH                 32824
#define ID_HELP_MULTIWIN                32825
#define ID_BUTTON32825                  32825
#define IDS_MYCOPYRIGHT                 61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32826
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
