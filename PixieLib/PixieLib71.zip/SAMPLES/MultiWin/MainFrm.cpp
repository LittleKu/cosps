////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "DopeyDlg.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Window map tells CWinMgr how to position toolbar, status bar and view.
//
BEGIN_WINDOW_MAP(MyMainWinMap)
BEGINROWS(WRCT_REST,0,0)
  RCTOFIT(AFX_IDW_TOOLBAR)
  RCREST(AFX_IDW_PANE_FIRST)
  RCTOFIT(AFX_IDW_STATUS_BAR)
ENDGROUP()
END_WINDOW_MAP()

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_REGISTERED_MESSAGE(WM_WINMGR, OnWinMgr)
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_VIEW_DIALOG, OnViewDialog)
	ON_NOTIFY(TBN_DROPDOWN, AFX_IDW_TOOLBAR, OnToolbarDropDown)
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame() : m_winMgr(MyMainWinMap)
{
}

CMainFrame::~CMainFrame()
{
}

//////////////////
// Override MFC's layout function -- call WinMgr instead
//
void CMainFrame::RecalcLayout(BOOL /* bNotify */)
{
	m_winMgr.CalcLayout(this);
	m_winMgr.SetWindowPositions(this);
// Don't call CFrameWnd!
//	CFrameWnd::RecalcLayout(bNotify);
}

////////////////
// Override for flicker-free drawing with no CS_VREDRAW and CS_HREDRAW
// and WS_CLIPCHILDREN. 
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;
	cs.style &= ~FWS_ADDTOTITLE;			 // don't add doc name to title
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
   return CFrameWnd::PreCreateWindow(cs);
}

//////////////////
// Main frame created: create control bars.
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	CToolBar& tb = m_wndToolBar;
	VERIFY(tb.Create(this));
	VERIFY(tb.LoadToolBar(IDR_MAINFRAME));
	tb.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	tb.SendMessage(TB_SETEXTENDEDSTYLE, 0, TBSTYLE_EX_DRAWDDARROWS);

	// change button style to dropdown
	int iButton = tb.SendMessage(TB_COMMANDTOINDEX, ID_FILE_OPEN);
	DWORD dwStyle = tb.GetButtonStyle(iButton);
	dwStyle |= TBSTYLE_DROPDOWN;
	tb.SetButtonStyle(iButton, dwStyle);

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(UINT)));

	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	// Install menu tip manager--that's all!
	m_menuTipManager.Install(this);

// WinMgr DOES NOT WORK with docking toolbars!!!
//	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
//	EnableDocking(CBRS_ALIGN_ANY);
//	DockControlBar(&m_wndToolBar);

	// start with help page
	PostMessage(WM_COMMAND, ID_HELP_MULTIWIN);

	return 0;
}

//////////////////
// Handle WM_WINMGR notification from WinMgr.
// Return TOFIT size for toolbar or status bar.
//
LRESULT CMainFrame::OnWinMgr(WPARAM wp, LPARAM lp)
{
	ASSERT(lp);
	NMWINMGR& nmw = *(NMWINMGR*)lp;
	if (nmw.code==NMWINMGR::GET_SIZEINFO) {
		CSize sz;
		if (wp==AFX_IDW_TOOLBAR) {
			// TOFIT size for toolbar: call MFC
			sz = m_wndToolBar.CalcFixedLayout(FALSE,TRUE);
		} else if (wp==AFX_IDW_STATUS_BAR) {
			// TOFIT size for status bar: call MFC
			sz = m_wndStatusBar.CalcFixedLayout(FALSE,TRUE);
		} else {
			return FALSE;
		}
		nmw.sizeinfo.szDesired = sz;
		nmw.sizeinfo.szMin.cy = sz.cy;
		return TRUE;
	}
	return FALSE;
}

//////////////////
// Handle WM_GETMINMAXINFO: pass to WinMgr.
//
void CMainFrame::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	m_winMgr.GetMinMaxInfo(this, lpMMI);
}

//////////////////
// Display dopey dialog
//
void CMainFrame::OnViewDialog()
{
	CDopeyDialog dlg(this);
	dlg.DoModal();
}

//////////////////
// Handle TBN_DROPDOWN
// Default is to display the specified menu at the right place.
// You can override to generate dynamic menus
//
// Args:
//		- NMTOOLBAR struct from TBN_DROPDOWN
//		- command id of button
//		- point to display menu at
//
void CMainFrame::OnToolbarDropDown(NMHDR* pnmh, LRESULT* /* plr */)
{
	NMTOOLBAR* pnmtb = (NMTOOLBAR*)pnmh;

	// load and display popup menu
	CMenu menu;
	menu.LoadMenu(IDR_FILEDROPDOWN);
	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup);

	CRect rc;
	m_wndToolBar.SendMessage(TB_GETRECT, pnmtb->iItem, (LPARAM)&rc);
	m_wndToolBar.ClientToScreen(&rc);

	pPopup->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_VERTICAL,
		rc.left, rc.bottom, this, &rc);
}
