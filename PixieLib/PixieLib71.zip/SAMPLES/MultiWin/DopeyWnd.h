////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

#include "Doc.h"

//////////////////
// Dopey static text control displays dopey message.
// Handles WM_WINMGR to specify its min size.
//
class CDopeyWnd : public CStatic {
public:
	CDopeyWnd();
	virtual ~CDopeyWnd();
	BOOL Create(CWnd* pParentWnd, UINT nID) {
		return CStatic::Create(NULL,SS_SUNKEN|WS_VISIBLE|WS_CHILD,
			CRect(0,0,0,0),pParentWnd,nID);
	}
protected:
	CFont m_font;
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);
	afx_msg int OnCreate(LPCREATESTRUCT lpcs);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CDopeyWnd)
};

