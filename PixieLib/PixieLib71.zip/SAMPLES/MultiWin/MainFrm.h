////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// Main frame window has window manager for toolbar, status bar and view.
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	~CMainFrame();

protected:
	CWinMgr				m_winMgr;			 // mainframe window manager
	CStatusBar			m_wndStatusBar;	 // standard status bar
	CFlatToolBar		m_wndToolBar;		 // standard toolbar
	CCoolMenuManager	m_menuManager;		 // manages menus for entire app + views
	CMenuTipManager	m_menuTipManager;	 // managed menu tips

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void RecalcLayout(BOOL bNotify = TRUE);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnViewBar(UINT nID);
	afx_msg void OnUpdateViewBar(CCmdUI* pCmdUI);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);

	// command handlers
	afx_msg void OnToolbarDropDown(NMHDR* pnmh, LRESULT* plRes);
	afx_msg void OnViewDialog();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
