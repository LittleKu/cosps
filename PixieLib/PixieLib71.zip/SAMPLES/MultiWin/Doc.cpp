////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "Doc.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyDoc, CHtmlEditDoc)
BEGIN_MESSAGE_MAP(CMyDoc, CHtmlEditDoc)
END_MESSAGE_MAP()

CMyDoc::CMyDoc()
{
}

CMyDoc::~CMyDoc()
{
}

BOOL CMyDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	TRACE(_T("CMyDoc::OnOpenDocument\n"));
	((CMyView*)m_viewList.GetHead())->GetHtmlCtrl()->Navigate(lpszPathName);
	return TRUE;
}

void CMyDoc::Serialize(CArchive& /*ar */)
{
	ASSERT(FALSE);	// should never get here
}

BOOL CMyDoc::OnNewDocument()
{
	TRACE(_T("CMyDoc::OnNewDocument\n"));
	if (CDocument::OnNewDocument()) {
		((CMyView*)m_viewList.GetHead())->GetHtmlCtrl()->Navigate(_T("about:blank"));
		return TRUE;
	}
	return FALSE;
}


