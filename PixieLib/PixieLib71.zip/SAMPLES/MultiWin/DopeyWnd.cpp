////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdAfx.h"
#include "DopeyWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CDopeyWnd, CStatic)
BEGIN_MESSAGE_MAP(CDopeyWnd, CStatic)
	ON_WM_CREATE()
	ON_REGISTERED_MESSAGE(WM_WINMGR, OnWinMgr)
END_MESSAGE_MAP()

CDopeyWnd::CDopeyWnd()
{
}

CDopeyWnd::~CDopeyWnd()
{
}

//////////////////
// Window created: create font and set text.
//
int CDopeyWnd::OnCreate(LPCREATESTRUCT lpcs)
{
	VERIFY(CWnd::OnCreate(lpcs)==0);
	if (m_font.CreatePointFont(240,_T("Broadway")) ||
		m_font.CreatePointFont(240,_T("Arial")))  {
		SetFont(&m_font);
	}
	SetWindowText(_T("This is the dopey pane. It is oh so dopey!"));
	return 0;
}

//////////////////
// Handle WM_WINMGR: give window manager my desired and min/tofit size.
// This is computed from the font with DrawText.
//
LRESULT CDopeyWnd::OnWinMgr(WPARAM /* wp */, LPARAM lp)
{
	ASSERT(lp);
	NMWINMGR& nmr = *(NMWINMGR*)lp;
	if (nmr.code==NMWINMGR::GET_SIZEINFO) {
		// get window text
		CString s;
		GetWindowText(s);

		// set up text rectangles
		CRect rcText(0,0,nmr.sizeinfo.szAvail.cx,0); // width of text = szAvail
		CRect rcMin = rcText;								// min rect

		// now use DrawText to compute desired text rectangle
		CClientDC dc(this);
		CFont* pOldFont = dc.SelectObject(GetFont());
		dc.DrawText(s, &rcText, DT_CALCRECT|DT_WORDBREAK);

		// min size: use height of letter A. Could also use GetTextMetrics here.
		int hOneLine = dc.DrawText(_T("A"), &rcMin, DT_CALCRECT|DT_WORDBREAK);
		dc.SelectObject(pOldFont);

		// give WinMgr my size info
		nmr.sizeinfo.szDesired = rcText.Size();
		nmr.sizeinfo.szMin = CSize(0, hOneLine);

		return TRUE; // handled
	}
	return 0;
}

