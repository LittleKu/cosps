////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// DragList shows how to use CDragDropMgr to implement drag-drop between
// controls within an app. DragList also shows how to use CListBoxTipHandler to
// show tooltips for list box items that are too long to be seen. 
//
#include "stdafx.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const WM_MYDRAGDROP = WM_APP+1;

//////////////////
// Generic MFC application class
//
class CMyApp : public CWinApp {
public:
	CMyApp() { }
	virtual BOOL InitInstance();
} theApp;

//////////////////
// Main dialog with two list boxes and edit control to drag/drop.
//
class CMyDlg : public CDialog {
protected:
	CDragDropMgr m_ddm;						 // drag-drop manager
	HICON m_hIcon;								 // app icon
	CStaticLink m_wndLink1;					 // static link
	CStaticLink m_wndLink2;					 // ..another
	CListBox m_wndList1;						 // first (source) list box
	CListBox m_wndList2;						 // second (source/target) list box
	CListBoxTipHandler m_tipHandler1;	 // tooltips for list box 1
	CListBoxTipHandler m_tipHandler2;	 // tooltips for list box 2
	CEdit m_wndEdit1;							 // edit control (target)
	int m_bAutoScroll;						 // in list box auto-scroll scroll mode
	int m_bScrollStopped;					 // i scrolled off one end

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	int  GetLBItemUnderPt(CListBox* pListBox, CPoint pt);
	void GetAutoScrollZone(CWnd* pWnd, CRect& rcTop, CRect& rcBot);
	void SetAutoScroll(int dir);

	BOOL OnDDStart(DRAGDROPINFO& ddi);
	void OnDDDrag(DRAGDROPINFO& ddi);
	void OnDDDrop(DRAGDROPINFO& ddi);
	void OnDDAbort();

public:
	CMyDlg(CWnd* pParent = NULL);	// standard constructor
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnReset();
	afx_msg LRESULT OnDragDrop(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
};

BOOL CMyApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();
	CWinApp::InitInstance();

	// Run modal dialog
	CMyDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	// return FALSE to exit app
	return FALSE;
}

BEGIN_MESSAGE_MAP(CMyDlg, CDialog)
	ON_COMMAND(IDC_RESET, OnReset)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_MYDRAGDROP, OnDragDrop)
END_MESSAGE_MAP()

CMyDlg::CMyDlg(CWnd* pParent) : CDialog(IDD_MAINFRAME, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bAutoScroll = FALSE;
	m_bScrollStopped = FALSE;
}

//////////////////
// Init dialog: subclass controls and install drag-drop manager
//
BOOL CMyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  MFC does this automatically
	// when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_wndLink1.SubclassDlgItem(IDC_PDURL,this);
	m_wndLink2.SubclassDlgItem(IDC_PIXIEURL,this);
	m_wndList1.SubclassDlgItem(IDC_LIST1,this);
	m_wndList2.SubclassDlgItem(IDC_LIST2,this);
	m_wndEdit1.SubclassDlgItem(IDC_EDIT1,this);

	OnReset();

	// table describing which child windows are sources and targets
	static BEGIN_DRAGDROP_MAP(MyDragDropWindows)
		DRAGDROP_WINDOW(IDC_LIST1, DDW_SOURCE)
		DRAGDROP_WINDOW(IDC_LIST2, DDW_SOURCE|DDW_TARGET)
		DRAGDROP_WINDOW(IDC_EDIT1, DDW_TARGET)
	END_DRAGDROP_MAP()

	m_ddm.Install(this, MyDragDropWindows, WM_MYDRAGDROP);

	// list box tooltips for wide items
	m_tipHandler1.Init(&m_wndList1);
	m_tipHandler2.Init(&m_wndList2);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

//////////////////
// Reset form/dialog contents to initial state. If edit control contains a
// three-letter word like 'all', fill list box #2 also. 
//
void CMyDlg::OnReset()
{
	static LPCTSTR MyItems[] = {
		_T("Dopey"),
		_T("Smokey"),
		_T("Pokey"),
		_T("Hokey"),
		_T("Croaky"),
		_T("Simple"),
		_T("Dimple"),
		_T("Pimple"),
		_T("Bot"),
		_T("Dot"),
		_T("Hot"),
		_T("Mot"),
		_T("Not"),
		_T("Pot"),
		_T("Rot"),
		_T("Sot"),
		_T("Zot"),
		_T("This is a looong item at the end."),
		_T("Another even looonger item is the very last one."),
		NULL
	};
	int len = m_wndEdit1.GetWindowTextLength();
	m_wndEdit1.SetWindowText(NULL);
	m_wndList1.ResetContent();
	m_wndList2.ResetContent();
	for (int i=0; MyItems[i]; i++) {
		m_wndList1.AddString(MyItems[i]);
		if (len==3)
			m_wndList2.AddString(MyItems[i]);
	}
}

//////////////////
// You must override PreTranslateMessage to pass input to drag-drop manager.
//
BOOL CMyDlg::PreTranslateMessage(MSG* pMsg)
{
	return m_ddm.PreTranslateMessage(pMsg) ? TRUE :
		CDialog::PreTranslateMessage(pMsg);
}

//////////////////
// Get top and bottom rects describing the auto-scroll zone: rects above and
// below the window where dragging triggers auto-scroll in the window
//
void CMyDlg::GetAutoScrollZone(CWnd* pWnd, CRect& rcTop, CRect& rcBot)
{
	CRect rc;
	pWnd->GetWindowRect(&rc);
	ScreenToClient(&rc);
	// Height of auto scroll "zone": Use caption height--why not?
	int cyZone = GetSystemMetrics(SM_CYCAPTION);

	// Compute the two rectangles
	rcTop = rc;
	rcTop.bottom = rcTop.top;
	rcTop.top -= cyZone;
	rcBot = rc;
	rcBot.top = rcBot.bottom;
	rcBot.bottom += cyZone;
}

//////////////////
// User let go the mouse: drop data into child control.
//
LRESULT CMyDlg::OnDragDrop(WPARAM wp, LPARAM lp)
{
	TRACE(_T("CMyDlg::OnDragDrop: %s\n"),
		CDragDropMgr::GetNotificationCodeName((UINT)wp));
	DRAGDROPINFO& ddi = *(DRAGDROPINFO*)lp;

	switch (wp) {
	case CDragDropMgr::DD_ENTER:
		return OnDDStart(ddi);

	case CDragDropMgr::DD_DRAG:
		OnDDDrag(ddi);
		break;

	case CDragDropMgr::DD_DROP:
		OnDDDrop(ddi);
		break;

	case CDragDropMgr::DD_ABORT:
		OnDDAbort();
		break;

	default:
		ASSERT(FALSE);
	}
	return 0;
}

//////////////////
// Begin dragging: create new text data from list item under point.
//
BOOL CMyDlg::OnDDStart(DRAGDROPINFO& ddi)
{
	TRACE(_T("OnDDStart\n"));
	CListBox* plb = DYNAMIC_DOWNCAST(CListBox, GetDlgItem(ddi.nID));
	ASSERT(plb!=NULL);
	int item = GetLBItemUnderPt(plb, ddi.pt);
	if (item>=0) {
		CString text;
		plb->GetText(item, text);
		ddi.data = new CDragDropText(text);
		return TRUE; // do drag-drop
	}
	return FALSE; // no item under mouse: nothing to drag
}

//////////////////
// User is dragging: If mouse in autoscroll zone, start auto-scroll.
//
void CMyDlg::OnDDDrag(DRAGDROPINFO& ddi)
{
	CRect rcTop,rcBot;
	GetAutoScrollZone(&m_wndList2, rcTop, rcBot);

	int dir=0;
	if (rcTop.PtInRect(ddi.pt))
		dir=1;
	else if (rcBot.PtInRect(ddi.pt))
		dir=-1;
	SetAutoScroll(dir);
}

//////////////////
// User let go the mouse: drop data into child control.
//
void CMyDlg::OnDDDrop(DRAGDROPINFO& ddi)
{
	LPCTSTR text = (LPCTSTR)ddi.data->OnGetData();

	SetAutoScroll(0);
	m_bScrollStopped = FALSE;

	if (ddi.nID==IDC_LIST2) {
		CListBox* plb = DYNAMIC_DOWNCAST(CListBox, GetDlgItem(ddi.nID));
		ASSERT(plb!=NULL);

		int iNew = GetLBItemUnderPt(plb, ddi.pt);
		int iOld = plb->FindString(0, text);
		if (iOld>=0) {
			plb->DeleteString(iOld);
			if (iOld < iNew)
				iNew--;
		}
		if (iNew>=0)
			plb->InsertString(iNew, text);
		else
			iNew = plb->AddString(text);
		plb->SetCurSel(iNew);

	} else if (ddi.nID==IDC_EDIT1) {
		m_wndEdit1.SetWindowText(text);
		
	} else {
		ASSERT(FALSE);
	}
}

//////////////////
// Dragging aborted: turn off autoscroll.
//
void CMyDlg::OnDDAbort()
{
	SetAutoScroll(0);
	m_bScrollStopped = FALSE;
}

//////////////////
// Helper to get the list box item under the mouse.
// This may not be the selected item when dropping.
//
int CMyDlg::GetLBItemUnderPt(CListBox* pListBox, CPoint pt)
{
	BOOL bOutside;
	UINT item = pListBox->ItemFromPoint(pt, bOutside);
	return item>=0 && !bOutside ? item : -1;
}

//////////////////
// Enter/leave auto-scroll mode. Arg is direction +-1=up/down, 0=off.
//
void CMyDlg::SetAutoScroll(int dir)
{
	if (m_bAutoScroll != dir && dir!=m_bScrollStopped) {
		m_bAutoScroll = dir;
		if (dir)
			SetTimer(1,330,NULL);
		else
			KillTimer(1);
	}
}

//////////////////
// Timer clicked: scroll another item
//
void CMyDlg::OnTimer(UINT_PTR /*nIDEvent*/)
{
	TRACE(_T("CMyDlg::OnTimer, dir=%d\n"), m_bAutoScroll);

	// move top item plus or minus one
	int iNewTop = m_wndList2.GetTopIndex() - m_bAutoScroll;
	if (iNewTop<0) {
		m_bScrollStopped = m_bAutoScroll; // scrolled off beginning: stop..
		SetAutoScroll(0);						 // ..kill timer

	} else {
		m_wndList2.SetTopIndex(iNewTop);	 // set new top item..
		m_wndList2.Invalidate();			 // and repaint..
		m_wndList2.UpdateWindow();
		if (iNewTop != m_wndList2.GetTopIndex()) {
			m_bScrollStopped = m_bAutoScroll; // scrolled off end: stop
			SetAutoScroll(0);						 // ..kill timer
		}
	}
}
