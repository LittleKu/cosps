#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define USE_PIXIE_DLL	// use PixieLib DLL
#include <afxwin.h>
#include <PixieLib.h>
#include <PLDragDrop.h>
