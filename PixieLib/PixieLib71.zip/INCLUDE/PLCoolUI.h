////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#include <afxext.h>		// MFC control bars
#include <afxcmn.h>		// MFC tooltip ctrl
#include <afxhtml.h>		// For CHtmlView

#ifndef TB_SETEXTENDEDSTYLE
#error CoolUI.h requires a newer version of commctrl.h than the one you have.
#endif

#include <PLDraw.h>
#include <list>
using namespace std;

//////////////////
// Improved CCommandLineInfo parses arbitrary switches.
// Use instead of CCommandLineInfo:
//
//		// E.g., in CMyApp::InitInstance
//		CPLCommandLineInfo cmdinfo;
//		ParseCommandLine(cmdinfo);
//
// After parsing, you can call GetOption to get the value of any switch. Eg:
//
//		if (cmdinfo.GetOption("nologo")) {
//			// user invoked program with -nologo option
//		}
//
// To get the value of a string option, type
//
//		CString filename;
//		if (cmdinfo.GetOption("f", filename)) {
//			// now filename is string following -f option
//		}
//
// Used in CSplash to automatically parse the -nologo option to suppress the
// splash screen.
//
class DLLCLASS CPLCommandLineInfo : public CCommandLineInfo {
public:
	BOOL GetOption(LPCTSTR option, CString& val);
	BOOL GetOption(LPCTSTR option) {
		CString s;
		return GetOption(option, s);
	}

protected:
	CMapStringToString m_options;	// hash of options
	CString	m_sLastOption;			// last option encountered
	virtual void ParseParam(const TCHAR* pszParam, BOOL bFlag, BOOL bLast);
};

//////////////////
// Programmer-friendly MENUITEMINFO initializes itself.
//
struct CMenuItemInfo : public MENUITEMINFO {
	CMenuItemInfo()
	{ memset(this, 0, sizeof(MENUITEMINFO));
	  cbSize = sizeof(MENUITEMINFO);
	}
};

//////////////////
// Popup text window is similar to a tooltip but eaiser to use. Just
// instantiate and Create. For example:
//
//		m_wndTip.Create(CPoint(0,0), pParent);		// create popup text
//		m_wndTip.m_szMargins = CSize(4,0);			// set margins
//		m_wndTip.SetWindowText("hello, world");	// set tip text
//		m_wndTip.ShowDelayed(200);						// show in 200 milliseconds
//
// To cancel (hide) the tip:
//
//		m_wndTip.Cancel();
//
// Used in CMenuTipManager to display menu tips. You can change m_font and/or
// m_color for different font/color (default=tooltip font/color), or override
// virtual DrawText function to do custom drawing.
//
class DLLCLASS CPopupText : public CWnd {
public:
	// change these if you like:
	CSize m_szMargins;		// extra space around text
	COLORREF m_clrBG;			// background color (default: tooltip bg color)
	COLORREF m_clrText;		// text color (default: tooltip text color)
	CFont m_font;				// font (default: menu font)
	UINT m_dfltDrawFlags;	// default flags for drawtext, you can change

	CPopupText();
	virtual ~CPopupText();

	BOOL Create(CPoint pt, CWnd* pParentWnd, UINT nID=0);
	void ShowDelayed(UINT msec, UINT msecTimeout=0);
	void Cancel();

protected:
	UINT  m_msecTimeout;		// auto-timeout

	virtual void PostNcDestroy();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	virtual void DrawText(CDC& dc, LPCTSTR lpText, CRect& rc, UINT flags);

	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnSetText(WPARAM wp, LPARAM lp);

	DECLARE_DYNAMIC(CPopupText);
	DECLARE_MESSAGE_MAP();
};

//////////////////
// This internal class fixes sizing bugs in older versions of MFC that
// calculate the size of toolbars incorrectly for modern toobars (comctl32
// version >= 4.71). It also has several useful wrappers for functions that
// CToolBar doesn't have (so you don't have to use GetToolBarCtrl), like
// GetButton. Generally, you should never use this class directly -- use
// CFlatToolBar instead.
//
class DLLCLASS CFixMFCToolBar : public CToolBar { // used internally
public:
	CFixMFCToolBar();
	virtual ~CFixMFCToolBar();

	static int iVerComCtl32; // version of commctl32.dll (eg 471)

	// There is a bug in comctl32.dll, version 4.71+ that causes it to
	// draw vertical separators in addition to horizontal ones, when the
	// toolbar is vertically docked. If the toolbar has no dropdown buttons,
	// this is not a problem because the separators are ignored when calculating
	// the width of the toolbar. If, however, you have dropdown buttons, then the
	// width of a vertically docked toolbar will be too narrow to show the
	// dropdown arrow. This is in fact what happens in Visual Studio. If you
	// want to show the dropdown arrow when vertical, set this to TRUE
	// (default = FALSE)
	//
	BOOL m_bShowDropdownArrowWhenVertical;

	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);

	CSize CalcLayout(DWORD nMode, int nLength = -1);
	CSize CalcSize(TBBUTTON* pData, int nCount);
	int WrapToolBar(TBBUTTON* pData, int nCount, int nWidth);
	void SizeToolBar(TBBUTTON* pData, int nCount, int nLength,
		BOOL bVert = FALSE);
	virtual void OnBarStyleChange(DWORD dwOldStyle, DWORD dwNewStyle);

	virtual CSize GetButtonSize(TBBUTTON* pData, int iButton);

	// MFC has versions of these that are protected--but why?
	//
	void GetButton(int nIndex, TBBUTTON* pButton) const;
	void SetButton(int nIndex, TBBUTTON* pButton);

protected:
	LRESULT OnSizeHelper(CSize& sz, LPARAM lp);
	afx_msg LRESULT OnSetBitmapSize(WPARAM, LPARAM);
	afx_msg LRESULT OnSetButtonSize(WPARAM, LPARAM);
	afx_msg LRESULT OnSettingChange(WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CFixMFCToolBar)
};

// fwd ref
struct DROPDOWNBUTTON;

#define CFlatToolBarBase CFixMFCToolBar

//////////////////
// CFlatToolbar is a drop-in replacement for CToolBar that supports flat-style
// buttons with gripper handles. Use instead of CToolBar in your CMainFrame.
// CFlatTooBars don't actually require the flat style, but they have it by
// default. If you don't want the flat look, call
//
//		m_wndToolBar.ModifyStyle(TBSTYLE_FLAT, 0);
//
// CFlatToolBar overcomes various MFC drawing bugs that cause it not to work
// with flat-style buttons. CFlatToolBar Can also be used inside a coolbar
// (unlike CToolBar). CFlatToolBar has other good stuff too, like an easy way
// to handle drop-down toolbar buttons. See the CoolEdit sample app for
// details.
//
class DLLCLASS CFlatToolBar : public CFlatToolBarBase {
public:
	CFlatToolBar();
	virtual ~CFlatToolBar();

	// set these before creation:
	BOOL m_bDrawSeparators;					// draw separators (dflt = TRUE)
	BOOL m_bDrawGrippers;					// draw grippers (dflt = 1). Set to 2
													// before creating to draw 2 grippers.
	BOOL m_bDrawDisabledButtonsInColor;	// draw disabled buttons in color
	BOOL m_bInCoolBar;						// set if flatbar is inside coolbar
	BOOL m_bFixWrappedSeparators;			// fix extraneous seps in comctl 471/472

	// You must call one of these to get the flat look; if not, you must
	// set TBSTYLE_FLAT yourself.
	BOOL LoadToolBar(LPCTSTR lpszResourceName);
	BOOL LoadToolBar(UINT nIDResource)
		{ return LoadToolBar(MAKEINTRESOURCE(nIDResource)); }

	// call to add drop-down buttons
	BOOL AddDropDownButton(UINT nIDButton, UINT nIDMenu, BOOL bArrow);

	// MFC overrides.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);

	// Use these to get/set the flat style. By default, LoadToolBar calls
	// SetFlatStyle(TRUE); if you create some other way, you must call it
	// yourself.
	BOOL SetFlatStyle(BOOL bFlat) {
		return ModifyStyle(bFlat ? 0 : TBSTYLE_FLAT, bFlat ? TBSTYLE_FLAT : 0);
	}
	BOOL GetFlatStyle() {
		return (GetStyle() & TBSTYLE_FLAT)!=0;
	}

	// silly function to fake out compiler with const-ness
	LRESULT SendMessageC(UINT m, WPARAM wp=0, LPARAM lp=0) const
		{ return ((CFlatToolBarBase*)this)->SendMessage(m, wp, lp); }

	// Wrappers that are not in MFC but should be.
	// I copied these from CToolBarCtrl
	BOOL EnableButton(int nID, BOOL bEnable)
		{ return (BOOL)SendMessage(TB_ENABLEBUTTON, nID, MAKELPARAM(bEnable, 0)); }
	BOOL CheckButton(int nID, BOOL bCheck)
		{ return (BOOL)SendMessage(TB_CHECKBUTTON, nID, MAKELPARAM(bCheck, 0)); }
	BOOL PressButton(int nID, BOOL bPress)
		{ return (BOOL)SendMessage(TB_PRESSBUTTON, nID, MAKELPARAM(bPress, 0)); }
	BOOL HideButton(int nID, BOOL bHide)
		{ return (BOOL)SendMessage(TB_HIDEBUTTON, nID, MAKELPARAM(bHide, 0)); }
	BOOL Indeterminate(int nID, BOOL bIndeterminate)
		{ return (BOOL)SendMessage(TB_INDETERMINATE, nID, MAKELPARAM(bIndeterminate, 0)); }
	BOOL IsButtonEnabled(int nID) const
		{ return (BOOL)SendMessageC(TB_ISBUTTONENABLED, nID); }
	BOOL IsButtonChecked(int nID) const
		{ return (BOOL)SendMessageC(TB_ISBUTTONCHECKED, nID); }
	BOOL IsButtonPressed(int nID) const
		{ return (BOOL)SendMessageC(TB_ISBUTTONPRESSED, nID); }
	BOOL IsButtonHidden(int nID) const
		{ return (BOOL)SendMessageC(TB_ISBUTTONHIDDEN, nID); }
	BOOL IsButtonIndeterminate(int nID) const
		{ return (BOOL)SendMessageC(TB_ISBUTTONINDETERMINATE, nID); }
	BOOL SetState(int nID, UINT nState)
		{ return (BOOL)SendMessage(TB_SETSTATE, nID, MAKELPARAM(nState, 0)); }
	int GetState(int nID) const
		{ return (int)SendMessageC(TB_GETSTATE, nID); }
	BOOL AddButtons(int nNumButtons, LPTBBUTTON lpButtons)
		{ return (BOOL)SendMessage(TB_ADDBUTTONS, nNumButtons, (LPARAM)lpButtons); }
	BOOL InsertButton(int nIndex, LPTBBUTTON lpButton)
		{ return (BOOL)SendMessage(TB_INSERTBUTTON, nIndex, (LPARAM)lpButton); }
	BOOL DeleteButton(int nIndex)
		{ return (BOOL)SendMessage(TB_DELETEBUTTON, nIndex); }
	int GetButtonCount() const
		{ return (int)SendMessageC(TB_BUTTONCOUNT); }
	UINT CommandToIndex(UINT nID) const
		{ return (UINT)SendMessageC(TB_COMMANDTOINDEX, nID); }
	void Customize()
		{ SendMessage(TB_CUSTOMIZE, 0, 0L); }
	int AddStrings(LPCTSTR lpszStrings)
		{ return (int)SendMessage(TB_ADDSTRING, 0, (LPARAM)lpszStrings); }
	void SetButtonStructSize(int nSize)
		{ SendMessage(TB_BUTTONSTRUCTSIZE, nSize); }
	BOOL SetButtonSize(CSize sz)
		{ return (BOOL)SendMessage(TB_SETBUTTONSIZE, 0, MAKELPARAM(sz.cx, sz.cy)); }
	BOOL SetBitmapSize(CSize sz)
		{ return (BOOL)SendMessage(TB_SETBITMAPSIZE, 0, MAKELPARAM(sz.cx, sz.cy)); }
	void AutoSize()
		{ SendMessage(TB_AUTOSIZE); }
	CToolTipCtrl* GetToolTips() const
		{ return (CToolTipCtrl*)CWnd::FromHandle((HWND)SendMessageC(TB_GETTOOLTIPS)); }
	void SetToolTips(CToolTipCtrl* pTip)
		{ SendMessage(TB_SETTOOLTIPS, (WPARAM)pTip->m_hWnd); }

// NO!!!--this is not the same as the MFC owner
//	void SetOwner(CWnd* pWnd)
//		{ SendMessage(TB_SETPARENT, (WPARAM)pWnd->m_hWnd); }

	void SetRows(int nRows, BOOL bLarger, LPRECT lpRect)
		{ SendMessage(TB_SETROWS, MAKELPARAM(nRows, bLarger), (LPARAM)lpRect); }
	int GetRows() const
		{ return (int) SendMessageC(TB_GETROWS); }
	BOOL SetCmdID(int nIndex, UINT nID)
		{ return (BOOL)SendMessage(TB_SETCMDID, nIndex, nID); }
	UINT GetBitmapFlags() const
		{ return (UINT) SendMessageC(TB_GETBITMAPFLAGS); }

	// Wrappers for some of the newer messages--not complete
	BOOL SetIndent(int indent)
		{ return (BOOL)SendMessage(TB_SETINDENT, indent); }
	HIMAGELIST GetImageList() const
		{ return (HIMAGELIST)SendMessageC(TB_GETIMAGELIST); }
	HIMAGELIST SetImageList(HIMAGELIST hImgList)
		{ return (HIMAGELIST)SendMessage(TB_SETIMAGELIST, 0, (LPARAM)hImgList); }
	int GetBitmap(UINT nIdButton) const
		{ return (int)SendMessageC(TB_GETBITMAP, nIdButton); }
	DWORD SetExtendedStyle(DWORD dwStyle)
		{ return (DWORD)SendMessage(TB_SETEXTENDEDSTYLE, 0, dwStyle); }
	BOOL GetRect(UINT nIdButton, RECT& rc) const
		{ return (BOOL)SendMessageC(TB_GETRECT, nIdButton, (LPARAM)&rc); }
	DWORD GetToolbarStyle() const
		{ return (DWORD)SendMessageC(TB_GETSTYLE); }
	void SetToolbarStyle(DWORD dwStyle)
		{ SendMessage(TB_SETSTYLE, 0, dwStyle); }
	int HitTest(CPoint p) const
		{ return (int)SendMessageC(TB_HITTEST, 0, (LPARAM)&p); }
	int  GetHotItem() const
		{ return (int)SendMessageC(TB_GETHOTITEM); }
	void SetHotItem(int iHot)
		{ SendMessage(TB_SETHOTITEM, iHot); }
	BOOL MapAccelerator(TCHAR ch, UINT& nID) const
		{ return (BOOL)SendMessageC(TB_MAPACCELERATOR, (WPARAM)ch, (LPARAM)&nID); }
	CSize GetPadding() const
		{ return (LONG)SendMessageC(TB_GETPADDING); }
	CSize SetPadding(CSize sz) 
		{ return (LONG)SendMessage(TB_SETPADDING, 0, MAKELPARAM(sz.cx,sz.cy)); }

protected:
	CRect				 m_rcOldPos;				// used when toolbar is moved
	DROPDOWNBUTTON* m_pDropDownButtons;		// list of dropdown button/menu pairs
	BOOL				 m_bNoEntry;				// implementation hack

	// override to do your own custom drop-down buttons
	virtual void OnDropDownButton(const NMTOOLBAR& nmtb, UINT nID, CRect rc);
	DROPDOWNBUTTON* FindDropDownButton(UINT nID);
	void FixWrappedSeparators(CDC& dc);

	// helpers
	virtual CSize AdjustSize(CSize sz, BOOL bHorz);
	virtual BOOL DrawItem(CDC& dc, const NMCUSTOMDRAW& cd);
	virtual void DrawSeparators(CDC& dc);
	virtual void InvalidateOldPos(const CRect& rcInvalid);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg void OnTbnDropDown(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg void OnWindowPosChanging(LPWINDOWPOS lpWndPos);
	afx_msg void OnWindowPosChanged(LPWINDOWPOS lpWndPos);
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalc, NCCALCSIZE_PARAMS*	pncp );
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg BOOL OnNcCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CFlatToolBar)
};

//////////////////
// CCoolBar wraps the IE common coolbar (also called rebar). To use it:
//
// * Derive your own CMyCoolBar from CCoolBar.
//
// * Implement OnCreateBands to create whatever bands you want. If you're
// using coolbars, your toolbars and menubars are children of the coolbar, so
// you should instantiate/create these control bars in CCoolBar/OnCreateBands
// instead of CMainFrame/OnCreate.
//
//		// in CMyCoolBar::OnCreateBands
//		VERIFY(m_wndMenuBar.CreateEx(...);		// create menu bar
// 	InsertBand(&m_wndMenuBar, ...);			// add to coolbar
//		m_wndToolBar.CreateEx(...);				// create toolbar
//		VERIFY(m_wndToolBar.LoadToolBar(IDR_TOOLBAR1)); // load it
//		InsertBand(&m_wndToolBar, ...);			// add to coolbar
//
// * Instantiate and create CMyCoolBar in your main frame as you would a toolbar.
//
//		// in CMainFrame::OnCreate
//		m_wndCoolBar.Create(...);
//		m_wndCoolBar.SetColors(...);
//		m_wndCoolBar.SetBackgroundBitmap(...);
//
// See CoolEdit for example of how to use.
//
class DLLCLASS CCoolBar : public CControlBar {
public:
	CCoolBar();
	virtual ~CCoolBar();

	BOOL Create(CWnd* pParentWnd, DWORD dwStyle,
		DWORD dwAfxBarStyle = CBRS_ALIGN_TOP,
		UINT nID = AFX_IDW_TOOLBAR);

	// message wrappers
	BOOL GetBarInfo(LPREBARINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_GETBARINFO, 0, (LPARAM)lp); }

	BOOL SetBarInfo(LPREBARINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_SETBARINFO, 0, (LPARAM)lp); }

	BOOL GetBandInfo(int iBand, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_GETBANDINFO, iBand, (LPARAM)lp); }

	BOOL SetBandInfo(int iBand, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_SETBANDINFO, iBand, (LPARAM)lp); }

	BOOL InsertBand(int iWhere, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_INSERTBAND, (WPARAM)iWhere, (LPARAM)lp); }

	BOOL DeleteBand(int nWhich)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_DELETEBAND, (WPARAM)nWhich); }

	int GetBandCount()
		{ ASSERT(::IsWindow(m_hWnd));
		  return (int)SendMessage(RB_GETBANDCOUNT); }

	int GetRowCount()
		{ ASSERT(::IsWindow(m_hWnd));
	     return (int)SendMessage(RB_GETROWCOUNT); }

	int GetRowHeight(int nWhich)
		{ ASSERT(::IsWindow(m_hWnd));
	     return (int)SendMessage(RB_GETROWHEIGHT, (WPARAM)nWhich); }

	// Call these handy functions from your OnCreateBands to do stuff
	// more easily than the Windows way.
	//
	BOOL InsertBand(CWnd* pWnd, CSize szMin, int cx = 0,
		LPCTSTR lpText=NULL, int iWhere=-1, BOOL bNewRow =FALSE);
	void SetColors(COLORREF clrFG, COLORREF clrBG);
	void SetBackgroundBitmap(CBitmap* pBitmap);
	void Invalidate(BOOL bErase = TRUE); // invalidates children too

protected:
	// YOU MUST OVERRIDE THIS in your derived class to create bands.
	virtual BOOL OnCreateBands() = 0; // return -1 if failed

	// Virtual fn called when the coolbar height changes as a result of moving
	// bands around. Override only if you want to do something different.
	virtual void OnHeightChange(const CRect& rcNew);

	// overrides to fix problems w/MFC. No need to override yourself.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);
	virtual void  OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnPaint();
	afx_msg void OnHeightChange(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CCoolBar)
};

//////////////////
// Programmer-friendly REBARINFO initializes itself.
//
class CRebarInfo : public REBARINFO {
public:
	CRebarInfo() {
		memset(this, 0, sizeof(REBARINFO));
		cbSize = sizeof(REBARINFO);
	}
};

//////////////////
// Programmer-friendly REBARBANDINFO initializes itself.
//
class CRebarBandInfo : public REBARBANDINFO {
public:
	CRebarBandInfo() {
		memset(this, 0, sizeof(REBARBANDINFO));
		cbSize = sizeof(REBARBANDINFO);
	}
};

struct CMyItemData;	// fwd ref

//////////////////
// CCoolMenuManager implements "cool" menus (menus with toolbar buttons in
// them). CCoolMenuManager also automatically finds accelerators and appends
// them to your menus; eg "Open" ==> "Open\tCtrl+O". To use:
//
// * Instantiate in your CMainFrame, then call Install and LoadToolbar from
// your OnCreate handler. For example:
//
//		// in CMainFrame::OnCreate
//		m_menuManager.Install(this);
//		m_menuManager.LoadToolbar(IDR_TOOLBAR1);
//
// CCoolMenuManager converts your menus to owner-draw menus. For each toolbar
// that you load, if CCoolMenuManager finds a button for a particular command,
// it draws the same bitmap in that command's menu item wherever it appears in
// menus, including context menus.
//
// If you want to use the same menu manager in child windows like views and
// MDI children that also have menus (including context menus), use
// CCoolMenuWindow in your child window class instead of instantiating a whole
// new CCoolMenuManager. See the MDI version of CoolEdit for an example of
// this. CoolEdit uses a single CCoolMenuManager in the main frame, and each
// child view has its own CCoolMenuWindow.
//
class DLLCLASS CCoolMenuManager : protected CSubclassWnd {
public:
	DECLARE_DYNAMIC(CCoolMenuManager)
	CCoolMenuManager();
	~CCoolMenuManager();

	enum { AcNone, AcAll, AcOnlyIfMissing };

	// You can set these any time
	BOOL m_bShowButtons;			// use to control whether buttons are shown
	BOOL m_bAutoAccel;			// generate auto accelerators
	BOOL m_bUseDrawState;		// use ::DrawState for disabled buttons
	BOOL m_bDrawDisabledButtonsInColor; // draw disabled buttons in color
													// (only if m_bUseDrawState = FALSE)

	// public functions to use
	void Install(CWnd* pWnd);							// connect to window
	BOOL LoadToolbars(const UINT* arIDs, int n);	// load multiple toolbars
	BOOL LoadToolbar(UINT nID);						// load one toolbar

	// Note: use can use SetButtonImage to set the image for an item
	// that is a submenu by calling SetButtonImage((UINT)hSubmenu, iImage)
	void SetButtonImage(UINT nIDButton, int iImage);

	// should never need to call:
	virtual void Destroy(); // destroys everything--to re-load new toolbars?
	virtual void Refresh(); // called when system colors, etc change
	static  HBITMAP GetMFCDotBitmap();	// get..
	static  void    FixMFCDotBitmap();	// and fix MFC's dot bitmap

protected:
	friend class CCoolMenuWindow;

	CUIntArray		m_arToolbarID;	// array of toolbar IDs loaded
	CImageList		m_ilButtons;	// image list for all buttons
	CMapWordToPtr	m_mapIDtoImage;// maps command ID -> image list index
	CMapWordToPtr	m_mapIDtoAccel;// maps command ID -> ACCEL*
	HACCEL			m_hAccel;		// current accelerators, if any
	ACCEL*			m_pAccel;		// ..and table in memory
	CPtrList			m_menuList;		// list of HMENU's initialized
	CSize				m_szBitmap;		// size of button bitmap
	CSize				m_szButton;		// size of button (including shadow)
	CFont				m_fontMenu;		// menu font
	CMyItemData*	m_pItemData;	// list of item data's allocated

	// this function actually does the window proc dispatch--don't call
	LRESULT DoWindowProc(CSubclassWnd *pSubWnd, UINT msg, WPARAM wp, LPARAM lp);

	// internal helpers
	CMyItemData* GetNewItemData();
	void DeleteItemData(CMyItemData* pmd);
	BOOL IsMyItemData(CMyItemData* pmd);
	void DestroyAccel();
	virtual void DrawMenuText(CDC& dc, CRect rc, CString text, COLORREF color);
	virtual BOOL Draw3DCheckmark(CDC& dc, const CRect& rc, BOOL bSelected,
				HBITMAP hbmCheck=NULL);
	void LoadAccel(HACCEL hAccel);
	BOOL AppendAccelName(CString& sItemName, UINT nID, UINT iWhich);
	CFont* GetMenuFont();

	// called from OnInitPopup when menu is displayed--don't call!
	virtual void ConvertMenu(CMenu* pMenu, UINT nIndex, BOOL bSysMenu,
		BOOL bShowButtons);

	// Get button index for given command ID, or -1 if not found
	int GetButtonIndex(WORD nID) {
		void* val;
		return m_mapIDtoImage.Lookup(nID, val) ? (int)(LPARAM)val : -1;
	}

	// Get the ACCEL structure associated with a given command ID
	ACCEL* GetAccel(WORD nID) {
		void* val;
		return m_mapIDtoAccel.Lookup(nID, val) ? (ACCEL*)val : NULL;
	}

	// window proc to hook frame using CSubclassWnd implementation
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);

	// CSubclassWnd message handlers 
	virtual void OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	virtual BOOL OnMeasureItem(LPMEASUREITEMSTRUCT lpms);
	virtual BOOL OnDrawItem(LPDRAWITEMSTRUCT lpds);
	virtual LONG OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu);
	virtual void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
};

//////////////////
// Companion class to CCoolMenuManager adds cool menu support for child
// windows too. Add one of these for each child window class that has its own
// menus, including context menus. Call Install to hook up. See
// CoolEdit/view.cpp.
//
class DLLCLASS CCoolMenuWindow : public CSubclassWnd {
protected:
	CCoolMenuManager* m_pCoolMenuManager;
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
public:
	CCoolMenuWindow();
	virtual ~CCoolMenuWindow();
	BOOL Install(CWnd* pWnd, CCoolMenuManager* pcmm);
};

class CMenuBar;	 // fwd ref

//////////////////
// CMDIMenuMgr manages the icon and min/restore/close buttons in the menu for
// a maximized MDI window. It's designed to work with CMenuBar. Used
// internally. You shouldn't need to use this class.
//
class DLLCLASS CMDIMenuMgr { // used internally
public:
	CMDIMenuMgr();
	virtual ~CMDIMenuMgr();

	virtual void	CalcLayout();
	virtual void	DrawButton(CDC& dc, int i, BOOL bPressed);
	virtual int		HitTest(CPoint pt);
	virtual BOOL	OnMouseMsg(UINT msg, UINT nFlags, CPoint pt);
	virtual void	OnInitWindowMenu();
	virtual void	AdjustClientRect(CRect& rcClient);
	virtual CSize  AdjustSize(CSize sz, BOOL bHorz);
	virtual CPoint ComputeMenuTrackPoint(const CRect& rcButton, TPMPARAMS& tpm);

	enum	 { RCICON=0, RCMIN, RCRESTORE, RCCLOSE, RCMAX }; // which button

	CMenuBar* m_pMenuBar;				// the menu bar
	HMENU		 m_hmenuWindow;			// "Window" menu
	CRect		 m_rects[4];				// rects: icon, min, restore, close
	int		 m_iTracking;				// which button I'm tracking
	BOOL		 m_bDown;					// whether it's up or down
	BOOL		 m_bMDIMaximized;			// whether on or not
	int		 m_xMin;						// min x pos for min/restore/close buttons
};

//////////////////
// CMenuBar uses this private class to intercept messages on behalf of its
// owning frame as well as the MDI client window. Conceptually, these should
// be two different hooks, but I want to reuse code.
//
class CMenuBarFrameHook : public CSubclassWnd { // used internally
protected:
	friend class CMenuBar;
	CMenuBar* m_pMenuBar;
	CMenuBarFrameHook();
	~CMenuBarFrameHook();
	BOOL Install(CMenuBar* pMenuBar, HWND hWndToHook);
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
};

//////////////////
// CMenuBar implements Office 97-style menu bars. A Menu bar is a menu that
// works like a toolbar: you can move it around, and you can move other
// toolbars next to it, to conserve space on the screen. Use it the way you
// would a CToolBar:
//
// * Instantiate and create the menu bar in your CMainFrame/OnCreate or
//   CCoolBar/OnCreateBands.
//
//		m_wndMenuBar.Create(this)
//
// * Call LoadMenu to load a menu. This will set your frame's menu to NULL.
//   The menu bar replaces your normal window menu.
//
//		m_wndMenuBar.LoadMenu(IDR_MAINFRAME);
//		m_wndMenuBar.SetBarStyle(CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
//
// * Override your frame's PreTranslateMessage function to call
//   CMenuBar::TranslateFrameMessage. This is required to translate kbd
//   mnemonics.
//
//		BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
//		{
//			return m_wndMenuBar.TranslateFrameMessage(pMsg) ? TRUE :
//				CFrameWnd::PreTranslateMessage(pMsg);
//		}
//
// A CMenuBar can be docked or floating, but it can't be docked vertically.
//
class DLLCLASS CMenuBar : public CFlatToolBar {
public:
	BOOL	 m_bAutoRemoveFrameMenu;		 // set frame's menu to NULL
	CMenuBar();
	~CMenuBar();

	// You must call this from your frame's PreTranslateMessage fn
	virtual BOOL TranslateFrameMessage(MSG* pMsg);

	HMENU LoadMenu(HMENU hmenu, HMENU hmenuWindow); // load menu
	HMENU LoadMenu(LPCTSTR lpszMenuName);				// ...from resource file
	HMENU LoadMenu(UINT nID) {
		return LoadMenu(MAKEINTRESOURCE(nID));
	}
	HMENU GetMenu() { return m_hmenu; }					// get current menu

	enum TRACKINGSTATE { // menubar has three states:
		TRACK_NONE = 0,   // * normal, not tracking anything
		TRACK_BUTTON,     // * tracking buttons (F10/Alt mode)
		TRACK_POPUP       // * tracking popups
	};

	TRACKINGSTATE GetTrackingState(int& iPopup) {
		iPopup = m_iPopupTracking; return m_iTrackingState;
	}

protected:
	friend class CMenuBarFrameHook;
	friend class CMDIMenuMgr;

	enum {										  // menu bar-specific message:
		MB_SET_MENU_NULL = WM_USER + 1100, // set window menu to NULL
	};

	CMDIMenuMgr			m_mdiMenuMgr;		 // manages MDI min/restore/close butns
	CMenuBarFrameHook m_frameHook;		 // hooks frame window messages
	CMenuBarFrameHook m_mdiClientHook;	 // hooks MDI client messages
	HWND					m_hWndMDIClient;	 // if this is an MDI app
	CStringArray		m_arStrings;		 // array of menu strings
	HMENU					m_hmenu;				 // the menu

	// menu tracking stuff:
	int	 m_iPopupTracking;				 // which popup I'm tracking if any
	int	 m_iNewPopup;						 // next menu to track
	BOOL	 m_bProcessRightArrow;			 // process l/r arrow keys?
	BOOL	 m_bProcessLeftArrow;			 // ...
	BOOL	 m_bEscapeWasPressed;			 // user pressed escape to exit menu
	CPoint m_ptMouse;							 // mouse location when tracking popup
	HMENU	 m_hMenuTracking;					 // current popup I'm tracking

	TRACKINGSTATE m_iTrackingState;		 // current tracking state

	// helpers
	void  RecomputeToolbarSize();
	void	RecomputeMenuLayout();
	void	UpdateFont();
	int	GetNextOrPrevButton(int iButton, BOOL bPrev);
	void	SetTrackingState(TRACKINGSTATE iState, int iButton=-1);
	void	TrackPopup(int iButton);
	void	ToggleTrackButtonMode();
	void	CancelMenuAndTrackNewOne(int iButton);
	void	OnInitMenuPopup();
	void  OnMenuSelect(HMENU hmenu, UINT nItemID);
	void  CheckMinMaxState();

	BOOL	IsValidButton(int iButton) const
		{ return 0 <= iButton && iButton < GetButtonCount(); }

	virtual BOOL OnMenuInput(MSG& m);	 // handle popup menu input

	// overrides
	virtual CSize AdjustSize(CSize sz, BOOL bHorz);
	virtual void OnBarStyleChange(DWORD dwOldStyle, DWORD dwNewStyle);
	int HitTest(CPoint p) const;

	// command/message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNcCalcSize(BOOL bCalc, NCCALCSIZE_PARAMS* pncp);
	afx_msg void OnNcPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnUpdateMenuButton(CCmdUI* pCmdUI);
	afx_msg LRESULT OnSetMenuNull(WPARAM wp, LPARAM lp);

	static LRESULT CALLBACK MenuInputFilter(int code, WPARAM wp, LPARAM lp);
	
	DECLARE_DYNAMIC(CMenuBar)
	DECLARE_MESSAGE_MAP()

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//////////////////
// Implements menu tips for MFC main window. Menu tips are tooltips that
// appear next to the menu item when you hold the mouse over it. To use:
// instantiate in your CMainFrm, then call Install from your OnCreate handler.
//
//		// in CMainFrame::OnCreate
//		m_menuTipManager.Install(this);
//
// You also have to implement prompt strings for each menu item ID the normal
// MFC way: as resource strings with the same command ID. If you're using MFC,
// you should already have done this.
//
class DLLCLASS CMenuTipManager : public CSubclassWnd {
protected:
	CPopupText m_wndTip;		// home-grown "tooltip"
	BOOL m_bMouseSelect;		// whether menu invoked by mouse
	BOOL m_bSticky;			// after first tip appears, show rest immediately

public:
	int m_iDelay;				// tooltip delay: you can change

	CMenuTipManager() : m_iDelay(1000), m_bSticky(FALSE) { }
	~CMenuTipManager() { }

	// call this to install tips
	void Install(CWnd* pWnd) { HookWindow(pWnd); }

	// Useful helpers to get window/rect of current active menu
	static CWnd* GetRunningMenuWnd();
	static void  GetRunningMenuRect(CRect& rcMenu);
	CRect GetMenuTipRect(HMENU hmenu, UINT nID);

	// Useful helper to get the prompt string for a command ID.
	// Like CFrameWnd::GetMessageString, but you don't need a frame wnd.
	static CString GetResCommandPrompt(UINT nID);

	// Get the prompt for given command ID
	virtual CString OnGetCommandPrompt(UINT nID)
	{
		return GetResCommandPrompt(nID);
	}

	// hook fn to trap main window's messages
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);

	// Call these handlers from your main window
	void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hMenu);
	void OnEnterIdle(UINT nWhy, HWND hwndWho);
};

//////////////////
// Plug-in class to support locking toolbars. To use: instantiate one of
// these in your main frame and call Install.
//
//		// in CMainFrame::OnCreate
//		m_lock.Install(this);
//
// Then call m_lock.SetLocked(TRUE/FALSE) to lock/unlock the toolbars.
// CLockBar finds all the control bars that have a docking context, and when
// the lock is ON, it traps mouse messages sent to the control bars to
// disallow moving them.
//
class DLLCLASS CLockBars : public CSubclassWnd {
protected:

	// message trap for msgs sent to toolbar
	class CHook : public CSubclassWnd {
	public:
		BOOL Install(CLockBars* pLock, CControlBar* pBar);

	protected:
		CLockBars*		m_pLock;
		CControlBar*	m_pBar;
		virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
	};
	typedef list<CHook*> CHookList;

	CHookList m_hooklist;	// list of hooked toolbars
	CFrameWnd* m_pFrame;		// main frame window
	BOOL m_bLocked;			// whether locked or not
	void Clear();				// clear all hooks

public:
	CLockBars();
	~CLockBars();

	// Call this to install. You must call AFTER adding toolbars
	void Install(CFrameWnd* pFrame);

	// Get/set locked state
	BOOL GetLocked()
	{
		return m_bLocked;
	}
	void SetLocked(BOOL bLocked);
};	

//////////////////
// Class to route user-defined WM_SYSCOMMAND messages through the normal MFC
// command routing system, so you can handle them the normal MFC way with
// ON_COMMAND and ON_UPDATE_COMMAND_UI handlers. The simplest way to achieve
// this is to translate the system commands to ordinary WM_COMMAND messages.
// To use: instantiate in your CMainFrame and call Init from OnCreate.
//
//		// In CMainFrame::OnCreate: add system menu items, then Init
//		CMenu* pMenu = GetSystemMenu(FALSE);
//		ASSERT(pMenu);
//		pMenu->AppendMenu(MF_SEPARATOR); 
//		pMenu->AppendMenu(MF_STRING,(UINT_PTR)ID_APP_ABOUT, _T("&About ImgView..."));
//		m_sysCmdRouter.Init(this);
//
// Now if the user invokes ID_APP_ABOUT from your system menu, your handler
// will get it. Without CSysCmdRouter, you'd have to handle WM_SYSCOMMAND
// yourself since MFC doesn't route system commands through its
// command-routing mechanism.
//
class DLLCLASS CSysCmdRouter : public CSubclassWnd {
protected:
	CWnd* m_pMainWnd;	// main window hooked
public:
	CSysCmdRouter() { }
	virtual ~CSysCmdRouter() { }

	// Initialize: hook the main window
	BOOL Init(CWnd* pMainWnd) {
		ASSERT(pMainWnd);
		m_pMainWnd = pMainWnd;
		return HookWindow(pMainWnd);
	}

	// Terminate: unhook. No need to call unless you want to stop hooking for
	// some reason; CSubclassWnd will automatically unhook itself when the
	// hooked window is destroyed.
	void Term() {
		Unhook();
	}

protected:
	// virtual WndProc handler: convert WM_SYSCOMMAND to WM_COMMAND if the command is
	// not a system command: That is, if the command ID is less than SC_SIZE =
	// 0xFFFF.
	//
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
};

////////////////
// CFontUI manages the user interface to changing a font. Handy for Edit |
// Font... command and Font Bigger/Font Smaller buttons. For example, to run
// the Windows common font dialog:
//
//		CFontUI fui;
//		if (fui.ChangeFont(m_font,CFontUI::OP_DLG,this,/* flags */) {
//			// now m_font holds the new font
//		}
//
// The same function can be used to increase or decrease the a font size one
// step:
//
// 	CFontUI fui;
//		fui.ChangeFont(m_font,CFontUI::OP_BIGGER);
//
// See the source code for the bigger/smaller algorithm used.
//
// CFontUI also has handy functions to get/set the font point size (automatic
// conversion to logical pixels), and to save/restore a font in the user's
// profile (INI file or registry).
//
class DLLCLASS CFontUI {
protected:
	int		m_nFontPtSizeMin;	// min..
	int		m_nFontPtSizeMax;	// ..and max font size in points

	// Override this to change the algorithm for OP_BIGGER and OP_SMALLER.
	virtual int GrowFontSize(int ptSize, int dir);

public:
	CFontUI();
	virtual ~CFontUI();

	// op codes for ChangeFont
	enum { OP_DLG=0, OP_BIGGER, OP_SMALLER };

	// Common function to change font size. Opcode tells what to do: display
	// font dialog, or make font bigger or smaller.
	BOOL ChangeFont(CFont& font, int op, CWnd* pWnd=NULL, DWORD dwFlags=0);

	// Set min/max font sizes for OP_BIGGER and OP_SMALLER
	void SetMinMaxFontSize(int nMin, int nMax) {
		m_nFontPtSizeMin = nMin;
		m_nFontPtSizeMax = nMax;
	}

	// Handy conversion functions.
	int  GetFontPointSize(CFont& font, CDC& dc);
	BOOL SetFontPointSize(CFont& font, CDC& dc, int pts);

	// Functions to save/restore font in profile (registry settings or .ini)
	BOOL WriteProfileFont(LPCTSTR lpszKey, LPCTSTR lpszVal, CFont& font,
		CDC* pDC=NULL);
	BOOL GetProfileFont(LPCTSTR lpszKey, LPCTSTR lpszVal, CFont& font,
		CDC* pDC=NULL);
};

//////////////////////////////////////////////////////////////////
// CSplash implements a splash screen in a separate thread. To use it, write:
//
//		static CSplash *MySplash = new CSplash(
//			IDB_MYBITMAP,			// bitmap resource ID (can be JPG, GIF, etc.)
//			duration,				// time to display, in msec
//			flags,					// see below
//			&MySplash);				// address of pointer (back pointer to self)
//
// To kill the splash, you can call
//
//		CSplash::Kill(pSplash);
//
// --but this is usually unecessary. You don't have to call delete either,
// since CSplash deletes itself when the splash times out or you kill it. When
// it does, it sets your pointer to NULL so you won't try to call Kill on a
// bad pointer.
//
// NOTE: the back pointer (MySplash) MUST be a static variable or class data
// member, not a local variable that can go out of scope, since CSplash will
// set it to NULL when the splash dies.
//
class DLLCLASS CSplash : public CWinThread {
public:
	CSplash(UINT nIDRes,				// resource ID of bitmap
		UINT duration,					// how long to show (minimum)
		WORD flags=0,					// see below
		CSplash** ppBackPtr=NULL);	// pointer to NULL when destroyed
	~CSplash();

	enum { // flags
		KillOnClick = 0x0001,		// any key/mouse dismisses splash
		IgnoreCmdLine = 0x0002,		// need I say more?
		NoWaitForMainWnd = 0x0004,	// don't wait for main window to expire
	};

	// override to create a different kind of splash window
	virtual CWnd* OnCreateSplashWnd(UINT nIDRes, UINT duration, WORD flags);
	static void Kill(CSplash* pSplash);

protected:
	CSplash**	m_ppBackPtr;		// caller's back pointer to me
	UINT			m_nIDRes;			// bitmap resource ID
	UINT			m_duration;			// how long to display
	WORD			m_flags;				// CSplashWnd creation flags

	virtual BOOL InitInstance();
	DECLARE_DYNAMIC(CSplash)
};

//////////////////
// Private class to implement the actual splash window that CSplash creates.
// Don't use it unless you're doing some hairy stuff to override the splash
// window, like create animated effects, etc.
// 
class DLLCLASS CSplashWnd : public CWnd { // used internally
public:
	// these are public so you can change easily
	static DWORD g_dwStyleDefaultEx;
	static DWORD g_dwStyleDefault;
protected:
	friend CSplash;
	CSplashWnd(CSplash* pThread);
	~CSplashWnd();

	CSplash* m_pSplash;		// ptr to splash thread
	CPicture	m_pict;			// image

	UINT		m_duration;		// duration (msec)
	WORD		m_flags;			// see below

	// override to do weird stuff
	virtual BOOL Create(UINT nIDRes, UINT duration, WORD flags);

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void PostNcDestroy();

	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CSplashWnd)
};

////////////////
// CTrayIcon manages an icon in the Windows system tray. To use, instantiate
// in your CMainFrame class. For example:
//
//
//		class CMainFrame : public CFrameWnd {
//		protected:
//			CTrayIcon m_trayIcon;		// my tray icon
//			...
//		}
//
// You must initialize the CTrayIcon with a resource ID like so:
//
//		CMainFrame::CMainFrame() : m_trayIcon(IDR_TRAYICON)
//		{
//			...
//		}
//
// The resource ID identifies the context menu CTrayIcon uses when the user
// right-clicks on your tray icon. Once you initialize the tray icon, you must
// call SetIcon to specify which the icon is displayed:
//
//		m_trayIcon.SetIcon(IDI_MYICON);
//
// IDI_MYICON is the resource ID of an ICON resource. CTrayTest also looks
// for a string resource with the same ID to use as the tray icon tooltip. If
// you want to receive notifications when the user clicks the tray icon, you
// can call SetNotificationWnd with a callback message ID.
//
//		m_trayIcon.SetNotificationWnd(this, WM_MY_TRAY_NOTIFICATION);
//
// Now Windows will send your window a WM_MY_TRAY_NOTIFICATION message when
// something happens. The notifications are as described in the Windows
// documentation for NOTIFTYICONDATA. WPARAM is the tray icon id (Eg,
// IDR_TRAYICON) and LPARAM is a mouse, keyboard or balloon tip message. You
// can call ShowBalloonTip to show a balloon tip; See TrayTest for details.
//
// CTrayIcon automatically handles WM_TASKBARCREATED to recreate your tray
// icon if Windows restarts Explorer.
// 
class DLLCLASS CTrayIcon : public CCmdTarget {
public:
	CTrayIcon(UINT uID);
	~CTrayIcon();

	// Call this to receive tray notifications
	void SetNotificationWnd(CWnd* pNotifyWnd, UINT uCbMsg);

	// SetIcon functions. To remove icon, call SetIcon(0)
	//
	BOOL SetIcon(UINT uID); // main variant you want to use
	BOOL SetIcon(HICON hicon, LPCTSTR lpTip);
	BOOL SetIcon(LPCTSTR lpResName, LPCTSTR lpTip)
		{ return SetIcon(lpResName ? 
			AfxGetApp()->LoadIcon(lpResName) : NULL, lpTip); }

	BOOL SetVersion(UINT uVersion);
	BOOL ShowBalloonTip(LPCTSTR szMsg, LPCTSTR szTitle,
		UINT uTimeout, DWORD dwInfoFlags=NIIF_INFO);

	BOOL SetStandardIcon(LPCTSTR lpszIconName, LPCTSTR lpTip)
		{ return SetIcon(::LoadIcon(NULL, lpszIconName), lpTip); }

	virtual LRESULT OnTrayNotify(WPARAM uID, LPARAM lEvent);
	virtual LRESULT OnTaskBarCreate(WPARAM wp, LPARAM lp);

protected:
	NOTIFYICONDATA m_nid;		  // struct for Shell_NotifyIcon args

	// private class used to hook tray notification and taskbar created
	class CTrayHook : public CSubclassWnd {
	private:
		CTrayIcon* m_pTrayIcon;
		virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
		friend CTrayIcon;
	};
	friend CTrayHook;
	CTrayHook m_notifyHook; // trap tray notifications
	CTrayHook m_parentHook; // trap taskbar created message
	DECLARE_DYNAMIC(CTrayIcon)
};

//////////////////
// This struct defines one entry in the command map that maps text strings to
// command IDs for HTML controls. Don't use it directly; instead, use the
// macros provided to create your command map:
//
//		BEGIN_HTML_COMMAND_MAP(MyHtmlCmds)
//			HTML_COMMAND(_T("about"), ID_APP_ABOUT)
//			HTML_COMMAND(_T("exit"),  ID_APP_EXIT)
//		END_HTML_COMMAND_MAP()
//
// Call CHtmlCtrl::SetCmdMap to use the map, usually just after you create the
// HTML control in your main frame's OnCreate handler.
//
//		// in CMainFrame::OnCreate
//		m_wndView.SetCmdMap(MyHtmlCmds, this);
//
// Now to invoke the About command from HTML in your CHtmlCtrl, you can add
// an HTML link using the "app" pseudo-protocol like so:
//
//		...<A HREF="app:about">About</A>....
//
// Clicking the link will be the same as sending the ID_APP_ABOUT command to
// whatever window you specified in SetCmdMap--in this case, the main frame.
// In general, you can use HREF="app:cmdname" where cmdname is any string
// appearing in your command map. See MultiWin for an example.
//
struct HTMLCMDMAP {
	LPCTSTR name;		// command name used in "app:name" HREF in <A
	UINT nID;
};

// macros for creating HTML command maps
#define BEGIN_HTML_COMMAND_MAP(name) HTMLCMDMAP name[] = {
#define HTML_COMMAND(cmd, id)		{ cmd, id },
#define END_HTML_COMMAND_MAP()	{ NULL, 0 } };

//////////////////
// CHtmlCtrl makes CHtmlView usable as a child window without doc/frame. Use
// it to display HTML in any child window--for example, inside a dialog. Call
// CreateFromStatic to create a CHtmlCtrl control in the same location as a
// static control in your dialog. For example:
//
//		BOOL CAboutDialog::OnInitDialog()
//		{
//			VERIFY(CDialog::OnInitDialog());
//			VERIFY(m_wndHtml.CreateFromStatic(IDC_HTMLVIEW, this));
//			m_wndHtml.LoadFromResource(_T("about.htm"));
//			m_wndHtml.SetCmdMap(MyHtmlCmds);
//			return TRUE;
//		}
//
// Here IDC_HTMLVIEW is the control ID of a static text control and
// "about.htm" is an HTML resource embedded in the resource file like so:
//
//			// in .rc file:
//			ABOUT.HTM HTML DISCARDABLE "res\\about.htm"
//
// If your HTML file has <IMG> tags, the images must also appear as HTML
// resources:
//
//			// in .rc file:
//			PD.JPG    HTML DISCARDABLE "res\\pd.jpg"
//			OKUP.GIF  HTML DISCARDABLE "res\\okup.gif"
//
// You can invoke commands from your HTML page by creating a command map and
// adding an A element with the special pseudo-protocol "app:". See the
// description for HTMLCMDMAP.
//
class DLLCLASS CHtmlCtrl : public CHtmlView {
public:
	CHtmlCtrl() : m_bHideMenu(FALSE), m_cmdmap(NULL) { }
	~CHtmlCtrl() { }

	// Get/set HideContextMenu property
	BOOL GetHideContextMenu()			 { return m_bHideMenu; }
	void SetHideContextMenu(BOOL val) { m_bHideMenu=val; }

	// Set doc contents from string.
	HRESULT SetHTML(LPCTSTR strHTML);

	// Set command map.
	void SetCmdMap(HTMLCMDMAP* val, CWnd* pWndCmd = NULL)
	{
		m_cmdmap = val;
		m_pWndCmd = pWndCmd ? pWndCmd : GetParent();
	}

	// Create control in same place as static control.
	BOOL CreateFromStatic(UINT nID, CWnd* pParent);

	// craete control from scratch
	BOOL Create(const RECT& rc, CWnd* pParent, UINT nID,
		DWORD dwStyle = WS_CHILD|WS_VISIBLE, CCreateContext* pContext = NULL)
	{
		return CHtmlView::Create(NULL, NULL, dwStyle, rc, pParent, nID, pContext);
	}

protected:
	HTMLCMDMAP* m_cmdmap;	// command map
	CWnd* m_pWndCmd;			// window to receive commands
	BOOL	m_bHideMenu;		// hide context menu

	// helpers
	UINT GetAppCommandID(LPCTSTR lpszCmd);

	// Override this to handle "app:" commands. Only if you don't use a command map.
	virtual void OnAppCmd(LPCTSTR lpszCmd);

	// virtual overrides

	// Override to trap "app:" pseudo protocol:
	void OnStatusTextChange(LPCTSTR lpszText);
	virtual void OnBeforeNavigate2( LPCTSTR lpszURL,
		DWORD nFlags,
		LPCTSTR lpszTargetFrameName,
		CByteArray& baPostedData,
		LPCTSTR lpszHeaders,
		BOOL* pbCancel );

	// Override to intercept child window messages to disable context menu.
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Normally, CHtmlView destroys itself in PostNcDestroy, but we don't want
	// to do that for a control since a control is usually implemented as a
	// member of another window object.
	//
	virtual void PostNcDestroy() {  }

	// Overrides to bypass MFC doc/view frame dependencies. These are
	// the only places CHtmView depends on livining inside a frame.
	afx_msg void OnDestroy();
	afx_msg int  OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT msg);
	afx_msg void OnSetFocus(CWnd* pOldWnd);

	DECLARE_MESSAGE_MAP();
	DECLARE_DYNAMIC(CHtmlCtrl)
};

//////////////////
// Helper class to build a dialog template in memory. Only supports what's
// needed for CStringDialog.
//
class DLLCLASS CDlgTemplateBuilder {	 // used internally
protected:
	WORD* m_pBuffer;							 // internal buffer holds dialog template
	WORD* m_pNext;								 // next WORD to copy stuff
	WORD* m_pEndBuf;							 // end of buffer

	// align ptr to nearest DWORD
	WORD* AlignDWORD(WORD* ptr) {
		ptr++;									 // round up to nearest DWORD
		LPARAM lp = (LPARAM)ptr;			 // convert to long
		lp &= 0xFFFFFFFC;						 // make sure on DWORD boundary
		return (WORD*)lp;
	}

	void AddItemTemplate(WORD wType, DWORD dwStyle, const CRect& rc,
		WORD nID, DWORD dwStyleEx);

public:
	// Windows predefined atom names
	enum { BUTTON=0x0080, EDIT, STATIC, LISTBOX, SCROLLBAR, COMBOBOX };

	CDlgTemplateBuilder(UINT nBufLen=1024);
	~CDlgTemplateBuilder();

	DLGTEMPLATE* GetTemplate() { return (DLGTEMPLATE*)m_pBuffer; }

	// functions to build the template
	DLGTEMPLATE* Begin(DWORD dwStyle, const CRect& rc, LPCTSTR caption, DWORD dwStyleEx=0);
	WORD* AddText(WORD* buf, LPCTSTR text);
	void AddItem(WORD wType, DWORD dwStyle, const CRect& rc,
		LPCTSTR text, WORD nID=-1, DWORD dwStyleEx=0);
	void AddItem(WORD wType, DWORD dwStyle, const CRect& rc,
		WORD nResID, WORD nID=-1, DWORD dwStyleEx=0);
};

//////////////////
// Class to implement a simple string input dialog. Kind of like MessageBox
// but it accepts a single string input from user. You provide the prompt. To
// use:
//
//		CStringDialog dlg;						// string dialog
//		dlg.m_bRequired = m_bRequired;		// if string is required
//		dlg.Create(_T("Title"), _T("Enter a string:"), this, IDI_QUESTION);
//		dlg.DoModal();								// run dialog
//		CString result = dlg.m_str;			// whatever the user typed
//
class DLLCLASS CStringDialog : public CDialog {
public:
	CString	m_str;							 // the string returned [in,out]
	BOOL		m_bRequired;					 // string required?
	HICON		m_hIcon;							 // icon if not supplied

	CStringDialog() { }
	~CStringDialog() { }

	// Call this to create the template with given caption and prompt.
	BOOL Create(LPCTSTR caption, LPCTSTR prompt, CWnd* pParent=NULL,
		UINT nIDIcon=LOWORD(IDI_QUESTION));

protected:
	CDlgTemplateBuilder m_dtb;				 // place to build/hold the dialog template
	enum { IDICON=1, IDEDIT };				 // control IDs

	// MFC virtual overrides
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void DoDataExchange(CDataExchange* pDX)
	{
		DDX_Text(pDX, IDEDIT, m_str);
	}
};

//////////////////
// Generic listbox tip handler to display tip for list box items too wide for
// list box. To use: instantiate one of these for each list box and call Init.
//
//		// in your dialog's OnInitDialog
//		m_lbTipHandler.Init(&m_wndListBox);
//
class DLLCLASS CListBoxTipHandler : public CSubclassWnd {
protected:
	static CPopupText g_wndTip;			 // THE tip window
	UINT	m_nCurItem;							 // index of current item
	BOOL	m_bCapture;							 // whether mouse is captured

	void Cancel();								 // helper: cancel tip

	// subclass window proc
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);

	// virtual fns you can override
	virtual void OnMouseMove(CPoint p);
	virtual BOOL IsRectCompletelyVisible(const CRect& rc);
	virtual UINT OnGetItemInfo(CPoint p, CRect& rc, CString& s);

public:
	CListBoxTipHandler();
	~CListBoxTipHandler();
	static UINT g_nTipTimeMsec;			 // global: msec wait before showing tip
	void Init(CWnd* pListBox);				 // initialize
};
