////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#include <PLStatLink.h>
#include <gdiplus.h>
using namespace Gdiplus;

// tell linker to look in gdiplus
#pragma comment(linker, "/defaultlib:gdiplus.lib")

//////////////////
// Picture object wraps GDI+ Image class. Use it to display GIF, JPG, BMP, TIF
// and other kinds of images. To display the image, call Render with your
// device context (pDC). For example:
//
//		CPicture pic;
//		pic.Load("pixie.jpg");
//		pic.Render(pDC);
//
// If you want a window that displays an image, use CPictureCtrl. Make sure
// you don't forget to initialize GDI+ !
//
class DLLCLASS CPicture {
public:
	CPicture();
	~CPicture();
	
	static BOOL IsURL(LPCTSTR pszPathName) {
		return _tcsncicmp(pszPathName, _T("http://"), 7)==0;
	}

	void DestroyPicture();

	// Load from various places
	BOOL Load(LPCTSTR pszPathName);
	BOOL Load(UINT nIDRes);
	BOOL Load(IStream* pstm);
	BOOL LoadURL(LPCTSTR url);

	// render to device context
	BOOL Render(CDC* pDC, CRect rc=CRect(0,0,0,0)) const;

	CSize GetImageSize(CDC* pDC=NULL) const;

	operator BOOL() {
		return m_pImage!=NULL;
	}

	Image* GetImage() {
		return m_pImage;
	}

	ImageType GetType() const {
		ASSERT(m_pImage);
		return m_pImage->GetType();
	}

	UINT GetFlags() const {
		ASSERT(m_pImage);
		return m_pImage->GetFlags();
	}

	Status GetRawFormat(GUID& guid) const {
		ASSERT(m_pImage);
		return m_pImage->GetRawFormat(&guid);
	}

	Status GetBounds(RectF &rc, Unit& unit) const {
		ASSERT(m_pImage);
		return m_pImage->GetBounds(&rc, &unit);
	}

	PixelFormat GetPixelFormat() const {
		ASSERT(m_pImage);
		return m_pImage->GetPixelFormat();
	}

	SizeF GetResolution() {
		ASSERT(m_pImage);
		return SizeF(GetHorizontalResolution(), GetVerticalResolution());
	}

	REAL GetHorizontalResolution() const {
		ASSERT(m_pImage);
		return m_pImage->GetHorizontalResolution();
	}

	REAL GetVerticalResolution() const {
		ASSERT(m_pImage);
		return m_pImage->GetVerticalResolution();
	}

	UINT GetAllPropertyItems(PropertyItem*& props);

	void Rotate(RotateFlipType rft);

	CString GetFormatName() const;

protected:
	BOOL m_bUseEmbeddedColorManagement;	 // set this before loading
	Image* m_pImage;							 // GDI+ Image object
	HGLOBAL m_hMem;							 // used for resource image
	PropertyItem* m_props;					 // properties, if requested
	UINT m_nProp;								 // num properties, if requested
	BOOL LoadFromMem(HGLOBAL hMem);		 // helper: load from global memory
};

//////////////////
// Implements a picture control based on CPicture. A picture control is a
// child window you can use in a frame, view, dialog or any other kind of
// window to display an image. CPictureCtrl is like a static bitmap, only it
// can display any of the image formats supported by CPicture/GDI+ such as
// JPG, GIF, TIF and so on. 
//
class DLLCLASS CPictureCtrl : public CStaticLink {
public:
	CPictureCtrl(BOOL bAutoLoadImage=TRUE);
	~CPictureCtrl();

	// brainless wrappers call CPicture
	BOOL LoadImage(LPCTSTR pszPathName) {
		Invalidate();
		return m_pict.Load(pszPathName);
	}

	BOOL LoadImage(UINT nID) {
		Invalidate();
		return m_pict.Load(nID);
	}

	BOOL LoadImage(IStream* pstm) {
		Invalidate();
		return m_pict.Load(pstm);
	}

	CSize GetImageSize() {
		return m_pict.GetImageSize();
	}

	const CPicture* GetPicture() {
		return &m_pict;
	}

protected:
	CPicture m_pict;			// picture
	BOOL m_bAutoLoadImage;	// automatically load image w/same Ctrl ID

	virtual void PreSubclassWindow();

	// message handlers
	afx_msg void OnPaint();
	afx_msg int  OnCreate(LPCREATESTRUCT lpcs);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	DECLARE_DYNAMIC(CPictureCtrl)
	DECLARE_MESSAGE_MAP()
};

//////////////////
// The caption painter (CCaptionPainter) will call your window proc with a
// pointer to this structure as LPARAM if you specify a callback message. Use
// it to do custom painting.
//
struct PAINTCAP {
	CSize	m_szCaption;	// size of caption rectangle
	CDC*	m_pDC;			// DC to draw in
};

//////////////////
// Generic caption painter. Handles WM_NCPAINT, WM_NCACTIVATE, etc. to draw
// custom captions. To use:
//
// * Call Install from your frame's OnCreate function. You must specify a
//   callback message to send when it's time to paint.
//
//		// Install caption painter
//		m_captionPainter.Install(this, WM_PAINTMYCAPTION);
//
// * Handle the callback message: Respond by painting your caption.
//
//   nMsg   = your callback message specified in Install;
//   wParam = whether caption is active (TRUE) or not (FALSE);
//   lParam = ptr to PAINTCAP struct above, or NULL if Windows sent
//            WM_SETTINGSCHANGE: you should update your colors, fonts, etc.
//
// - The PAINTCAP struct contains a memory DC the size of the caption bar.
//	  CCaptionPainter maintains a bitmap for the caption to do flicker-free
//   drawing. All you have to do is paint into the supplied DC when you get
//   the callback message.
//
// * In your handler, you MUST call DrawIcon and DrawButtons to draw the
//   caption icon and buttons, or else they will not appear. If you are drawing
//   custom caption buttons as well, you must handle WM_NCLBUTTONDOWN & co.
//   yourself. CCaptionPainter does not handle the mouse for custom caption
//   buttons. DrawIcon/DrawButtons both return the width of the area painted.
//
class DLLCLASS CCaptionPainter : private CSubclassWnd {
public:
	DECLARE_DYNAMIC(CCaptionPainter);
	CCaptionPainter();
	virtual ~CCaptionPainter();

	BOOL Install(CFrameWnd* pFrameWnd, UINT nPaintMsg);
	int  DrawIcon(const PAINTCAP& pc);
	int  DrawButtons(const PAINTCAP& pc);
	void Invalidate() { m_szCaption=CSize(0,0); }

protected:
	CBitmap	m_bmCaption[2];	// bitmaps for active/inactive captions 
	CSize		m_szCaption;		// size of caption rectangle
	BOOL		m_bActive;			// active/inactive state
	UINT		m_nPaintMsg;		// callback message to paint caption

	// Helper
	void PaintCaption();

	// These are similar to, but NOT the same as the equivalent CWnd fns. Don't
	// override unless you're a guru, and even THEN I wouldn't recommend it.
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);	
	virtual void OnNcPaint(HRGN hUpdateRgn);
	virtual BOOL OnNcActivate(BOOL bActive);
	virtual void OnSetText(LPCTSTR lpText);
};

////////////////////////////////////////////////////////////////
// This is the magic ROP code used to generate the embossed look for
// a disabled button. It's listed in Appendix F of the Win32 Programmer's
// Reference as PSDPxax (!) which is a cryptic reverse-polish notation for
//
// ((Destination XOR Pattern) AND Source) XOR Pattern
//
// which I leave to you to figure out. In the case where I apply it,
// Source is a monochrome bitmap which I want to draw in such a way that
// the black pixels get transformed to the brush color and the white pixels
// draw transparently--i.e. leave the Destination alone.
//
// black ==> Pattern (brush)
// white ==> Destination (ie, transparent)
//
// 0xb8074a is the ROP code that does this. For more info, see Charles
// Petzold, _Programming Windows_, 2nd Edition, p 622-624.
//
#define TRANSPARENTROP 0xb8074a

class CImageList; // fwd ref

// Paint a rectangle a given color.
extern DLLFUNC void PLFillRect(CDC& dc, const CRect& rc, COLORREF color);

// Fill rectangle with 3D light color.
extern DLLFUNC void PLFillRect3DLight(CDC& dc, const CRect& rc);

// Draw image list item with embossed look. 
extern DLLFUNC void PLDrawEmbossed(CDC& dc, CImageList& il, int i, CPoint p, BOOL bColor=FALSE);

// Load bitmap from resource name, converting grays to system colors.
extern DLLFUNC HBITMAP PLLoadSysColorBitmap(LPCTSTR lpResName, BOOL bMono=FALSE);

// Load bitmap from resource ID, converting grays to system colors.
inline HBITMAP PLLoadSysColorBitmap(UINT nResID, BOOL bMono=FALSE)
{	return PLLoadSysColorBitmap(MAKEINTRESOURCE(nResID), bMono); }

//////////////////
// Generic palette message handler makes handling/realizing palettes easy.
// Handles WM_PALETTECHANGED, WM_QUERYNEWPALETTE, WM_SETFOCUS. Note that this
// class is more or less obsolete now since hardly anyone has monitors
// incapable of 16-bit color. To use:
//
// * Instantiate a CPalMsgHandler in your main frame and every CWnd class that
//   needs to realize palettes (e.g., your view).
//
// * Call Install to install.
//
// * Call DoRealizePalette(TRUE) from your view's OnInitialUpdate fn.
//
class DLLCLASS CPalMsgHandler : protected CSubclassWnd {
public:
	DECLARE_DYNAMIC(CPalMsgHandler);
	CPalMsgHandler();
	~CPalMsgHandler();

	// Get/Set palette obj
	CPalette* GetPalette()				{ return m_pPalette; }
	void SetPalette(CPalette* pPal)	{ m_pPalette = pPal; }

	// Call this to install the palette handler
	BOOL Install(CWnd* pWnd, CPalette* pPal) {
		m_pPalette = pPal;
		return HookWindow(pWnd);
	}
	BOOL IsHooked() { return CSubclassWnd::IsHooked(); }

	// Call this from your OnInitialUpdate functions.
	// Override if you realize your palette some other way
	// (ie, not by having a ptr to a CPalette you pass to SetPalette).
	//
	virtual int  DoRealizePalette(BOOL bForeground);

protected:
	CPalette* m_pPalette; // ptr to palette

	// These are similar to, but NOT the same as the equivalent CWnd fns.
	// Rarely, if ever need to override.
	//
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);	
	virtual void	 OnPaletteChanged(CWnd* pFocusWnd);
	virtual BOOL	 OnQueryNewPalette();
	virtual void	 OnSetFocus(CWnd* pOldWnd);
};
