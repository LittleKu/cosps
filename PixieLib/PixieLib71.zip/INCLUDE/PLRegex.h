////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#pragma warning(push)
#pragma warning(disable : 4018)
#pragma warning(disable : 4389)
#include <atlrx.h>
#pragma warning(pop)
#include <vector>				// STL vector
using namespace std;

//////////////////
// CRegex encapsulates CAtlRegExp<> to make ATL regular expressions a little
// more usable. CRegex hides CAtlRegExp and CAtlREMatchContext and also
// implements useful functions like Replace and Split. Assumes you are using
// default CAtlRECharTraits (ie, TCHARs). See the RegexTest sample program.
//
class DLLCLASS CRegex : public CAtlRegExp<> {
protected:
 	CString m_re;					// the regular expression
	BOOL m_bCaseSensitive;		// case sensitive?
	CAtlREMatchContext<> m_mc; // internal ATL match context
	LPCTSTR m_szIn;				// original input string
	LPCTSTR m_szNext;				// next character to search

	// helper to extract string from ATL MatchGroup
	CString GetMGString(const CAtlREMatchContext<>::MatchGroup& mg) const
	{
		CString match = mg.szStart;
		return match.Left((int)(mg.szEnd-mg.szStart));
	}

public:
	REParseError m_err;			// current ATL parse error, if any

	// helper functions to get error name from error code
	static LPCTSTR GetErrorName(REParseError err);

	// default constructor
	CRegex() : m_err(REPARSE_ERROR_OK) { }

	// construct from RE and case-sensitive flag
	CRegex(LPCTSTR szRE, BOOL bCaseSensitive=TRUE)
	{
		m_err = Parse(szRE, bCaseSensitive);
	}

	// copy ctor
	CRegex(const CRegex& r)
	{
		*this = r; // do assignment to parse
	}

	~CRegex() { }

	// assignment: only copy regex and case flag, not dynamic state!
	// Reparse expression.
	const CRegex& operator= (const CRegex& r)
	{
		m_re = r.m_re;
		m_bCaseSensitive = r.m_bCaseSensitive;
		if (!m_re.IsEmpty())
			m_err = Parse(m_re, m_bCaseSensitive);
		return *this;
	}

	// convert to string: return RE
	operator LPCTSTR() const { return m_re; }

	// Parse RE: reset internal state and return error code.
	REParseError Parse(LPCTSTR szRE, BOOL bCaseSensitive=TRUE)
	{
		m_re = szRE;
		m_szIn = m_szNext = NULL;
		return CAtlRegExp<>::Parse(szRE, bCaseSensitive);
	}

	// Set input string. Use this with NextMatch to find all matches.
	void SetInput(LPCTSTR szIn) 
	{
		m_szIn = m_szNext = szIn;
	}

	// Find a single match in input string.
	// Optional 2nd arg returns pointer to next input char to search after
	// match. Used internally to find successive matches.
	BOOL Match(LPCTSTR szIn, LPCTSTR* ppszEnd=NULL)
	{
		if (szIn==NULL || *szIn==0)
			return FALSE;
		SetInput(szIn);
		return CAtlRegExp<>::Match(szIn, &m_mc, ppszEnd);
	}

	// Find next match after calling SetInput
	BOOL NextMatch()
	{
		return CAtlRegExp<>::Match(m_szNext, &m_mc, &m_szNext);
	}

	// Get current match; optional arg returns offset in input string.
	CString GetMatch(int* pOffset=NULL) const
	{
		if (pOffset)
			*pOffset = (int)(m_mc.m_Match.szStart - m_szIn);
		return GetMGString(m_mc.m_Match);
	}

	// Get number of groups. In ATL syntax, groups are marked with {}.
	UINT GetNumGroups() const
	{
		return m_mc.m_uNumGroups;
	}

	// Get nth match group. Optional arg returns offset into input string.
	CString GetGroup(int nIndex, int* pOffset=NULL) const
	{
		CAtlREMatchContext<>::MatchGroup mg;
		const_cast<CRegex*>(this)->m_mc.GetMatch(nIndex, &mg);
		if (pOffset)
			*pOffset = (int)(mg.szStart - m_szIn);			
		return GetMGString(mg);
	}

	// replace callback for dyanmic Replace
	typedef CString (CALLBACK* REREPLACEPROC)(const CRegex& re,
		const CString& match, void* param);

	// Global replace. This is not implemented by ATL, but easy to do. Does
	// not support $1 $2 variables (replace with subgroup match).
	CString Replace(LPCTSTR szIn, LPCTSTR val, BOOL bAll=TRUE);
	static CString Replace(LPCTSTR szIn, LPCTSTR regex, LPCTSTR val, BOOL bAll=TRUE,
		BOOL bIgnoreCase=FALSE);

	CString Replace(LPCTSTR szIn, REREPLACEPROC replfn, void* param);
	static CString Replace(LPCTSTR szIn, LPCTSTR regex, REREPLACEPROC replfn,
		void* param, BOOL bIgnoreCase=FALSE);

	// Split function implements Perl-style split. Splits input string into
	// array (STL vector) of CStrings serparated by regex. For example, if you
	// call Split("one,two, three",",\b*"), you'll get an array of three
	// strings: ["one","two","three"]. Optional arg says maximum number to
	// split.
	vector<CString> Split(LPCTSTR szIn, int nMax=0);
	static vector<CString> Split(LPCTSTR szIn, LPCTSTR szSep, BOOL bCaseSensitive=TRUE,
		int nMax=0);
};

//////////////////
// CRegexForm, used to do regex-based form validation.
//


//
// This internal structure is used to create the field map that describes your
// form. Each RGXFIELD entry specifies an edit control ID and optional
// parameters. You don't need to use RGXFIELD directly; use the macros below
// to build your regex form map. See the form validation example in RegexTest.
//
// Each field ID is expected to have a corresponding resource string with the
// format:
//
// "FieldName\nRegex\nLegalChars\nHint\nErrorMsg"
//
//		FieldName	= name of field, required
//		Regex			= regular expression used to validate input, optional
//		LegalChars	= regex describing legal chars to type (eg "[\d.-]" numbers)
//		Hint			= format hint, eg "#####-####" for zip code
//		ErrorMsg		= error message if input doesn't match. Defaults to "Should
//						  be [Hint]" if there's a hint, where "Should be" is another
//						  resource substring for the whole form--see description of
//						  Init method and TestForm.rc for examples.
//
struct RGXFIELD {
	UINT	id;						// field/control ID
	DWORD	flags;					// see below
	BOOL	bIgnoreCase;			// ignore case?
};
typedef const RGXFIELD* RGXFIELDMAP;	 // note map is const

// flags
enum RGXF_FLAGS {
	RGXF_NONE = 0,
	RGXF_REQUIRED = 0x0001,		// field is required
	RGXF_NOTRIM   = 0x0002,		// by default, validator trims lead/trailing whitespace
	RGXF_IMMED    = 0x0004,		// validate immediately (on EN_KILLFOCUS)
	RGXF_CALLBACK = 0x0008,		// custom validation: call app to validate
};

// Use these macros to define your form validation map.
#define BEGIN_REGEX_FORM(symbol) static RGXFIELD symbol[] = {
#define RGXFIELD(id,flags,case)	{id,flags,case},
#define END_REGEX_FORM()			{0,0,0} };

// per-field error codes
enum RGXERROR {
	RGXERR_OK = 0,			// field OK
	RGXERR_MISSING,		// required field is missing
	RGXERR_NOMATCH,		// field value doesn't match regular expression
};

// Callback notification codes. Currently there's only one.
enum {
	RGXNM_VALIDATEFIELD=1,	// call app to validate
};

//////////////////
// Exception thrown if field not found
//
class CRgxFieldNotFoundException : public CException
{
public:
	UINT m_nID;	// ID of field
	CRgxFieldNotFoundException(UINT nID) : CException(FALSE), m_nID(nID) { }
	virtual ~CRgxFieldNotFoundException() {	}
};

//////////////////
// Regex Form Manager. Provides DDX support and regex-based
// validation for MFC dialogs.
//
//		-Validates dialog input using regular expressions.
//		-Can display field hints
//		-Can validate fields immediately (not recommended)
//		-Can enforce legal characters in edit controls
//		-Can do min/max validation using pseudo-regex expressions.
//
// For example of how to use, see the form validation dialog in the RegexTest
// sample program.
//
class DLLCLASS CRegexForm : protected CSubclassWnd {
protected:
	CDialog*		m_pDlg;				// ptr to dialog
	CString		m_sError;			// " Error"
	CString		m_sRequired;		// "required"
	CString		m_sFldErrPfx;		// prefix to combine w/hints for fld error msg
	CString		m_sDfltErrMsg;		// default error message if not field error msg
	CPopupText	m_wndHint;			// tooltip-like hint window
	BOOL			m_bShowHints;		// show field hints?
	UINT			m_msecDelay;		// msec delay for hints (0=immediate display)
	UINT			m_msecTimeout;		// msec auto-hode for hints (0=never hide)
	BOOL			m_bImmedVal;		// validate each field immediately?
	UINT			m_msgCallback;		// callback message to notify app
	CStatic*		m_pWndFeedback;	// "feedback" window
	COLORREF		m_clrError;			// feedback window error color
	COLORREF		m_clrFeedback;		// current feedback window color

	// Private struct to hold dynamic field runtime info.
	// Base part is same as RGXFIELDMAP entry.
	//
	struct FLDINFO : public RGXFIELD {
		FLDINFO() : err(RGXERR_OK) { id=0; }
		CString name;				// field name
		CRegex  regex;				// regex for validation
		CString hint;				// tooltip "hint" text
		CString errmsg;			// error message if no match
		CString val;				// current value (text)
		RGXERROR err;				// error code for this field
	};

	typedef vector<FLDINFO> FLDARRAY;
	typedef FLDARRAY::iterator FLDITERATOR;
	static FLDINFO NULLFLD;		// empty or NULL field
	FLDARRAY m_fldinfo;			// STL array of all FLDINFOs

	// private subclass hook to trap edit control messages
	class CEditHook : public CSubclassWnd {
	public:
		CEditHook(CWnd* pDlg, UINT nID, LPCTSTR lpszLegalChars);
		CEditHook* m_next;
		CRegex m_rgxLegalChars;
		virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
	};

	// private helpers
	int GetFieldIndex(UINT nID);				// get index of field/edit control in map
	RGXERROR ValidateField(FLDINFO& fld);	// validate single field
	BOOL ValidatePseudo(FLDINFO& fld, LPCTSTR rgxPseudo, BOOL bInit=FALSE);
	FLDINFO& GetFieldInfo(UINT nID);			// get FLDINFO from ID
	LPCTSTR GetFieldErrorMsg(const FLDINFO& fld);
	void ShowBadField(const FLDINFO& fld, BOOL bBeep, BOOL bFocus);
	void ShowHint(FLDINFO& fld, CWnd* pCtl);

	// helpers to handle intercepted dialog messages 
	void OnEnKillFocus(FLDINFO& fld, CWnd* pCtl);
	void OnEnSetFocus(FLDINFO& fld, CWnd* pCtl);
	void OnEnChange(FLDINFO& fld, CWnd* pCtl);

	// virtual wndproc to trap dialog messages
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);

public:
	CRegexForm();
	virtual ~CRegexForm();

	// Initialize the form manager. You must supply:
	//
	//		- field map
	//		- ptr to dialog
	//		- resource string ID
	//		- callback message ID
	//
	// The resource string holds various several substrings separated by '\n':
	//
	//		"[RequiredMsg]\n[ShouldBeMsg %s]\n[DefaultErrorMessage]"
	//
	// For example:
	//
	//    "Required\nShould be: %s\nBad Value"
	//
	// See RegexTest.rc in the RegexTest sample. 
	//
	// The [Should be %s] string (fld error message prefix, m_sFldErrPfx) is
	// combined with the hint to produce an error message if there's no explicit
	// DefaultErrorMessage. For example, if the field's hint is "###" then the
	// error message in this example will be "Should be ###". Use %s where you
	// want the hint to go. DefaultErrorMessage is something generic like "Bad
	// Value", used as last resort if there's no hint and no error message.
	//
	void Init(RGXFIELDMAP map, CDialog* pDlg, UINT nIDDfltStrs, UINT msgCallback=0);
	void SetFeedbackWindow(CStatic* pWndFeedback, COLORREF clrError) {
		m_pWndFeedback = pWndFeedback;
		m_clrError = clrError;
	}
	void Feedback(LPCTSTR msg, COLORREF clr=0);
	void ShowBadField(UINT nID, BOOL bBeep, BOOL bFocus)
	{
		return ShowBadField(GetFieldInfo(nID), bBeep, bFocus);
	}

	int  Validate();					// validate form data: returns # bad fields
	vector<UINT> GetBadFields();	// get IDs of bad fields as array.

	// Get/set current field values. Note these are stored in the form
	// manager, not your dialog as in normal MFC DDX. Also, field values are
	// always text (CString).
	LPCTSTR GetFieldValue(UINT nID) {
		return GetFieldInfo(nID).val;
	}
	void SetFieldValue(UINT nID, CString val) {
		GetFieldInfo(nID).val = val;
	}

	// Get value as int or double. Add more for different types
	int GetFieldValInt(UINT nID) {
		return _tstoi(GetFieldValue(nID));
	}
	double GetFieldValDouble(UINT nID) {
		return _tstof(GetFieldValue(nID));
	}

	// Get various field properties/results
	LPCTSTR GetFieldName(UINT nID) {
		return GetFieldInfo(nID).name;
	}
	LPCTSTR GetFieldHint(UINT nID) {
		return GetFieldInfo(nID).hint;
	}
	RGXERROR GetFieldError(UINT nID) {
		return (RGXERROR)GetFieldInfo(nID).err;
	}
	void SetFieldError(UINT nID, RGXERROR err) {
		GetFieldInfo(nID).err = err;
	}
	LPCTSTR GetFieldErrorMsg(UINT nID) {
		return GetFieldErrorMsg(GetFieldInfo(nID));
	}

	// Set focus and select/highlight field (edit control) text
	void HighlightField(UINT nID);

	// You must call this from your dialog's DoDataExchange
	void DoDataExchange(CDataExchange* pDX);

	// When you turn hints on, you can specify a delay-to-show time and a
	// timeout time, like for tooltips.
	void SetShowHints(BOOL bShowHints, UINT msecDelay=250, UINT msecTimeout=0) {
		m_bShowHints = bShowHints;
		m_msecDelay = msecDelay;
		m_msecTimeout = msecTimeout;
	}

	BOOL GetShowHints() {
		return m_bShowHints;
	}

	// Cancel (hide) hint if any
	void CancelHint() {
		m_wndHint.Cancel();
	}

	// If you want the form manager to validate fields immediately (when the
	// user attempts to leave a field), call this with TRUE. The form manager
	// will send a RGXNM_BADFIELD notification with WPARM=ID and LPARAM=CWnd*
	// for the offending control. You should return TRUE if you want to halt
	// further processing of EN_KILLFOCUS--ie, if you SetFocus to the bad
	// control; otherwise return FALSE.
	//
	// Immediate validation is not recommended, it's not good GUI.
	//
	void SetValidateImmed(BOOL bVal) {
		m_bImmedVal = bVal;
	}
	BOOL GetValidateImmed() {
		return m_bImmedVal;
	}
};
