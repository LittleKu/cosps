////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// This is the main include file for PixieLib. Applications that use
// PixieLib should include this file in stdafx.h.
//
#pragma once

#ifndef __cplusplus
#error PixieLib requires C++!
#endif

#ifndef __AFX_H__
#error PixieLib requires MFC!
#endif

//////////////////
// Stuff to make DLL classes work
//
#if defined(BUILD_PIXIE_DLL)
#	define DLLFUNC  __declspec ( dllexport )
#	define DLLDATA  __declspec ( dllexport )
#	define DLLCLASS __declspec ( dllexport )
#elif defined(USE_PIXIE_DLL)
#	define DLLFUNC  __declspec ( dllimport )
#	define DLLDATA  __declspec ( dllimport )
#	define DLLCLASS __declspec ( dllimport )
#else
#	define DLLFUNC
#	define DLLDATA
#	define DLLCLASS
#endif

#define countof(x)	(sizeof(x)/sizeof(x[0]))

// Link with right library. Must come before <afxwin.h> !
#ifndef BUILD_PIXIE_DLL
#ifdef _AFXDLL
	#ifdef USE_PIXIE_DLL // using PixieLib.dll : debug/Unicode
		#ifdef _UNICODE
			#ifdef _DEBUG
				#pragma comment(lib, "PixieLib71UD.lib")
			#else
				#pragma comment(lib, "PixieLib71U.lib")
			#endif
		#else
			#ifdef _DEBUG
				#pragma comment(lib, "PixieLib71D.lib")
			#else
				#pragma comment(lib, "PixieLib71.lib")
			#endif
		#endif
	#else // using MFC DLL but not PixieLib.dll: use static link libraries
		#ifdef _UNICODE
			#ifdef _DEBUG
				#pragma comment(lib, "PixieLib71SUD.lib")
			#else
				#pragma comment(lib, "PixieLib71SU.lib")
			#endif
		#else
			#ifdef _DEBUG
				#pragma comment(lib, "PixieLib71SD.lib")
			#else
				#pragma comment(lib, "PixieLib71S.lib")
			#endif
		#endif
	#endif
#else // using static MFC: use static PixieLib w/static MFC, debug or Unicode
	#ifdef _UNICODE
		#ifdef _DEBUG
			#pragma comment(lib, "PixieLib71MSUD.lib")
		#else
			#pragma comment(lib, "PixieLib71MSU.lib")
		#endif
	#else
		#ifdef _DEBUG
			#pragma comment(lib, "PixieLib71MSD.lib")
		#else
			#pragma comment(lib, "PixieLib71MS.lib")
		#endif
	#endif
#endif
#endif // BUILD_PIXIE_DLL

#include <afxmt.h>			// MFC multi-threading
#include <vector>				// STL vector/array

using namespace std;

//#if defined(_AFXDLL) && !defined(USE_PIXIE_DLL)
// if using MFC DLL, force-link PixieLib StdPL.obj for precompiled hdr stuff
//#pragma comment(linker, "/include:__linkPixieLib")
//#endif

//////////////////
// Like CRect, but constructor gets client/window dimensions in
// various coords depending on value of "which". Lets you write
//
//		CWinRect rc(this); // get window client rectangle
//		SomeFn(rc);
//
// or
//
//		// get window (as opposed to client) rect
//		CWinRect rc(this, CWinRect::WINDOW); 
//
// where "this" is your window (view, frame, etc).
//
class DLLCLASS CWinRect : public CRect {
protected:
	void Construct(CWnd *pWnd, int which);
public:
	enum { CLIENT, CLIENTSCREEN, WINDOW, WINDOWCLIENT, MDICLIENT };
	// Constructors and assignment
	CWinRect(CWnd *pWnd, int which=CLIENT) { Construct(pWnd, which); }
	CWinRect(const CRect& rc)					{ *this = rc; }

	CWinRect& operator= (const CRect& rc) {
		*((CRect*)this) = rc;
		return *this;
	}
	void CapturePt(CPoint &pt);
	void Normalize();
	BOOL CenterInRect(const CRect& rc);
};

////////////////
// CWindowPlacement reads and writes WINDOWPLACEMENT from/to application
// profile or CArchive. This lets you save and restore the position of a
// window across user sessions. For an example of how to use it, see the
// TraceWin sample program.
//
struct DLLCLASS CWindowPlacement : public WINDOWPLACEMENT {
	CWindowPlacement();
	~CWindowPlacement();
	
	// read/write to app profile
	BOOL GetProfileWP(LPCTSTR lpszKey, LPCTSTR lpszVal);
	BOOL WriteProfileWP(LPCTSTR lpszKey, LPCTSTR lpszVal);

	// save/restore window pos (from app profile)
	void Save(LPCTSTR lpszKey, LPCTSTR lpszVal, CWnd* pWnd);
	BOOL Restore(LPCTSTR lpszKey, LPCTSTR lpszVal, CWnd* pWnd);

	// save/restore from archive
	friend CArchive& operator<<(CArchive& ar, const CWindowPlacement& wp);
	friend CArchive& operator>>(CArchive& ar, CWindowPlacement& wp);
};

//////////////////
// Generic class to subclass a CWnd. Once subclassed, all messages go to
// CSubclassWnd::WindowProc before going to the window. Specific subclasses
// can trap messages and do something. This very powerful class lets you
// write a plug-in classes that handle windows messages without deriving a
// new window class. To use:
//
// * Derive from CSubclassWnd.
//
// * Override CSubclassWnd::WindowProc to handle messages. Make sure you call
//   CSubclassWnd::WindowProc if you don't handle the message, or your
//   window will never get messages. If you write separate message handlers,
//   you can call Default() to pass the message to the window.
//
// * Instantiate your derived class somewhere and call HookWindow(pWnd)
//   to hook your window, AFTER it has been created.
//	  To unhook, call Unhook or HookWindow(NULL).
//
// Many PixieLib classes derive from this very important class. To see how it
// works, look at the Hook sample program.
//
class DLLCLASS CSubclassWnd : public CObject {
public:
	CSubclassWnd();
	~CSubclassWnd();

	// Subclass a window. Hook(NULL) to unhook (automatic on WM_NCDESTROY)
	BOOL	HookWindow(HWND  hwnd);
	BOOL	HookWindow(CWnd* pWnd)	{ return HookWindow(pWnd->GetSafeHwnd()); }
	void	Unhook()						{ HookWindow((HWND)NULL); }
	BOOL	IsHooked()					{ return m_hWnd!=NULL; }

	friend LRESULT CALLBACK HookWndProc(HWND, UINT, WPARAM, LPARAM);
	friend class CSubclassWndMap;

	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
	LRESULT Default();				// call this at the end of handler fns

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	HWND				m_hWnd;				// the window hooked
	WNDPROC			m_pOldWndProc;		// ..and original window proc
	CSubclassWnd*	m_pNext;				// next in chain of hooks for this window

	DECLARE_DYNAMIC(CSubclassWnd);
};

//////////////////
// Top-level window list, STL vector of HWNDs. To use:
//
//		CWinList wl;		// window list
//		wl.Fill();			// fill it
//		for (CWinList::iterator it=wl.begin(); it!=wl.end(); it++) {
//			HWND hwnd = *it;
//			// do something with it
//		}
//
// Derived classes can override OnWindow to filter windows--eg, only visible.
// If you specify a parent window, CWinList will generate a deep child window
// list:
//
//		CWinList wl(hwndParent);
//		wl.Fill();
//
// In this case, CWinList uses EnumChildWindows instead of EnumWindows.
//
class DLLCLASS CWinList : public vector<HWND> {
protected:
	HWND m_hwndParent;
	static BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lp);
	// override to filter different kinds of windows
	virtual BOOL OnWindow(HWND /* hwnd */) {
		return TRUE;
	}
public:
	CWinList(HWND hwndParent=NULL, UINT nReserve=25);
	virtual ~CWinList() { }
	UINT Fill();
};

//////////////////
// Get list of main windows for a process. To use:
//
//		CMainWinList wl(pid);	// process ID
//		wl.Fill();					// fill it
//
// Now wl is an STL array of HWNDs for windows that belong to the given
// process.
//
class DLLCLASS CMainWinList : public CWinList  {
protected:
	DWORD m_pid;				// process id
	BOOL  m_bOnlyVisible;	// show only visible windows
	virtual BOOL OnWindow(HWND hwnd);	 // override
public:
	CMainWinList(DWORD dwProcessID, BOOL bOnlyVisible=TRUE, UINT nReserve = 25)
		: CWinList(NULL, nReserve), m_pid(dwProcessID), m_bOnlyVisible(bOnlyVisible) { }
};

//////////////////
// CFindWinList finds all windows with a given class name at top level or as a
// descendant of a given window. To use it, instantiate like so:
//
//		CFindWinList fwl(hwndParent, classname);
//		fwl.Fill();
//
// CFindWinList is now an array of HWNDs with the desired classname. Use
// hwndParent=NULL to search top-level windows only; otherwise CFindWinList
// does a deep search. Iterate using STL as for CWinList.
//
class DLLCLASS CFindWinList : public CWinList {
protected:
	virtual BOOL OnWindow(HWND hwnd);	 // override
public:
	LPCTSTR m_lpClassName; // class name to look for
	CFindWinList(HWND hwndParent, LPCTSTR classname, int nReserve=25)
		: CWinList(hwndParent, nReserve), m_lpClassName(classname) { }
};

////////////////
// Handy class to lock a critical section. Constructor/destructor
// locks/unlocks the critical section. You can put this at the top of a
// function or code block to lock the data for the scope of the function/code
// block. For example:
//
//		void CMyClass::MyMethod(...)
//		{
//			static CCriticalSection here;
//			CLockData lock(here);
//			// ...manipulate class data members safely
//		}
//
class CLockData {
private:
	CSyncObject& m_syncObj;
public:
	CLockData(CSyncObject& so) : m_syncObj(so) { VERIFY(m_syncObj.Lock()); }
	~CLockData() { m_syncObj.Unlock(); }
};

//////////////////
// CBitArray no longer exists. Use vector<bool>.
//

////////////////////////////////////////////////////////////////
// Global objects for mouse, keyboard, cursor, etc.
////////////////////////////////////////////////////////////////

//////////////////
// Global mouse class with singleton instance TheMouse. Use it to capture the
// mouse. 
//
//		TheMouse.Capture(pWnd);			// capture mouse input
//		TheMouse.Release();				// release the mouse
// 
class GMouse {
public:
	CWnd* Capture()			{ return CWnd::GetCapture(); }
	CWnd* Capture(CWnd *w)	{ return w->SetCapture(); }
	void Release()				{ ReleaseCapture(); }
};
extern DLLCLASS GMouse TheMouse;

//////////////////
// Global Keyboard class with singleton object TheKeyboard. Use it to get
// information about the keyboard.
//
//		int nfnkey = TheKeyboard.NumFnKeys();
//		int cp = TheKeyboard.CodePage();
// 
class GKeyboard {
public:
	int CodePage()						{ return GetKBCodePage(); }
	int Type()							{ return GetKeyboardType(0); }
	int SubType()						{ return GetKeyboardType(1); }
	int NumFnKeys()					{ return GetKeyboardType(2); }
	int KeyName(LONG lparam, LPTSTR buf, int buflen)
		{ return GetKeyNameText(lparam, buf, buflen); }
	int State(int vkey)				{ return GetKeyState(vkey); }
	void GetState(BYTE* buf)		{ GetKeyboardState(buf); }
	void SetState(BYTE* buf)		{ SetKeyboardState(buf); }
	BOOL IsArrowKey(int key)		{ return VK_LEFT<=key && key<=VK_DOWN; }
};
extern DLLCLASS GKeyboard TheKeyboard;

/////////////////
// Global Cursor class with singleton instance TheCursor. Use it to manipulate
// the cursor. For example:
//
//		TheCursor = ID_MYCURSOR;	// change cursor icon
//    CPoint p = TheCurser;		// get cursor pos
//		TheCursor = CPoint(10,50);	// move cursor pos
//
class GCursor {
public:
	HCURSOR operator= (HCURSOR hc)	{ return SetCursor(hc); }
	HCURSOR operator= (LPCTSTR name)	
		{ return SetCursor(AfxGetApp()->LoadCursor(name)); }
	HCURSOR operator= (int id)			
		{ return SetCursor(AfxGetApp()->LoadCursor(id)); }

	void		SetPos(int x, int y)		{ SetCursorPos(x, y); }
	CPoint	GetPos()						{ CPoint p; GetCursorPos(&p); return p; }
	operator CPoint()						{ return GetPos(); }
	CPoint	operator=(CPoint p)		{ SetCursorPos(p.x, p.y); return p; }

	void Clip(CWnd *pWnd) {
		ASSERT_VALID(pWnd);
		CWinRect rc(pWnd, CWinRect::CLIENTSCREEN);
		Clip(rc);							// call overloaded clip fn
	}
	void Clip(CRect &rect)				{ ClipCursor(&rect); }
	void UnClip()							{ ClipCursor(NULL); }
	void Show(BOOL val)					{ ShowCursor(val); }
};
extern DLLCLASS GCursor TheCursor;

//////////////////
// Implements a wait cursor (hourglass). The constructor changes the cursor to
// an hourglass and captures the mouse; the destructor restores it when the
// function/scope ends. Just instantiate it at the top of any function or code
// block that does something lengthy. For example:
//
//		SomeTimeConsumingFn(...)
//		{
//			CHourglass(pMyWnd);  // optional window to capture mouse
//			.
//			.
//			.
//		}
//
class CHourglass {
protected:
	CWnd*		m_pCapWnd;		// window to capture mouse, if any
	HCURSOR	m_hSaveCursor;	// save cursor handle
public:
	CHourglass(CWnd *pWnd=NULL) {
		m_hSaveCursor = TheCursor = IDC_WAIT;
		if ((m_pCapWnd=pWnd)!=NULL)
			TheMouse.Capture(m_pCapWnd);
	}
	~CHourglass() {
		TheCursor = m_hSaveCursor;
		if (m_pCapWnd)
			TheMouse.Release();
	}
};

//////////////////
// Write text or resource string to MFC status bar. For example:
//
//		PLPrompt("hello, world");
//
// writes "hello, world" to the satus line.
//
extern DLLFUNC void PLPrompt(LPCTSTR lpText, BOOL bUpdateNow=FALSE);
extern DLLFUNC void PLPrompt(UINT nResID,    BOOL bUpdateNow=FALSE);

// handy color definitions
const COLORREF CBLACK  = RGB(0,0,0);
const COLORREF CWHITE  = RGB(255,255,255);
const COLORREF CRED	  = RGB(255,0,0);
const COLORREF CGREEN  = RGB(0,255,0);
const COLORREF CBLUE	  = RGB(0,0,255);
const COLORREF CLTGRAY = RGB(192,192,192);
const COLORREF CDKGRAY = RGB(128,128,128);

//////////////////
// Get NONCLIENTMETRICS info: ctor calls SystemParametersInfo. Just
// instantiate and use.
//
//		CNonClientMetrics ncm;
//		// now ncm is filled with NONCLIENTMETRICs
//
class CNonClientMetrics : public NONCLIENTMETRICS {
public:
	CNonClientMetrics() {
		cbSize = sizeof(NONCLIENTMETRICS);
		SystemParametersInfo(SPI_GETNONCLIENTMETRICS,0,this,0);
	}
};

#include "PLDebug.h"
#include "PLCoolUI.h"
#include "PLDraw.h"
#include "PLInet.h"
#include "PLProcess.h"
#include "PLStatLink.h"

static TCHAR _pdcredit[] = 
_T("Portions of this program use PixieLib, written by Paul DiLascia.	Copyright 1997-2005.");
