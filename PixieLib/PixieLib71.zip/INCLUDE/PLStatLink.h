////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CStaticLink implements a static control that's a hyperlink
// to any file on your desktop or web. You can use it in dialog boxes
// to create hyperlinks to web sites. When clicked, opens the file/URL
//
#pragma once

//////////////////
// Use this class to force STA (single thread apartment model) threading in
// mixed-mode .NET apps so ShellExecute will work correctly launching an URL.
// Constructor calls CoInitialize(NULL) to force STA. To use, instantiate at
// top-level in your main application module or anywhere the constructor will
// run before the CLR.
//
//		// in main module
//		CSTAThread forceSTA;
//
class CSTAThread {
public:
	CSTAThread()	{ CoInitialize(NULL); }
	~CSTAThread()	{ CoUninitialize();   }
};

//////////////////
// Simple text hyperlink derived from CString. Used in CStatlicLink, rarely by
// itself. But you could use it to launch an URL like so:
//
//		CHyperlink link(_T("http://www.dilascia.com"));
//		link.Navigate();
//
class CHyperlink : public CString {
public:
	CHyperlink(LPCTSTR lpLink = NULL) : CString(lpLink) { }
	~CHyperlink() { }
	const CHyperlink& operator=(LPCTSTR lpsz) {
		CString::operator=(lpsz);
		return *this;
	}
	operator LPCTSTR() {
		return CString::operator LPCTSTR(); 
	}

	// Navigate the link. Use rundll32.exe
	BOOL Navigate() {
		return IsEmpty() ? NULL :
			((INT64)ShellExecute(0, _T("open"), *this, 0, 0, SW_SHOWNORMAL)>32);
	}
};

//////////////////
// CStaticLink implements a static control in a dialog that clicks to a web
// page, just like an <A> tag in HTML. If you want to let users click using
// the keyboard as well as mouse, don't forget to turn on WS_TABSTOP for the
// static control in your dialog. You can do this using dialog editor or by
// adding WS_TABSTOP in your .rc file. To use CStaticLink, add a member in
// your dialog class, and subclass it in your OnInitDialog handler.
//
//		class CAboutDialog : public CDialog {
//		protected:
//			CStaticLink	m_wndLink;
//			virtual BOOL OnInitDialog() {
//				m_wndLink.SubclassDlgItem(IDC_MYURL, this);
//				return CDialog::OnInitDialog();
//			}
//		};
//
// IDC_MYURL is the control ID of a static control (text or image) in your
// dialog, and CStaticLink looks for a string resource with the same ID to
// get the URL.
//
// CStaticLink does all the things you'd expect: it draws the link text in the
// default link color (blue) and underlines it, it changes the cursor to a
// pointing finger when the user moves the mouse over the link, and so on.
// You can changed g_colorUnvisited and g_colorVisited to change the default
// colors.
//
class DLLCLASS CStaticLink : public CStatic {
public:
	CStaticLink(LPCTSTR lpLink = NULL, BOOL bDeleteOnDestroy=FALSE);
	~CStaticLink() { }

	// Use this to create a static link from scratch
	BOOL Create(LPCTSTR lpszText, DWORD dwStyle, CWnd* pParentWnd,
		UINT nID = 0xffff, LPCTSTR lpszLink=NULL, RECT rc=CRect(0,0,0,0)) {
		m_link = lpszLink;
		return CStatic::Create(lpszText, dwStyle, rc, pParentWnd, nID);
	}

	// Use this if you want to subclass and also set different URL
	BOOL SubclassDlgItem(UINT nID, CWnd* pParent, LPCTSTR lpszLink=NULL) {
		m_link = lpszLink;
		return CStatic::SubclassDlgItem(nID, pParent);
	}

	void SetNoLink(BOOL bNoLink) {
		m_bNoLink = bNoLink;
	}

	BOOL Navigate(); // navigate the link (like clicking)

	// Hyperlink contains URL/filename. If NULL, I will use the window text.
	// (GetWindowText) to get the target.
	CHyperlink	m_link;			// hyperlink
	COLORREF		m_color;			// current color

	// Default colors you can change
	// These are global, so they're the same for all links.
	static COLORREF g_colorUnvisited;
	static COLORREF g_colorVisited;

	// Cursor used when mouse is on a link--you can set, or
	// it will default to the standard hand with pointing finger.
	// This is global, so it's the same for all links.
	static HCURSOR g_hCursorLink;

protected:
	CFont			m_font;					// underline font for text control
	BOOL			m_bDeleteOnDestroy;	// delete object when window destroyed?
	BOOL			m_bNoLink;

	void DrawFocusRect();	// draw focus rectangle

	virtual void PostNcDestroy();

	// message handlers
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CStaticLink)
};
