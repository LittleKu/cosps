////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

#include <PLWinMgr.h>

// folder tab control style flags
#define FTS_FULLBORDER	0x1 // draw full border
#define FTS_BUTTONS	   0x2 // draw next/prev buttons

enum { FTN_TABCHANGED = 1 };				 // notification: tab changed
enum { FTBPREV=1, FTBNEXT };				 // folder button IDs

//////////////////
// Notification struct used by folder tabs.
//
struct NMFOLDERTAB : public NMHDR {		 // notification struct
	int iItem;									 // item/tab index
	LPCTSTR lpText;							 // tab text
};

//////////////////
// Private (internal) class to represent one folder tab. This class draws the
// trapezoidal tab. Used in CFolderTabCtrl. Generally you shouldn't have to
// create this class, only use it by calling GetText or SetText to get/set
// the tab name.
//
class CFolderTab {  // used internally
private:
	CString	m_sText; // tab text
	CRect		m_rect;	// bounding rect
	CRgn		m_rgn;	// polygon region to fill (trapezoid)

	int		ComputeRgn(CDC& dc, int x);
	int		Draw(CDC& dc, CFont& font, BOOL bSelected);
	BOOL		HitTest(CPoint pt)			{ return m_rgn.PtInRegion(pt); }
	CRect		GetRect() const				{ return m_rect; }
	void		GetTrapezoid(const CRect& rc, CPoint* pts) const;

	friend class CFolderTabCtrl;

public:
	CFolderTab(LPCTSTR lpszText) : m_sText(lpszText) { }
	LPCTSTR	GetText() const				{ return m_sText; }
	void  	SetText(LPCTSTR lpszText)	{ m_sText = lpszText; }
};

//////////////////
// Class to implement next/prev folder buttons to navigate tabs when they
// don't all fit in the tab window. You shouldn't have to use this class
// yourself, it's used internally by the folder tab control.
//
class DLLCLASS CFolderButton : public CButton { // used internally
public:
	BOOL Create(DWORD dwStyle, CWnd* pParent, const RECT& rc, UINT nID) {
		return CButton::Create(NULL, dwStyle|BS_OWNERDRAW, rc, pParent, nID);
	}

protected:
	int  m_nTimerClick;						 // for initial scroll delay

	// paint function
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDis);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint pt);
	afx_msg void OnTimer(UINT nIDEvent);
	DECLARE_DYNAMIC(CFolderButton);
	DECLARE_MESSAGE_MAP()
};

//////////////////
// Folder tab control, similar to the Windows common tab control, but draws
// upside-down Excel-style "folder" tabs. Use this if you want to create a
// folder tab control as a child window in a view or other compound window.
// Incorporates next/prev folder buttons used when the tabs don't all fit
// within the window.
//
// You don't need to use this class if you use CFolderFrame/CFolderView.
// CFolderFrame has its own CFolderTabCtrl.
//
class DLLCLASS CFolderTabCtrl : public CWnd {
protected:
	CFolderButton m_wndButton[2];			 // folder buttons
	CPtrList		m_lsTabs;					 // array of CFolderTabs
	DWORD			m_dwFtabStyle;				 // folder tab style flags
	int			m_iCurTab;					 // current selected tab
	CFont			m_fontNormal;				 // current font, normal ntab
	CFont			m_fontSelected;			 // current font, selected tab
	int			m_cxDesired;				 // exact fit width
	int			m_cxButtons;				 // width of buttons
	int			m_iFirstTab;				 // first tab to show

	// helpers
	void InvalidateTab(int iTab, BOOL bErase=TRUE);
	void DrawTabs(CDC& dc, const CRect& rc);
	void UpdateButtons();

public:
	CFolderTabCtrl();
	virtual ~CFolderTabCtrl();

	BOOL CreateFromStatic(UINT nID, CWnd* pParent);

	virtual BOOL Create(DWORD dwWndStyle, const RECT& rc,
		CWnd* pParent, UINT nID, DWORD dwFtabStyle=0);
	virtual BOOL Load(UINT nIDRes);

	int	GetSelectedTab()				{ return m_iCurTab; }
	int	GetTabCount()					{ return (int)m_lsTabs.GetCount(); }
	int	GetDesiredWidth()				{ return m_cxDesired; }
	int	GetDesiredHeight()			{ return GetSystemMetrics(SM_CYHSCROLL); }
	BOOL  AddTab(LPCTSTR lpszText);
	BOOL  RemoveTab(int iPos);
	void	RecomputeLayout();
	int	HitTest(CPoint pt);
	int	SelectTab(int iTab);
	void	SetFonts(CFont& fontNormal, CFont& fontSelected);
	LPCTSTR GetTabText(int iTab = -1);
	void    SetTabText(int iTab, LPCTSTR lpText);
	CFolderTab* GetTab(int iTab = -1);
	BOOL  HasButtons() {
		return m_wndButton[0].m_hWnd != NULL;
	}

protected:
	afx_msg int  OnCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnNextTab();
	afx_msg void OnPrevTab();
	DECLARE_DYNAMIC(CFolderTabCtrl);
	DECLARE_MESSAGE_MAP()
};

//////////////////
// CFolderFrame manages the combined folder tab control, view and scroll bars.
// The main frame contains this window as a child/client, and it holds the
// view, tab control and scroll bars. To use, create an instance in your main
// frame, then override OnCreateClient like so:
//
//		BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT, CCreateContext* pcc)
//		{
//			return m_wndFolderFrame.Create(this,
//				RUNTIME_CLASS(CMyView),	pcc, IDR_FOLDERTABS);
//		}
//
// You must derive your view from CFolderView. IDR_FOLDERTABS is the resource
// ID of a string with the names of the folder tabs separated by newlines. For
// example:
//
//		STRINGTABLE PRELOAD DISCARDABLE 
//		BEGIN
//			IDR_FOLDERTABS "Tab 1\nTab 2\nTab 3"
//		END
//
// This creates three folder tabs: Tab 1, Tab 2 and Tab 3.
//
// Finally, you must override CFolderView::OnChangedFolder in your view.
// PixieLib calls this function when the user selects a different tab.
//
//		void CMyView::OnChangedFolder(int iPage)
//		{
//			m_iPage = iPage;			// 0-based index of tab selected.
//			UpdateScrollSizes();		// scroll sizes potentially different for this page
//			Invalidate();				// repaint
//		}
//
// Your OnDraw function should draw the contents of the view based on which
// tab (m_iPage) is selected. Note that each "folder" uses the same window--in
// the example, there's only one view window, not three.
//
//		void CMyView::OnDraw(CDC* pDC)
//		{
//			if (m_iPage==PAGE1) {
//				// draw it
//		} else if (m_iPage==PAGE2) {
//				// draw it
//		} else {
//				// etc
//		}
//
class DLLCLASS CFolderFrame : public CWnd {
protected:
	CWinMgr			m_winMgr;				 // window manager
	CFolderTabCtrl	m_wndFolderTabCtrl;	 // folder tab
	CSizerBar		m_wndSizerBar;			 // sizer bar
	CScrollBar		m_wndSBHorz;			 // horizontal scroll bar..
	CScrollBar		m_wndSBVert;			 // ... vertical
	CScrollBar		m_wndSBBox;				 // ... and box
	int				m_cxFolderTabCtrl;	 // width of folder tab
	UINT				m_nIDRes;				 // resource ID for tab names
	DECLARE_WINDOW_MAP(FrameMap)			 // declare WinMgr window map

public:
	// Window IDs for child windows in combined tab control
	enum { IDC_FOLDERTABS=1, IDC_SIZERBAR, IDC_SIZEBOX };

	CFolderFrame();
	virtual ~CFolderFrame();

	BOOL Create(CWnd* pParent, CRuntimeClass* pViewClass, CCreateContext* pcc,
		UINT nIDRes = 0,
		int cxFolderTabCtrl=-2,
		DWORD dwStyle = WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN);

	CScrollBar* GetScrollBar(int nBar) const;
	CFolderTabCtrl& GetFolderTabCtrl()			 { return m_wndFolderTabCtrl; }
	CWnd* GetView(UINT nID=AFX_IDW_PANE_FIRST) { return GetDlgItem(nID); }
	int	GetFolderTabWidth()						 { return m_cxFolderTabCtrl; }

	enum  { bestFit=-1, hide=-2 };
	void	ShowControls(int width);		 // show ctrls: bestFit, hide, or width

	// virtual overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CFolderFrame)
};

//////////////////
// CScrollView-based folder view. Derive your view from this. Override
// OnChangedTab to process event when the user selects a new tab. Typically,
// you'll save the tab index somewhere. Your view's OnDraw method can then use
// this value to draw the appropriate view. See CFolderFrame.
//
class DLLCLASS CFolderView : public CScrollView {
public:
	CFolderView() { }
	virtual ~CFolderView() { }

	// override to use my own scrollbar controls, not built-in
	virtual CScrollBar* GetScrollBarCtrl(int nBar) const;
	virtual void OnChangedFolder(int iPage);
	CFolderFrame* GetFolderFrame() const;

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnChangedTab(NMHDR* nmtab, LRESULT* pRes);
	DECLARE_DYNAMIC(CFolderView)
};


