////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// ---
// Private stuff internal to PixieLib
//
#pragma once

#ifdef _DEBUG

#define PLTRACEFN					\
	CTraceFn __fooble;			\
	if (CPixieDebug::bTRACE)	\
		TRACE

#define PLTRACE					\
	if (CPixieDebug::bTRACE)	\
		TRACE

#else

#define PLTRACEFN TRACE
#define PLTRACE   TRACE

#endif
