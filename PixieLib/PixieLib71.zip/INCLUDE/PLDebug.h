////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// ---
// General purpose debugging utilities.
//
#pragma once

#ifndef countof
#define countof(x)	(sizeof(x)/sizeof(x[0]))
#endif

class DLLCLASS CPixieDebug {
public:
	static BOOL bTRACE;		// turn PixieLib TRACEing on
};

#ifdef _DEBUG

// tell linker to look in ole32 lib (for StringFromClsid)
#pragma comment(linker, "/defaultlib:ole32.lib")

// This macro lets you put a debug test into your, so you can write
//
//     DEBUG_IF((x=5),TRACE("Something is rotten here.\n"));
//
// instead of
//
// #ifdef _DEBUG
//     if (x=5)
//       TRACE("Something is rotten here.\n");
// #endif
//
#define DEBUG_IF(condition, action) do (condition) while(0)

//////////////////
// TRACEFN is a macro that lets you generate indented TRACE output so you
// can see the call stack. To use it:
//
//		SomeFn(...)
//		{
//			TRACEFN("Entering SomeFn...\n");
//			.
//			.
//		}
//
// Now all trace output after TRACEFN will be indented one space, until SomeFn
// returns. You can put TRACEFN in multiple functions to see indented trace
// output. For an example of this, see the HOOK sample program.
//
// NOTE: YOU MUST NOT USE TRACEFN IN A ONE-LINE IF STATEMENT!
// This will fail:
//
// if (foo)
//    TRACEFN(...)
//
// Instead, you must enclose the TRACE in squiggle-brackets
//
// if (foo) {
//		TRACEFN(...)
// }
//
#define TRACEFN CTraceFn __fooble; TRACE

//////////////////
// This class is used by TRACEFN to do intended stack-TRACE output. Don't use
// directly, use TRACEFN instead.
//
class DLLCLASS CTraceFn { // used internally
private:
	static int	nIndent;				// current indent level
	friend void AFX_CDECL AfxTrace(LPCTSTR lpszFormat, ...);
public:
	CTraceFn()  { nIndent++; }		// constructor bumps indent
	~CTraceFn() { nIndent--; }		// destructor restores it
};

//////////////////
// The following stuff is for getting human-readable names of things so
// you can show them in TRACE statements. For example,
//
// TRACE("Window is: %s\n", _TR(pWnd));
//
// Will generate output showing the name and title of the window, etc. The
// macro _TR casts _DbgName(x) to LPCTSTR for use with in printf so you can
// write
//
//   TRACE("Message is %s\n", _TR(uMsg));
//
// instead of
//
//   TRACE("Message is %s\n", (LPCTSTR)_DbgName(uMsg));
//
#define _TR(x)			(LPCTSTR)_DbgName(x)

// overloaded fns to get names of things.
extern DLLFUNC CString _DbgName(CWnd* pWnd); // get name of window, used internally
extern DLLFUNC CString _DbgName(UINT uMsg);	// get name of WM_ message, used internally
extern DLLFUNC CString _DbgName(REFIID iid);	// get name of COM interface, used internally
extern DLLFUNC CString _DbgName(SCODE sc);	// get name of COM SCODE, used internally

//////////////////
// This structure is used to implement a table for displaying the
// human-readable names of COM interfaces in TRACE diagnostics. PixieLib
// already knows the names of many common interfaces (see Debug.cpp for a
// list). To add more interfaces, put them in a table like so:
//
//		DEBUG_BEGIN_INTERFACE_NAMES()
//			DEBUG_INTERFACE_NAME(IFoo)
//			DEBUG_INTERFACE_NAME(IBar)
//			DEBUG_INTERFACE_NAME(ISomeOtherInterface)
//		DEBUG_END_INTERFACE_NAMES();
//
// Now you can write
//
//		REFIID iid = // some interface ID
//		TRACE("Interface: %s\n", _TR(iid));
//
// And see the interface name instead of a pointer or GUID. All the macros
// generate no code in Release builds.
//
struct DBGINTERFACENAME { // used internally
	const IID* piid;		  // ptr to GUID
	LPCTSTR name;			  // human-readable name of interface
};

//////////////////
// Private class used to manage tables of DBGINTERFACENAMEs. Don't use this
// class; use DEBUG_BEGIN/END_INTERFACE_NAMES. See DBGINTERFACENAME.
//
class DLLCLASS CInterfaceNames { // used internally
protected:
	static CInterfaceNames* s_pFirst;	 // first table of names
	CInterfaceNames*			m_pNext;		 // next table of names
	DBGINTERFACENAME*			m_pEntries;	 // entries for this table
	UINT							m_nEntries;	 // number of entries
public:
	CInterfaceNames(DBGINTERFACENAME* pdin, UINT n);
	static const DBGINTERFACENAME* FindEntry(REFIID iid);
};

#define DEBUG_BEGIN_INTERFACE_NAMES()								\
static DBGINTERFACENAME _myDBI[] = {								\

#define DEBUG_INTERFACE_NAME(iface)									\
	{ &IID_##iface, _T(#iface) },										\

#define DEBUG_END_INTERFACE_NAMES()									\
};																				\
static CInterfaceNames _initMyDBI(_myDBI, countof(_myDBI));	\

// Macro casts to LPCTSTR for use with TRACE/printf/CString::Format
//
#define DbgName(x)	(LPCTSTR)_DbgName(x)

#else // Below NOT _DEBUG ----------------------------------------------------

#define DEBUG_IF(cond, action) ((void)0)
#define _TR(x)			((LPCTSTR)NULL)
#define DbgName(x)	((LPCTSTR)NULL)
#define TRACEFN TRACE

#define DEBUG_BEGIN_INTERFACE_NAMES()
#define DEBUG_END_INTERFACE_NAMES()
#define DEBUG_INTERFACE_NAME(iface)

#endif // _DEBUG


