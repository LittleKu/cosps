////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once
#include <hash_map>
#include <windowsx.h>	// extensions--for GET_X_LPARAM

// typedefs for window map: uses STL hash_map
using namespace stdext;
typedef hash_map<HWND,UINT> HWNDMAP;
typedef pair<HWND,UINT> HWNDMAPENTRY;

//////////////////
// Abstract drag/drop data knows how to draw itself. Used with CDragDropMgr.
// Override for specific data types like text or image. PixieLib already has
// CDragDropText for text.
//
class DLLCLASS CDragDropData {
protected:
	CBitmap m_bitmap;		// bitmap used for drawing
public:
	CDragDropData() { }
	virtual ~CDragDropData() { }

	virtual CImageList* CreateDragImage(CWnd* pWnd, CRect& rc);

	// derived classes must implement these:
	virtual CSize OnGetDragSize(CDC& dc) = 0;
	virtual void  OnDrawData(CDC& dc, CRect& rc) = 0;
	virtual void* OnGetData() = 0;
};

//////////////////
// Concrete class for drag-drop text data. Virtual functions calculate the
// size, draw the text and get the data (string).
//
class DLLCLASS CDragDropText : public CDragDropData {
protected:
	enum { MAXWIDTH=64 };
	CString m_text;
public:
	CDragDropText(LPCTSTR text) {
		m_text = text;
	}
	~CDragDropText() { }

	virtual CSize OnGetDragSize(CDC& dc);
	virtual void  OnDrawData(CDC& dc, CRect& rc);
	virtual void* OnGetData() { return (void*)(LPCTSTR)m_text; }
};

// flags used for window type in window map
#define DDW_SOURCE 0x01		// window is drag-drop source
#define DDW_TARGET 0x02		// window is drag-drop target

// Single entry in drag/drop window map. Map is an array of these structs,
// each entry specifies a child window ID and whether the window is a source,
// target, or both.
struct DRAGDROPWND {
	UINT id;			// window ID
	UINT type;		// DDW_ flags above
};

// Use these macros to define your map:
#define BEGIN_DRAGDROP_MAP(name)		DRAGDROPWND name[] = {
#define DRAGDROP_WINDOW(id,flags)	{ id, flags },
#define END_DRAGDROP_MAP()				{ 0,0 } };

//////////////////
// Drag-drop structure passed as LPARAM in callback notification. WPARAM is
// notification code.
//
struct DRAGDROPINFO {
	UINT nID;				// control ID
	HWND hwndSource;		// source window
	HWND hwndTarget;		// target window
	CDragDropData* data;	// data to drag/drop
	POINT pt;				// current point (cursor) in client coords
								// of whatever window is identified by WPARAM
};

//////////////////
// Intra-app drag-drop manager. To use it, instantiate in your main window or
// dialog, create a drag-drop map and call Install from your OnCreate or
// OnInitDialog handler:
//
//		// table describing which child windows are sources and targets
//		// in OnInitDialog or OnCreate
//		BEGIN_DRAGDROP_MAP(MyDragDropWindows)
//			DRAGDROP_WINDOW(IDC_LIST1, DDW_SOURCE)
//			DRAGDROP_WINDOW(IDC_LIST2, DDW_SOURCE|DDW_TARGET)
//			DRAGDROP_WINDOW(IDC_EDIT1, DDW_TARGET)
//		END_DRAGDROP_MAP()
//		m_ddm.Install(this, MyDragDropWindows, WM_MYDRAGDROP);
//
// The table says which windows are sources (DDW_SOURCE) and which targets
// (DDW_TARGET). A window can be both.
//
// You must also override your main window's PreTranslateMessage to call
// CDragDropMgr::PreTranslateMessage:
//
//		BOOL CMyDlg::PreTranslateMessage(MSG* pMsg)
//		{
//			return m_ddm.PreTranslateMessage(pMsg) ? TRUE :
//				CDialog::PreTranslateMessage(pMsg);
//		}
//
// When you install the drag/drop manager, you give it a callback message
// (WM_MYDRAGDROP). CDragDropMgr sends this message when stuff happens, with:
//
//		WPARAM = notification code (DD_ENTER, DD_DRAG, DD_DROP, DD_ABORT)
//		LPARAM = pointer to a DRAGDROPINFO struct.
//
// Typically you should handle these notifications like so:
//
//		DD_ENTER:	set DRAGDROPINFO::data to a new CDragDropData object.
//		DD_DRAG:		scroll if necessary
//		DD_DROP:		do something with the contents of CDragDropData.
//		DD_ABORT:	cleanup if necessary
//
// See the DDTest sample for details. PixieLib has a CDragDropText for text
// data. If you want to drag other kinds of data--for example, and image,
// you'll have to derive from CDragDropData and override the pure virtual
// functions.
//
class DLLCLASS CDragDropMgr {
protected:
	enum { NONE=0, CAPTURED, DRAGGING }; // internal states

	// static stuff 
	CWnd*				m_pMainWnd;				 // main window
	UINT				m_uCallbackMsg;		 // callback message for app
	HWNDMAP			m_mapHwnd;				 // map of source/target windows
	HCURSOR			m_hCursorDrop;			 // ok-to-drop cursor
	HCURSOR			m_hCursorNo;			 // no-drop cursor

	// dynamic stuff used during dragging
	DRAGDROPINFO	m_info;					 // data during drag/drop
	UINT				m_iState;				 // current state: CAPTURED/DRAGGING
	HWND				m_hwndTracking;		 // window w/mouse capture
	CPoint			m_ptOrg;					 // original point start of drag
	CImageList*		m_pDragImage;			 // imagelist for dragging
	HCURSOR			m_hCursorSave;			 // save previous cursor here

	// mouse input handlers: can override if you derive
	virtual BOOL OnLButtonDown(const MSG& msg);
	virtual BOOL OnMouseMove(const MSG& msg);
	virtual BOOL OnLButtonUp(const MSG& msg);

	// internal helper functions
	void SetState(UINT iState);
	BOOL IsCaptured() { return m_iState>=CAPTURED; }
	BOOL IsDragging() { return m_iState>=DRAGGING; }
	BOOL IsSourceWnd(HWND hwnd) {
		return GetWindowType(hwnd) & DDW_SOURCE ? TRUE : FALSE;
	}
	BOOL IsTargetWnd(HWND hwnd) {
		return GetWindowType(hwnd) & DDW_TARGET ? TRUE : FALSE;
	}
	UINT GetWindowType(HWND hwnd);
	BOOL NotifyClient(UINT nCode, DRAGDROPINFO* pInfo=NULL);

public:
	CDragDropMgr();
	virtual ~CDragDropMgr();

	// notification codes for DRAGDROPINFO
	enum {
		DD_ENTER = 1,		// start dragging
		DD_DRAG,				// dragging
		DD_DROP,				// drop
		DD_ABORT,			// abort dragging
	};

	// Call this to initialize. 2nd arg is array of DRAGDROPWND's, one for
	// each source/target child window.
	//
	BOOL Install(CWnd *pMainWnd, DRAGDROPWND* pWnds, UINT uCbMsg);

	// You must call this from your main window's PreTranslateMessage.
	BOOL PreTranslateMessage(MSG* pMsg);

	// Call this if you want non-standard cursors.
	void SetCursors(HCURSOR hCursorDrop, HCURSOR hCursorNo)
	{
		m_hCursorDrop = hCursorDrop;
		m_hCursorNo = hCursorNo;
	}

	// useful for debugging
	static LPCTSTR GetNotificationCodeName(UINT nCode);

	// Call these to add/remove source/target windows dynamically.
	void AddWindow(HWND hwnd, int type);
	void RemoveWindow(HWND hwnd);
};
