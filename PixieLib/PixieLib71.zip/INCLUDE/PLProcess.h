////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

#include <psapi.h>			// EnumProcesses, etc.
#include <shlwapi.h>			// DllGetVersion definitions

// link with psapi for EnumProcesses & co.
#pragma comment(linker, "/defaultlib:psapi.lib")

// link with version.lib for VerQueryValue, etc.
#pragma comment(linker, "/defaultlib:version.lib")

//////////////////
// CLoadLibrary loads a DLL. Destructor frees for automatic cleanup.
//
class CLoadLibrary {
private:
	HINSTANCE m_hinst;
public:
	CLoadLibrary(LPCTSTR lpszName) : m_hinst(LoadLibrary(lpszName)) { }
	~CLoadLibrary()		 { FreeLibrary(m_hinst); }
	operator HINSTANCE () { return m_hinst; } 	// cast operator
};

//////////////////
// CModuleVersion provides easy access to read version info from module's
// resource file. For example, to get the VERSIONINFO in the current running
// module:
//
//		CModuleVersion ver;
//		if (ver.dwProductVersionMS>2) {
//			CString s = ver.GetValue(_T("CompanyName"));
//			...
//		}
//
// You can also read the version info for another file like so:
//
//		CModuleVersion ver("foo.exe");
//		...
//
// You can also call the static fn DllGetVersion to get the DLLVERSIONINFO.
//
class DLLCLASS CModuleVersion : public VS_FIXEDFILEINFO {
protected:
	BYTE* m_pVersionInfo;	// all version info

	struct TRANSLATION {
		WORD langID;			// language ID
		WORD charset;			// character set (code page)
	} m_translation;

public:
	CModuleVersion(HMODULE hModule=NULL);
	CModuleVersion(LPCTSTR modulename);
	virtual ~CModuleVersion();

	BOOL	  GetFileVersionInfo(HMODULE hModule=NULL);
	CString GetValue(LPCTSTR lpKeyName);
	static BOOL DllGetVersion(LPCTSTR modulename, DLLVERSIONINFO& dvi);
};

//////////////////
// CWebVersion encapsulates over-the-web version checking. It downloads a text
// file that contains 4 numbers separated by commas, the same format used for
// FILEVERSION and PRODUCTVERSION in VS_VERSION_INFO. ReadVersion reads these
// numbers into dwVersionMS and dwVersionLS. For example, you could add the
// following in your startup code or About dialog to read the latest program
// version number from the FTP area on your web site:
//
// 	// read current version number from web
//		DWORD dwLatestVersion = 0; // assume failure
//		if (CWebVersion::Online()) {	// if connected to internet:
//			CWebVersion ver(_T("ftp.mysite.com"));
//			if (ver.ReadVersion(_T("MyProgramVer")))
//				m_dwLatestVersion = ver.dwVersionMS;
//		}
//
// Now dwLatestVersion contains the latest major version number. You can
// compare it to the version compiled into the code like so:
//
//		CVersionInfo ver;
//		if (dwLatestVersion > ver.dwProductVersionMS) {
//			// prompt user to download update...
//		}
//
class DLLCLASS CWebVersion {
protected:
	enum { BUFSIZE = 64 };
	LPCTSTR m_lpServer;						 // server name
	DWORD	  m_dwError;						 // most recent error code
	TCHAR   m_errInfo[256];					 // extended error info
	char	  m_version[BUFSIZ];				 // version number as text
	void    SaveErrorInfo();				 // helper to save error info

public:
	DWORD dwVersionMS;		// version number: most-sig 32 bits
	DWORD dwVersionLS;		// version number: least-sig 32 bits

	CWebVersion(LPCTSTR server) : m_lpServer(server) { }
	~CWebVersion()	{ }

	static  BOOL Online();
	BOOL	  ReadVersion(LPCTSTR lpFileName);
	LPCSTR  GetVersionText()		 { return m_version; }
	DWORD   GetError()				 { return m_dwError; }
	LPCTSTR GetExtendedErrorInfo() { return m_errInfo; }
};

//////////////////
// Process list. Creates STL vector of process IDs. Use standard STL iterator
// to enumerate items in the array.
//
//		CProcessList pl;
//		pl.Fill();
//		for (CProcessList::iterator it=pl.begin(); it!=pl.end(); it++) {
//			DWORD pid = *it;
//			// do something
//		}
//
// You can derive and override OnProcess to filter specific processes.
//
class DLLCLASS CProcessList : public vector<DWORD> {
protected:
	UINT m_nAlloc;
	// override to filter different kinds of processes
	virtual BOOL OnProcess(DWORD /* pid */) {
		return TRUE;
	}
public:
	CProcessList(UINT nAlloc=64) : m_nAlloc(nAlloc) { }
	virtual ~CProcessList() { }
	UINT Fill();
};

//////////////////
// Process module list. The first module is the main EXE that started the
// process. To use:
//
//		CProcessModuleList pml(pid);
//		pml.Fill();
//		for (CProcessModuleList::iterator it=pml.begin(); it!=pml.end(); it++) {
//			HANDLE  hProcess = pml.GetProcessHandle();
//			HMODULE hMod = *it;
//			// do something
//		}
//
// You can derive and override OnModule to filter specific modules.
//
class DLLCLASS CProcessModuleList : public vector<HMODULE> {
protected:
	DWORD		m_pid;							 // process ID
	UINT		m_nAlloc;						 // increment to allocate buffer
	HANDLE	m_hProcess;						 // process handle
	// override to filter different kinds of modules
	virtual BOOL OnModule(HANDLE /* hMod */) {
		return TRUE;
	}
public:
	CProcessModuleList(DWORD pid, UINT nAlloc=4) : m_pid(pid), m_nAlloc(nAlloc) { }
	virtual ~CProcessModuleList();
	HANDLE GetProcessHandle() { return m_hProcess; }
	UINT Fill();
};

//////////////////
// Application process list--gets all processes associated with a given
// module. For example:
//
//		CAppProcessList apl("Outlook");
//		apl.Fill();
//		for (CAppModuleList::iterator it=apl.begin(); it!=apl.end(); it++) {
//			DWORD pid = *it;
//			CAppProcessList::KillProcess(pid);		// kill process
//		}
//
// This will find and kill processes whose main module name is "Outlook" or
// "Outlook.exe". KillProcess tries to kill the process gracefully, by sending
// WM_QUERYENDSESSION and WM_CLOSE to all its main windows.
//
class DLLCLASS CAppProcessList : public CProcessList {
protected:
	// override
	virtual BOOL OnProcess(DWORD pid);
public:
	CString m_sAppName;					 // name of app/module whose processes to list
	CAppProcessList(LPCTSTR lpAppName) : m_sAppName(lpAppName) { }
	~CAppProcessList() { }
	static BOOL KillProcess(DWORD pid, BOOL bZap);
};
