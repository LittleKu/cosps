////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#pragma once

// when using screen dimensions, this is infinite
const LONG INFINITY=0x7fff; // max short

// useful size constants
#define SIZEZERO		CSize(0,0)
#define SIZEMAX		CSize(INFINITY,INFINITY)

// handy functions to take the min or max of a CSize
inline CSize minsize(CSize a, CSize b) {
	return CSize(min((UINT)a.cx,(UINT)b.cx),min((UINT)a.cy,(UINT)b.cy));
}

inline CSize maxsize(CSize a, CSize b) {
	return CSize(max((UINT)a.cx,(UINT)b.cx),max((UINT)a.cy,(UINT)b.cy));
}

//////////////////
// Size info about a WinMgr rectangle/row/column. CWinMgr sends your window a
// WM_WINMGR message with one of these in NMWINMGR::sizeinfo with the
// NMWINMGR::GET_SIZEINFO notification. You can change the members szDesired,
// szMin or szMax for custom sizing.
//
struct SIZEINFO {
	SIZE szAvail;		// total size avail (passed)
	SIZE szDesired;	// desired size: default=current
	SIZE szMin;			// minimum size: default=SIZEZERO
	SIZE szMax;			// maximum size: default=MAXSIZE
};

// types of rectangles:
#define	WRCT_FIXED		0x0001		// height/width is fixed
#define	WRCT_PCT			0x0002		// height/width is percent of total
#define	WRCT_REST		0x0003		// height/width is whatever remains
#define	WRCT_TOFIT		0x0004		// height/width to fit contents
#define	WRCF_TYPEMASK	0x000F		// mask for type
#define	WRCT_END			0				// end of table

// group flags
#define	WRCF_ROWGROUP	0x0010		// beginning of row group
#define	WRCF_COLGROUP	0x0020		// beginning of column group
#define	WRCF_ENDGROUP	0x00F0		// end of group
#define	WRCF_GROUPMASK	0x00F0

//////////////////
// This structure is used to hold a rectangle and describe its layout. Each
// WINRECT corresponds to a child rectangle/window. Each window that uses
// WinMgr provides a table (C array) of these to describe its layout.
// Generally, you don't need to use this struct directly; instead, use
// DECLARE_WINDOW_MAP(name) to declare your window map and
// BEGIN/END_WINDOW_MAP to implement it. See MultWin.
//
class DLLCLASS WINRECT { // used internally
protected:
	// pointers initialized by the window manager for easy traversing:
	WINRECT* next;			// next at this level
	WINRECT* prev;			// prev at this level

	// data
	CRect rc;				// current rectangle position/size
	WORD  flags;			// flags (see above)
	int	nID;				// window ID if this WINRECT represents a window
	LONG	param;			// arg depends on type

public:
	WINRECT(WORD f, int id, LONG p);

	static WINRECT* InitMap(WINRECT* map, WINRECT* parent=NULL);

	WINRECT* Prev()			{ return prev; }
	WINRECT* Next()			{ return next; }
	WINRECT* Children()		{ return IsGroup() ? this+1 : NULL; }
	WINRECT* Parent();
	WORD GetFlags()			{ return flags; }
	WORD SetFlags(WORD f)	{ return flags=f; }
	LONG GetParam()			{ return param; }
	LONG SetParam(LONG p)	{ return param=p; }
	UINT GetID()				{ return nID; }
	UINT SetID(UINT id)		{ return nID=id; }
	CRect& GetRect()					{ return rc; }
	void SetRect(const CRect& r)	{ rc = r; }
	WORD Type() const			{ return flags & WRCF_TYPEMASK; }
	WORD GroupType() const	{ return flags & WRCF_GROUPMASK; }
	BOOL IsGroup() const		{ return GroupType() && GroupType()!=WRCF_ENDGROUP; }
	BOOL IsEndGroup() const { return flags==0 || flags==WRCF_ENDGROUP; }
	BOOL IsEnd() const		{ return flags==0; }
	BOOL IsWindow() const	{ return nID>0; }
	BOOL IsRowGroup()	const { return (flags & WRCF_GROUPMASK)==WRCF_ROWGROUP; }
	void SetHeight(LONG h)	{ rc.bottom = rc.top + h; }
	void SetWidth(LONG w)	{ rc.right = rc.left + w; }
	LONG GetHeightOrWidth(BOOL bHeight) const {
		return bHeight ? rc.Height() : rc.Width();
	}
	void SetHeightOrWidth(LONG horw, BOOL bHeight) {
		bHeight ? SetHeight(horw) : SetWidth(horw);
	}
	BOOL GetMargins(int& w, int& h);

	// For TOFIT types, param is the TOFIT size, if nonzero. Used in dialogs,
	// with CWinMgr::InitToFitSizeFromCurrent.
	BOOL HasToFitSize()			{ return param != 0; }
	SIZE GetToFitSize()			{ return CSize(LOWORD(param),HIWORD(param)); }
	void SetToFitSize(SIZE sz)	{ param = MAKELONG(sz.cx,sz.cy); }
};

//////////////////
// Below are all the macros to build your window map. 
//
#define DECLARE_WINDOW_MAP(name)	static WINRECT name[];

// Begin/end window map. 'name' can be anything you want
#define BEGIN_WINDOW_MAP(name)	WINRECT name[] = {
#define END_WINDOW_MAP()			WINRECT(WRCT_END,(UINT)-1,0) }; 

// Begin/end a group.
// The first entry in your map must be BEGINROWS or BEGINCOLS.
#define BEGINROWS(type,id,m)	WINRECT(WRCF_ROWGROUP|type,id,m),
#define BEGINCOLS(type,id,m)  WINRECT(WRCF_COLGROUP|type,id,m),
#define ENDGROUP()				WINRECT(WRCF_ENDGROUP,(UINT)-1,0),

// This macros is used only with BEGINGROWS or BEGINCOLS to specify margins
#define RCMARGINS(w,h)			MAKELONG(w,h)

// Macros for primitive (non-group) entries.
// val applies to height for a row entry; width for a column entry.
#define RCFIXED(id,val)		WINRECT(WRCT_FIXED,id,val),
#define RCPERCENT(id,val)	WINRECT(WRCT_PCT,id,val),
#define RCREST(id)			WINRECT(WRCT_REST,id,0),
#define RCTOFIT(id)			WINRECT(WRCT_TOFIT,id,0),
#define RCSPACE(val)			RCFIXED(-1,val)

//////////////////
// CWinMgr uses this internal class to iterate the WINRECT entries in a group.
// You don't need to use this class unless you override CWinMgr to do
// something hairy.
//
//		CWinGroupIterator it;
//		for (it=pGroup; it; it.Next()) {
//			WINRECT* wrc = it;
//			..
//		}
//
class DLLCLASS CWinGroupIterator { // used internally
protected:
	WINRECT* pCur;	  // current entry
public:
	CWinGroupIterator() { pCur = NULL; }
	CWinGroupIterator& operator=(WINRECT* pg) {
		ASSERT(pg->IsGroup()); // can only iterate a group!
		pCur = pg->Children();
		return *this;
	}
	operator WINRECT*()	{ return pCur; }
	WINRECT* pWINRECT()	{ return pCur; }
	WINRECT* Next()		{ return pCur = pCur ? pCur->Next() : NULL;}
};

// Registered WinMgr message
extern DLLCLASS const UINT WM_WINMGR;

//////////////////
// Notification struct sent by CWinMgr as LPARAM in the WM_WINMGR message.
// Currently there are two notifications sent: GET_SIZEINFO when CWinMgr wants
// to know the desired size of one of your TOFIT windows; and SIZEBAR_MOVED
// when the user moves a sizer bar.
//
// * When you receive GET_SIZEINFO, you should set the desired size for your
// window in NMWINMGR::sizeinfo.
//
//		LRESULT CMyView::OnWinMgr(WPARAM wp, LPARAM lp)
//		{
//			ASSERT(lp);
//			NMWINMGR& nmw = *(NMWINMGR*)lp;
//			if (nmw.code==NMWINMGR::GET_SIZEINFO) {
//				CRect rc = // calculate desired size
//				nmw.sizeinfo.szDesired = rc.Size();
//				return TRUE; // handled -- important!
//			}
//		}
//
// - You should also set szMin and/or szMax if you want to restrict your
// window's minimum/maximum size.
//
// * When you get SIZEBAR_MOVED, all you typically have to do is call CWinMgr
// to move the affected windows:
//
//		LRESULT CMyView::OnWMWinMgr(WPARAM wp, LPARAM lp)
//		{
//			ASSERT(lp);
//			NMWINMGR& nmw = *(NMWINMGR*)lp;
//			if (nmw.code==NMWINMGR::SIZEBAR_MOVED) {
//				// wp is child window ID
//				m_winMgr.MoveRect(wp, nmw.sizebar.ptMoved, this);
//				m_winMgr.SetWindowPositions(this);
//			}
//		}
//
// See MultiWin for details.
//
struct DLLCLASS NMWINMGR : public NMHDR {
	enum {								// notification codes:
		GET_SIZEINFO = 1,				// WinMgr is requesting size info
		SIZEBAR_MOVED,					// user moved sizer bar
	};

	// each notification code has its own part of union
	union {
		SIZEINFO sizeinfo;	// used for GET_SIZEINFO
		struct {					// used for SIZEBAR_MOVED
			POINT ptMoved;		//  distance moved (x or y = zero)
		} sizebar;
	};

	// ctor: initialize to zeroes
	NMWINMGR() { memset(this,0,sizeof(NMWINMGR)); }
};

///////////////////
// CWinMgr implements automatic rule-based sizing for child windows. Use the
// macros BEGIN/END_WINDOW_MAP to define a window map that describes the
// layout of the child windows, and call the CalcLayout method from your
// OnSize handler to automatically resize your child windows based on the
// rules. For main frames, override CMainFrame::RecalcLayout; for dialogs,
// derive your dialog from CSizeableDlg.
//
// To use CWinMgr, you first define a table that describes the rules for
// sizing your child windows. For example:
//
//		BEGIN_WINDOW_MAP(MyViewMap)
//		 BEGINCOLS(WRCT_REST,0,RCMARGINS(4,4)) // whole view: 4 pixel margins
//		  BEGINROWS(WRCT_TOFIT,0,0)				//   left pane
//			RCTOFIT(ID_WIN_LOGO2)					//     bitmap
//			RCTOFIT(ID_WIN_LOGO1)					//     bitmap
//			RCREST(ID_WIN_LICENSE)					//     text
//		  ENDGROUP()
//		  RCFIXED(ID_WIN_SIZERBAR_VERT,4)		//  vertical sizer bar
//		  BEGINROWS(WRCT_REST,0,0)					//   right half
//			RCREST(ID_WIN_EDIT)						//     edit view
//			RCFIXED(ID_WIN_SIZERBAR_HORZ,4)		//     horizontal sizer bar
//			RCTOFIT(ID_WIN_DOPEY)					//     dopey pane
//		  ENDGROUP()
//		 ENDGROUP()
//		END_WINDOW_MAP()
//
// Each entry in the table is a WINRECT that describes either a group or a
// single child window. Groups can be groups of rows or columns. Each WINRECT
// has one of the following types (see above for details):
//
//		WRCT_FIXED - height/width is fixed
//		WRCT_PCT   - height/width is percent of total
//		WRCT_REST  - height/width is whatever remains, only one per group
//		WRCT_TOFIT - height/width to fit window contents
//
// Note that the type refers to the height for rectangles within a row group
// and the width for rectangles in column groups. For WRCT_TOFIT entries,
// CWinMgr uses the current window size and sends a NMWINMGR notification with
// code GET_SIZEINFO to get the desired size. You should set
// NMWINMGR::sizeinfo.szDesired to the desired window size.
//
// For a detailed description of how CWinMgr, see my article in the July 2001
// MSDN Magazine: http://msdn.microsoft.com/msdnmag/issues/01/07/winmgr/. The
// version in PixieLib has new features and bug fixes implemented since the
// original article.
//
class DLLCLASS CWinMgr : public CObject {
public:
	CWinMgr(WINRECT* map);
	virtual ~CWinMgr();

	virtual void GetWindowPositions(CWnd* pWnd); // load map from window posns
	virtual void SetWindowPositions(CWnd* pWnd); // set window posns from map

	// get min/max/desired size of a rectangle
	virtual void OnGetSizeInfo(SIZEINFO& szi, WINRECT* pwrc, CWnd* pWnd=NULL);

	// calc layout using client area as total area
	void CalcLayout(CWnd* pWnd)
	{
		ASSERT(pWnd);
		CRect rcClient;
		pWnd->GetClientRect(&rcClient);
		CalcLayout(rcClient, pWnd);
	}

	// calc layout using cx, cy (for OnSize)
	void CalcLayout(int cx, int cy, CWnd* pWnd=NULL)
	{
		CalcLayout(CRect(0,0,cx,cy), pWnd);
	}

	// calc layout using given rect as total area
	void CalcLayout(CRect rcTotal, CWnd* pWnd=NULL)
	{
		ASSERT(m_map);
		m_map->SetRect(rcTotal);
		CalcGroup(m_map, pWnd);
	}

	// Move rectangle vertically or horizontally. Used with sizer bars.
	void MoveRect(int nID, CPoint ptMove, CWnd* pParentWnd)
	{
		MoveRect(FindRect(nID), ptMove, pParentWnd);
	}
	void MoveRect(WINRECT* pwrcMove, CPoint ptMove, CWnd* pParentWnd);

	CRect GetRect(UINT nID)
	{
		return FindRect(nID)->GetRect();
	}
	void SetRect(UINT nID, const CRect& rc)
	{
		FindRect(nID)->SetRect(rc);
	}

	// get WINRECT corresponding to ID
	WINRECT* FindRect(UINT nID);

	// Calculate MINMAXINFO
	void GetMinMaxInfo(CWnd* pWnd, MINMAXINFO* lpMMI);
	void GetMinMaxInfo(CWnd* pWnd, SIZEINFO& szi);

	// set TOFIT size for all windows from current window sizes
	void InitToFitSizeFromCurrent(CWnd* pWnd);

	void TRACEDump() const { TRACEDump(m_map); }
	void TRACEDump(WINRECT* map) const;

protected:
	WINRECT*	m_map;			// THE window map

	int  CountWindows();
	BOOL SendGetSizeInfo(SIZEINFO& szi, CWnd* pWnd, UINT nID);

	// you can override to do weird stuff or fix bugs
	virtual void CalcGroup(WINRECT* group, CWnd* pWnd);
	virtual void AdjustSize(WINRECT* pEntry, BOOL bRow,
		int& hwRemaining, CWnd* pWnd);
	virtual void PositionRects(WINRECT* pGroup,
		const CRect& rcTotal,BOOL bRow);

private:
	CWinMgr() { ASSERT(FALSE); } // no default constructor
};

//////////////////
// CSizerBar (a better splitter window) lets users adjust the size of two
// siblings. See MultiWin for example how to use.
//
class DLLCLASS CSizerBar : public CStatic {
public:
	CSizerBar();
	virtual ~CSizerBar();
	BOOL Create(DWORD dwStyle,				 // window styles
		CWnd* pParentWnd,						 // parent window
		CWinMgr& wmgr,							 // window manger
		UINT nID,								 // ID of sizer bar
		const RECT& rc = CRect(0,0,0,0)); // initial rectangle

protected:
	CWinMgr* m_pWinMgr;			// window manager
	BOOL		m_bHorz;				// horizontal bar; else vertical
	BOOL		m_bDragging;		// in drag mode?
	CPoint	m_ptPrevious;		// previous mouse pos during dragging
	HWND		m_hwndPrevFocus;	// to restore after dragging

	// helpers
	void CancelDrag();					 // cancel drag mode
	BOOL IsHorizontal();					 // is bar horizontal?
	void NotifyMoved(CPoint ptDelta); // send move notification to parent

	// MFC overrides & message handlers
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg void OnPaint();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT msg);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint pt);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint pt);
	afx_msg void OnMouseMove(UINT nFlags, CPoint pt);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnCancelMode();

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CSizerBar)
};

//////////////////
// Generic WinMgr-based sizeable dialog. To create a sizeable dialog, derive
// from this, create a window map using BEGIN/END_WINDOW_MAP, and pass it to
// your constructor. Otherwise (if you don't derive from CSizeableDlg), mimic
// OnInitDialog, OnSize, OnGetMinMaxInfo. See MultWin sample for details.
//
class DLLCLASS CSizeableDlg : public CDialog {
public:
	CSizeableDlg(UINT nID, CWnd* pParent, WINRECT* pWinMap);
	~CSizeableDlg();

protected:
	CWinMgr m_winMgr;	  // window manager

	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg LRESULT OnWinMgr(WPARAM wp, LPARAM lp);

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CSizeableDlg)
};
