////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

// THE popup tip window
CPopupText CListBoxTipHandler::g_wndTip;

// Timeout before showing long list box tip -- you can change
UINT CListBoxTipHandler::g_nTipTimeMsec = 100; // .1 sec

CListBoxTipHandler::CListBoxTipHandler()
{
	m_nCurItem=(UINT)-1;
	m_bCapture = FALSE;
}

CListBoxTipHandler::~CListBoxTipHandler()
{
}

//////////////////
// Install hook. Initialize control ID from list box and create
// (invisible) tip window.
//
void CListBoxTipHandler::Init(CWnd* pListBox)
{
	CSubclassWnd::HookWindow(pListBox);
	if (!g_wndTip) {
		// create scroll tip window
		g_wndTip.Create(CPoint(0,0), NULL, 0);
	}
}

//////////////////
// "Hook" function traps messages sent to list box/control. 
//
LRESULT CListBoxTipHandler::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg) {
	case WM_LBUTTONDOWN:
		Cancel();	// possible drag-drop: cancel tip
		break;
	case WM_MOUSEMOVE:
		OnMouseMove(CPoint(GET_X_LPARAM(lp),GET_Y_LPARAM(lp)));
		break;
	}
	return CSubclassWnd::WindowProc(msg, wp, lp);
}

/////////////////
// User moved the mouse: Get info for list box item under mouse. If text is too
// wide to fit in list box, show tip window. Cancel if not over an item.
//
void CListBoxTipHandler::OnMouseMove(CPoint pt)
{
	CListBox* pListBox = (CListBox*)CWnd::FromHandle(m_hWnd);
	if (!m_bCapture) {
		::SetCapture(m_hWnd);
		m_bCapture = TRUE;
	}

	// Get text and text rectangle for item under mouse
	CString sText;	// item text
	CRect rcText;	// item text rect
	UINT nItem = OnGetItemInfo(pt, rcText, sText);

	if (nItem != m_nCurItem) {
		g_wndTip.Cancel();
		if (nItem>=0 && !IsRectCompletelyVisible(rcText)) {
			// new item, and not wholly visible: prepare popup tip
			CRect rc = rcText;
			pListBox->ClientToScreen(&rc);	// text rect in screen coords
			g_wndTip.SetWindowText(sText);	// set tip text to that of item

			// move tip window over list text
			g_wndTip.SetWindowPos(NULL, rc.left-3, rc.top, rc.Width()+6,
				rc.Height(), SWP_NOZORDER|SWP_NOACTIVATE);

			g_wndTip.ShowDelayed(g_nTipTimeMsec); // show popup text delayed
		}
	}
	m_nCurItem = nItem;

	if (nItem == -1)
		Cancel(); // not on item: cancel
}

void CListBoxTipHandler::Cancel()
{
	::ReleaseCapture();
	m_bCapture=FALSE;
	g_wndTip.Cancel();
}

//////////////////
// Determine if given rectangle is completely visible within list box
//
BOOL CListBoxTipHandler::IsRectCompletelyVisible(const CRect& rc)
{
	CListBox* pListBox = (CListBox*)CWnd::FromHandle(m_hWnd);
	CRect rcClient;
	pListBox->GetClientRect(&rcClient);
	return rcClient.Width() > rc.Width();
}

//////////////////
// Get info (rectangle and text) for item under point
//
UINT CListBoxTipHandler::OnGetItemInfo(CPoint p, CRect& rc, CString& s)
{
	CListBox* pListBox = (CListBox*)CWnd::FromHandle(m_hWnd);
	ASSERT_VALID(pListBox);
	BOOL bOutside;
	UINT nItem = pListBox->ItemFromPoint(p,bOutside);
	s.Empty();
	if (!bOutside) {
		pListBox->GetText(nItem, s);
		pListBox->GetItemRect(nItem, &rc);
		CFont *pFont = pListBox->GetFont();
		CClientDC dc(pListBox);
		CFont* pOldFont = dc.SelectObject(pFont);
		dc.DrawText(s,&rc,DT_CALCRECT);
		dc.SelectObject(pOldFont);
		return nItem;
	}
	return (UINT)-1;
}
