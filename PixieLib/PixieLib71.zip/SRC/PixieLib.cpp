////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

// symbol used to force-link this module
// int linkPixieLib;

static TCHAR _libcredit[] = 
_T("PixieLib.NET Class Library Copyright 2005 Paul DiLascia.");

////////////////////////////////////////////////////////////////
// Instantiate global objects
//
GMouse	 TheMouse;
GKeyboard TheKeyboard;
GCursor	 TheCursor;

//////////////////
// Helper writes prompt to status bar 
//
static void DoPrompt(WPARAM wp, LPARAM lp, BOOL bUpdateNow)
{
	CWnd* pWnd = AfxGetMainWnd();
	if (pWnd) {
		pWnd->SendMessage(WM_SETMESSAGESTRING, wp, lp);
		if (bUpdateNow)
			pWnd->UpdateWindow();
	}
	
}

// write char string to prompt
void PLPrompt(LPCTSTR lpText, BOOL bUpdateNow)
{
	DoPrompt(0, (LPARAM)lpText, bUpdateNow);
}

// write resource string to status bar
void PLPrompt(UINT nResID, BOOL bUpdateNow)
{
	DoPrompt(nResID, 0, bUpdateNow);
}

#if defined(BUILD_PIXIE_DLL)
//////////////// Building DLL: implement MFC DLL extension module ////////////////

#include <afxdllx.h> // include source code for MFC extension module 

// my extension module
static AFX_EXTENSION_MODULE PixieDLL = { NULL, NULL };

// Main entry point
extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /* lpReserved */)
{

#ifdef _DEBUG
	TCHAR fn[_MAX_PATH];
	GetModuleFileName(hInstance, fn, _MAX_PATH);
#endif

	if (dwReason == DLL_PROCESS_ATTACH) {
		TRACE1("%s Initializing\n", fn);
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(PixieDLL, hInstance))
			return 0;

		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an ActiveX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.

		new CDynLinkLibrary(PixieDLL);

	} else if (dwReason == DLL_PROCESS_DETACH) {
		TRACE1("%s Terminating\n", fn);

		// Terminate the library before destructors are called
		AfxTermExtensionModule(PixieDLL);
	}
	return 1;   // ok
}

#endif // defined(BUILD_PIXIE_DLL)
