////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CLockBars::CLockBars() : m_bLocked(0), m_pFrame(NULL)
{
}

CLockBars::~CLockBars()
{
	Clear();
}

//////////////////
// Destroy all hooks
//
void CLockBars::Clear()
{
	m_pFrame = NULL;
	CHookList& list = m_hooklist;
	for (CHookList::iterator it=list.begin(); it!=list.end(); it++) {
		delete *it;
	}
	list.clear();
}

//////////////////
// Install: add hook for every control bar that has a docking context.
// This should correspond to all toolbars/dialog bars that can be docked.
//
void CLockBars::Install(CFrameWnd* pFrame)
{
	Clear();
	m_pFrame = pFrame;
	if (pFrame) {
		POSITION pos = pFrame->m_listControlBars.GetHeadPosition();
		while (pos) {
			CControlBar* pBar = (CControlBar*)pFrame->m_listControlBars.GetNext(pos);
			ASSERT(pBar);
			if (pBar->m_pDockContext) {
				PLTRACE(_T("CLockBars: add control bar: %p\n"), pBar);
				CHook* pHook = new CHook();
				pHook->Install(this, pBar);
				m_hooklist.push_back(pHook);
			}
		}
	}
}

//////////////////
// Set/clear the lock state for all toolbars. For each toolbar: turn gripper
// on or off as appropriate. Save locked state in m_bLocked so hooks will
// disallow dragging the toolbar if lock is set.
//
void CLockBars::SetLocked(BOOL bLocked)
{
	CFrameWnd* pFrame = m_pFrame;
	if (pFrame) {
		POSITION pos = pFrame->m_listControlBars.GetHeadPosition();
		while (pos) {
			CControlBar* pBar = (CControlBar*)pFrame->m_listControlBars.GetNext(pos);
			ASSERT(pBar);
			if (pBar->m_pDockContext) {
				DWORD dwStyle = pBar->GetBarStyle();
				if (bLocked) {
					pFrame->DockControlBar(pBar);	 // dock if not already
					dwStyle &= ~CBRS_GRIPPER;		 // turn off gripper
				} else {
					dwStyle |= CBRS_GRIPPER;
				}
				pBar->SetBarStyle(dwStyle);
			}
		}
		pFrame->RecalcLayout();				 // make frame recalc toolbar sizes
	}
	m_bLocked = bLocked;						 // save state
}

/////////////////
// Install hook: store back pointer to CLockBars and hook the control bar.
//
BOOL CLockBars::CHook::Install(CLockBars* pLock, CControlBar* pBar)
{
	ASSERT(pLock);
	ASSERT(pBar);
	m_pLock = pLock;
	m_pBar = pBar;
	return HookWindow(pBar);
}

//////////////////
// Trap messages sent to control bar: disallow dragging if toolbars are locked.
//
LRESULT CLockBars::CHook::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	if ((msg==WM_LBUTTONDOWN || msg==WM_LBUTTONDBLCLK) && m_pLock->m_bLocked) {
		// Got click or double-click and toolbar is locked: if mouse in "dead
		// zone" then ignore the message--don't pass to control bar
		//
		CPoint pt(lp);
		CWnd* pWnd = CWnd::FromHandle(m_hWnd);
		if (pWnd->OnToolHitTest(pt, NULL) == -1)
			return 0; // return without handling: bypass control bar dragging!
	}
	// pass unhandled messages subclassed window--this is important!
	return CSubclassWnd::WindowProc(msg, wp, lp);
}

