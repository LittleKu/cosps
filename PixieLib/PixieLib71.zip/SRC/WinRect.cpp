////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CWinRect makes it easier to get and manipulate window rectangles

#include "StdPxl.h"

//////////////////
// Common constructor worker fn for CWinRect. Stuffs rect w/appropriate
// window dimensions in appropriate coords:
//
//   which = CLIENT			Get client area in client coords top left = (0,0)
//   which = CLIENTSCREEN	Get client area in screen coords
//   which = WINDOW			Get window area in screen coords
//   which = WINDOWCLIENT	(strange) Get window area in client coords
//   which = MDICLIENT		Get MDI client win client area in window coords;
//									pWnd must be MDI Frame window
//
void CWinRect::Construct(CWnd *pWnd, int which)
{
	ASSERT_VALID(pWnd);
	switch (which) {
	default:
		ASSERT(FALSE);
	case CLIENT:
	case CLIENTSCREEN:
		pWnd->GetClientRect(this); 
		if (which==CLIENTSCREEN)
			pWnd->ClientToScreen(this);
		break;

	case WINDOW:
	case WINDOWCLIENT:
		pWnd->GetWindowRect(this); 
		if (which==WINDOWCLIENT)
			pWnd->ScreenToClient(this);
		break;

	case MDICLIENT:
		// get rectangle for MDI client--assumes pWnd is MDI frame
		HWND hwnd = GetWindow(pWnd->m_hWnd, GW_CHILD);
		ASSERT_KINDOF(CMDIFrameWnd, pWnd);
		ASSERT(hwnd);
		GetWindowRect(hwnd, (LPRECT)this);
		break;
	}
}

//////////////////
// Capture a point.
// That is, alter the point so that it lies within the rectangle.
//
void CWinRect::CapturePt(CPoint &pt)
{	
	CWinRect rc = *this;
	rc.Normalize();
	pt.x = min(max(pt.x, rc.left), rc.right-1); 
	pt.y = min(max(pt.y, rc.top),  rc.bottom-1); 
}

//////////////////
// Make sure that left <= right and top <= bottom.
// 
void CWinRect::Normalize()
{
	if (left > right) {
		int r = right;
		right = left;
		left = r;
	}
	if (top > bottom) {
		int b = bottom;
		bottom = top;
		top = b;
	}
}

//////////////////
// Center rectangle in another rectangle
// Before: this contains rectangle of desired width, height.
// After:  this contains rectangle of same width, height, centered
// within rc. Will shrink this if necessary. Returns TRUE if rectangle
// fits within rc, FALSE otherwise.
//
BOOL CWinRect::CenterInRect(const CRect& rc)
{
	BOOL bFits = TRUE;
	int width =  Width();
	int height = Height();
	int xmargin = (rc.Width()-width)/2;
	if (xmargin<0) {
		xmargin=0;
		bFits = FALSE;
	}
	int ymargin = (rc.Height()-height)/2;
	if (ymargin<0) {
		ymargin=0;
		bFits = FALSE;
	}
	*this += CPoint(rc.left + xmargin - left, rc.top + ymargin - top);
	return bFits;
}

