////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CPalMsgHandler, CSubclassWnd);

CPalMsgHandler::CPalMsgHandler()
{
	m_pPalette = NULL;
}

CPalMsgHandler::~CPalMsgHandler()
{
}

//////////////////
// Message handler handles palette-related messages
//
LRESULT CPalMsgHandler::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	ASSERT(m_hWnd);

	switch (msg) {
	case WM_PALETTECHANGED:
		OnPaletteChanged(CWnd::FromHandle((HWND)wp));
		return 0;
	case WM_QUERYNEWPALETTE:
		return OnQueryNewPalette();
	case WM_SETFOCUS:
		OnSetFocus(CWnd::FromHandle((HWND)wp));
		return 0;
	}
	return CSubclassWnd::WindowProc(msg, wp, lp);
}

//////////////////
// Handle WM_PALETTECHANGED
//
void CPalMsgHandler::OnPaletteChanged(CWnd* pFocusWnd)
{
	ASSERT(m_hWnd);
	CWnd& wnd = *CWnd::FromHandle(m_hWnd);

	PLTRACEFN(_T("CPalMsgHandler::OnPaletteChanged for %s [from %s]\n"), 
		_TR(&wnd), _TR(pFocusWnd));

	if (pFocusWnd->GetSafeHwnd() != wnd.m_hWnd) {
		if (DoRealizePalette(FALSE)==0) {
			if (wnd.GetParent()==NULL) {
				// I'm the top-level frame: Broadcast to children
				// (only MFC permanent CWnd's!)
				//
				const MSG& curMsg = AfxGetThreadState()->m_lastSentMsg;
				wnd.SendMessageToDescendants(WM_PALETTECHANGED,
					curMsg.wParam, curMsg.lParam);
			}
		}
	} else {
		// I'm the window that triggered the WM_PALETTECHANGED
		// in the first place: ignore it
		//
		PLTRACE(_T("[It's me, don't realize palette.]\n"));
	}
}

//////////////////
// Handle WM_QUERYNEWPALETTE
//
BOOL CPalMsgHandler::OnQueryNewPalette()
{
	ASSERT(m_hWnd);
	CWnd& wnd = *CWnd::FromHandle(m_hWnd);

	PLTRACEFN(_T("CPalMsgHandler::OnQueryNewPalette for %s\n"), _TR(&wnd));

	if (DoRealizePalette(TRUE)==0) {	// realize in foreground
		// No colors changed: if this is the top-level frame,
		// give active view a chance to realize itself
		//
		if (wnd.GetParent()==NULL && wnd.IsFrameWnd()) {
			CWnd* pView = ((CFrameWnd&)wnd).GetActiveFrame()->GetActiveView();
			if (pView) 
				pView->SendMessage(WM_QUERYNEWPALETTE);
		}
	}
	return TRUE;
}

//////////////////
// Handle WM_SETFOCUS
//
void CPalMsgHandler::OnSetFocus(CWnd* /* pOldWnd */) 
{
	ASSERT(m_hWnd);
	CWnd& wnd = *CWnd::FromHandle(m_hWnd);

	PLTRACEFN(_T("CPalMsgHandler::OnSetFocus for %s\n"), _TR(&wnd));

	wnd.SetForegroundWindow();		// Windows likes this
	DoRealizePalette(TRUE);			// realize in foreground
	Default();							// let app handle focus message too
}

/////////////////
// Function to actually realize the palette.
// Override this to do different kind of palette realization; e.g.,
// DrawDib instead of setting the CPalette.
//
int CPalMsgHandler::DoRealizePalette(BOOL bForeground)
{
	if (!m_pPalette || !m_pPalette->m_hObject)
		return 0;

	ASSERT(m_hWnd);
	CWnd& wnd = *CWnd::FromHandle(m_hWnd);

	PLTRACEFN(_T("CPalMsgHandler::DoRealizePalette(%s) for %s\n"),
		bForeground ? _T("foreground") : _T("background"), _TR(&wnd));

	CClientDC dc(&wnd);
	CPalette* pOldPal = dc.SelectPalette(m_pPalette, !bForeground);
	int nColorsChanged = dc.RealizePalette();
	if (pOldPal)
		dc.SelectPalette(pOldPal, TRUE);
	if (nColorsChanged > 0)
		wnd.Invalidate(FALSE); // repaint

	PLTRACE(_T("[%d colors changed]\n"), nColorsChanged);

	return nColorsChanged;
}
