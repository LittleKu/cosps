////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Parse a command line parameter/token. Just add it to the table.
// 
void CPLCommandLineInfo::ParseParam(const TCHAR* pszParam, BOOL bFlag, BOOL bLast)
{
	if (bFlag) {
		// this is a "flag" (begins with / or -)
		m_options[pszParam] = "TRUE";		// default value is "TRUE"
		m_sLastOption = pszParam;			// save in case other value specified

	} else if (!m_sLastOption.IsEmpty()) {
		// last token was option: set value
		m_options[m_sLastOption] = pszParam;
		m_sLastOption.Empty(); // clear
	}

	// Call base class so MFC can see this param/token.
	CCommandLineInfo::ParseParam(pszParam, bFlag, bLast);
}

BOOL CPLCommandLineInfo::GetOption(LPCTSTR option, CString& val)
{
	return m_options.Lookup(option, val);
}
