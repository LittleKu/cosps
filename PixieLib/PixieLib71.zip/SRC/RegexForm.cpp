////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"
#include <PLRegex.h>

// NULL or empty field used when GetFieldInfo can't find field
CRegexForm::FLDINFO CRegexForm::NULLFLD;

//////////////////
// ctor: initialize
//
CRegexForm::CRegexForm()
{
	m_bImmedVal = FALSE;			// default: don't do immediate validation
	m_pWndFeedback = NULL;		// no "feedback" window
	m_clrError = RGB(255,0,0);	// red
	m_clrFeedback = 0;			// current feedback window color: none
	SetShowHints(TRUE);			// default: show hints
}

//////////////////
// dtor: nothing to do
//
CRegexForm::~CRegexForm()
{
}

/////////////////
// Initialize regex form. See header file.
//		-Allocate FLDINFO array and copy basic data from caller's map.
//		-Load/parse main resource string
//		-Load/parse field strings
//		-Create "hint" window
//		-Install dialog hook to trap dialog messages
//		-Install edit hooks if needed to enforce for legal character
// 
void CRegexForm::Init(RGXFIELDMAP map, CDialog* pDlg, UINT nIDDfltStrs,
	UINT msgCallback)
{
	ASSERT(pDlg && pDlg->m_hWnd);
	m_pDlg = pDlg;
	m_msgCallback = msgCallback;
	
	// Count number map entries. Must be NULL-terminated!
	int nFields = 0;
	for (int len=0; map[len].id; len++)
		nFields++;

	// Load main resource string and parse it
	CString strs;
	VERIFY(strs.LoadString(nIDDfltStrs));
	vector<CString> dfltstrs = CRegex::Split(strs, _T("\n"));
	const UINT NRGXSTRS = 4;
	ASSERT(dfltstrs.size()==NRGXSTRS);
	m_sError      = dfltstrs[0];	// "Error %s" string
	m_sRequired   = dfltstrs[1];	// "required" string
	m_sFldErrPfx  = dfltstrs[2];	// default fld error msg, will combine w/hint
	m_sDfltErrMsg = dfltstrs[3];	// default error message

	// Now build FLDINFO array. Each entry based on RGXFIELD map entry, but
	// adds additional members to hold dynamic runtime data.
	//
	m_fldinfo.reserve(nFields);		// pre-allocate for efficiency
	for (int i=0; i<nFields; i++) {	// for each field in map:
		FLDINFO fld;						// create FLDINFO
		((RGXFIELD&)fld) = map[i];		// copy base part from app's map

		// Load and parse each field descriptor string. It contains
		// substrings separated by newlines (\n): field name, regex,
		// legal chars, hint, error msg.
		//
		CString fldstr;
		VERIFY(fldstr.LoadString(fld.id));
		vector<CString> substrs = CRegex::Split(fldstr, _T("\n"));
		size_t len = substrs.size();
		ASSERT(len>=1);
		fld.name = substrs[0]; // field name
		if (len>1) { // regex:
			fld.regex.Parse(substrs[1], !fld.bIgnoreCase);
			ValidatePseudo(fld, substrs[1], TRUE); // initialize pseudo-constraints
		}
		if (len>2 && !substrs[2].IsEmpty()) { // legal chars:
			// install edit hook. will delete itself when edit ctl is destroyed.
			new CEditHook(pDlg, fld.id, substrs[2]);
		}
		if (len>3) // hint
			fld.hint = substrs[3];
		if (len>4) {											// if error message:
			fld.errmsg = substrs[4];						// ..use it
		} else if (!fld.hint.IsEmpty()) {				// no error message: hint?
			fld.errmsg.Format(m_sFldErrPfx,fld.hint); // ..yes: combine w/hint
		} else if (!m_sDfltErrMsg.IsEmpty()) {			// no hint: default err msg?
			fld.errmsg = m_sDfltErrMsg;					// ..yes: use global default
		} else {													// no default:
			fld.errmsg = _T("Bad Value");					// ..hardwired last ditch default
		}
		if (fld.flags & RGXF_REQUIRED) {					// if field is required:
			CString temp;										// ..append
			temp.Format(_T(" (%s)"), m_sRequired);		// .."(required)"..
			fld.hint += temp;									// ..to hint
		}
		m_fldinfo.push_back(fld); // add FLDINFO to internal array.
	}

	// create hint window
	m_wndHint.Create(CPoint(0,0),pDlg);

	// install myself as dialog hook
	VERIFY(HookWindow(pDlg));
}

//////////////////
// Set contents/color of feedback window, a static text control
//
void CRegexForm::Feedback(LPCTSTR msg, COLORREF clr)
{
	if (m_pWndFeedback->GetSafeHwnd()) {
		m_clrFeedback = clr;
		m_pWndFeedback->SetWindowText(msg);
	}
}

//////////////////
// Show single bad field: beep, hilite field,
// display message in feedback window.
//
void CRegexForm::ShowBadField(const FLDINFO& fld, BOOL bBeep, BOOL bSetFocus)
{
	if (bBeep)
		MessageBeep(MB_ICONEXCLAMATION); // beep!

	if (bSetFocus) {
		// highlight contents, set focus
		CEdit* pEdit = (CEdit*)m_pDlg->GetDlgItem(fld.id);
		ASSERT(pEdit);
		pEdit->SetFocus();   // set focus to control..
		pEdit->SetSel(0,-1);	// ..and highlight text
	}

	// set feedback window text
	LPCTSTR pszFldErr = GetFieldErrorMsg(fld);
	CString msg;
	if (m_sError.IsEmpty()) {
		msg = pszFldErr;
	} else {
		msg.Format(m_sError, pszFldErr);
	}
	Feedback(msg, m_clrError);
}

//////////////////
// Get field index (into m_fldinfo table) from ID
//
int CRegexForm::GetFieldIndex(UINT nID)
{
	for (int i=0; i<(int)m_fldinfo.size(); i++)  {
		if (m_fldinfo[i].id == nID)
			return i;
	}
	return -1;  // not found
}

//////////////////
// Get field info from ID. returns NULLFLD if not found.
//
CRegexForm::FLDINFO& CRegexForm::GetFieldInfo(UINT nID)
{
	int i = GetFieldIndex(nID);
	return (i>=0) ? m_fldinfo[i] : NULLFLD;
}

//////////////////
// Highlight field: set focus and select all text.
// Assumes control is really an edit control!
//
void CRegexForm::HighlightField(UINT nID)
{
	CEdit* pEdit = (CEdit*)m_pDlg->GetDlgItem(nID);
	ASSERT(pEdit);
	pEdit->SetFocus();   // set focus to control..
	pEdit->SetSel(0,-1);	// ..and highlight text
}

//////////////////
// Do data exchange. Instead of storing values in your dialog, the field
// values are stored in FLDINFO::val. This saves you the trouble of having to
// define a data member for each field. Use Get/SetFieldValue to get/set
// values by ID.
//
void CRegexForm::DoDataExchange(CDataExchange* pDX)
{
	for (FLDITERATOR it = m_fldinfo.begin(); it!=m_fldinfo.end(); it++) {
		FLDINFO& fld = *it;
		DDX_Text(pDX, fld.id, fld.val);
		if (! (fld.flags & RGXF_NOTRIM)) {
			fld.val.Trim();
		}
	}
}

//////////////////
// Validate the whole form. Return number of bad fields.
//
int CRegexForm::Validate()
{
	int nBad = 0; // assume all fields OK
	for (FLDITERATOR it = m_fldinfo.begin(); it!=m_fldinfo.end(); it++) {
		if (ValidateField(*it)!=RGXERR_OK)
			nBad++;
	}
	CancelHint();
	return nBad;
}

//////////////////
// Validate a single field. Set/return error code.
//
RGXERROR CRegexForm::ValidateField(FLDINFO& fld)
{
	fld.err = RGXERR_OK;	// assume field OK

	if (fld.val.IsEmpty()) {				 // no value:
		if (fld.flags & RGXF_REQUIRED)	 // .. required?
			fld.err = RGXERR_MISSING;		 // .. if so, error

	} else {
		CString rgx = fld.regex;
		if (!rgx.IsEmpty()) {
			if (!ValidatePseudo(fld, rgx)) { // not pseudo-regex:
				// validate normal regex
				if (!fld.regex.Match(fld.val))
					fld.err = RGXERR_NOMATCH; // error: no match
			}
		}
	}

	// if field is OK so far, and RGXF_CALLBACK specified, call app to validate
	if (!fld.err && (fld.flags & RGXF_CALLBACK)) {
		ASSERT(m_msgCallback);
		fld.err = (RGXERROR)m_pDlg->SendMessage(m_msgCallback, // yes: do it
			MAKELONG(fld.id, RGXNM_VALIDATEFIELD), (LPARAM)&fld.val);
	}

	return fld.err;
}

// function template to do min/max validation for any type T. Args are: value,
// minval, maxval (all as strings) and parser function that converts a string
// to type T. All T needs is operator<=. parser is pointer to fn like _tstoi
// or _tstof that converts LPCTSTR to T.
//
template<typename T>
RGXERROR ValidateMinMax(LPCTSTR sval, LPCTSTR smin, LPCTSTR smax,
	T (*parser)(LPCTSTR arg))
{
	T val = (*parser)(sval);
	T min = (*parser)(smin);
	T max = (*parser)(smax);
	return min<=val && val<=max ? RGXERR_OK : RGXERR_NOMATCH;
}

//////////////////
// Validate pseudo-regex. The regex must be of the form
// "rgx:expr1,expr2,...,exprN". Each expression has the form
// constraint:arg1:arg1:...:argN.
//
// Currently supported commands:
//
//		minmax:type:minval:maxval
//		maxchars:n
//
// This function is used both to initialize the field (bInit=TRUE) and
// validate it (bInit=FALSE). This is because the maxchars constraint works by
// calling CEdit::SetLimitText once during initialization; whereas minmax
// constraint is validated each time the user enters a new value.
//
BOOL CRegexForm::ValidatePseudo(FLDINFO& fld, LPCTSTR rgxPseudo, BOOL bInit)
{
	CString rgx = rgxPseudo;
	if (rgx.Left(4)!=_T("rgx:"))
		return FALSE;

	rgx = rgx.Right(rgx.GetLength()-4);

	// parse constraints
	vector<CString> exprs = CRegex::Split(rgx, _T(",")); 

	for (vector<CString>::iterator it=exprs.begin(); it!=exprs.end(); it++) {
		CString expr = *it;
		vector<CString> args = CRegex::Split(*it, _T(":")); // parse args
		if (args[0]==_T("minmax")) { // min/max constraint?
			if (!bInit) {
				// pseudo "minmax" regex has the form "minmax:type:vmin:vmax",
				// where type is "int" or "double" and vmin,vmax are the
				// minimum/maximum values allowed.
				ASSERT(args.size()==4);
				if (args[1]==_T("int")) {
					fld.err = ValidateMinMax<int>(fld.val,args[2],args[3],_tstoi);
				} else if (args[1]==_T("double")) {
					fld.err = ValidateMinMax<double>(fld.val,args[2],args[3],_tstof);
				} // add more types here
			}

		} else if (args[0]==_T("maxchars")) {
			if (bInit) {
				ASSERT(args.size()==2);
				CEdit* pEdit = (CEdit*)m_pDlg->GetDlgItem(fld.id);
				ASSERT(pEdit);
				pEdit->SetLimitText(_tstoi(args[1]));
			}
		} else {
			TRACE(_T("CRegexForm: unrecognized pseudo-constraint: %s\n"), expr);
			ASSERT(FALSE);
		}
	}
	return TRUE;
}

//////////////////
// Get array (STL vector) of bad fields IDs.
//
vector<UINT> CRegexForm::GetBadFields()
{
	vector<UINT> badflds;
	badflds.reserve(m_fldinfo.size());	 // at most
	for (FLDITERATOR it = m_fldinfo.begin(); it != m_fldinfo.end(); it++) {
		FLDINFO& fld = *it;
		if (fld.err)
			badflds.push_back(fld.id);
	}
	return badflds;
}

//////////////////
// Get error message for field.
//
LPCTSTR CRegexForm::GetFieldErrorMsg(const FLDINFO& fld)
{
	if (fld.err==RGXERR_OK)
		return NULL;
	else if (fld.err==RGXERR_NOMATCH)
		return fld.errmsg;
	else if (fld.err==RGXERR_MISSING)
		return m_sRequired;
	ASSERT(FALSE); // should never get here
	return NULL;
}

//////////////////
// Handle EN_KILLFOCUS on behalf of dialog:
//		- cancel hint if any
//		- clear feedback window
//    - if immediate validation is on, validate it.
// 
void CRegexForm::OnEnKillFocus(FLDINFO& fld, CWnd* pCtl)
{
	CancelHint();		// clear hint
	Feedback(NULL);	// ..and feedback

	if (m_bImmedVal || (fld.flags & RGXF_IMMED)) {
		// if doing immediate validation:
		ASSERT(pCtl);
		pCtl->GetWindowText(fld.val);
		RGXERROR err = ValidateField(fld);
		if (err && err!=RGXERR_MISSING) {
			ShowBadField(fld,TRUE,TRUE);		 // show error message
		}
	}
}

//////////////////
// Handle EN_SETFOCUS on behalf of dialog:
// User moved to a new field:
//		- show hint if hints are on.
//		- show error message in feedback window if field has error state
//
void CRegexForm::OnEnSetFocus(FLDINFO& fld, CWnd* pCtl)
{
	if (m_bShowHints)
		ShowHint(fld, pCtl);
	if (fld.err)
		ShowBadField(fld,FALSE,FALSE);
}

//////////////////
// Display field hint, if any. Use CPopupText and delay/timeout.
//
void CRegexForm::ShowHint(FLDINFO& fld, CWnd* pCtl)
{
	if (!fld.hint.IsEmpty()) {
		ASSERT(pCtl);
		CRect rc;
		pCtl->GetWindowRect(&rc);
		rc += CPoint(rc.Width()+2,0);
		m_wndHint.MoveWindow(&rc);
		m_wndHint.SetWindowText(fld.hint);
		m_wndHint.ShowDelayed(m_msecDelay, m_msecTimeout);
	}
}

//////////////////
// Handle EN_CHANGE on behalf of dialog:
// User started typing: clear field error and feedback window.
//
void CRegexForm::OnEnChange(FLDINFO& fld, CWnd* /* pCtl */)
{
	if (fld.err) {
		fld.err = RGXERR_OK;	// clear error state..
		Feedback(NULL);		// ..and feedback window
	}
}

////////////////////////////////////////////////////////////////
// CSbuclassWnd::WindowProc override to trap dialog messages.
//
LRESULT CRegexForm::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	UINT nCode = HIWORD(wp);
	if (msg==WM_COMMAND && EN_SETFOCUS<=nCode && nCode<=EN_CHANGE) {
		// handle EN_SET/KILLFOCUS or EN_CHANGE
		UINT nID = LOWORD(wp);
		FLDINFO& fld = GetFieldInfo(nID);
		if (fld.id==nID) {		// if found:
			CWnd *pCtl = CWnd::FromHandle((HWND)lp);
			ASSERT(pCtl);
			if (nCode == EN_KILLFOCUS) {
				OnEnKillFocus(fld, pCtl);
			} else if (nCode == EN_SETFOCUS) {
				OnEnSetFocus(fld, pCtl);
			} else if (nCode == EN_CHANGE) {
				OnEnChange(fld, pCtl);
			}
		}
	} else if (msg==WM_CTLCOLORSTATIC) {
		LRESULT lr = CSubclassWnd::WindowProc(msg, wp, lp);
		CWnd *pStatic = CWnd::FromHandle((HWND)lp);
		if (pStatic==m_pWndFeedback) {
			// set proper feedback window text color
			::SetTextColor((HDC)wp, m_clrFeedback);
		}
		return lr;

	} else if (msg==WM_MOVE) {
		CancelHint(); // dialog move: cancel hint
		CWnd* pCtl = CWnd::GetFocus();
		if (pCtl) {
			FLDINFO& fld = GetFieldInfo(pCtl->GetDlgCtrlID());
			if (fld.id) {						 // and if mine:
				ShowHint(fld, pCtl);			 // ..show it again
			}
		}
	}
	return CSubclassWnd::WindowProc(msg, wp, lp); // pass to base--important!
}

////////////////////////////////////////////////////////////////
// CSubclassWnd-derived hook to trap edit control messages. Used to enforce
// legal characters constraint. lpszLegalChars is regular expression
// describing legal characters. CRegexForm installs one of these for each
// field that has a "legal chars" regex.
//
CRegexForm::CEditHook::CEditHook(CWnd* pDlg, UINT nID, LPCTSTR lpszLegalChars)
	: m_rgxLegalChars(lpszLegalChars), m_next(NULL)
{
	HWND hwnd = ::GetDlgItem(pDlg->GetSafeHwnd(), nID); // get dlg control
	ASSERT(hwnd);													 // check it exists
	VERIFY(HookWindow(hwnd));									 // install hook
}

//////////////////
// Hook proc for edit hook: trap WM_CHAR to reject disallowed characters.
//
LRESULT CRegexForm::CEditHook::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	if (msg==WM_CHAR && _istprint((TCHAR)wp)) {		// only block printing chars
		CString s = (TCHAR)wp;								// build one-character string
		if (!m_rgxLegalChars.Match(s)) {					// if doesn't match:
 			MessageBeep(0);									//   beep..
			return 0;											//   ..and eat it
		}
	} else if (msg==WM_DESTROY) {			 // window destroyed:
		delete this;							 // commit suicide!
		return 0;
	}
	return CSubclassWnd::WindowProc(msg, wp, lp); // pass to base--important!
}
