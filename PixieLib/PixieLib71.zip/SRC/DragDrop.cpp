////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Macro to get point from WM_ mouse messages
#define GETPOINT(lp) (CPoint(GET_X_LPARAM(lp), GET_Y_LPARAM(lp)))

//////////////////
// Create drag drop manager: initialize member data
//
CDragDropMgr::CDragDropMgr()
{
	m_pMainWnd = NULL;				// ptr to main window
	m_hwndTracking = NULL;			// current window I'm tracking (drag source)
	m_hCursorSave = NULL;			// saved cursor while dragging
	m_pDragImage = NULL;				// image list
	m_iState = 0;						// FSM: start in home state (0)
	m_uCallbackMsg = 0;				// message to call client with
	SetCursors(LoadCursor(NULL, IDC_ARROW), LoadCursor(NULL, IDC_NO));
	memset(&m_info,0,sizeof(m_info));
}

CDragDropMgr::~CDragDropMgr()
{
}

//////////////////
// Install drag/drop manager: use client's window map and callback message
//
BOOL CDragDropMgr::Install(CWnd *pMainWnd, DRAGDROPWND* ddwnds, UINT uCbMsg)
{
	PLTRACE(_T("CDragDropMgr::Install, uCbMsg = %d(0x%04x)\n"), uCbMsg, uCbMsg);
	ASSERT(uCbMsg);
	m_pMainWnd = pMainWnd;
	for (int i=0; ddwnds[i].type; i++) {
		HWND hwnd = ::GetDlgItem(pMainWnd->m_hWnd, ddwnds[i].id);
		ASSERT(hwnd && ::IsWindow(hwnd));
		m_mapHwnd[hwnd] = ddwnds[i].type;
	}
	m_uCallbackMsg = uCbMsg;

#ifdef _DEBUG
	HWNDMAP::iterator it;
	for (it=m_mapHwnd.begin(); it!=m_mapHwnd.end(); it++) {
		HWNDMAPENTRY pair = *it;
		PLTRACE("hwnd: %p = %04x\n", pair.first, pair.second);
	}
#endif
	return TRUE;
}

//////////////////
// Add source/target window dynamically
//
void CDragDropMgr::AddWindow(HWND hwnd, int type)
{
	m_mapHwnd[hwnd] = type;
}

//////////////////
// Remove source/target window dynamically
//
void CDragDropMgr::RemoveWindow(HWND hwnd)
{
	HWNDMAP::iterator pos = m_mapHwnd.find(hwnd);
	if (pos != m_mapHwnd.end()) {
		m_mapHwnd.erase(pos);
	}
}

/////////////////
// Get window type (source/target) flags.
//
UINT CDragDropMgr::GetWindowType(HWND hwnd)
{
	HWNDMAP::const_iterator pos = m_mapHwnd.find(hwnd);
	return pos != m_mapHwnd.end() ? pos->second : 0;
}

//////////////////
// Translate message: look for mouse down/up/move and keystrokes.
// Detail: Note that this works for input only.
//
BOOL CDragDropMgr::PreTranslateMessage(MSG* pMsg)
{
	const MSG& msg = *pMsg;

	if (IsSourceWnd(msg.hwnd)) {
		if (msg.message==WM_LBUTTONDOWN) {
			return OnLButtonDown(msg);

		} else if (msg.message==WM_MOUSEMOVE) {
			return OnMouseMove(msg);

		} else if (msg.message==WM_LBUTTONUP) {
			return OnLButtonUp(msg);

		} else if (msg.message==WM_KEYDOWN && msg.wParam==VK_ESCAPE) {
			if (m_iState) {
				NotifyClient(DD_ABORT);
				SetState(NONE);
				delete m_info.data;
				m_info.data=NULL;
				return 1;
			}
		}
	}
	return FALSE;
}

BOOL CDragDropMgr::OnLButtonDown(const MSG& msg)
{
	::SendMessage(msg.hwnd, msg.message, msg.wParam, msg.lParam);
	m_hwndTracking = msg.hwnd;
	m_ptOrg = GETPOINT(msg.lParam);
	SetState(CAPTURED);
	return TRUE;
}

BOOL CDragDropMgr::OnMouseMove(const MSG& msg)
{
	if (!m_iState)
		return FALSE;

	CWnd* pWnd = CWnd::FromHandle(m_hwndTracking);
	CPoint pt = GETPOINT(msg.lParam);
	DRAGDROPINFO& info = m_info;

	if (IsDragging()) {
		// already dragging: move drag image
		pWnd->ClientToScreen(&pt);			 // convert to screen coords
		m_pDragImage->DragMove(pt);		 // move drag image

		// get new target window if any and set cursor appropriately
		m_pMainWnd->ScreenToClient(&pt); // convert to main window coords
		info.pt = pt;
		info.hwndTarget = m_pMainWnd->ChildWindowFromPoint(pt)->GetSafeHwnd();
		NotifyClient(DD_DRAG,&info);
		SetCursor(info.hwndTarget && IsTargetWnd(info.hwndTarget) ?
			m_hCursorDrop : m_hCursorNo);

	} else {
		// Not dragging yet: enter drag mode if mouse moves beyond threshhold.
		CPoint delta = pt - m_ptOrg;
		static CPoint jog(GetSystemMetrics(SM_CXDRAG),
			GetSystemMetrics(SM_CYDRAG));

		if (abs(delta.x)>=jog.x || abs(delta.y)>jog.y) {
//			::LockWindowUpdate(m_hwndTracking);
			info.hwndSource = m_hwndTracking;
			info.pt = m_ptOrg;	// start from ORIGINAL point, not where now
			info.hwndTarget = NULL;
			info.data = NULL;
			info.nID = ::GetDlgCtrlID(m_hwndTracking);

			// Enter drag mode. Notify client first in case client wants to abort.
			BOOL bDrag = NotifyClient(DD_ENTER, &info);
			if (bDrag && info.data) {
				SetState(DRAGGING);			 // I am now dragging
				OnMouseMove(msg);
				pWnd->ClientToScreen(&pt);
				CRect rc;
				m_pDragImage = info.data->CreateDragImage(pWnd, rc);
				m_pDragImage->BeginDrag(0, rc.BottomRight());
				m_pDragImage->DragEnter(NULL,pt);

			} else {
				SetState(NONE);
			}
		}
	}
	return TRUE;
}

BOOL CDragDropMgr::OnLButtonUp(const MSG& msg)
{
	if (IsDragging()) {
		DRAGDROPINFO& info = m_info;
		SetState(NONE);
		if (IsTargetWnd(info.hwndTarget)) {
			CPoint pt = GETPOINT(msg.lParam);
			CWnd* pWndSource  = CWnd::FromHandle(info.hwndSource);
			CWnd* pWndTarget = CWnd::FromHandle(info.hwndTarget);
			pWndSource->ClientToScreen(&pt);
			pWndTarget->ScreenToClient(&pt);
			info.pt = pt;
			info.nID = pWndTarget->GetDlgCtrlID();
			NotifyClient(DD_DROP, &info);

		} else {
			NotifyClient(DD_ABORT);
		}
		delete info.data;
		info.data=NULL;
		return TRUE;
	}
	SetState(NONE);
	return FALSE;
}

//////////////////
// Get text name of notification code--for debugging
//
LPCTSTR CDragDropMgr::GetNotificationCodeName(UINT nCode)
{
	static struct {
		UINT code;
		LPCTSTR name;
	} MyNames[] = {
		{ DD_ENTER, _T("DD_ENTER") },
		{ DD_DRAG,	_T("DD_DRAG")	},
		{ DD_DROP,	_T("DD_DROP")	},
		{ DD_ABORT, _T("DD_ABORT") },
		{ 0, NULL }
	};
	for (int i=0; MyNames[i].code; i++) {
		if (nCode == MyNames[i].code)
			return MyNames[i].name;
	}
	return _T("Unknown");
}

//////////////////
// Send notification to client.
//
BOOL CDragDropMgr::NotifyClient(UINT nCode, DRAGDROPINFO* pInfo)
{
	PLTRACE(_T("CDragDropMgr: sending notification %d (%s)\n"), nCode,
		GetNotificationCodeName(nCode));
	return (BOOL)m_pMainWnd->SendMessage(m_uCallbackMsg, nCode, (LPARAM)(void*)pInfo);
}

//////////////////
// Set internal state of FSM (finite state machine). States are NONE,
// CAPTURED, DRAGGING.
//
void CDragDropMgr::SetState(UINT iState)
{
	PLTRACE(_T("CDragDropMgr::SetState(%d)\n"), iState);
	if (iState!=m_iState) {
		if (iState==CAPTURED) {
			::SetCapture(m_hwndTracking);

		} else if (iState==DRAGGING) {
			m_hCursorSave = GetCursor();
		
		} else if (iState==NONE) {
			::ReleaseCapture();
			SetCursor(m_hCursorSave);
			if (m_pDragImage) {
				m_pDragImage->EndDrag();
				delete m_pDragImage;
				m_pDragImage=NULL;
			}
//			::LockWindowUpdate(NULL);
			m_hwndTracking = NULL;
		}
		m_iState = iState;
	}
}

//////////////////
// Create drag image. Call virtual fn to get size, then create a bitmap in
// memory and memory DC and call virtual fn to draw into it. This is done
// once upon first entering drag mode; thereafter I can blt the pixels to the
// screen as the user moves the mouse.
//
CImageList* CDragDropData::CreateDragImage(CWnd* pWnd, CRect& rc)
{
	const COLORREF BGCOLOR = GetSysColor(COLOR_3DLIGHT);

	// create memory dc compatible w/source window
	CWindowDC dcWin(pWnd);
	CDC dcMem;
	dcMem.CreateCompatibleDC(&dcWin);

	// use same font as source window
	CFont* pFont = pWnd->GetFont();
	CFont* pOldFont = dcMem.SelectObject(pFont);

	// get size of drag image
	CSize sz = OnGetDragSize(dcMem); // call virtual fn to get size
	rc = CRect(CPoint(0,0), sz);

	// create image list: create bitmap and draw into it
	m_bitmap.CreateCompatibleBitmap(&dcWin, sz.cx, sz.cy);
	CBitmap* pOldBitmap = dcMem.SelectObject(&m_bitmap);
	CBrush brush;
	brush.CreateSolidBrush(GetSysColor(COLOR_HIGHLIGHT));
	dcMem.FillRect(&rc,&brush);
	dcMem.SetBkMode(TRANSPARENT);
	dcMem.SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
	OnDrawData(dcMem, rc); // call virtual fn to draw
	dcMem.SelectObject(pOldFont);
	dcMem.SelectObject(pOldBitmap);

	// create image list and add bitmap to it
	CImageList *pil = new CImageList();
	pil->Create(sz.cx, sz.cy, ILC_COLOR24|ILC_MASK, 0, 1);
	pil->Add(&m_bitmap, BGCOLOR);
	return pil;
}

//////////////////
// Get drag size for text: calculate text rectangle
//
CSize CDragDropText::OnGetDragSize(CDC& dc)
{
	CRect rc(0,0,0,0);
	dc.DrawText(m_text, &rc, DT_CALCRECT);
	if (rc.right>MAXWIDTH)
		rc.right = MAXWIDTH;
	return rc.Size();
}

//////////////////
// Draw text data: call MFC CDC::DrawText to do it.
//
void CDragDropText::OnDrawData(CDC& dc, CRect& rc)
{
	dc.DrawText(m_text, &rc, DT_LEFT|DT_END_ELLIPSIS);
}
	
