////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CFlatToolBar implements dockable flat-style toolbars with "grippers"
//
#include "StdPxl.h"

/////////////////
// One of these for each drop-down button
//
struct DROPDOWNBUTTON {
	DROPDOWNBUTTON* next;
	UINT idButton;								 // command ID of button
	UINT idMenu;								 // popup menu to display
};

// these define size of grippers
const UINT GRIP_WIDTH   = 3;
const UINT GRIP_MARGIN  = 5;

// flags stored in item data
#define	ITEMF_INITIALIZED	0x01 // item data initialized
#define	ITEMF_CHECKED		0x02 // item is checked

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CFlatToolBar--does flat tool bar in MFC.
//
IMPLEMENT_DYNAMIC(CFlatToolBar, CFlatToolBarBase)

BEGIN_MESSAGE_MAP(CFlatToolBar, CFlatToolBarBase)
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_NOTIFY_REFLECT(TBN_DROPDOWN,  OnTbnDropDown)
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_ERASEBKGND()
	ON_WM_NCCREATE()
	ON_WM_PAINT()
	ON_WM_CREATE()
END_MESSAGE_MAP()

CFlatToolBar::CFlatToolBar()
{
	PLTRACE(_T("CFlatToolBar::CFlatToolBar, comctl32 version = %d\n"), iVerComCtl32);

	m_bDrawSeparators = (iVerComCtl32 <= 470);
	m_bFixWrappedSeparators = (iVerComCtl32==471 || iVerComCtl32 == 472);
	m_bDrawGrippers = FALSE;					// only need for old versions of windows
	m_bDrawDisabledButtonsInColor = FALSE; // don't use color
	m_bInCoolBar = FALSE;						// assume not inside coolbar
	m_pDropDownButtons = NULL;					// list of drop-down buttons
	m_bShowDropdownArrowWhenVertical = TRUE;
	m_bNoEntry = FALSE;
}

CFlatToolBar::~CFlatToolBar()
{
	while (m_pDropDownButtons) {
		DROPDOWNBUTTON* pnext = m_pDropDownButtons->next;
		delete m_pDropDownButtons;
		m_pDropDownButtons = pnext;
	}
}

/////////////////
// Create handler: set flat style by default
//
int CFlatToolBar::OnCreate(LPCREATESTRUCT lpcs)
{
	if (CFlatToolBarBase::OnCreate(lpcs) == -1)
		return -1;
	ModifyStyle(0, TBSTYLE_FLAT);
	return 0;  // OK
}

////////////////
// Load function sets flat style after loading buttons.
//
BOOL CFlatToolBar::LoadToolBar(LPCTSTR lpszResourceName)
{
	// Set transparent/flat style before loading buttons to allow zero-height
	// border. This required because of bug in comctl32.dll that always adds
	// a border, unless flat/transparent.
	//
	DWORD dwStyle = GetStyle();
	ModifyStyle(0, TBSTYLE_FLAT|TBSTYLE_TRANSPARENT);
	BOOL bRet = CFlatToolBarBase::LoadToolBar(lpszResourceName);
	SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);
	return bRet;
}

////////////////
// Custom draw handler used to
//  * draw separators if m_bDrawSeparators is TRUE (comctl32.dll version <= 470)
//  * draw checked buttons as pressed
//
// Only do this if the style is flat
//
void CFlatToolBar::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pRes)
{
	DWORD dwStyle = GetStyle();
	if (dwStyle & TBSTYLE_FLAT) {

		NMCUSTOMDRAW& cd = (NMCUSTOMDRAW&)(*pNMHDR);
		DWORD dwStage = cd.dwDrawStage;

		CDC dc;
		dc.Attach(cd.hdc);
		if (dwStage == CDDS_PREPAINT) {
			if (m_bDrawSeparators)
				DrawSeparators(dc);			 // draw the separators
			*pRes |= CDRF_NOTIFYITEMDRAW;	 // and notify me to draw items
			if (m_bFixWrappedSeparators)		 // if fixing vertical separators:
				*pRes |= CDRF_NOTIFYPOSTPAINT; // ..do it on postpaint

		} else if (dwStage==CDDS_ITEMPREPAINT) {
			if (DrawItem(dc, cd))			 // paint the item
				*pRes |= CDRF_SKIPDEFAULT;	 // if painted, tell toolbar not to

		} else if (dwStage==CDDS_POSTPAINT) {
			if (m_bFixWrappedSeparators) {
				FixWrappedSeparators(dc);
			}
		}
		dc.Detach();
	}
}

//////////////////
// Draw separators
//
void CFlatToolBar::DrawSeparators(CDC& dc)
{
	int nButtons = GetButtonCount();
	for (int i=0; i<nButtons; i++) {
		if (LOWORD(GetButtonStyle(i)) == TBSTYLE_SEP) {
			// item is a separator
			CRect rcItem;							// item rectangle

			// Don't use GetItemRect because it has side-effects
			SendMessage(TB_GETITEMRECT, i, (LPARAM)&rcItem);
			UINT nFlag = BF_LEFT;				// assume horz toolbar

			if (m_dwStyle & CBRS_ORIENT_VERT) {
				// For some reason, GetItemRect doesn't give the correct
				// rect for separators in a vertical toolbar, so I must adjust.
				// First move it, then swap width/height
				rcItem += CPoint(-m_sizeButton.cx, m_sizeButton.cy-2);
				int h = rcItem.Width();
				int w = rcItem.Height();
				rcItem.right  = rcItem.left + w;
				rcItem.bottom = rcItem.top  + h;

				// compute where edge is: midpoint of rectangle horz or vert
				rcItem.top  = ((rcItem.top + rcItem.bottom)>>1) - 1;
				nFlag = BF_TOP;

			} else
				rcItem.left = ((rcItem.left + rcItem.right)>>1) - 1;

			dc.DrawEdge(&rcItem, EDGE_ETCHED, nFlag);	// draw it
		}
	}
}

//////////////////
// In comctl32 version 471 and 472, the toolbar control draws extra separators
// when the toolbar is not completely horizontal: it draws both horizontal
// and vertical seps when it should only draw the horizontal one. Fix it by
// painting over (yuk).
// 
void CFlatToolBar::FixWrappedSeparators(CDC& dc)
{
	int nButtons = GetButtonCount();
	for (int i=0; i<nButtons; i++) {
		TBBUTTON tbb;
		GetButton(i, &tbb);
		if (tbb.fsStyle & TBSTYLE_SEP && tbb.fsState & TBSTATE_WRAP && i>0) {
			
			CRect rcItem;
			SendMessage(TB_GETITEMRECT, i, (LPARAM)&rcItem);

			CRect rcPrevItem;
			SendMessage(TB_GETITEMRECT, i-1, (LPARAM)&rcPrevItem);

			rcPrevItem += CPoint(rcPrevItem.Width(), 0);
			rcPrevItem.right = rcPrevItem.left + rcItem.Width();
			rcItem = rcPrevItem;

			CBrush br(GetSysColor(COLOR_3DFACE));
			CBrush* pOldBrush = dc.SelectObject(&br);
			const CRect& rc=rcItem;
			dc.PatBlt(rc.left, rc.top, rc.Width(), rc.Height(), PATCOPY);
			dc.SelectObject(pOldBrush);
		}
	}
}

//////////////////
// Draw an item. I will only draw it if it's checked:
// Draw checked item as pressed, and handle hot state correctly.
// Returns TRUE if button was drawn; otherwise FALSE.
//
BOOL CFlatToolBar::DrawItem(CDC& dc, const NMCUSTOMDRAW& cd)
{
	if (m_bNoEntry)
		return TRUE;

	UINT nItem  = CommandToIndex(cd.dwItemSpec);
	TBBUTTON butn;
	GetButton(nItem, &butn);
	if (butn.iBitmap<0)
		return FALSE; // don't draw text buttons: default is OK

	UINT nStyle = butn.fsState; //GetButtonStyle(nItem);
	BOOL bChecked  = (nStyle & TBSTATE_CHECKED) != 0;
	BOOL bDisabled = (nStyle & TBSTATE_ENABLED) != 0;
	BOOL bPressed  = (nStyle & TBSTATE_PRESSED) != 0;
	BOOL bHot      = cd.uItemState & CDIS_HOT;

	// Don't use MFC GetItemRect!!
	CRect rcItem;
	SendMessage(TB_GETITEMRECT, nItem, (LPARAM)&rcItem);

	if (m_bInCoolBar) {
		// For coolbar, force repaint of the background, but make sure
		// to avoid reentry. This allows bitmap backgrounds.
		// Only erase portion that lies in region I am painting (clip box).
		CRect rc;
		dc.GetClipBox(&rc);
		if (rc.IntersectRect(&rc, &rcItem)) {
			m_bNoEntry = TRUE;
			InvalidateRect(&rc, TRUE);
			UpdateWindow();
			m_bNoEntry = FALSE;
		}
	} else {
		// solid background: just draw it
		PLFillRect(dc, rcItem, GetSysColor(COLOR_3DFACE));
	}

	// only do custom paint for checked buttons, or disabled if color is on
	if (!bChecked && !(bDisabled && m_bDrawDisabledButtonsInColor) )
		return FALSE;

	// if I got here, button is either checked *OR*
	// button is disabled and I am drawing color

	// Get top left corner of image. This is top left corner of the item,
	// plus offset to center button in item (bitmap is smaller than item)
	CPoint p = rcItem.TopLeft();
	p.x += (m_sizeButton.cx - m_sizeImage.cx)/2 + 1;
	p.y += (m_sizeButton.cy - m_sizeImage.cy)/2 + 1;
	if (bPressed)
		p += CPoint(1,1);		// press even deeper

	if (!bHot && !bPressed && !bDisabled) 
		PLFillRect3DLight(dc, rcItem);
	else if (bHot && !bPressed)
		PLFillRect(dc, rcItem, GetSysColor(COLOR_3DFACE));

	// draw button
	CImageList il;
	VERIFY(il.Attach(GetImageList()));
	UINT iBitmap = GetBitmap(cd.dwItemSpec);

	PLTRACE(_T("CFlatToolBar::DrawItem %d: %schecked%s%s%s\n"),
		nItem,
		bChecked  ? _T("") : _T("not "),
		bPressed  ? _T(", pressed") : _T(""),
		bDisabled ? _T(", disabled") : _T(""),
		bHot      ? _T(", hot") : _T("") );

	if (bDisabled) {
		// draw embossed
		PLDrawEmbossed(dc, il, iBitmap, p, m_bDrawDisabledButtonsInColor);
	}
	if (bChecked) {
		if (!bDisabled)	// disabled button already drawn above
			il.Draw(&dc, iBitmap, p, ILD_TRANSPARENT);	// draw button..
		dc.DrawEdge(&rcItem, BDR_SUNKENOUTER, BF_RECT);	// ..and sunken border
	}
	il.Detach();

	return TRUE;
}

//////////////////
// Override MFC sizing functions to add extra non-client width.
// Mainly needed so outline rectangle during drag operation is the right size.
//
CSize CFlatToolBar::CalcFixedLayout(BOOL bStretch, BOOL bHorz)
{
	return AdjustSize(CFlatToolBarBase::CalcFixedLayout(bStretch, bHorz), bHorz);
}

CSize CFlatToolBar::CalcDynamicLayout(int nLength, DWORD dwMode)
{
	if ((nLength == -1) && !(dwMode & LM_MRUWIDTH) && !(dwMode & LM_COMMIT) &&
		((dwMode & LM_HORZDOCK) || (dwMode & LM_VERTDOCK))) {
		return CalcFixedLayout(dwMode & LM_STRETCH, dwMode & LM_HORZ);
	}
	return AdjustSize(CFlatToolBarBase::CalcLayout(dwMode, nLength),
		dwMode & LM_HORZ);
}

//////////////////
// Adjust fixed/dynamic size by adding extra space for gripper
//
CSize CFlatToolBar::AdjustSize(CSize sz, BOOL bHorz)
{
	// correct for grippers, whether shown (CBRS_GRIPPERS or not)
	if (m_bDrawGrippers) {
		int delta = m_bDrawGrippers==2 ? (2*GRIP_WIDTH) : GRIP_WIDTH;
		if (bHorz) 
			sz.cx += delta;
		else
			sz.cy += delta;
	}
	return sz;
}

//////////////////
// Calculate size of client area. Adds room for grippers
//
void CFlatToolBar::OnNcCalcSize(BOOL /* bCalc */, NCCALCSIZE_PARAMS*	pncp)
{
	if (m_bInCoolBar) { // if I am in a coolbar (rebar):
		Default();		  // ..bypass CToolBar/CControlBar

	} else {
		CRect& rc = (CRect&)pncp->rgrc[0]; // rect to return

		// copied from MFC below:
		CRect rcMargin(0,0,0,0);
		CControlBar::CalcInsideRect(rcMargin, m_dwStyle & CBRS_ORIENT_HORZ);

		// adjust non-client area for border space
		rc.left  += rcMargin.left;
		rc.top   += rcMargin.top; // MFC has -2 here, bug for newer comctl32
		rc.right += rcMargin.right;
		rc.bottom+= rcMargin.bottom;

		if (!(m_dwStyle & CBRS_FLOATING) && m_bDrawGrippers) {
			// adjust for gripper handles, regardless of CBRS_GRIPPERS
			if (m_bDrawGrippers) {
				int delta = m_bDrawGrippers==2 ? (2*GRIP_WIDTH) : GRIP_WIDTH;
				if (m_dwStyle & CBRS_ORIENT_HORZ)
					rc.left += delta;
				else
					rc.top += delta;
			}
		}
	}
}

//////////////////
// Paint non-client area. Do default, then paint grippers
//
void CFlatToolBar::OnNcPaint()
{
	if (m_bInCoolBar) {
		Default();
		return;
	}

	CFlatToolBarBase::OnNcPaint();

	// only draw grippers if CBRS_GRIPPER style specified too.
	if ((m_dwStyle & CBRS_GRIPPER) && m_bDrawGrippers && !(m_dwStyle & CBRS_FLOATING)) {
		CPoint topLeft, shift;
		CSize  sz;
		CWinRect rcWin(this, CWinRect::WINDOW);

		// subtract inner margins from window rect
		CRect rc = rcWin;
		BOOL bHorz = (m_dwStyle & CBRS_ORIENT_HORZ);
		CalcInsideRect(rc, bHorz);
		if (bHorz) {
			topLeft = CPoint(GRIP_MARGIN, rc.top-rcWin.top);
			sz = CSize(GRIP_WIDTH, rc.Height());
			shift = CPoint(GRIP_WIDTH, 0);
		} else {
			topLeft = CPoint(rc.left-rcWin.left, GRIP_MARGIN);
			sz = CSize(rc.Width(), GRIP_WIDTH);
			shift = CPoint(0, GRIP_WIDTH);
		}

		CWindowDC dc(this);
		for (int i=0; i<2; i++) {
			// draw 1 or 2 grippers
			dc.DrawEdge(CRect(topLeft, sz), BDR_RAISEDINNER, BF_RECT);
			if (m_bDrawGrippers!=2)
				break;
			topLeft += shift;
		}
	}
}

//////////////////
// MFC doesn't handle moving a TBSTYLE_FLAT toolbar correctly. The simplest
// way to fix it is to repaint whatever was underneath whenever the toolbar
// moves. This is done in this and the following function. All this stuff is
// only required because flat toolbars paint transparently (don't paint their
// backgrounds).
// 
void CFlatToolBar::OnWindowPosChanging(LPWINDOWPOS lpwp)
{
	if (m_bInCoolBar)
		// inside coolbars, don't do MFC thing
		Default();
	else {
		CFlatToolBarBase::OnWindowPosChanging(lpwp);
		if (!(lpwp->flags & SWP_NOMOVE))
			GetWindowRect(&m_rcOldPos);		 // remember old position
	}
}

//////////////////
// Now toolbar has really moved: repaint area beneath old position
//
void CFlatToolBar::OnWindowPosChanged(LPWINDOWPOS lpwp)
{
	if (m_bInCoolBar) {
		Default();
	} else {
		CFlatToolBarBase::OnWindowPosChanged(lpwp);
		if (!(lpwp->flags & SWP_NOMOVE)) {	 // if moved:
			InvalidateOldPos(m_rcOldPos);		 // invalidate area of old position

			// Now paint my non-client area at the new location.
			// Without this, you will still have a partial display bug (try it!)
			SendMessage(WM_NCPAINT);
		}
	}
}

//////////////////
// Invalidate toolbar rectangle. Because flat toolbars are transparent,
// this requires invalidating parent and all siblings that intersect the
// rectangle.
//
void CFlatToolBar::InvalidateOldPos(const CRect& rcInvalid)
{
	// make parent paint the area beneath rectangle
	CWnd* pParent = GetParent();		// parent (dock bar/frame) window
	ASSERT_VALID(pParent);				// check
	CRect rc = rcInvalid;				// copy rectangle
	pParent->ScreenToClient(&rc);		// convert to parent client coords
	pParent->InvalidateRect(&rc);		// invalidate

	// now do same for each sibling too
	for (CWnd* pSib = pParent->GetWindow(GW_CHILD);
		  pSib;
		  pSib=pSib->GetNextWindow(GW_HWNDNEXT)) {

		CWinRect rc(pSib, CWinRect::WINDOW);	// window rect of sibling
		if (rc.IntersectRect(rc, rcInvalid)) {	// if intersects invalid rect
			pSib->ScreenToClient(&rc);				// convert to sibling coords
			pSib->InvalidateRect(&rc);				// invalidate
			pSib->SendMessage(WM_NCPAINT);		// nonclient area too!
		}
	}
}

////////////////
// Override to avoid MFC in case I'm inside a coolbar
//
BOOL CFlatToolBar::OnEraseBkgnd(CDC* pDC)
{
	return m_bInCoolBar ? Default() : CFlatToolBarBase::OnEraseBkgnd(pDC);
}

//////////////////
// If toolbar is inside a coolbar, need to make the parent frame
// my owner so it will get notifications.
//
BOOL CFlatToolBar::OnNcCreate(LPCREATESTRUCT lpcs)
{
	CWnd* pParent = GetParent();
	ASSERT(pParent);
	TCHAR classname[64];
	GetClassName(pParent->m_hWnd, classname, countof(classname));
	if (_tcscmp(classname, REBARCLASSNAME)==0) {
		CFrameWnd* pFrame = GetParentFrame();
		ASSERT_VALID(pFrame);
		SetOwner(pFrame);
		m_bInCoolBar = TRUE;
		m_bDrawGrippers = FALSE;
	}
	return CFlatToolBarBase::OnNcCreate(lpcs);
}

//////////////////
// Avoid MFC if I'm inside a coolbar
//
void CFlatToolBar::OnPaint()
{
	if (m_bInCoolBar)
		Default();	// bypass CToolBar/CControlBar
	else
		CFlatToolBarBase::OnPaint();
}

////////////////////////////////////////////////////////////////
// Stuff for handling drop-down buttons in toolbars
//

//////////////////
// Add dropdown buttons.
// The manager takes care of setting appropriate styles, etc.
//
// Args:
//		- array of LONGs: MAKELONG(commandID, menuID)
//		- number of buttons
//
BOOL CFlatToolBar::AddDropDownButton(UINT nIDButton, UINT nIDMenu, BOOL bArrow)
{
	ASSERT_VALID(this);

	DROPDOWNBUTTON* pb = FindDropDownButton(nIDButton);
	if (!pb) {
		pb = new DROPDOWNBUTTON;
		ASSERT(pb);
		pb->next = m_pDropDownButtons;
		m_pDropDownButtons = pb;
	}
	pb->idButton = nIDButton;
	pb->idMenu   = nIDMenu;

	int iButton = CommandToIndex(nIDButton);

	DWORD dwStyle = GetButtonStyle(iButton);
	dwStyle |= TBSTYLE_DROPDOWN;
	SetButtonStyle(iButton, dwStyle);

	if (bArrow)
		SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS);

	return TRUE;
}

//////////////////
// Find buttons structure for given ID
//
DROPDOWNBUTTON* CFlatToolBar::FindDropDownButton(UINT nID)
{
	for (DROPDOWNBUTTON* pb = m_pDropDownButtons; pb; pb = pb->next) {
		if (pb->idButton == nID)
			return pb;
	}
	return NULL;
}

//////////////////
// Handle TBN_DROPDOWN
// Default is to display the specified menu at the right place.
// You can override to generate dynamic menus
//
// Args:
//		- NMTOOLBAR struct from TBN_DROPDOWN
//		- command id of button
//		- point to display menu at
//
void CFlatToolBar::OnTbnDropDown(NMHDR* pNMHDR, LRESULT* /* pRes */)
{
	const NMTOOLBAR& nmtb = *(NMTOOLBAR*)pNMHDR;

	// get location of button
	CRect rc;
	GetRect(nmtb.iItem, rc);
	ClientToScreen(&rc);

	// call virtual function to display dropdown menu
	OnDropDownButton(nmtb, nmtb.iItem, rc);
}

/////////////////
// Virtual fn you can override to hand drop-down button
// events with more friendly args
//
void CFlatToolBar::OnDropDownButton(const NMTOOLBAR& nmtb, UINT /* nID */, CRect rc)
{
	DROPDOWNBUTTON* pb = FindDropDownButton(nmtb.iItem);
	if (pb && pb->idMenu) {
		// load and display popup menu
		CMenu menu;
		VERIFY(menu.LoadMenu(pb->idMenu));
		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_VERTICAL,
			rc.left, rc.bottom, GetOwner(), &rc);
	}
}

