////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CPicture implementation
//

CPicture::CPicture()
{
	m_bUseEmbeddedColorManagement = FALSE;
	m_pImage = NULL;
	m_hMem = NULL;
	m_props = NULL;
}

CPicture::~CPicture()
{
	DestroyPicture();
}

//////////////////
// Free Image object and global memory (for resource images) if any
//
void CPicture::DestroyPicture()
{
	if (m_pImage) {
		delete m_pImage;
		m_pImage = NULL;
	}
	if (m_hMem) {
		GlobalFree(m_hMem);
		m_hMem = NULL;
	}
	if (m_props) {
		delete [] (char*)m_props;
		m_props = NULL;
	}
}

//////////////////
// Load from path name.
//
BOOL CPicture::Load(LPCTSTR pszPathName)
{
	DestroyPicture();
	USES_CONVERSION;
	if (IsURL(pszPathName))
		return LoadURL(pszPathName);

	m_pImage = Image::FromFile(CT2W(pszPathName), m_bUseEmbeddedColorManagement);
	return m_pImage->GetLastStatus()==Ok;
}

//////////////////
// Load from stream.
//
BOOL CPicture::Load(IStream* pstm)
{
	DestroyPicture();
	m_pImage = Image::FromStream(pstm, m_bUseEmbeddedColorManagement);
	return m_pImage->GetLastStatus()==Ok;
}

//////////////////
// Load from Internet URL
//
BOOL CPicture::LoadURL(LPCTSTR url)
{
	DestroyPicture();
	CInternetSession inet;
	BOOL bRet = FALSE;
	CHttpFile* f = NULL;
	try {
		f = (CHttpFile*)inet.OpenURL(url,1,INTERNET_FLAG_TRANSFER_BINARY);
	} catch (CException*) {

	}
	if (f) {
		DWORD status;
		VERIFY(f->QueryInfoStatusCode(status));
		if (200<=status && status<300) {
			DWORD len;
			DWORD buflen=sizeof(len);
			VERIFY(f->QueryInfo(HTTP_QUERY_CONTENT_LENGTH|HTTP_QUERY_FLAG_NUMBER,
				&len, &buflen));

			HGLOBAL hMem = GlobalAlloc(GMEM_FIXED, len);
			BYTE* buf = (BYTE*)GlobalLock(hMem);
			VERIFY(f->Read(buf, len)==len);
			bRet = LoadFromMem(hMem);
		}
		f->Close();
		delete f;
	}
	inet.Close();
	return bRet;
}

//////////////////
// Load from resource. Looks for "IMAGE" type.
//
BOOL CPicture::Load(UINT nIDRes)
{
	DestroyPicture();
	if (nIDRes==0)
		return FALSE;

	// find resource in resource file
	HINSTANCE hInst = AfxGetResourceHandle();
	HRSRC hRsrc = ::FindResource(hInst,
		MAKEINTRESOURCE(nIDRes),
		_T("IMAGE")); // type
	if (!hRsrc)
		return FALSE;

	// load resource into memory
	DWORD len = SizeofResource(hInst, hRsrc);
	BYTE* lpRsrc = (BYTE*)LoadResource(hInst, hRsrc);
	if (!lpRsrc)
		return FALSE;

	// create stream on global memory
	HGLOBAL hMem = GlobalAlloc(GMEM_FIXED, len);
	BYTE* buf = (BYTE*)GlobalLock(hMem);
	memcpy(buf, lpRsrc, len);
	FreeResource(lpRsrc);
	return LoadFromMem(hMem);
}

//////////////////
// Load picture from memory block. Create stream on global memory and load it.
//
BOOL CPicture::LoadFromMem(HGLOBAL hMem)
{
	IStream* pstm;
	VERIFY(CreateStreamOnHGlobal(hMem,FALSE,&pstm)==S_OK);
	BOOL bRet = Load(pstm);					 // load from stream
	GlobalUnlock(hMem);
	pstm->Release();
	m_hMem = hMem;
	return bRet;
}

//////////////////
// Rotate image 
//
void CPicture::Rotate(RotateFlipType rft)
{
	if (m_pImage) {
		m_pImage->RotateFlip(rft);
	}
}

//////////////////
// Render to device context.
//
BOOL CPicture::Render(CDC* pDC, CRect rc) const
{
	ASSERT(pDC);
	if (rc.IsRectNull()) {
		CSize sz = GetImageSize(pDC);
		rc.right = sz.cx;
		rc.bottom = sz.cy;
	}
	Graphics graphics(pDC->m_hDC);
	graphics.DrawImage(m_pImage, rc.left, rc.top, rc.Width(), rc.Height());

	return TRUE;
}

//////////////////
// Get image size in pixels.
//
CSize CPicture::GetImageSize(CDC* /* pDC */) const
{
	CSize sz(0,0);
	if (m_pImage) {
		sz = CSize(m_pImage->GetWidth(), m_pImage->GetHeight());
	}
	return sz;
}

CString CPicture::GetFormatName() const
{
	static struct {
		const GUID* pguid;
		LPCTSTR name;
	} FormatIDs[] = {
		{ &ImageFormatUndefined,_T("Undefined") },
		{ &ImageFormatMemoryBMP,_T("MemoryBMP") },
		{ &ImageFormatBMP,_T("BMP") },
		{ &ImageFormatEMF,_T("EMF") },
		{ &ImageFormatWMF,_T("WMF") },
		{ &ImageFormatJPEG,_T("JPEG") },
		{ &ImageFormatPNG,_T("PNG") },
		{ &ImageFormatGIF,_T("GIF") },
		{ &ImageFormatTIFF,_T("TIFF") },
		{ &ImageFormatEXIF,_T("EXIF") },
		{ &ImageFormatIcon,_T("Icon") },
		{ NULL,NULL }
	};

	GUID guid;
	if (GetRawFormat(guid)==Ok) {
		for (int i=0; FormatIDs[i].name; i++) {
			if (IsEqualGUID(*FormatIDs[i].pguid,guid)) {
				return FormatIDs[i].name;
			}
		}
	}
	return _T("unknown");
};

//////////////////
// Get all properties.
//
UINT CPicture::GetAllPropertyItems(PropertyItem*& props)
{
	ASSERT(m_pImage);
	if (!m_props) {
		UINT nBufSiz;
		m_pImage->GetPropertySize(&nBufSiz, &m_nProp);
		m_props = (PropertyItem*)new char[nBufSiz];
		m_pImage->GetAllPropertyItems(nBufSiz, m_nProp, m_props);
	}
	props = m_props;
	return m_nProp;
}