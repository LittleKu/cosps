////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CModuleVersion provides an easy way to get version info
// for a module.(DLL or EXE).
//
#include "StdPxl.h"

//////////////////////////////// CModuleVersion ////////////////////////////////

CModuleVersion::CModuleVersion(HMODULE hModule) : m_pVersionInfo(NULL)
{
	GetFileVersionInfo(hModule);
}

CModuleVersion::CModuleVersion(LPCTSTR modulename) : m_pVersionInfo(NULL)
{
	if (modulename) {
		CLoadLibrary lib(modulename);
		if (lib) {
			GetFileVersionInfo(lib);
		}
	}
}

//////////////////
// Destroy: delete version info
//
CModuleVersion::~CModuleVersion()
{
	delete [] m_pVersionInfo;
}

//////////////////
// Get file version info for a given module
// Allocates storage for all info, fills "this" with
// VS_FIXEDFILEINFO, and sets code page.
//
BOOL CModuleVersion::GetFileVersionInfo(HMODULE hModule)
{
	m_translation.charset = 1252;		// default = ANSI code page
	memset((VS_FIXEDFILEINFO*)this, 0, sizeof(VS_FIXEDFILEINFO));

	// get own module (EXE) filename 
	TCHAR fn[_MAX_PATH];
	GetModuleFileName(hModule, fn, _MAX_PATH);

	// read file version info
	DWORD dwDummyHandle; // will always be set to zero
	DWORD len = GetFileVersionInfoSize(fn, &dwDummyHandle);
	if (len <= 0)
		return FALSE;

	if (m_pVersionInfo)
		delete m_pVersionInfo;
	m_pVersionInfo = new BYTE[len]; // allocate version info
	if (!::GetFileVersionInfo(fn, 0, len, m_pVersionInfo))
		return FALSE;

	LPVOID lpvi;
	UINT iLen;
	if (!VerQueryValue(m_pVersionInfo, _T("\\"), &lpvi, &iLen))
		return FALSE;

	// copy fixed info to myself, which am derived from VS_FIXEDFILEINFO
	*(VS_FIXEDFILEINFO*)this = *(VS_FIXEDFILEINFO*)lpvi;

	// Get translation info
	// Note: VerQueryValue could return a value > 4, in which case
	// multiple languages are supported and VerQueryValue returns an
	// array of langID/code page pairs and you have to decide which to use.
	if (VerQueryValue(m_pVersionInfo,
		_T("\\VarFileInfo\\Translation"), &lpvi, &iLen) && iLen >= 4) {
		m_translation = *(TRANSLATION*)lpvi;
		PLTRACE(_T("CModuleVersion::code page = %d\n"), m_translation.charset);
	}

	return dwSignature == VS_FFI_SIGNATURE;
}

//////////////////
// Get string file info.
// Key name is something like "CompanyName".
// returns the value as a CString.
//
CString CModuleVersion::GetValue(LPCTSTR lpKeyName)
{
	CString sVal;
	if (m_pVersionInfo) {

		// To get a string value must pass query in the form
		//
		//    "\StringFileInfo\<langID><codepage>\keyname"
		//
		// where <lang-codepage> is the languageID concatenated with the
		// code page, in hex. Wow.
		//
		CString query;
		query.Format(_T("\\StringFileInfo\\%04x%04x\\%s"),
			m_translation.langID,
			m_translation.charset,
			lpKeyName);

		LPCTSTR pVal;
		UINT iLenVal;
		if (VerQueryValue(m_pVersionInfo, (LPTSTR)(LPCTSTR)query,
				(LPVOID*)&pVal, &iLenVal)) {

			sVal = pVal;
		}
	}
	return sVal;
}

/////////////////
// Get DLL Version by calling DLL's DllGetVersion proc
//
BOOL CModuleVersion::DllGetVersion(LPCTSTR modulename, DLLVERSIONINFO& dvi)
{
	CLoadLibrary lib(modulename);
	if (!lib)
		return FALSE;

	// typedef for DllGetVersion proc
	typedef HRESULT (CALLBACK* DLLGETVERSIONPROC)(DLLVERSIONINFO *);

	// Must use GetProcAddress because the DLL might not implement 
	// DllGetVersion. Depending upon the DLL, the lack of implementation of the 
	// function may be a version marker in itself.
	//
	DLLGETVERSIONPROC pDllGetVersion =
		(DLLGETVERSIONPROC)GetProcAddress(lib, "DllGetVersion");
	if (!pDllGetVersion)
		return FALSE;

	memset(&dvi, 0, sizeof(dvi));			 // clear
	dvi.cbSize = sizeof(dvi);				 // set size for Windows

	return SUCCEEDED((*pDllGetVersion)(&dvi));
}

//////////////////////////////// CProcessList ////////////////////////////////

//////////////////
// Fill the array: Call EnumProcesses to do it. Return count.
//
UINT CProcessList::Fill()
{
	BOOL quit = FALSE;
	DWORD nAlloc = m_nAlloc;
	while (!quit) {
		DWORD* buf = new DWORD[nAlloc];
		DWORD nReturned=0;
		DWORD len = nAlloc*sizeof(DWORD);
		EnumProcesses(buf, len, &nReturned);
		if (nReturned<len) {
			quit = TRUE;
			int count = nReturned/sizeof(DWORD);
			reserve(count);					 // reserve space in vector
			insert(begin(),buf,buf+count); // copy from temp buf to array
		}
		delete [] buf;
		nAlloc<<=1;								 // double size and try again
	}
	return size();
}

//////////////////////////////// CModuleProcessList ////////////////////////////////

////////////////////////////////////////////////////////////////
// Fill the array: Call EnumProcessModules to do it. Return count.
//
UINT CProcessModuleList::Fill()
{
	m_hProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,FALSE,m_pid);
	if (!m_hProcess)
		return 0;
	BOOL quit = FALSE;
	DWORD nAlloc = m_nAlloc;
	while (!quit) {
		HMODULE* buf = new HMODULE[nAlloc];
		DWORD nReturned=0;
		DWORD len = nAlloc*sizeof(HMODULE);
		EnumProcessModules(m_hProcess, buf, len, &nReturned);
		if (nReturned<len) {
			quit = TRUE;
			int count = nReturned/sizeof(HMODULE);
			reserve(count);					 // reserve space in vector
			insert(begin(),buf,buf+count); // copy from temp buf to array
		}
		delete [] buf;
		nAlloc<<=1;								 // double size and try again
	}
	return size();
}

/////////////////
// dtor: close process handle
//
CProcessModuleList::~CProcessModuleList()
{
	if (m_hProcess) {
		CloseHandle(m_hProcess);
		m_hProcess=NULL;
	}
}

//////////////////////////////// CAppProcessList ////////////////////////////////

////////////////////////////////////////////////////////////////
// CAppProcessList - list of application processes. Derived from CProcessList
// with OnProcess override to find processes that use the given module.
//
BOOL CAppProcessList::OnProcess(DWORD pid)
{
	CProcessModuleList pml(pid);
	HANDLE hProcess = pml.GetProcessHandle();
	for (CProcessModuleList::iterator it=pml.begin(); it!=pml.end(); it++) {
		HMODULE hMod = *it;
		TCHAR modname[_MAX_PATH];
		GetModuleBaseName(hProcess, hMod, modname, _MAX_PATH);
		if (m_sAppName == modname)			 // module name match?
			return TRUE;						 //  yes: include it
		CString temp = m_sAppName;			 // module name
		temp += _T(".exe");					 // add .exe
		if (modname==temp)					 // match?
			return TRUE;						 //   yes: include it
	}
	return FALSE;
}

//////////////////
// Kill a process cleanly: Close main windows and wait.
// bZap=TRUE to force kill.
//
BOOL CAppProcessList::KillProcess(DWORD pid, BOOL bZap)
{
	CMainWinList mwl(pid);
	for (CMainWinList::iterator it=mwl.begin(); it!=mwl.end(); it++) {
		HWND hwnd = *it;
		DWORD bOKToKill = FALSE;
		SendMessageTimeout(hwnd, WM_QUERYENDSESSION, 0, 0,
			SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG, 100, &bOKToKill);
		if (!bOKToKill)
			return FALSE;  // window doesn't want to die: abort
		PostMessage(hwnd, WM_CLOSE, 0, 0);
	}

	// I've closed the main windows; now wait for process to die. 
	BOOL bKilled = TRUE;
	HANDLE hp=OpenProcess(SYNCHRONIZE|PROCESS_TERMINATE,FALSE,pid);
	if (hp) {
		if (WaitForSingleObject(hp, 5000) != WAIT_OBJECT_0) {
			if (bZap) { // didn't die: force kill it if zap requested
				TerminateProcess(hp,0);
			} else {
				bKilled = FALSE;
			}
		}
		CloseHandle(hp);
	}
	return bKilled;
}
