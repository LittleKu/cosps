////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LRESULT CSysCmdRouter::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	if (msg==WM_SYSCOMMAND && wp<SC_SIZE) {
		return m_pMainWnd->SendMessage(WM_COMMAND, wp, NULL);
	} else if (msg==WM_INITMENUPOPUP) {
		// Hide system menu flag (= HIWORD(lp)) so even system menu can be
		// initialized throughout MFC. This is somewhat dangerous because you lose the
		// ability to distinguish between the system menu and other menus--but if
		// you're adding your own commands it shouldn't matter which menu(s) they
		// come from! Just make sure your command IDs don't conflict with the
		// built-in commands like SC_SIZE, etc, which start at 0xF000. By default,
		// MFC command IDs start at 0x8000 so you'll be safe if you follow MFC.
		lp = LOWORD(lp);
	}
	return CSubclassWnd::WindowProc(msg, wp, lp); // pass along--important!
}

