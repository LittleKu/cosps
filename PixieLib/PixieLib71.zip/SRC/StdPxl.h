//#pragma warning( disable : 4661 ) // ignore ATL errors
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1
#include <afxwin.h>			// MFC core and standard components
#include <afxext.h>			// MFC extensions
#include <objbase.h>			// basic COM defs
#include <afxpriv.h>			// MFC private stuff
#include <afxinet.h>			// internet classes
#include <afxhtml.h>			// CHtmlView
#include <windowsx.h>		// GET_Y_LPARAM etc.

#include <PixieLib.h>		// public  PixieLib stuff
#include <PLWinMgr.h>		// WinMgr
#include <PLFolderTab.h>	// folder tabs
#include <PLDragDrop.h>		// drag/drop
#include <PLPrivate.h>		// private PixieLib stuff
