////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
// CMDIMenuMgr handles all aspects of MDI maximized stuff in a menu bar.
// In particular, it handles drawing of icon and min/restore/close buttons
// just like in main caption; handling these buttons; and initializing the
// MDI "Window" menu. CMDIMenuMgr is used by CMenuBar; you should never need
// to use it yourself.
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMDIMenuMgr::CMDIMenuMgr()
{
	m_bMDIMaximized = FALSE;	// are MDI windows maximized?
	m_xMin = 0;						// min x-pos for min/restore/close
	m_iTracking = 0;				// caption button tracking
}

CMDIMenuMgr::~CMDIMenuMgr()
{
}

//////////////////
// Compute the rectangles for icon and min/restore/close buttons.
//
void CMDIMenuMgr::CalcLayout()
{
	CMenuBar* pMenuBar = m_pMenuBar;
	ASSERT(pMenuBar);

	BOOL bHorz = (m_pMenuBar->m_dwStyle & CBRS_ORIENT_HORZ)!=0;

	// compute minimum allowed x-pos for min/restore/close buttons. This is
	// the rightmost edge of the last button, plus 2 pixels for good merit.
	// Note: xMin is really yMin for vertical toolbar.
	m_xMin = 0;
	int nButtons = pMenuBar->GetButtonCount();
	if (nButtons>0) {
		CRect rc;
		pMenuBar->GetItemRect(nButtons-1, &rc);
		m_xMin = (bHorz ? rc.right : rc.bottom) + 2;
	}

	// Compute rectangles for icon and min/max/close buttons
	CRect rcClient;
	pMenuBar->GetClientRect(&rcClient);
	pMenuBar->ClientToScreen(&rcClient);
	CRect rcWin;
	pMenuBar->GetWindowRect(&rcWin);
	rcClient -= rcWin.TopLeft(); // client rect in win rect coords

	// min/max/close buttons are inside rect of SM_CXSIZE x SM_CYSIZE
	int cxIcon = GetSystemMetrics(SM_CXSIZE);
	int cyIcon = GetSystemMetrics(SM_CYSIZE);

	CRect rc  = rcClient;

	if (bHorz) {
		rc.right = rc.left;
		rc.left -= GetSystemMetrics(SM_CXSMICON);
		rc.bottom = rc.top  + GetSystemMetrics(SM_CYSMICON);
		int delta = (rcClient.Height() - rc.Height())/2;
		rc += CPoint(0, delta);					 // center vertically
		m_rects[RCICON] = rc;					 // rectangle for icon: done

		// caption buttons must never overlap menu bar buttons ("File",
		// "Edit", etc). It is the menu bar's responsibility to set m_xMin.
		int right = max(rcClient.right, rcClient.left + m_xMin) + 3*cxIcon;

		// close button
		rc.SetRect(right-cxIcon, rc.top, right, rc.top+cyIcon);
		rc.DeflateRect(0,2);					// close box has 2 pixel border all sides...
		rc.right -= 2;							// ...but left
		m_rects[RCCLOSE] = rc;				// rectangle for close button: done

		// restore button 
		rc -= CPoint(cxIcon, 0);			// move left one button
		m_rects[RCRESTORE] = rc;			// restore button: done

		// minimize button
		rc -= CPoint(cxIcon-2,0);			// 2 pixel border on all sides but right.
		m_rects[RCMIN] = rc;					// minimize button: done

	} else {

		rc.bottom = rc.top;
		rc.top -= GetSystemMetrics(SM_CYSMICON);
		if (m_pMenuBar->m_dwStyle & CBRS_ALIGN_RIGHT)
			rc.left = rc.right - GetSystemMetrics(SM_CXSMICON);
		else
			rc.right = rc.left + GetSystemMetrics(SM_CXSMICON);
		m_rects[RCICON] = rc;					 // rectangle for icon: done

		// caption buttons must never overlap menu bar buttons ("File",
		// "Edit", etc). It is the menu bar's responsibility to set m_xMin.
		int bottom = max(rcClient.bottom, rcClient.top + m_xMin) + 3*cyIcon;

		// close button
		rc.SetRect(rc.left, bottom-cyIcon, rc.left + cxIcon, bottom);
		rc.DeflateRect(0,2);					// close box has 2 pixel border all sides...
		rc.right -= 2;							// ...but left
		m_rects[RCCLOSE] = rc;				// rectangle for close button: done

		// restore button 
		rc -= CPoint(0, rc.Height()+2);
		m_rects[RCRESTORE] = rc;

		// minimize button
		rc -= CPoint(0, rc.Height());
		m_rects[RCMIN] = rc;
	}
}

//////////////////
// Adjust client rectangle of menubar by shrinking it to
// allow room for MDI icon and min/max/close
//
void CMDIMenuMgr::AdjustClientRect(CRect& rcClient)
{
	if (m_bMDIMaximized) {
		if (m_pMenuBar->m_dwStyle & CBRS_ORIENT_HORZ) {
			rcClient.left += GetSystemMetrics(SM_CXSMICON);
			rcClient.right -= 3*GetSystemMetrics(SM_CXSIZE);
			if (rcClient.Width() < m_xMin)
				rcClient.right = rcClient.left + m_xMin;
		} else {
			rcClient.top += GetSystemMetrics(SM_CYSMICON);
			rcClient.bottom -= 3*GetSystemMetrics(SM_CYSIZE);
			if (rcClient.Height() < m_xMin)
				rcClient.bottom = rcClient.top + m_xMin;
		}
	}
}

//////////////////
// Adjust size of menubar by adding room for MDI icon and min/max/close.
//
CSize CMDIMenuMgr::AdjustSize(CSize sz, BOOL bHorz)
{
	if (m_bMDIMaximized) {
		if (bHorz) {
			// if MDI app, allow room for icon and sys/min/max/close buttons
			sz.cx += GetSystemMetrics(SM_CXSMICON) +
				3 * GetSystemMetrics(SM_CXSIZE);
		} else {
			sz.cy += GetSystemMetrics(SM_CYSMICON) +
				3 * GetSystemMetrics(SM_CYSIZE);
		}
	}
	return sz;
}

//////////////////
// Determine which button, if any, a point is in (pt in client coords).
//
int CMDIMenuMgr::HitTest(CPoint pt)
{
	for (int i=0; i<RCMAX; i++) {
		if (m_rects[i].PtInRect(pt))
			return i;
	}
	return -1;
}

//////////////////
// Handle a mouse message: look for click on one of my buttons.
// Returns TRUE if handled; ie, caller should eat the mouse message.
//
BOOL CMDIMenuMgr::OnMouseMsg(UINT msg, UINT /* nFlags */, CPoint pt)
{
	if (!m_bMDIMaximized)					 // not maximized:
		return FALSE;							 // don't even bother

	CWnd* pMenuBar = m_pMenuBar;
	ASSERT(pMenuBar);

	pMenuBar->ClientToScreen(&pt);
	CRect rc;
	pMenuBar->GetWindowRect(&rc);
	pt -= rc.TopLeft();

	ASSERT_VALID(pMenuBar);
	if (msg==WM_LBUTTONDOWN) {
		m_iTracking = HitTest(pt);			 // which button?

		if (m_iTracking==RCICON) {
			// user clicked on icon: draw "control" (system) menu
			CFrameWnd* pFrame = pMenuBar->GetTopLevelFrame()->GetActiveFrame();
			ASSERT_VALID(pFrame);

			// track menu
			TPMPARAMS tpm;
			CRect rcButton = m_rects[m_iTracking];
			CRect rcWin;
			pMenuBar->GetWindowRect(&rcWin);
			rcButton += rcWin.TopLeft();
			CPoint pt = ComputeMenuTrackPoint(rcButton, tpm);
			HMENU hmenu = ::GetSystemMenu(*pFrame, FALSE);
			if (hmenu) {
				TrackPopupMenuEx(hmenu,
					TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_VERTICAL,
					pt.x, pt.y, pMenuBar->GetOwner()->m_hWnd, &tpm);
			}
			return TRUE; // handled

		} else if (m_iTracking>=0) {
			// use clicked min, restore or close button: go into tracking mode
			CWindowDC dc(pMenuBar);
			DrawButton(dc, m_iTracking, TRUE); // draw button down
			m_bDown = TRUE;						  // remember state
			pMenuBar->SetCapture();				  // grab mouse input
			return TRUE;							  // handled
		}

	} else if ((msg==WM_MOUSEMOVE) && m_iTracking>0) {
		// mouse moved, and I am tracking: possibly draw button up/down
		BOOL bOldDown = m_bDown;
		m_bDown = m_rects[m_iTracking].PtInRect(pt);
		if (bOldDown != m_bDown) {
			// up/down state changed: need to redraw button
			CWindowDC dc(pMenuBar);
			DrawButton(dc, m_iTracking, m_bDown);
		}
		return TRUE; // handled

	} else if (msg==WM_LBUTTONUP && m_iTracking>0) {
		// user released the mouse and I am tracking: do button command
		ReleaseCapture(); // let go the mouse
		if (m_bDown) {
			// if button was down when released: draw button up, and do system cmd
			CWindowDC dc(pMenuBar);
			DrawButton(dc, m_iTracking, FALSE);
			CFrameWnd* pFrame = pMenuBar->GetTopLevelFrame()->GetActiveFrame();
			ASSERT_VALID(pFrame);
			static UINT syscmd[4] =
				{ SC_MOUSEMENU, SC_MINIMIZE, SC_RESTORE, SC_CLOSE };
			pFrame->SendMessage(WM_SYSCOMMAND, syscmd[m_iTracking]);
		}
		m_iTracking = 0; // stop tracking
		return TRUE;	  // handled (eat)
	}
	return FALSE;
}

//////////////////
// Given button rectangle, compute point and "exclude rect" for
// TrackPopupMenu, based on current docking style, so that the menu will
// appear always inside the window.
//
CPoint CMDIMenuMgr::ComputeMenuTrackPoint(const CRect& rcButn, TPMPARAMS& tpm)
{
	tpm.cbSize = sizeof(tpm);
	DWORD dwStyle = m_pMenuBar->m_dwStyle;
	CPoint pt;
	CRect& rcExclude = (CRect&)tpm.rcExclude;
	rcExclude = rcButn;
	::GetWindowRect(::GetDesktopWindow(), &rcExclude);

	switch (dwStyle & CBRS_ALIGN_ANY) {
	case CBRS_ALIGN_BOTTOM:
		pt = CPoint(rcButn.left, rcButn.top);
		rcExclude.top = rcButn.top;
		break;

	case CBRS_ALIGN_LEFT:
		pt = CPoint(rcButn.right, rcButn.top);
		rcExclude.right = rcButn.right;
		break;

	case CBRS_ALIGN_RIGHT:
		pt = CPoint(rcButn.left, rcButn.top);
		rcExclude.left = rcButn.left;
		break;

	default: //	case CBRS_ALIGN_TOP:
		pt = CPoint(rcButn.left, rcButn.bottom);
		break;
	}
	return pt;
}

//////////////////
// Initialize MDI "Window" menu by adding names of all the MDI children.
// This duplicates what the default handler for WM_MDISETMENU does, but
// it's necessary to reinvent the wheel since menu bars manage the menu
// themselves. This function is called when the frame gets WM_INITMENUPOPUP.
//
void CMDIMenuMgr::OnInitWindowMenu()
{
	CMenu menu;
	menu.Attach((HMENU)m_hmenuWindow);

	// scan for first window command
	int n = menu.GetMenuItemCount();
	BOOL bAddSeperator = TRUE;
	int iPos;
	for (iPos=0; iPos<n; iPos++) {
		if (menu.GetMenuItemID(iPos) >= AFX_IDM_FIRST_MDICHILD) {
			bAddSeperator = FALSE;
			break;
		}
	}

	// iPos is either first window item, or end if none found.

	// delete everything after.
	while (iPos < (int)menu.GetMenuItemCount())
		menu.RemoveMenu(iPos, MF_BYPOSITION);

	// get active window so I can check its menu item
	ASSERT(m_pMenuBar->m_hWndMDIClient);
	HWND hwndActive = (HWND)::SendMessage(m_pMenuBar->m_hWndMDIClient,
		WM_MDIGETACTIVE, 0, NULL);

	// append window names in the form "# title"
	int iWin=1;
	for (HWND hwnd=GetWindow(m_pMenuBar->m_hWndMDIClient, GW_CHILD);
		  hwnd;
		  hwnd = GetWindow(hwnd, GW_HWNDNEXT)) {

		if (bAddSeperator) {
			menu.InsertMenu(iPos++, MF_BYPOSITION|MF_SEPARATOR);
			bAddSeperator = FALSE;
		}

		// build item name and add it to the menu
		CString sWinName, sMenuItem;
		CWnd::FromHandle(hwnd)->GetWindowText(sWinName);
		sMenuItem.Format(_T("&%d  %s"), iWin++, (LPCTSTR)sWinName);
		menu.InsertMenu(iPos, MF_BYPOSITION,
			::GetDlgCtrlID(hwnd), sMenuItem);
		if (hwnd==hwndActive)
			menu.CheckMenuItem(iPos, MF_BYPOSITION|MF_CHECKED);
		iPos++;
	}
	menu.Detach();
}

//////////////////
// Draw single button in up or down state
//
void CMDIMenuMgr::DrawButton(CDC& dc, int iWhich, BOOL bPressed)
{
	ASSERT(RCICON<=iWhich && iWhich<=RCMAX);
	CRect& rc = m_rects[iWhich];
	if (iWhich==RCICON) {
		// draw icon
		ASSERT(m_pMenuBar->m_hWndMDIClient);
		HWND hwnd = (HWND)::SendMessage(m_pMenuBar->m_hWndMDIClient,
			WM_MDIGETACTIVE, 0, NULL);
		HICON hicon = (HICON)GetClassLong(hwnd, GCL_HICONSM);
		DrawIconEx(dc, rc.left, rc.top, hicon, rc.Width(), rc.Height(),
			0, NULL, DI_NORMAL);

	} else {
		// use DrawFrameControl to draw min/restore/close button
		static UINT dfcs[4] = { 0,
			DFCS_CAPTIONMIN, DFCS_CAPTIONRESTORE, DFCS_CAPTIONCLOSE };
		UINT uState = dfcs[iWhich];
		if (bPressed)
			uState |= DFCS_PUSHED;
		dc.DrawFrameControl(&rc, DFC_CAPTION, uState);
	}
}

