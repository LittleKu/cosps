////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-2005 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual Studio.NET 7.1 or greater. Set tabsize=3.
// 
// NOTE: PixieLib is NOT freeware! 
// If you didn't pay for your copy, you're violating my copyright!
//
#include "StdPxl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CSizeableDlg, CDialog)
BEGIN_MESSAGE_MAP(CSizeableDlg, CDialog)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()

CSizeableDlg::CSizeableDlg(UINT nIDRes, CWnd* pParent, WINRECT* pWinMap)
	: CDialog(nIDRes, pParent), m_winMgr(pWinMap)
{
}

CSizeableDlg::~CSizeableDlg()
{
}

//////////////////
// Initialize dialog: make TOFIT size for all TOFIT controls whatever their
// current size is. Also, do a recalc/setpos because the calculated layout
// will never match exactly the dialog template--need to force calculated
// layout to avoid controls jumping the first time the user sizes. THIS IS
// IMPORTANT!
//
BOOL CSizeableDlg::OnInitDialog()
{
	BOOL bRet = CDialog::OnInitDialog();
	m_winMgr.InitToFitSizeFromCurrent(this); // make tofit = current size
	m_winMgr.CalcLayout(this);					  // recalc
	m_winMgr.SetWindowPositions(this);		  // set positions
	return bRet;
}

/////////////////
// Dialog sized: let WinMgr handle it
//
void CSizeableDlg::OnSize(UINT /* nType */, int cx, int cy)
{
	m_winMgr.CalcLayout(cx,cy,this);
	m_winMgr.SetWindowPositions(this);
}

//////////////////
// Handle WM_GETMINMAXINFO: Let WinMgr calculate it.
//
void CSizeableDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	m_winMgr.GetMinMaxInfo(this, lpMMI);
}

