The documentation and instructions are in PixieDoc.htm, which you can view
with your web browser. The latest changes are listed in ReleaseHistory.txt 

Thanks, and Happy Programming!

Paul DiLascia
www.dilascia.com



