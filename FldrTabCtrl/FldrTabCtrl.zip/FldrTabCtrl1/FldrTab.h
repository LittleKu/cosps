/////////////////////////////////////////////////////////////////////////////
// Project��FLDRTAB
// Author��NorthTibet
// Date�����ڶ�, ʮ���� 24, 2002
// Description��ʾ����δ����ļ���ʽ���ı�ǩ����
//
/////////////////////////////////////////////////////////////////////////////
// FldrTab.h : main header file for the FLDRTAB application
//

#if !defined(AFX_FLDRTAB_H__57568F29_10DB_4B9C_8BA6_FE705DD69381__INCLUDED_)
#define AFX_FLDRTAB_H__57568F29_10DB_4B9C_8BA6_FE705DD69381__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFldrTabApp:
// See FldrTab.cpp for the implementation of this class
//

class CFldrTabApp : public CWinApp
{
public:
	CFldrTabApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFldrTabApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFldrTabApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLDRTAB_H__57568F29_10DB_4B9C_8BA6_FE705DD69381__INCLUDED_)
