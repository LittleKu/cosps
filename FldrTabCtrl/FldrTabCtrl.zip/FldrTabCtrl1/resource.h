//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FldrTab.rc
//
#define IDR_FOLDERTABS                  1
#define IDD_FLDRTAB_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_STATIC_IMG                  130
#define IDC_STATIC_TEXT                 1004
#define IDC_STATIC_MAIL                 1005
#define IDC_FOLDERTAB                   1006
#define IDC_STATICINFO                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
