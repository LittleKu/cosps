/////////////////////////////////////////////////////////////////////////////
// Project��FLDRTAB
// Author��NorthTibet
// Date�����ڶ�, ʮ���� 24, 2002
// Description��ʾ����δ����ļ���ʽ���ı�ǩ����
//
/////////////////////////////////////////////////////////////////////////////
// FldrTabDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ftab.h"
#include "FldrTab.h"
#include "FldrTabDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFldrTabDlg dialog

CFldrTabDlg::CFldrTabDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFldrTabDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFldrTabDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFldrTabDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFldrTabDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFldrTabDlg, CDialog)
	//{{AFX_MSG_MAP(CFldrTabDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(FTN_TABCHANGED, IDC_FOLDERTAB, OnChangedTab)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFldrTabDlg message handlers

BOOL CFldrTabDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// hook info control
	m_wndStaticInfo.SubclassDlgItem(IDC_STATICINFO, this);

	// Create folder tab and load it. Control is created in same position
	// as static control with IDC_FOLDERTAB, which will be deleted.
	// This is just a trick so I can design the dialog with the resource editor.
	//
	m_wndFolderTab.CreateFromStatic(IDC_FOLDERTAB, this);
	m_wndFolderTab.Load(IDR_FOLDERTABS); // Load strings


	m_wndLink1.m_link = _T("http://www.vckbase.com");
	m_wndLink2.m_link = _T("http://www.vckbase.com");
	m_wndLink3.m_link = _T("mailto:vckbase@publik.hk.hi.cn");
	m_wndLink1.SubclassDlgItem(IDB_STATIC_IMG, this);
	m_wndLink2.SubclassDlgItem(IDC_STATIC_TEXT, this);
	m_wndLink3.SubclassDlgItem(IDC_STATIC_MAIL, this);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFldrTabDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFldrTabDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFldrTabDlg::OnChangedTab(NMFOLDERTAB* nmtab, LRESULT* pRes)
{
	CString s;
	s.Format(_T("ѡ�� %d: %s"), nmtab->iItem,
		nmtab->pItem->GetText());
	m_wndStaticInfo.SetWindowText(s);	
}
