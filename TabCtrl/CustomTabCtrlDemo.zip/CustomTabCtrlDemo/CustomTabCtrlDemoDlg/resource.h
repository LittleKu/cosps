//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomTabCtrlDemoDlg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CUSTOMTABCTRLDEMO_DIALOG    102
#define IDR_MAINFRAME                   128
#define IDC_CURSORMOVE                  133
#define IDC_CURSORCOPY                  134
#define IDC_TAB                         1000
#define IDC_COLOR                       1001
#define IDC_FIXEDCK                     1002
#define IDC_FOURBUTTONSCK               1003
#define IDC_AUTOHIDEBUTTONSCK           1004
#define IDC_TOOLTIPSCK                  1005
#define IDC_MULTIHIGHLIGHTCK            1006
#define IDC_EDITLABELSCK                1007
#define IDC_DRAGMOVECK                  1008
#define IDC_DRAGCOPYCK                  1009
#define IDC_RADIO1                      1010
#define IDC_RADIO2                      1011
#define IDC_CLOSEBUTTONSCK              1012
#define IDC_LIST1                       1013
#define IDC_RTLYCK                      1013
#define IDC_CLOSEBUTTONSCK2             1014
#define IDC_BUTTONSAFTERCK              1014
#define IDC_TOPCK                       1015
#define IDC_RADIO3                      1015
#define IDC_RADIO4                      1016
#define IDC_RADIO5                      1017
#define IDC_RADIO6                      1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
