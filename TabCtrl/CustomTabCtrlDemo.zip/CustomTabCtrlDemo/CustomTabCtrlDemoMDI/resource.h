//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomTabCtrlDemoMDI.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CUSTOMTYPE                  129
#define IDD_PROPERTIES                  131
#define IDB_BITMAP1                     132
#define IDC_CURSORMOVE                  133
#define IDC_LABELED                     1000
#define IDC_URLED                       1001
#define IDC_TOOLTIPED                   1002
#define ID_INCHEIGHT                    32771
#define ID_DECHEIGHT                    32772
#define ID_LEFT                         32775
#define ID_RIGHT                        32776
#define ID_TOP                          32777
#define ID_BOTTOM                       32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
