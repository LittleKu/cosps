//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BarDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BARDEMTYPE                  129
#define IDD_DIALOGBAR                   130
#define IDB_BUTBMP                      131
#define IDI_ICON3                       133
#define IDI_ICON2                       134
#define IDD_DIALOGBAR2                  135
#define IDI_ICON1                       136
#define IDC_COMBO1                      1002
#define IDC_CHECK1                      1003
#define IDC_CHECK2                      1004
#define IDC_EDIT1                       1005
#define IDC_TREE1                       1006
#define ID_SHOWLEFTBAR                  32771
#define ID_SHOWBOTTOMBAR                32772
#define IDC_MYTREECTRL                  61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
