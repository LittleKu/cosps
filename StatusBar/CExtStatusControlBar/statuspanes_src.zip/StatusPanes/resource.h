//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StatusPanes.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_STATUSPANESTYPE             129
#define IDS_PANE_TEXT                   129
#define IDR_TOOLBAR2                    130
#define IDR_HEARTBEAT                   130
#define IDB_BMP_PROFUIS                 130
#define IDS_PANE_EDIT                   131
#define IDS_PANE_SLIDER_CTRL            132
#define IDS_PANE_BUTTON                 133
#define IDD_DIALOG_CHILD_VIEW           136
#define IDR_DOWNLOAD                    138
#define IDC_DRAW_PANE_SEPARATORS        1000
#define IDC_OUTER_RECT_IN_FIRST_BAND    1001
#define IDC_HIDE_TEXT_ON_DISABLED_PANES 1002
#define IDC_PROFUIS_LOGO                1002
#define IDC_EDIT1                       1004
#define IDC_POSITION                    1004
#define IDC_RADIO_TYPE_TEXT             1009
#define IDC_RADIO_TYPE_EDIT             1011
#define IDC_RADIO_TYPE_PROGRESS         1012
#define IDC_RADIO_TYPE_SLIDER           1013
#define IDC_RADIO_TYPE_BUTTON           1014
#define IDC_SPIN_POSITION               1015
#define IDC_RADIO_TYPE_ANIM_CTRL        1024
#define IDC_RADIO_TYPE_STATIC           1025
#define IDC_STATUS_BAR_BUTTON           3018
#define IDC_ADD_PANE                    24001
#define IDC_REMOVE_PANE                 24002
#define IDC_DISABLE_PANE                24003
#define ID_VIEW_MENUBAR                 32771
#define ID_VIEW_LIKE_OFFICE_2K          32772
#define ID_VIEW_LIKE_OFFICE_XP          32773
#define IDS_PANE_PROGRESS               32774
#define ID_VIEW_PANEL_EMPTY             32775
#define ID_VIEW_PANEL_CUSTOM_DRAWN      32776
#define ID_VIEW_PANEL_EDIT              32777
#define ID_VIEW_PANEL_DIALOG            32778
#define ID_VIEW_PANEL_PALETTE           32779
#define ID_VIEW_PANEL_TOOLS             32780
#define ID_VIEW_PANEL_RESIZABLE1        32781
#define ID_VIEW_PANEL_RESIZABLE2        32782
#define ID_VIEW_LIKE_OFFICE_2003        32783
#define IDS_PANE_ANIMATE                32784
#define IDS_PANE_LABEL                  32785
#define IDS_PANE_HYPER_LINK             32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
