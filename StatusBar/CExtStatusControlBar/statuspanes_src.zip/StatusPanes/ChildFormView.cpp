// ChildFormView.cpp : implementation file
//

#include "stdafx.h"
#include "StatusPanes.h"
#include "ChildFormView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFormView

IMPLEMENT_DYNCREATE(CChildFormView, CFormView)

CChildFormView::CChildFormView()
	: CFormView ( CChildFormView::IDD )
,m_pWndEdit(NULL)
,m_pWndSliderCtrl(NULL)
,m_pWndButton(NULL)
,m_pWndProgressCtrl(NULL)
,m_pWndAnimateCtrl(NULL)
{
	//{{AFX_DATA_INIT(CChildFormView)
	m_nPosition = 0;
	m_nPaneType = 0;
	//}}AFX_DATA_INIT
	m_bInitComplete = false;
	m_pMainFrame = DYNAMIC_DOWNCAST(CMainFrame,AfxGetMainWnd());
}

CChildFormView::~CChildFormView()
{
}

void CChildFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChildFormView)
	DDX_Control(pDX, IDC_DISABLE_PANE, m_btnDisablePane);
	DDX_Control(pDX, IDC_SPIN_POSITION, m_SpinPosition);
	DDX_Control(pDX, IDC_REMOVE_PANE, m_btnRemovePane);
	DDX_Control(pDX, IDC_ADD_PANE, m_btnAddPane);
	DDX_Text(pDX, IDC_POSITION, m_nPosition);
	DDV_MinMaxInt(pDX, m_nPosition, 0, 20);
	DDX_Radio(pDX, IDC_RADIO_TYPE_TEXT, m_nPaneType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChildFormView, CFormView)
	//{{AFX_MSG_MAP(CChildFormView)
	ON_BN_CLICKED(IDC_ADD_PANE, OnAddPane)
	ON_BN_CLICKED(IDC_REMOVE_PANE, OnRemovePane)
	ON_BN_CLICKED(IDC_DISABLE_PANE, OnDisablePane)
	ON_BN_CLICKED(IDC_STATUS_BAR_BUTTON, OnStatusBarButton)
	ON_UPDATE_COMMAND_UI(ID_APP_ABOUT, OnUpdateAppAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFormView diagnostics

#ifdef _DEBUG
void CChildFormView::AssertValid() const
{
	CFormView::AssertValid();
}

void CChildFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFormView message handlers

BOOL CChildFormView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CFormView::PreCreateWindow(cs))
		return FALSE;
	
	cs.dwExStyle &= ~(WS_EX_CLIENTEDGE|WS_EX_STATICEDGE);
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(0);
	
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	m_SpinPosition.SetRange(0,20);

	m_pMainFrame->m_wndStatusBar.GetStatusBarCtrl().SetMinHeight(23);
	
	m_pMainFrame->m_wndStatusBar.SetPaneWidth(0,100);

	m_nPaneType = 6; // label
	m_nPosition = 0;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 1; // edit
	m_nPosition = 2;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 2; // progress ctrl
	m_nPosition = 3;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 3; // slider ctrl
	m_nPosition = 4;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 5; // animate ctrl
	m_nPosition = 5;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 4; // button
	m_nPosition = 6;
	UpdateData(0);
	OnAddPane(); 

	m_nPaneType = 0;
	m_nPosition = 0;
	UpdateData(0);
	
	m_bInitComplete = true;
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnAddPane() 
{
	UpdateData();
	
	if( m_nPosition < 0 || m_nPosition > 20 )
		return;

	switch( m_nPaneType ) 
	{
	case 0: // text
		{
			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_TEXT,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
		}
		break;

	case 1: // edit
		{
			m_pWndEdit = new CExtStatusBarEdit;
			if (!m_pWndEdit->Create(
				WS_CHILD|WS_VISIBLE|WS_TABSTOP, 
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				0))
			{
				TRACE(_T("Failed to create edit control.\n"));
				return;
			}
			
			m_pWndEdit->SetFont(
				CFont::FromHandle(
				(HFONT)::GetStockObject(DEFAULT_GUI_FONT)
				)
			 	);

			m_pWndEdit->SetWindowText(_T("Type text here..."));
			
			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_EDIT,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_EDIT);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 100);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndEdit, IDS_PANE_EDIT, true);
		}
		break;

	case 2: // progress ctrl
		{
			m_pWndProgressCtrl = new CExtStatusBarProgressCtrl;
			if (!m_pWndProgressCtrl->Create(
				WS_CHILD|WS_VISIBLE|WS_TABSTOP, //|PBS_SMOOTH
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				0))
			{
				TRACE(_T("Failed to create progress control.\n"));
				return;
			}

			m_pWndProgressCtrl->ModifyStyleEx(WS_EX_STATICEDGE,0,SWP_FRAMECHANGED);

			m_pWndProgressCtrl->SetRange(0,300);
			m_pWndProgressCtrl->SetPos(0);
			m_pWndProgressCtrl->SetStep(1);

			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_PROGRESS,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_PROGRESS);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 100);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndProgressCtrl, IDS_PANE_PROGRESS, true);

			m_pWndProgressCtrl->SetTimer(0,1,NULL);
		}
		break;

	case 3: // slider ctrl
		{
			m_pWndSliderCtrl = new CExtStatusBarSliderCtrl;
			if (!m_pWndSliderCtrl->Create(
				WS_CHILD|WS_VISIBLE|WS_TABSTOP|TBS_HORZ, 
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				0))
			{
				TRACE(_T("Failed to create slider control.\n"));
				return;
			}
			
			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_SLIDER_CTRL,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_SLIDER_CTRL);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 80);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndSliderCtrl, IDS_PANE_SLIDER_CTRL, true);
		}
		break;
		
	case 4: // button
		{
			m_pWndButton = new CExtStatusBarButton;
			if (!m_pWndButton->Create(
				_T("Button"),
				WS_CHILD|WS_VISIBLE|WS_TABSTOP,
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				IDC_STATUS_BAR_BUTTON))
			{
				TRACE(_T("Failed to create button control.\n"));
				return;
			}
			m_pWndButton->SetFont(
				CFont::FromHandle(
				(HFONT)::GetStockObject(DEFAULT_GUI_FONT)
				)
				);
			
			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_BUTTON,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_BUTTON);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 50);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndButton, IDS_PANE_BUTTON, true);
		}
		break;
	
	case 5: // animate ctrl
		{
			m_pWndAnimateCtrl = new CExtStatusBarAnimateCtrl;
			if (!m_pWndAnimateCtrl->Create(
				WS_CHILD|WS_VISIBLE|WS_TABSTOP|ACS_CENTER|ACS_AUTOPLAY|ACS_TRANSPARENT,
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				0))
			{
				TRACE(_T("Failed to create animate control.\n"));
				return;
			}
			m_pWndAnimateCtrl->Open(IDR_DOWNLOAD);
			
			
			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_ANIMATE,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_ANIMATE);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 16);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndAnimateCtrl, IDS_PANE_ANIMATE, true);
		}
		break;
	
	case 6: // label
		{
			m_pWndLabel = new CExtStatusBarLabel;
			if (!m_pWndLabel->Create(
				_T("Company Logo"),
				WS_CHILD|WS_VISIBLE|WS_TABSTOP|SS_CENTER,
				CRect(0,0,0,0), 
				&m_pMainFrame->m_wndStatusBar, 
				0))
			{
				TRACE(_T("Failed to create label control.\n"));
				return;
			}
			
			m_pWndLabel->SetFont(
				CFont::FromHandle(
				(HFONT)::GetStockObject(DEFAULT_GUI_FONT)
				)
				);

			BOOL bRet = m_pMainFrame->m_wndStatusBar.AddPane(IDS_PANE_LABEL,m_nPosition);
			if(!bRet){
				AfxMessageBox(_T("Pane index out of range\nor pane with same ID already exists in the status bar"), MB_ICONERROR);
				return;
			}
			
			int nIndex = m_pMainFrame->m_wndStatusBar.CommandToIndex(IDS_PANE_LABEL);
			if (nIndex == -1)
				return;
			
			m_pMainFrame->m_wndStatusBar.SetPaneWidth(nIndex, 110);
			m_pMainFrame->m_wndStatusBar.AddPaneControl(m_pWndLabel, IDS_PANE_LABEL, true);
		}
		break;
	}
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnRemovePane() 
{
	UpdateData();
	if( m_nPosition < 0 || m_nPosition > 20 )
		return;

	if(!m_pMainFrame->m_wndStatusBar.RemovePane(
		m_pMainFrame->m_wndStatusBar.GetItemID(m_nPosition))
		)
	{
		CString s;
		s.Format(_T("Pane %d was not found in the status bar \nor must be at least one of them."), m_nPosition);
		AfxMessageBox(s, MB_ICONERROR);
	}
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnStatusBarButton() 
{
	AfxMessageBox(_T("StatusBar Button Clicked."));
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnDisablePane() 
{
	UpdateData();
	if( m_nPosition < 0 || m_nPosition > 20 )
		return;
	
	UINT nID, nStyle;
	int cxWidth;
	
	m_pMainFrame->m_wndStatusBar.GetPaneInfo(m_nPosition, nID, nStyle, cxWidth);
	
	BOOL bDisabled = ((nStyle&SBPS_DISABLED) == 0);

	m_pMainFrame->m_wndStatusBar.SetPaneStyle(
		m_nPosition,
		//nID,
		bDisabled 
			? nStyle | SBPS_DISABLED 
			: nStyle & ~SBPS_DISABLED
		//`cxWidth
		);
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::CheckControls()
{
	if(!m_bInitComplete)
		return;
	
	UpdateData();
	if( m_nPosition < 0 ){
		m_nPosition = 0;
		UpdateData(0);
		return;
	}
	if( m_nPosition > 20 ){
		m_nPosition = 20;
		UpdateData(0);
		return;
	}
	
	int nCount = m_pMainFrame->m_wndStatusBar.GetPanesCount();

	if( m_nPosition >= nCount )
	{
		m_btnDisablePane.EnableWindow(FALSE);
		m_btnRemovePane.EnableWindow(FALSE);
		if( m_nPosition != nCount ){
			m_btnAddPane.EnableWindow(FALSE);
			return;
		}
	}
	else
	{
		m_btnDisablePane.EnableWindow(TRUE);
		m_btnRemovePane.EnableWindow(TRUE);
	}

	BOOL bFinded = false;
	int i=0;

	switch(m_nPaneType) {
	case 0:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_TEXT == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 1:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_EDIT == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 2:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_PROGRESS == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 3:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_SLIDER_CTRL == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 4:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_BUTTON == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 5:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_ANIMATE == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	case 6:
		for(i=0; i<m_pMainFrame->m_wndStatusBar.GetPanesCount(); i++)
			if( IDS_PANE_LABEL == m_pMainFrame->m_wndStatusBar.GetItemID(i) ){
				bFinded = true;
				break;
			}
		break;
	}

	m_btnAddPane.EnableWindow( !bFinded );
	
}

//////////////////////////////////////////////////////////////////////////

void CChildFormView::OnUpdateAppAbout(CCmdUI* pCmdUI) 
{
	pCmdUI;
	CheckControls();
}
