#if !defined(AFX_CHILDFORMVIEW_H__5A1BD4EF_2576_4480_BC1A_54B9357C8DC8__INCLUDED_)
#define AFX_CHILDFORMVIEW_H__5A1BD4EF_2576_4480_BC1A_54B9357C8DC8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChildFormView.h : header file
//

#include "ExtLabel.h"

class CMainFrame;

/////////////////////////////////////////////////////////////////////////////
// CChildFormView form view

class CChildFormView
: public CFormView
{
protected:
	CChildFormView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CChildFormView)

	friend class CMainFrame;
	
	CMainFrame *m_pMainFrame;

// Form Data
public:
	//{{AFX_DATA(CChildFormView)
	enum { IDD = IDD_DIALOG_CHILD_VIEW };
	CButton	m_btnDisablePane;
	CSpinButtonCtrl	m_SpinPosition;
	CButton	m_btnRemovePane;
	CButton	m_btnAddPane;
	int		m_nPosition;
	int		m_nPaneType;
	//}}AFX_DATA

// Attributes
public:

	class CExtStatusBarAnimateCtrl : public CAnimateCtrl{
		virtual void PostNcDestroy(){
			delete this;
		}
	};
	 
	class CExtStatusBarEdit : public CEdit{
		virtual void PostNcDestroy(){
			delete this;
		}
	};

	class CExtStatusBarSliderCtrl : public CSliderCtrl{
		virtual void PostNcDestroy(){
			delete this;
		}
	};

	class CExtStatusBarButton : public CButton{
		virtual void PostNcDestroy(){
			delete this;
		}
	};

	class CExtStatusBarLabel : public CExtLabel{
		virtual void PostNcDestroy(){
			delete this;
		}
	};

	class CExtStatusBarProgressCtrl : public CProgressCtrl
	{
		virtual LRESULT WindowProc(    
			UINT uMsg,
			WPARAM wParam,
			LPARAM lParam
			)
		{
			if( uMsg == WM_TIMER ){
				StepIt();
			}
			if( uMsg == WM_DESTROY ){
				KillTimer(0);
			}
			LRESULT lResult = CProgressCtrl::WindowProc(uMsg, wParam, lParam);
			return lResult;
		}
		
		virtual void PostNcDestroy(){
			delete this;
		}
	};

	CExtStatusBarEdit *m_pWndEdit;
	CExtStatusBarSliderCtrl *m_pWndSliderCtrl;
	CExtStatusBarButton *m_pWndButton;
	CExtStatusBarProgressCtrl *m_pWndProgressCtrl;
	CExtStatusBarAnimateCtrl *m_pWndAnimateCtrl;
	CExtStatusBarLabel *m_pWndLabel;

// Operations
public:


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFormView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CChildFormView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CChildFormView)
	afx_msg void OnAddPane();
	afx_msg void OnRemovePane();
	afx_msg void OnDisablePane();
	afx_msg void OnStatusBarButton();
	afx_msg void OnUpdateAppAbout(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void CheckControls();
	bool m_bInitComplete;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFORMVIEW_H__5A1BD4EF_2576_4480_BC1A_54B9357C8DC8__INCLUDED_)
