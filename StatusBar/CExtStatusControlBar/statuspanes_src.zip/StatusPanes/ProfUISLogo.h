#if !defined(AFX_PROFUISLOGO_H__C0EE973E_91E9_4172_B9B0_CA2DD8C6D12A__INCLUDED_)
#define AFX_PROFUISLOGO_H__C0EE973E_91E9_4172_B9B0_CA2DD8C6D12A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProfUISLogo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProfUISLogo window

class CProfUISLogo : public CStatic
{
// Construction
public:
	CProfUISLogo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProfUISLogo)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProfUISLogo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CProfUISLogo)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnClicked();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	HINSTANCE GotoURL(LPCTSTR url, int showcmd);
	HCURSOR m_hLinkCursor;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROFUISLOGO_H__C0EE973E_91E9_4172_B9B0_CA2DD8C6D12A__INCLUDED_)
