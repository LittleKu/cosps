// CToolBarExDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CToolBarEx.h"
#include "CToolBarExDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCToolBarExDlg dialog

CCToolBarExDlg::CCToolBarExDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCToolBarExDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCToolBarExDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCToolBarExDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCToolBarExDlg)
	DDX_Control(pDX, IDC_TOOLBAR2, m_toolBar2);
	DDX_Control(pDX, IDC_TOOLBAR, m_toolBar);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCToolBarExDlg, CDialog)
	//{{AFX_MSG_MAP(CCToolBarExDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCToolBarExDlg message handlers

BOOL CCToolBarExDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_toolBar.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON2),IMAGE_ICON,16,16,0),300,"Test Button 1");
	m_toolBar.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON3),IMAGE_ICON,16,16,0),301,"Test Button 2");
	m_toolBar.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON2),IMAGE_ICON,16,16,0),302,"Test Button 3");
	m_toolBar.AddSeparator();
	m_toolBar.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON5),IMAGE_ICON,16,16,0),303,"Test Button 4");
	m_toolBar.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON2),IMAGE_ICON,16,16,0),304,"Test Button 5");


	m_toolBar2.SetButtonSize(CSize(32,32));
	m_toolBar2.SetButtonSpacing(CSize(40,40));
	m_toolBar2.SetBackGroundColor(RGB(255,255,128));
	m_toolBar2.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON4),IMAGE_ICON,32,32,0),300,"Test Button 1");
	m_toolBar2.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON7),IMAGE_ICON,32,32,0),301,"Test Button 2");
	m_toolBar2.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON6),IMAGE_ICON,32,32,0),302,"Test Button 3");
	m_toolBar2.AddSeparator();
	m_toolBar2.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON4),IMAGE_ICON,32,32,0),303,"Test Button 4");
	m_toolBar2.AddButton((HICON)LoadImage(AfxGetInstanceHandle( ),
		MAKEINTRESOURCE(IDI_ICON7),IMAGE_ICON,32,32,0),304,"Test Button 5");
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCToolBarExDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCToolBarExDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCToolBarExDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCToolBarExDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	m_toolBar.EnableButton(1,!m_toolBar.GetButton(1,-1)->fsState);
}

BOOL CCToolBarExDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	switch(wParam)
	{
	case 300:
		AfxMessageBox("Button1");
		break;
	case 301:
		AfxMessageBox("Button2");
		break;
	case 302:
		AfxMessageBox("Button3");
		break;
	case 303:
		AfxMessageBox("Button4");
		break;
	case 304:
		AfxMessageBox("Button5");
		break;
	case 305:
		AfxMessageBox("Button6");
		break;
	}
	return CDialog::OnCommand(wParam, lParam);
}
