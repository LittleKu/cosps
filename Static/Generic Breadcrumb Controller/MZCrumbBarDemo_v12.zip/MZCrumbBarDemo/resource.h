//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CrumbBarDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CRUMBBARDEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_CRUMBBAR                    1000
#define IDC_TEXT                        1001
#define IDC_TEXT2                       1002
#define IDC_CRUMBPATH                   1002
#define IDC_CHKGRADIENT                 1003
#define IDC_CHKGRADIENT2                1004
#define IDC_CHK_NODELIMITERONLAST       1004
#define IDC_CHKADVMODE                  1006
#define IDC_CHKCUSTMODE                 1007
#define IDC_CHKEDITONCLICK              1008
#define IDC_CHKEDITONDBLCK              1009
#define IDC_CHKLEFTMARGIN               1010
#define IDC_EDITMARGIN                  1011
#define IDC_BTNPATH1                    1012
#define IDC_BTNPATH2                    1013
#define IDC_BTNPATH3                    1014
#define IDC_RADIO1                      1015
#define IDC_RADIO2                      1016
#define IDC_RADIO3                      1017
#define IDC_CHKSPACING                  1018
#define IDC_EDITMARGIN2                 1019
#define IDC_EDITSPACING                 1019
#define IDC_CHKEDITONBK                 1020
#define IDC_CHKEDITONCLICKL             1021
#define IDC_CHKEDITONCLICKR             1022
#define IDC_CHKEDITONCLICKM             1023
#define IDC_CHKEDITONCLICKDBLL          1024
#define IDC_CHECK1                      1025
#define IDC_CHK_STYLECALLBACK           1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
