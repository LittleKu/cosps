#if !defined(AFX_CONFIG_H__38865E88_6F50_4A91_ADB1_593C20A0C17E__INCLUDED_)
#define AFX_CONFIG_H__38865E88_6F50_4A91_ADB1_593C20A0C17E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Config.h : header file
//

#include "BigclockDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CConfig dialog

class CConfig : public CDialog
{
// Construction
public:
	void Show();
	CConfig(CWnd* pParent = NULL);   // standard constructor

	CBigclockDlg *parent;
	int created;

	int firstpaint;
// Dialog Data
	//{{AFX_DATA(CConfig)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConfig)
	afx_msg void OnCheck1();
	afx_msg void OnOk2();
	afx_msg void OnButton1();
	afx_msg void OnCheck2();
	virtual BOOL OnInitDialog();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRadio1();
	afx_msg void OnRadio3();
	afx_msg void OnRadio2();
	afx_msg void OnOk3();
	afx_msg void OnPaint();
	afx_msg void OnCheck3();
	afx_msg void OnCheck4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIG_H__38865E88_6F50_4A91_ADB1_593C20A0C17E__INCLUDED_)
