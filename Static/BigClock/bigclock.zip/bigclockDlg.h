// bigclockDlg.h : header file
//

#if !defined(AFX_BIGCLOCKDLG_H__214280AE_D12E_4081_88A3_C238CD99B158__INCLUDED_)
#define AFX_BIGCLOCKDLG_H__214280AE_D12E_4081_88A3_C238CD99B158__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define LARGE_CLOCK	0
#define MEDI_CLOCK	1
#define SMALL_CLOCK	2

/////////////////////////////////////////////////////////////////////////////
// CBigclockDlg dialog

#include "lcd7.h"
#include "label1.h"

class CBigclockDlg : public CDialog

{
// Construction

	int		firstrun;
public:

	int		c12;
	void	Set12(int flag);
	void	ResizeLCD(Clcd7 *lcd, WINDOWPLACEMENT *wp, int num);
	void	ResizeDot(CLabel *lab, WINDOWPLACEMENT *wp, int num);

	void	MoveLCD(Clcd7 *lcd1, Clcd7 *lcd2, int dist);
	void	MoveDots(CLabel *lab1, CLabel *lab2, Clcd7 *lcd, int dist);

	void SetClockSize(int size);
	void ShowConfig();
	
	void ShowSec(int flag);
	int showsec;

	void SetClockColor(COLORREF col);
	COLORREF clockcolor;
	
	void SetOntop(int top);
	int	ontop;

	WINDOWPLACEMENT wp_lcd1;
	WINDOWPLACEMENT wp_lcd2;
	WINDOWPLACEMENT wp_lcd3;
	WINDOWPLACEMENT wp_lcd4;
	WINDOWPLACEMENT wp_lcd5;
	WINDOWPLACEMENT wp_lcd6;

	WINDOWPLACEMENT wp_dot1;
	WINDOWPLACEMENT wp_dot2;
	WINDOWPLACEMENT wp_dot3;
	WINDOWPLACEMENT wp_dot4;
	
	int clocksize;

	CBigclockDlg(CWnd* pParent = NULL);	// standard constructor

	int			old_sec, old_min, old_hour;

	HBITMAP		m_hBitmap;
    DWORD		m_dwWidth;			// Width of bitmap
	DWORD		m_dwHeight;			// Height of bitmap

// Dialog Data
	//{{AFX_DATA(CBigclockDlg)
	enum { IDD = IDD_BIGCLOCK_DIALOG };
	CLabel	m_dot4;
	CLabel	m_dot3;
	CLabel	m_dot2;
	CLabel	m_dot1;
	Clcd7	m_lcd6;
	Clcd7	m_lcd5;
	Clcd7	m_lcd4;
	Clcd7	m_lcd3;
	Clcd7	m_lcd2;
	Clcd7	m_lcd1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBigclockDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CBigclockDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnDestroy();
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BIGCLOCKDLG_H__214280AE_D12E_4081_88A3_C238CD99B158__INCLUDED_)
