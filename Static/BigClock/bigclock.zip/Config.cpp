// Config.cpp : implementation file
//

#include "stdafx.h"
#include "bigclock.h"
#include "Config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfig dialog


CConfig::CConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConfig)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	firstpaint = true;
	created = false;
}


void CConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfig)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfig, CDialog)
	//{{AFX_MSG_MAP(CConfig)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDOK2, OnOk2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDOK3, OnOk3)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	ON_BN_CLICKED(IDC_CHECK4, OnCheck4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfig message handlers

void CConfig::OnCheck1() 

{
	parent->SetOntop( ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() );
}

void CConfig::OnOk2() 
{
	EndDialog(IDOK);
	parent->EndDialog(IDOK);
	
}

void CConfig::OnButton1() 
{
	CString str;
	
	CColorDialog cd;

	//memset(&cd.m_cc, 0, sizeof(CHOOSECOLOR));
	//cd.m_cc.lStructSize = sizeof(CHOOSECOLOR);
	
	cd.m_cc.Flags = CC_RGBINIT | CC_FULLOPEN | CC_ANYCOLOR | CC_ENABLEHOOK;
	cd.m_cc.rgbResult = parent->clockcolor;
	//cd.m_cc.lpCustColors = custom;

	if(cd.DoModal() == IDOK)
		{
		parent->SetClockColor(cd.m_cc.rgbResult);
		}

}

void CConfig::OnCheck2() 
{
	parent->ShowSec( ((CButton*)GetDlgItem(IDC_CHECK2))->GetCheck() );	
}

BOOL CConfig::OnInitDialog() 

{
	CDialog::OnInitDialog();
	
	CenterWindow(GetDesktopWindow());
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CConfig::OnLButtonDown(UINT nFlags, CPoint point) 
{
	PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(point.x, point.y));	
	CDialog::OnLButtonDown(nFlags, point);
}

void CConfig::OnRadio1() 
{
	parent->SetClockSize(SMALL_CLOCK);
}

void CConfig::OnRadio3() 
{
	parent->SetClockSize(LARGE_CLOCK);
}

void CConfig::OnRadio2() 
{
	parent->SetClockSize(MEDI_CLOCK);
	
}

#include "About.h"

void CConfig::OnOk3() 

{
	CAbout about;	
	
	about.DoModal();

}

void CConfig::OnPaint() 

{
	if(firstpaint)
		{
		// Shift it by some pixels
		firstpaint = false;
		
#if 0
		int offset = 120, hh = GetSystemMetrics(SM_CYFULLSCREEN);

		WINDOWPLACEMENT wp;
		GetWindowPlacement(&wp);

		if(wp.rcNormalPosition.top  > 2 * hh / 3)
			{
			offset = -offset;
			}
		wp.rcNormalPosition.top += offset;
		wp.rcNormalPosition.bottom += offset;
		SetWindowPlacement(&wp);

#endif
		}

	CPaintDC dc(this); // device context for painting
	
	// Do not call CDialog::OnPaint() for painting messages
}

void CConfig::Show()
{
	TRACE("CConfig::Show()\r\n");

	if(!created)
		{
		created = true;
		Create(IDD);
		}

	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(parent->ontop);
	((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(parent->showsec);
	((CButton*)GetDlgItem(IDC_CHECK4))->SetCheck(parent->c12);
	
	ULONG type;
	unsigned char str[_MAX_PATH]; str[0] = 0;
	ULONG size = _MAX_PATH;
	HKEY key;
	LONG ret = RegCreateKey(HKEY_LOCAL_MACHINE,
					"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", &key);

	LONG ret3 = RegQueryValueEx(key, "BigClock", NULL, &type, str, &size);

	int flag = strlen((char *)str);
	((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(flag);

	TRACE("Read reg key: '%s'\r\n", str);

	switch(parent->clocksize)
		{
		case  LARGE_CLOCK:
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(true);
			break;

		case MEDI_CLOCK:
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(true);
			break;

		case SMALL_CLOCK:
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(true);
			break;
	}


	ShowWindow(SW_SHOW);
	SetFocus();
}

void CConfig::OnCheck3() 

{
	int restart = ((CButton*)GetDlgItem(IDC_CHECK3))->GetCheck();

	TRACE("Writing new reg %d\r\n", restart);

	if(restart)
		{	
		HKEY key;
		LONG ret = RegCreateKey(HKEY_LOCAL_MACHINE,
					"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", &key);

		CString appr;
		GetModuleFileName(AfxGetInstanceHandle(), appr.GetBuffer(_MAX_PATH), MAX_PATH);
		appr.ReleaseBuffer();

		LONG ret2 = RegSetValueEx(key, "BigClock", 0, REG_SZ,
					(const unsigned char*)((const char *)appr), appr.GetLength());

		RegCloseKey(key);
		}
	else
		{
		HKEY key;
		LONG ret = RegCreateKey(HKEY_LOCAL_MACHINE,
					"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", &key);

		LONG ret2 = RegDeleteValue(key, "BigClock");
		}
}

void CConfig::OnCheck4() 

{
	parent->Set12( ((CButton*)GetDlgItem(IDC_CHECK4))->GetCheck() );
}
