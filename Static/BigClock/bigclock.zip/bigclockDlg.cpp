// bigclockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "bigclock.h"
#include "bigclockDlg.h"

#include "Config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WS_EX_LAYERED 0x00080000
#define LWA_COLORKEY 1 // Use color as the transparency color.
#define LWA_ALPHA    2 // Use bAlpha to determine the opacity of the layer

//  Function pointer for lyering API in User32.dll
typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)
            (HWND hWnd, COLORREF cr, BYTE bAlpha, DWORD dwFlags);

lpfnSetLayeredWindowAttributes g_pSetLayeredWindowAttributes = NULL;

CConfig  cfg;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBigclockDlg dialog

CBigclockDlg::CBigclockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBigclockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBigclockDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	old_sec = old_min = old_hour = 0;
	clockcolor = RGB(100,100,100);
	showsec = true;
	ontop = false;
	clocksize = LARGE_CLOCK;
	firstrun = false;
	c12 = false;
}

void CBigclockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBigclockDlg)
	DDX_Control(pDX, IDC_DOT4, m_dot4);
	DDX_Control(pDX, IDC_DOT3, m_dot3);
	DDX_Control(pDX, IDC_DOT2, m_dot2);
	DDX_Control(pDX, IDC_DOT1, m_dot1);
	DDX_Control(pDX, IDC_LCD6, m_lcd6);
	DDX_Control(pDX, IDC_LCD5, m_lcd5);
	DDX_Control(pDX, IDC_LCD4, m_lcd4);
	DDX_Control(pDX, IDC_LCD3, m_lcd3);
	DDX_Control(pDX, IDC_LCD2, m_lcd2);
	DDX_Control(pDX, IDC_LCD1, m_lcd1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CBigclockDlg, CDialog)
	//{{AFX_MSG_MAP(CBigclockDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_CHAR()
	ON_WM_DESTROY()
	ON_WM_RBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBigclockDlg message handlers

BOOL CBigclockDlg::OnInitDialog()

{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);  // Set big icon
	SetIcon(m_hIcon, FALSE);  // Set big icon

	ModifyStyleEx(WS_EX_APPWINDOW,0);

	SetWindowText("BigClock");

	//ModifyStyle(WS_OVERLAPPED | WS_OVERLAPPEDWINDOW | WS_POPUP | WS_BORDER | WS_THICKFRAME | WS_DLGFRAME, 0);
	//ModifyStyle(WS_EX_DLGMODALFRAME | WS_EX_STATICEDGE, 0);
	//SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOSIZE  | SWP_NOZORDER | SWP_NOMOVE | SWP_FRAMECHANGED);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	//SetIcon(m_hIcon, TRUE);			// Set big icon
	//SetIcon(m_hIcon, FALSE);		// Set small icon

		HMODULE hUser32 = GetModuleHandle(_T("USER32.DLL"));
	g_pSetLayeredWindowAttributes = (lpfnSetLayeredWindowAttributes)
                        GetProcAddress(hUser32, "SetLayeredWindowAttributes");

	{
    //  Set layered style for the dialog
    SetWindowLong(m_hWnd, GWL_EXSTYLE, GetWindowLong(m_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);

	BYTE bAlpha = 200;

    //  Call it with 255 as alpha - opacity
	if(g_pSetLayeredWindowAttributes)
		{
		//g_pSetLayeredWindowAttributes(m_hWnd, 0, bAlpha, LWA_ALPHA);
		g_pSetLayeredWindowAttributes(m_hWnd, RGB(0, 255, 0), 0, LWA_COLORKEY);
		}
	}

	// Load bmp for transparent background
    HINSTANCE  hInstResource = NULL;

    // Find correct resource handle
    hInstResource = AfxFindResourceHandle(MAKEINTRESOURCE(IDB_BITMAP1), RT_BITMAP);

    // Load bitmap In
    m_hBitmap = (HBITMAP)::LoadImage(hInstResource, MAKEINTRESOURCE(IDB_BITMAP1),
                                   IMAGE_BITMAP, 0, 0, 0);
    // Get bitmap size
	BITMAP  csBitmapSize;

    int nRetValue = ::GetObject(m_hBitmap, sizeof(csBitmapSize), &csBitmapSize);
    ASSERT(nRetValue);

	m_dwWidth = (DWORD)csBitmapSize.bmWidth;
	m_dwHeight = (DWORD)csBitmapSize.bmHeight;


	// Restore old placement
	WINDOWPLACEMENT wp2;
	GetWindowPlacement(&wp2);
	
	CString section("Main");
	CString str = AfxGetApp()->GetProfileString(section, "ClockPos", "");

	if(str != "")
		{
		sscanf(str, "%d %d %d %d",
			&wp2.rcNormalPosition.top, &wp2.rcNormalPosition.left,
				&wp2.rcNormalPosition.bottom,  &wp2.rcNormalPosition.right);
		}
	SetWindowPos(NULL, wp2.rcNormalPosition.left, wp2.rcNormalPosition.top, 0, 0, SWP_NOSIZE  | SWP_NOZORDER );

	//m_lcd6.SubclassWindow(m_lcd6.m_hWnd);

	// Set the LCD transparent
	m_lcd1.SetBgColor(RGB(0,255,0));
	m_lcd2.SetBgColor(RGB(0,255,0));
	m_lcd3.SetBgColor(RGB(0,255,0));
	m_lcd4.SetBgColor(RGB(0,255,0));
	m_lcd5.SetBgColor(RGB(0,255,0));
	m_lcd6.SetBgColor(RGB(0,255,0));

	// Save original positions
	m_lcd1.GetWindowPlacement(&wp_lcd1);
	m_lcd2.GetWindowPlacement(&wp_lcd2);
	m_lcd3.GetWindowPlacement(&wp_lcd3);
	m_lcd4.GetWindowPlacement(&wp_lcd4);
	m_lcd5.GetWindowPlacement(&wp_lcd5);
	m_lcd6.GetWindowPlacement(&wp_lcd6);

	m_dot1.GetWindowPlacement(&wp_dot1);
	m_dot2.GetWindowPlacement(&wp_dot2);
	m_dot3.GetWindowPlacement(&wp_dot3);
	m_dot4.GetWindowPlacement(&wp_dot4);


	clockcolor = AfxGetApp()->GetProfileInt(section, "Color", RGB(100,100,100));
	SetClockColor(clockcolor);

	clocksize = AfxGetApp()->GetProfileInt(section, "Size", 0);
	SetClockSize(clocksize);

	c12 = AfxGetApp()->GetProfileInt(section, "c12", 0);
	SetClockSize(clocksize);

	firstrun = AfxGetApp()->GetProfileInt(section, "FirstRun", 1);
	AfxGetApp()->WriteProfileInt(section, "FirstRun", 0);
	
	ontop = AfxGetApp()->GetProfileInt(section, "OnTop", 0);
	SetOntop(ontop);

	SetTimer(1, 300, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CBigclockDlg::OnSysCommand(UINT nID, LPARAM lParam)

{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
		{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
		}
	else
		{
		CDialog::OnSysCommand(nID, lParam);
		}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBigclockDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBigclockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CBigclockDlg::OnEraseBkgnd(CDC* pDC)
{

	BOOL bRetValue = CDialog::OnEraseBkgnd(pDC);

	if (!m_hBitmap)
        return bRetValue;

	CRect   rect;
    GetClientRect(rect);

    CDC dc;
    dc.CreateCompatibleDC(pDC);

    HBITMAP    pbmpOldBmp = NULL;

    pbmpOldBmp = (HBITMAP)::SelectObject(dc.m_hDC, m_hBitmap);

	int ixOrg, iyOrg;

	for (iyOrg = 0; iyOrg < rect.Height(); iyOrg += m_dwHeight)
        {
            for (ixOrg = 0; ixOrg < rect.Width(); ixOrg += m_dwWidth)
            {
                pDC->BitBlt (ixOrg, iyOrg, rect.Width(), rect.Height(), &dc, 0, 0, SRCCOPY);
            }
        }

    ::SelectObject(dc.m_hDC, m_hBitmap);

    return bRetValue;

	//return CDialog::OnEraseBkgnd(pDC);
}

void CBigclockDlg::OnTimer(UINT nIDEvent)

{
	if(firstrun)
		{
		firstrun = false;
		AfxMessageBox(
			"You may configure BigClock by double clicking on any clock digit,\r\n"
			"or move BigClock by dragging any digit.\r\n"
			"You may exit BigClock by  right doble clicking on any digit.\r\n"
			"Hot key to exit: ALT-X, hot key to configure: ALT-C\r\n\r\n"
			" This message is one time only", MB_OK | MB_ICONINFORMATION
			);
		}

	CTime ct = CTime::GetCurrentTime();

	int hh, mm, ss;

	// Early out:
	// ------------------------
	ss = ct.GetSecond();
	if(ss == old_sec)
		goto skip0;

	//TRACE("timer %d\r\n", ss);
	if(showsec)
		{
		m_lcd5.num  = ss / 10;
		m_lcd6.num  = ss % 10;
		m_lcd5.Invalidate();
		m_lcd6.Invalidate();
		}
	else
		{
		if(ss % 2 == 0)
			{
			m_dot1.ShowWindow(SW_SHOW);
			m_dot2.ShowWindow(SW_SHOW);
			}
		else
			{
			m_dot1.ShowWindow(SW_HIDE);
			m_dot2.ShowWindow(SW_HIDE);
			}
		}

	old_sec = ss;

skip0:
	// ------------------------
	mm = ct.GetMinute();
	if(mm == old_min)
		goto skip1;

	m_lcd3.num  = mm / 10;
	m_lcd4.num  = mm % 10;
	m_lcd3.Invalidate();
	m_lcd4.Invalidate();

	old_min = mm;

skip1:
	// ------------------------
	hh = ct.GetHour();

	if(c12)
		{
		if(hh > 12)
			{
			hh -= 12;
			}
		else if(hh == 0)
			{
			hh = 12;
			}
		}

	if(mm == old_hour)
		goto endd;
	
	m_lcd1.num  = hh / 10;
	m_lcd2.num  = hh % 10;
	m_lcd1.Invalidate();
	m_lcd2.Invalidate();

	old_hour = hh;

endd:

	//Invalidate();
	CDialog::OnTimer(nIDEvent);
}

void CBigclockDlg::OnLButtonDown(UINT nFlags, CPoint point)

{
	PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(point.x, point.y));

	CDialog::OnLButtonDown(nFlags, point);
}


void CBigclockDlg::OnLButtonDblClk(UINT nFlags, CPoint point)

{
	ShowConfig();

	CDialog::OnLButtonDblClk(nFlags, point);
}

void CBigclockDlg::SetOntop(int top)

{
	ontop = top;

	if(top)
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	else
		SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);


	//TRACE("SetOntop %d\r\n", top);
}

void CBigclockDlg::SetClockColor(COLORREF col)

{

	clockcolor = col;

	// If we have transparency color - cheat one
	if(clockcolor == RGB(0,255,0))
		clockcolor++;
	
	m_lcd1.SetFgColor(clockcolor);
	m_lcd2.SetFgColor(clockcolor);
	m_lcd3.SetFgColor(clockcolor);
	m_lcd4.SetFgColor(clockcolor);
	m_lcd5.SetFgColor(clockcolor);
	m_lcd6.SetFgColor(clockcolor);

	m_dot1.SetBkColor(clockcolor); m_dot1.Invalidate();
	m_dot2.SetBkColor(clockcolor); m_dot2.Invalidate();
	m_dot3.SetBkColor(clockcolor); m_dot3.Invalidate();
	m_dot4.SetBkColor(clockcolor); m_dot4.Invalidate();
}

void CBigclockDlg::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)

{
	CDialog::OnChar(nChar, nRepCnt, nFlags);
}
/**/
BOOL CBigclockDlg::PreTranslateMessage(MSG* pMsg)

{
	switch(pMsg->message)
	{
	// Get rid of ESC CR

	case WM_KEYDOWN:

		//TRACE("OnChar(UINT nChar %d\r\n", pMsg->wParam);

		// Stop the dialog from closing on ESC
		if(pMsg->wParam == 27)
			return true;
		if(pMsg->wParam == 13)
			return true;
		break;

	case WM_SYSKEYDOWN:

		TRACE("OnSysChar(UINT nChar %d\r\n", pMsg->wParam);

		// Hotkey for exit (Alt-X)
		if(pMsg->wParam == 88)
			{
			EndDialog(IDOK);
			return true;
			}

		// Hotkey for config (Alt-C)
		if(pMsg->wParam == 67)
			{
			ShowConfig();
			return true;
			}


		break;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CBigclockDlg::ShowSec(int flag)

{
	showsec = flag;

	if(showsec)
		{
		m_lcd5.ShowWindow(SW_SHOW);
		m_lcd6.ShowWindow(SW_SHOW);

		m_dot3.ShowWindow(SW_SHOW);
		m_dot4.ShowWindow(SW_SHOW);
		Invalidate();
		}
	else
		{
		m_lcd5.ShowWindow(SW_HIDE);
		m_lcd6.ShowWindow(SW_HIDE);
		m_dot3.ShowWindow(SW_HIDE);
		m_dot4.ShowWindow(SW_HIDE);
		Invalidate();
		}

	m_dot1.ShowWindow(SW_SHOW);
	m_dot2.ShowWindow(SW_SHOW);
}

void CBigclockDlg::ShowConfig()
{
	cfg.parent = this;

	//cfg.DoModal();
	cfg.Show();
}

void CBigclockDlg::SetClockSize(int size)

{
	//int ww, hh;
	clocksize = size;

	switch(clocksize)
		{
		case  LARGE_CLOCK:

			//m_lcd2.SetWindowPlacement(&wp_lcd2);
			//ww = wp_lcd2.rcNormalPosition.right - wp_lcd2.rcNormalPosition.left;
			//m_lcd2.width = ww / 4;

			ResizeLCD(&m_lcd1, &wp_lcd1, 1);
			ResizeLCD(&m_lcd2, &wp_lcd2, 1);
			ResizeLCD(&m_lcd3, &wp_lcd3, 1);
			ResizeLCD(&m_lcd4, &wp_lcd4, 1);
			ResizeLCD(&m_lcd5, &wp_lcd5, 1);
			ResizeLCD(&m_lcd6, &wp_lcd6, 1);

			ResizeDot(&m_dot1, &wp_dot1, 1);
			ResizeDot(&m_dot2, &wp_dot2, 1);
			ResizeDot(&m_dot3, &wp_dot3, 1);
			ResizeDot(&m_dot4, &wp_dot4, 1);

			Invalidate();
			break;

		case MEDI_CLOCK:

			ResizeLCD(&m_lcd1, &wp_lcd1, 2);
			ResizeLCD(&m_lcd2, &wp_lcd2, 2);  MoveLCD(&m_lcd1, &m_lcd2, 8);
			ResizeLCD(&m_lcd3, &wp_lcd3, 2);  MoveLCD(&m_lcd2, &m_lcd3, 24);
			ResizeLCD(&m_lcd4, &wp_lcd4, 2);  MoveLCD(&m_lcd3, &m_lcd4, 8);
			ResizeLCD(&m_lcd5, &wp_lcd5, 2);  MoveLCD(&m_lcd4, &m_lcd5, 24);
			ResizeLCD(&m_lcd6, &wp_lcd6, 2);  MoveLCD(&m_lcd5, &m_lcd6, 8);

			ResizeDot(&m_dot1, &wp_dot1, 2);
			ResizeDot(&m_dot2, &wp_dot2, 2);
			ResizeDot(&m_dot3, &wp_dot3, 2);
			ResizeDot(&m_dot4, &wp_dot4, 2);

			MoveDots(&m_dot1, &m_dot2, &m_lcd2, 8);
			MoveDots(&m_dot3, &m_dot4, &m_lcd4, 8);

			Invalidate();
			break;

		case SMALL_CLOCK:

			ResizeLCD(&m_lcd1, &wp_lcd1, 4);
			ResizeLCD(&m_lcd2, &wp_lcd2, 4);  MoveLCD(&m_lcd1, &m_lcd2, 4);
			ResizeLCD(&m_lcd3, &wp_lcd3, 4);  MoveLCD(&m_lcd2, &m_lcd3, 12);
			ResizeLCD(&m_lcd4, &wp_lcd4, 4);  MoveLCD(&m_lcd3, &m_lcd4, 4);
			ResizeLCD(&m_lcd5, &wp_lcd5, 4);  MoveLCD(&m_lcd4, &m_lcd5, 12);
			ResizeLCD(&m_lcd6, &wp_lcd6, 4);  MoveLCD(&m_lcd5, &m_lcd6, 4);

			ResizeDot(&m_dot1, &wp_dot1, 4);
			ResizeDot(&m_dot2, &wp_dot2, 4);
			ResizeDot(&m_dot3, &wp_dot3, 4);
			ResizeDot(&m_dot4, &wp_dot4, 4);

			MoveDots(&m_dot1, &m_dot2, &m_lcd2, 6);
			MoveDots(&m_dot3, &m_dot4, &m_lcd4, 6);

			Invalidate();
			break;
	}
}

void CBigclockDlg::ResizeLCD(Clcd7 *lcd, WINDOWPLACEMENT *wp, int num)

{
	WINDOWPLACEMENT fresh;

	memcpy(&fresh, wp, sizeof(WINDOWPLACEMENT));

	int ww = fresh.rcNormalPosition.right - fresh.rcNormalPosition.left; ww/=num;
	int hh = fresh.rcNormalPosition.bottom - fresh.rcNormalPosition.top; hh/=num;

	fresh.rcNormalPosition.bottom = fresh.rcNormalPosition.top + hh;
	fresh.rcNormalPosition.right = fresh.rcNormalPosition.left + ww;

	lcd->SetWindowPlacement(&fresh);
	lcd->width = ww / 4;
}


void CBigclockDlg::MoveLCD(Clcd7 *lcd1, Clcd7 *lcd2, int dist)

{
	WINDOWPLACEMENT wp1, wp2;

	lcd1->GetWindowPlacement(&wp1);
	lcd2->GetWindowPlacement(&wp2);

	int ww = wp2.rcNormalPosition.right - wp2.rcNormalPosition.left;

	wp2.rcNormalPosition.left = wp1.rcNormalPosition.right + dist;
	wp2.rcNormalPosition.right = wp2.rcNormalPosition.left + ww;

	lcd2->SetWindowPlacement(&wp2);
}


void CBigclockDlg::MoveDots(CLabel *lab1, CLabel *lab2, Clcd7 *lcd, int dist)

{
	WINDOWPLACEMENT wp, wp1, wp2;

	lcd->GetWindowPlacement(&wp);

	lab1->GetWindowPlacement(&wp1);
	lab2->GetWindowPlacement(&wp2);

	// Dot HH WW
	int ww = wp1.rcNormalPosition.right - wp1.rcNormalPosition.left;
	int hh = wp1.rcNormalPosition.bottom - wp1.rcNormalPosition.top; 

	// LCD HH
	int lhh = wp.rcNormalPosition.bottom - wp.rcNormalPosition.top; 

	//TRACE ("dot ww=%d hh=%d\r\n", ww, hh);

	wp1.rcNormalPosition.left = wp.rcNormalPosition.right + dist;
	wp1.rcNormalPosition.right = wp1.rcNormalPosition.left + ww;

	wp1.rcNormalPosition.top = wp.rcNormalPosition.top + lhh/4;
	wp1.rcNormalPosition.bottom = wp1.rcNormalPosition.top + hh;
	
	// ------------------

	wp2.rcNormalPosition.left = wp.rcNormalPosition.right + dist;
	wp2.rcNormalPosition.right = wp2.rcNormalPosition.left + ww;
	
	wp2.rcNormalPosition.top = wp.rcNormalPosition.top + 3 * lhh/4;
	wp2.rcNormalPosition.bottom = wp2.rcNormalPosition.top + hh;
	
	lab1->SetWindowPlacement(&wp1);
	lab2->SetWindowPlacement(&wp2);
}


void CBigclockDlg::ResizeDot(CLabel *lab, WINDOWPLACEMENT *wp, int num)

{
	WINDOWPLACEMENT fresh;

	memcpy(&fresh, wp, sizeof(WINDOWPLACEMENT));

	int ww = fresh.rcNormalPosition.right - fresh.rcNormalPosition.left; ww/=num;
	int hh = fresh.rcNormalPosition.bottom - fresh.rcNormalPosition.top; hh/=num;

	fresh.rcNormalPosition.bottom = fresh.rcNormalPosition.top + hh;
	fresh.rcNormalPosition.right = fresh.rcNormalPosition.left + ww;

	lab->SetWindowPlacement(&fresh);
}

void CBigclockDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// Save position
	WINDOWPLACEMENT wp2;
	GetWindowPlacement(&wp2);

	CString tmp; tmp.Format("%d %d %d %d",
		wp2.rcNormalPosition.top, wp2.rcNormalPosition.left,
				wp2.rcNormalPosition.bottom,  wp2.rcNormalPosition.right);

	CString section("Main");
	AfxGetApp()->WriteProfileString(section, "ClockPos", tmp);
	AfxGetApp()->WriteProfileInt(section, "Color",  clockcolor);
	AfxGetApp()->WriteProfileInt(section, "Size",  clocksize);
	AfxGetApp()->WriteProfileInt(section, "OnTop",  ontop);
	AfxGetApp()->WriteProfileInt(section, "c12",  c12);
}

void CBigclockDlg::OnRButtonDblClk(UINT nFlags, CPoint point) 

{
	CDialog::OnRButtonDblClk(nFlags, point);
	EndDialog(IDOK);
}

void CBigclockDlg::Set12(int flag)

{
	c12 = flag;
	Invalidate();
}
