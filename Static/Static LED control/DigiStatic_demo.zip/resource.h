//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by counter.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COUNTER_DIALOG              102
#define IDS_TEST                        102
#define IDR_MAINFRAME                   128
#define IDB_FILE                        129
#define IDB_STATE                       130
#define IDB_Digit0                      136
#define IDB_Digit1                      138
#define IDB_Digit2                      139
#define IDB_Digit3                      140
#define IDB_Digit4                      141
#define IDB_Digit5                      142
#define IDB_Digit6                      143
#define IDB_Digit7                      144
#define IDB_Digit8                      145
#define IDB_Digit9                      146
#define IDB_DigitBlank                  147
#define IDB_SKY                         158
#define IDB_DigitDot                    165
#define IDB_DigitMinus                  166
#define IDC_COUNTER                     1000
#define IDC_TREE1                       1001
#define IDC_DSTRING_STATIC              1002
#define IDC_SMOOTH_CHECK                1003
#define IDC_14_RADIO                    1004
#define IDC_7_RADIO                     1005
#define IDC_PROP_CHECK                  1006
#define IDC_LED_EDIT                    1007
#define IDC_TEXT2_STATIC                1008
#define IDC_FRAME1                      1009
#define IDC_TRANS_CHECK                 1010
#define IDC_Score                       1011
#define IDC_TIME_STATIC                 1011
#define IDC_Double                      1012
#define IDC_SCROLL                      1012
#define IDC_SOFT_EDGE_CHECK             1013
#define IDC_TYPE_TEXT_STATIC            1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
