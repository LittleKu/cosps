// HyperlinkScrollerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HyperlinkScroller.h"
#include "HyperlinkScrollerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkScrollerDlg dialog

CHyperlinkScrollerDlg::CHyperlinkScrollerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHyperlinkScrollerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHyperlinkScrollerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHyperlinkScrollerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHyperlinkScrollerDlg)
	DDX_Control(pDX, IDC_EDIT_URL, m_ctrlURL);
	DDX_Control(pDX, IDC_EDIT_NAME, m_ctrlName);
	DDX_Control(pDX, IDC_STATIC_HYPERLINKSCROLLER, m_ctrlHyperlinkScroller);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHyperlinkScrollerDlg, CDialog)
	//{{AFX_MSG_MAP(CHyperlinkScrollerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkScrollerDlg message handlers

BOOL CHyperlinkScrollerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Add hyperlink to scroller and then start scrolling
	m_ctrlHyperlinkScroller.AddScrollText(_T("Click here to go to CodeProject"), _T("http://www.codeproject.com"));
	m_ctrlHyperlinkScroller.StartScrolling();

	m_ctrlName.SetFocus();
	
	return FALSE;
}

void CHyperlinkScrollerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHyperlinkScrollerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHyperlinkScrollerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHyperlinkScrollerDlg::OnButtonAdd() 
{
	// Hyperlink name and its url must be entered
	if (m_ctrlName.GetWindowTextLength() <=0 || m_ctrlURL.GetWindowTextLength() <= 0)
	{
		AfxMessageBox(_T("Hyperlink name and its url must be entered"));
		return;
	}

	CString sName, sURL;

	// Get hyperlink name its url
	m_ctrlName.GetWindowText(sName);
	m_ctrlURL.GetWindowText(sURL);

	// Clear text
	m_ctrlName.SetWindowText(_T(""));
	m_ctrlURL.SetWindowText(_T(""));

	// Set focus
	m_ctrlName.SetFocus();

	// Add new hyperlink and restart our scroller
	m_ctrlHyperlinkScroller.AddScrollText(sName, sURL);
	m_ctrlHyperlinkScroller.StartScrolling();
}

BOOL CHyperlinkScrollerDlg::PreTranslateMessage(MSG* pMsg) 
{
	// Get pointer to window that has the current focus
	CWnd* pFocusedWnd = GetFocus();

	// Check if this is the enter key
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
	{
		// If focus is in the name or url edit control, simulate Add button pressed
		if (pFocusedWnd->m_hWnd == GetDlgItem(IDC_EDIT_NAME)->m_hWnd ||
			pFocusedWnd->m_hWnd == GetDlgItem(IDC_EDIT_URL)->m_hWnd)		
			OnButtonAdd();

		// Message handled
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}
