CCloudsCtrl - Simulating clouds using MFC

This class simulates clouds by using plasma's and a few 'simple' pixel operations. 3 layers of plasma's are blended together to build an image that looks like pretty realistic clouds(on a not so cloudy day...). There's also an option to enhance the clouds with an exponential function to create an even more realistic looking sky.
You can learn the complete theory by reading the excelent tutorial at: http://freespace.virgin.net/hugo.elias/models/m_clouds.htm.
Unfortunately this great article only gives us psuedo code, so we have to do the rest ourselves...
The plasma implementation is partially based on code by Andrea Griffini (found on the internet).

I've also added some scrolling text to create a nice looking AboutBox for applications that need something more than the standard MFC AboutBox.



