// ExampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CExampleDlg::CExampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExampleDlg)
	m_bInteractive = FALSE;
	m_bExponentialClouds = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	CString strCredits = "\tCCloudsCtrl Example\n\n"
				   "\rProgrammed by:\n"
				   "Pablo van der Meer\n\n\n"
				   "\rSpecial thanks to:\nPetra and Jamie\n\n\n"
				   "Copyright � 2003 Pablo Software Solutions\n"
				   "All right reserved.\n\n\n"
				   "\rhttp:\\www.pablovandermeer.nl\n\n";

	m_CloudsCtrl.SetCredits(strCredits);
}

void CExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExampleDlg)
	DDX_Control(pDX, IDC_CLOUDS, m_CloudsCtrl);
	DDX_Check(pDX, IDC_INTERACTIVE, m_bInteractive);
	DDX_Check(pDX, IDC_EXPONENTIAL, m_bExponentialClouds);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CExampleDlg, CDialog)
	//{{AFX_MSG_MAP(CExampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INTERACTIVE, OnInteractive)
	ON_BN_CLICKED(IDC_EXPONENTIAL, OnExponential)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExampleDlg message handlers

BOOL CExampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	return TRUE;
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CExampleDlg::OnInteractive() 
{
	UpdateData();
	m_CloudsCtrl.SetInteractive(m_bInteractive);
}

void CExampleDlg::OnExponential() 
{
	UpdateData();
	m_CloudsCtrl.SetExponentialClouds(m_bExponentialClouds);
}
