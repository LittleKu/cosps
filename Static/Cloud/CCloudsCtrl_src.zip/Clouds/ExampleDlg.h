// ExampleDlg.h : header file
//

#if !defined(AFX_EXAMPLEDLG_H__F9713E91_5C53_4214_832D_B1DE8216A309__INCLUDED_)
#define AFX_EXAMPLEDLG_H__F9713E91_5C53_4214_832D_B1DE8216A309__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Clouds.h"

class CExampleDlg : public CDialog
{
// Construction
public:
	CExampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CExampleDlg)
	enum { IDD = IDD_EXAMPLE_DIALOG };
	CCloudsCtrl	m_CloudsCtrl;
	BOOL	m_bInteractive;
	BOOL	m_bExponentialClouds;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CExampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnInteractive();
	afx_msg void OnExponential();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXAMPLEDLG_H__F9713E91_5C53_4214_832D_B1DE8216A309__INCLUDED_)
