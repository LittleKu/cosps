// RandomFXStaticDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CoolFXStaticDemo.h"
#include "RandomFXStaticDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRandomFXStaticDemoDlg dialog


CRandomFXStaticDemoDlg::CRandomFXStaticDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRandomFXStaticDemoDlg::IDD, pParent)
	, m_stcRandomFX(TRUE)
{
	//{{AFX_DATA_INIT(CRandomFXStaticDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CRandomFXStaticDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRandomFXStaticDemoDlg)
	DDX_Control(pDX, STC_RANDOM_FX, m_stcRandomFX);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRandomFXStaticDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CRandomFXStaticDemoDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRandomFXStaticDemoDlg message handlers
