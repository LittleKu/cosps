//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CoolFXStaticDemo.rc
//
#define IDD_COOLFXSTATICDEMO_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDB_CODEPROJECT                 129
#define IDB_CODEPROJECT_HIGH_COLOR      130
#define DLG_RANDOM_FX                   131
#define CHK_WATER                       1000
#define CHK_FIRE                        1001
#define CHK_PLASMA                      1002
#define STC_CODEPROJECT                 1003
#define CHK_RAINDROP                    1004
#define STC_RAINDROP                    1007
#define SPIN_RAINDROP                   1008
#define CHK_ANIMATE                     1010
#define SLD_FIRE_ALPHA                  1011
#define SLD_PLASMA_ALPHA                1013
#define STC_CODEPROJECT_RUN_TIME        1017
#define STC_RANDOM_FX                   1018
#define BTN_SHOW_RANDOM_FX_DLG          1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
