// CoolFXStaticDemoDlg.h : header file
//

#if !defined(AFX_COOLFXSTATICDEMODLG_H__EC2517EE_67CC_4976_98B5_9720A3EFE405__INCLUDED_)
#define AFX_COOLFXSTATICDEMODLG_H__EC2517EE_67CC_4976_98B5_9720A3EFE405__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CoolFXStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CCoolFXStaticDemoDlg dialog

class CCoolFXStaticDemoDlg : public CDialog
{
// Construction
public:
	CCoolFXStaticDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCoolFXStaticDemoDlg)
	enum { IDD = IDD_COOLFXSTATICDEMO_DIALOG };
	CCoolFXStatic	m_stcCodeproject;
	CCoolFXStatic	m_stcCodeprojectRuntime;
	CBitmap m_bmpCodeprojectRuntime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCoolFXStaticDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCoolFXStaticDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCtrl();
	afx_msg void OnDeltaposRaindrop(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureFireAlpha(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcapturePlamaAlpha(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnShowRandomFxDlg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COOLFXSTATICDEMODLG_H__EC2517EE_67CC_4976_98B5_9720A3EFE405__INCLUDED_)
