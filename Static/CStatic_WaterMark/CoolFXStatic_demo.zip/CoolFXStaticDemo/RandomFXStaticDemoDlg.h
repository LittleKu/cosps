#if !defined(AFX_RANDOMFXSTATICDEMODLG_H__3F645A13_90DA_4359_BE09_4B0416073B75__INCLUDED_)
#define AFX_RANDOMFXSTATICDEMODLG_H__3F645A13_90DA_4359_BE09_4B0416073B75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RandomFXStaticDemoDlg.h : header file
//

#include "RandomFXStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CRandomFXStaticDemoDlg dialog

class CRandomFXStaticDemoDlg : public CDialog
{
// Construction
public:
	CRandomFXStaticDemoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRandomFXStaticDemoDlg)
	enum { IDD = DLG_RANDOM_FX };
	CRandomFXStatic	m_stcRandomFX;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRandomFXStaticDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRandomFXStaticDemoDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RANDOMFXSTATICDEMODLG_H__3F645A13_90DA_4359_BE09_4B0416073B75__INCLUDED_)
