// CoolFXStaticDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CoolFXStaticDemo.h"
#include "CoolFXStaticDemoDlg.h"
#include "RandomFXStaticDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCoolFXStaticDemoDlg dialog

CCoolFXStaticDemoDlg::CCoolFXStaticDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCoolFXStaticDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCoolFXStaticDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCoolFXStaticDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCoolFXStaticDemoDlg)
	DDX_Control(pDX, STC_CODEPROJECT, m_stcCodeproject);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCoolFXStaticDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CCoolFXStaticDemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(CHK_WATER, OnCtrl)
	ON_NOTIFY(UDN_DELTAPOS, SPIN_RAINDROP, OnDeltaposRaindrop)
	ON_NOTIFY(NM_RELEASEDCAPTURE, SLD_FIRE_ALPHA, OnReleasedcaptureFireAlpha)
	ON_NOTIFY(NM_RELEASEDCAPTURE, SLD_PLASMA_ALPHA, OnReleasedcapturePlamaAlpha)
	ON_BN_CLICKED(CHK_RAINDROP, OnCtrl)
	ON_BN_CLICKED(CHK_FIRE, OnCtrl)
	ON_BN_CLICKED(CHK_PLASMA, OnCtrl)
	ON_BN_CLICKED(CHK_ANIMATE, OnCtrl)
	ON_BN_CLICKED(BTN_SHOW_RANDOM_FX_DLG, OnShowRandomFxDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCoolFXStaticDemoDlg message handlers

BOOL CCoolFXStaticDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	

	// run-time creation
	RECT ctrlRect = { 0 };
	GetDlgItem(STC_CODEPROJECT_RUN_TIME)->GetWindowRect(&ctrlRect);
	ScreenToClient(&ctrlRect);
	m_stcCodeprojectRuntime.Create(_T(""), WS_CHILD | WS_VISIBLE, ctrlRect, this);
	m_bmpCodeprojectRuntime.LoadBitmap(IDB_CODEPROJECT_HIGH_COLOR);
	m_stcCodeprojectRuntime.SetBitmap(m_bmpCodeprojectRuntime);

	((CSpinButtonCtrl*)GetDlgItem(SPIN_RAINDROP))->SetRange(0, 99);
	((CSpinButtonCtrl*)GetDlgItem(SPIN_RAINDROP))->SetRange32(0, 99);
	((CSpinButtonCtrl*)GetDlgItem(SPIN_RAINDROP))->SetPos(5);
	SetDlgItemInt(STC_RAINDROP, 5);
	m_stcCodeproject.intervalsPerRaindrop = 5;
	m_stcCodeprojectRuntime.intervalsPerRaindrop = 5;

	((CSliderCtrl*)GetDlgItem(SLD_FIRE_ALPHA))->SetRange(0, 255);
	((CSliderCtrl*)GetDlgItem(SLD_FIRE_ALPHA))->SetPos(30);
	m_stcCodeproject.SetFireAlpha(30);
	m_stcCodeprojectRuntime.SetFireAlpha(30);
	((CSliderCtrl*)GetDlgItem(SLD_PLASMA_ALPHA))->SetRange(0, 255);
	((CSliderCtrl*)GetDlgItem(SLD_PLASMA_ALPHA))->SetPos(30);
	m_stcCodeproject.SetPlasmaAlpha(30);
	m_stcCodeprojectRuntime.SetPlasmaAlpha(30);

	((CButton*)GetDlgItem(CHK_WATER))->SetCheck(BST_CHECKED);
	((CButton*)GetDlgItem(CHK_RAINDROP))->SetCheck(BST_CHECKED);
	OnCtrl();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCoolFXStaticDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCoolFXStaticDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCoolFXStaticDemoDlg::OnCtrl() 
{
	int renderWhich;
	renderWhich = m_stcCodeproject.GetRender();

	if(((CButton*)GetDlgItem(CHK_WATER))->GetCheck() == 1) {
		m_stcCodeproject.SetRender(renderWhich |= CCoolFXStatic::RenderWater);
		m_stcCodeprojectRuntime.SetRender(renderWhich |= CCoolFXStatic::RenderWater);
	} else {
		m_stcCodeproject.SetRender(renderWhich &= ~CCoolFXStatic::RenderWater);
		m_stcCodeprojectRuntime.SetRender(renderWhich &= ~CCoolFXStatic::RenderWater);
	}

	m_stcCodeproject.bRaindrop = (((CButton*)GetDlgItem(CHK_RAINDROP))->GetCheck() == 1);
	m_stcCodeprojectRuntime.bRaindrop = (((CButton*)GetDlgItem(CHK_RAINDROP))->GetCheck() == 1);

	if(((CButton*)GetDlgItem(CHK_FIRE))->GetCheck() == 1) {
		m_stcCodeproject.SetRender(renderWhich |= CCoolFXStatic::RenderFire);
		m_stcCodeprojectRuntime.SetRender(renderWhich |= CCoolFXStatic::RenderFire);
	} else {
		m_stcCodeproject.SetRender(renderWhich &= ~CCoolFXStatic::RenderFire);
		m_stcCodeprojectRuntime.SetRender(renderWhich &= ~CCoolFXStatic::RenderFire);
	}

	if(((CButton*)GetDlgItem(CHK_PLASMA))->GetCheck() == 1) {
		m_stcCodeproject.SetRender(renderWhich |= CCoolFXStatic::RenderPlasma);
		m_stcCodeprojectRuntime.SetRender(renderWhich |= CCoolFXStatic::RenderPlasma);
	} else {
		m_stcCodeproject.SetRender(renderWhich &= ~CCoolFXStatic::RenderPlasma);
		m_stcCodeprojectRuntime.SetRender(renderWhich &= ~CCoolFXStatic::RenderPlasma);
	}

	if(((CButton*)GetDlgItem(CHK_ANIMATE))->GetCheck() == 1) {
		m_stcCodeproject.StartAnimation();
		m_stcCodeprojectRuntime.StartAnimation();
	} else {
		m_stcCodeproject.StopAnimation();
		m_stcCodeprojectRuntime.StopAnimation();
	}

}

void CCoolFXStaticDemoDlg::OnDeltaposRaindrop(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	m_stcCodeproject.intervalsPerRaindrop = pNMUpDown->iPos;
	m_stcCodeprojectRuntime.intervalsPerRaindrop = pNMUpDown->iPos;

	// using "set buddy integer" seems always give the static a value that is one less than iPos, bug?
	SetDlgItemInt(STC_RAINDROP, pNMUpDown->iPos);

	*pResult = 0;
}

void CCoolFXStaticDemoDlg::OnReleasedcaptureFireAlpha(NMHDR* pNMHDR, LRESULT* pResult) 
{
	m_stcCodeproject.SetFireAlpha(((CSliderCtrl*)GetDlgItem(SLD_FIRE_ALPHA))->GetPos());
	m_stcCodeprojectRuntime.SetFireAlpha(((CSliderCtrl*)GetDlgItem(SLD_FIRE_ALPHA))->GetPos());
	
	*pResult = 0;
}

void CCoolFXStaticDemoDlg::OnReleasedcapturePlamaAlpha(NMHDR* pNMHDR, LRESULT* pResult) 
{
	m_stcCodeproject.SetPlasmaAlpha(((CSliderCtrl*)GetDlgItem(SLD_PLASMA_ALPHA))->GetPos());
	m_stcCodeprojectRuntime.SetPlasmaAlpha(((CSliderCtrl*)GetDlgItem(SLD_PLASMA_ALPHA))->GetPos());
	
	*pResult = 0;
}

void CCoolFXStaticDemoDlg::OnShowRandomFxDlg() 
{
	CRandomFXStaticDemoDlg dlg;

	dlg.DoModal();
}
