


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Ԥ����
#include <Windows.h>
#include <CommCtrl.h>
#include "Resource.h"
#include "Language.h"
#pragma comment(lib, "ComCtl32.lib")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �궨��
#define _RectWidth(r)				((r).right - (r).left)
#define _RectHeight(r)				((r).bottom - (r).top)
#define _NumberOf(v)				(sizeof(v) / sizeof(v[0]))
#define _IsMenuChecked(h, n)		((MF_CHECKED & GetMenuState(h, n, MF_BYCOMMAND)) == MF_CHECKED)

#define LNG_Ready					_Lang(0, "Ready.")
#define LNG_Test					_Lang(1, "This is test text ...")

#define STR_AppName					TEXT("MultiLang")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ȫ�ֱ���
HWND g_hWnd = NULL;
HMENU g_hMenu = NULL;
HWND g_hEditBox = NULL;
HWND g_hStatusBar = NULL;
HINSTANCE g_hInst = NULL;
HIMAGELIST g_hImageLists[3] = {NULL};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
VOID OnCreate();
VOID OnSize(WPARAM wParam, LPARAM lParam);
VOID OnCommand(UINT uCmd);
VOID OnViewLanguage(UINT uLang);

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �������
INT APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR pszCmdLine, INT iCmdShow)
{
	MSG msgMsg;
	WNDCLASSEX wceClass;

	g_hInst = hInstance;

	// ��ʼ�������ļ�
	CLanguage::Initialize();	

	// ע����������
	ZeroMemory(&wceClass, sizeof(WNDCLASSEX));
	wceClass.cbSize = sizeof(WNDCLASSEX);
	wceClass.style = CS_VREDRAW | CS_HREDRAW;
	wceClass.lpfnWndProc = MainWndProc;
	wceClass.hInstance = g_hInst;
	wceClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wceClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wceClass.hbrBackground = (HBRUSH) COLOR_BTNSHADOW;
	wceClass.lpszMenuName = MAKEINTRESOURCE(IDR_Menu);
	wceClass.lpszClassName = STR_AppName;
	RegisterClassEx(&wceClass);

	// ����������
	CreateWindowEx(WS_EX_APPWINDOW, STR_AppName, STR_AppName, WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, g_hInst, NULL);

	// ��Ϣѭ��
	while (GetMessage(&msgMsg, NULL, 0, 0))
	{
		TranslateMessage(&msgMsg);
		DispatchMessage(&msgMsg);
	}

	return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ص�����
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		// ��������
		g_hWnd = hWnd;
		g_hMenu = GetMenu(g_hWnd);
		OnCreate();
		break;

	case WM_SIZE:
		// �ı�ߴ�
		OnSize(wParam, lParam);
		break;

	case WM_MENUSELECT:
		// ��״̬����ʾ��Ӧ�Ĳ˵�����ʾ
		if ((LOWORD(wParam) > IDM_View_Default) && (LOWORD(wParam) < IDM_View_Default + 50))
		{
			CLanguage::GetDescription(g_hMenu, LOWORD(wParam));
		}
		else
		{
			CLanguage::TranslateString(LOWORD(wParam));
		}
		if (CLanguage::m_tzText[0])
		{
			SendMessage(g_hStatusBar, SB_SETTEXT, 0, (LPARAM) CLanguage::m_tzText);
			break;
		}

	case WM_EXITMENULOOP:
		// ��״̬����ʾ��������
		SendMessage(g_hStatusBar, SB_SETTEXT, 0, (LPARAM) LNG_Ready);
		break;

	case WM_COMMAND:
		// ������Ϣ
		OnCommand(LOWORD(wParam));
		break;

	case WM_DESTROY:
		// ɾ��ͼ���б����˳�
		ImageList_Destroy(g_hImageLists[0]);
		ImageList_Destroy(g_hImageLists[1]);
		ImageList_Destroy(g_hImageLists[2]);
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���öԻ���ص�����
INT_PTR CALLBACK SettingDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		CLanguage::TranslateDialog(hWnd, MAKEINTRESOURCE(IDD_Setting));
		return TRUE;

	case WM_COMMAND:
		if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
		{
			EndDialog(hWnd, LOWORD(wParam));
		}		
		break;

	case WM_CLOSE:
		SendMessage(hWnd, WM_COMMAND, IDOK, 0);
		break;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
VOID OnCreate()
{
#ifdef _MAKELANG
	OnViewLanguage(IDM_View_Default);
#else // _MAKELANG
	// �г�����
	if (CLanguage::List(GetSubMenu(GetSubMenu(g_hMenu, 3), 13)) != IDM_View_Default)
	{
		// ����˵�
		CLanguage::TranslateMenu(g_hMenu, MAKEINTRESOURCE(IDR_Menu));
	}
#endif // _MAKELANG

	// ����״̬��
	g_hStatusBar = CreateStatusWindow(WS_CHILD | WS_VISIBLE, LNG_Ready, g_hWnd, IDC_StatusBar);

	// �����༭��
	g_hEditBox = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), NULL, 
		WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOHSCROLL | WS_HSCROLL | WS_VSCROLL,
		0, 0, 0, 0, g_hWnd, (HMENU) IDC_EditBox, g_hInst, NULL);
	SendMessage(g_hEditBox, WM_SETFONT, (WPARAM) GetStockObject(DEFAULT_GUI_FONT), TRUE);

	SetWindowText(g_hEditBox, LNG_Test);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ı�ߴ�
VOID OnSize(WPARAM wParam, LPARAM lParam)
{
	RECT rtRect;
	INT iStatusBar;	

	if (wParam != SIZE_MINIMIZED)
	{
		// ����״̬��
		SendMessage(g_hStatusBar, WM_SIZE, wParam, lParam);


		if (_IsMenuChecked(g_hMenu, IDM_View_StatusBar))
		{
			GetWindowRect(g_hStatusBar, &rtRect);
			iStatusBar = _RectHeight(rtRect);
		}
		else
		{
			iStatusBar = 0;
		}

		// �����༭��
		MoveWindow(g_hEditBox, 0, 0, LOWORD(lParam), HIWORD(lParam) - iStatusBar, TRUE);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ������Ϣ
VOID OnCommand(UINT uCmd)
{
	RECT rtRect;
	BOOL bCheck;

	if ((uCmd >= IDM_View_Default) && (uCmd <= IDM_View_Default + 49))
	{
		// �ı�����
		if (((MF_CHECKED & GetMenuState(g_hMenu, uCmd, MF_BYCOMMAND)) != MF_CHECKED))
		{
			OnViewLanguage(uCmd);
		}
		return;
	}

	switch (uCmd)
	{
	case IDM_File_Exit:
		// �˳�
		PostMessage(g_hWnd, WM_CLOSE, 0, 0);
		break;

	case IDM_View_Setting:
		// ��ʾ�Ի���
		DialogBox(g_hInst, MAKEINTRESOURCE(IDD_Setting), g_hWnd, (DLGPROC) SettingDlgProc);
		break;

	case IDM_View_StatusBar:
		// ��ʾ����ʾ������
		bCheck = !_IsMenuChecked(g_hMenu, uCmd);
		CheckMenuItem(g_hMenu, uCmd, bCheck ? MF_CHECKED : MF_UNCHECKED);
		ShowWindow(g_hStatusBar, bCheck ? SW_SHOW : SW_HIDE);
		GetClientRect(g_hWnd, &rtRect);
		OnSize(SIZE_RESTORED, MAKELONG(_RectWidth(rtRect), _RectHeight(rtRect)));
		break;
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ı�����
VOID OnViewLanguage(UINT uLang)
{
#ifdef _MAKELANG
	// ���泣���ַ���
	LNG_Ready; LNG_Test;

	// ������Դ�ַ���
	for (INT i = IDM_File_Open; i <= IDM_Help_About; i++)
	{
		CLanguage::TranslateString(i);
	}

	// ����˵�
	CLanguage::TranslateMenu(g_hMenu, MAKEINTRESOURCE(IDR_Menu));

	// ����Ի����ַ���
	OnCommand(IDM_View_Setting);

#else // _MAKELANG

	// ��������
	CLanguage::Set(g_hMenu, uLang);

	// ����˵�
	CLanguage::TranslateMenu(g_hMenu, MAKEINTRESOURCE(IDR_Menu));
	DrawMenuBar(g_hWnd);

	// �����������ϵ��ı�
	MainWndProc(g_hWnd, WM_MENUSELECT, uLang, 0);
	SetWindowText(g_hEditBox, LNG_Test);
#endif // _MAKELANG
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
