//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDD_Setting                     170
#define IDR_Menu                        500
#define IDB_Toolbar                     800
#define IDC_Toolbar                     1000
#define IDC_StatusBar                   1001
#define IDC_EditBox                     1002
#define IDC_Setting_GeneralFrame        1700
#define IDC_Setting_ShowSplash          1701
#define IDC_Setting_ShowOpen            1702
#define IDC_Setting_ShowIndex           1703
#define IDC_Setting_SaveRecent          1704
#define IDC_Setting_RecentCountText     1705
#define IDC_Setting_RecentCount         1706
#define IDC_Setting_RecentCountSpin     1707
#define IDC_Setting_ClearRecent         1708
#define IDC_Setting_AutoAcquireName     1709
#define IDC_Setting_PicturesPath        1710
#define IDC_Setting_PathText            1711
#define IDC_Setting_Browse              1712
#define IDC_Setting_FixedFrame          1713
#define IDC_Setting_FixedWidthText      1714
#define IDC_Setting_FixedWidth          1715
#define IDC_Setting_FixedWidthSpin      1716
#define IDC_Setting_FixedHeightText     1717
#define IDC_Setting_FixedHeight         1718
#define IDC_Setting_FixedHeightSpin     1719
#define IDC_Setting_ColorFrame          1720
#define IDC_Setting_BkColorText         1721
#define IDC_Setting_CanvasColor         1722
#define IDC_Setting_BorderColorText     1723
#define IDC_Setting_BorderColor         1724
#define IDC_Setting_TextColorText       1725
#define IDC_Setting_TextColor           1726
#define IDC_Setting_Default             1727
#define IDM_File_Open                   5000
#define IDM_File_Reload                 5001
#define IDM_File_Close                  5002
#define IDM_File_Save                   5003
#define IDM_File_Twain                  5004
#define IDM_File_Wia                    5005
#define IDM_File_Exit                   5006
#define IDM_File_Recent                 5050
#define IDM_Sel_DragSelect              5100
#define IDM_Sel_FixedSelect             5101
#define IDM_Sel_AutoSelect              5102
#define IDM_Sel_SelectAll               5103
#define IDM_Sel_SelectInverse           5104
#define IDM_Sel_Delete                  5105
#define IDM_Sel_DeleteAll               5106
#define IDM_Sel_AdjustIndex             5107
#define IDM_Sel_LoadTemplet             5108
#define IDM_Sel_SaveTemplet             5109
#define IDM_Sel_DefaultTemplet          5110
#define IDM_Image_Undo                  5200
#define IDM_Image_Stretch               5201
#define IDM_Image_FlipHorizon           5202
#define IDM_Image_FlipVertical          5203
#define IDM_Image_Rotate90              5204
#define IDM_Image_Rotate180             5205
#define IDM_Image_Rotate270             5206
#define IDM_Image_Rotate                5207
#define IDM_Image_Decolourize           5208
#define IDM_Image_Negative              5209
#define IDM_Image_Expose                5210
#define IDM_Image_Emboss                5211
#define IDM_Image_Adjust                5212
#define IDM_View_Toolbar                5300
#define IDM_View_StatusBar              5301
#define IDM_View_AlwaysOnTop            5302
#define IDM_View_MinToTray              5303
#define IDM_View_Setting                5304
#define IDM_View_ZoomIn                 5305
#define IDM_View_ZoomOut                5306
#define IDM_View_ZoomWindow             5307
#define IDM_View_ZoomActual             5308
#define IDM_View_Default                5309
#define IDM_View_FirstLang              5310
#define IDM_Help_Content                5400
#define IDM_Help_Desktop                5401
#define IDM_Help_StartMenu              5402
#define IDM_Help_ProgramMenu            5403
#define IDM_Help_QuickLaunch            5404
#define IDM_Help_About                  5406

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        10000
#define _APS_NEXT_COMMAND_VALUE         20000
#define _APS_NEXT_CONTROL_VALUE         30000
#define _APS_NEXT_SYMED_VALUE           40000
#endif
#endif
