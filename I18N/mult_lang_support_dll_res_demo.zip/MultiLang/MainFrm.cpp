/*****************************************************************************

Program....:	MainFrm
Version....:	1.0
Author.....:	Ted Ferenc
Date.......:	Dec 2002
Notice.....:	Copyright (C) NDW Ltd. http://www.ndrw.co.uk
					This source code is placed into the public domain
					under the GNU Copyleft Licence
Description:	
				
Modified...:  1.01	Added Accelerators
							Display date in different languages
							Use a dialog template for selecting a file

Ammendments..: 	
	

*****************************************************************************/

#include "stdafx.h"
#include <locale.h>

#include "MultiLang.h"

#include "MainFrm.h"

	// Needed for GetOpenFileName when using a template
	// Contains the UI dialog header information
#include <dlgs.h>
	// CommDlgExtendedError() extended error Codes
#include <Cderr.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_LANGUAGE_DEFAULT, OnLanguageDefault)
	ON_COMMAND(ID_LANGUAGE_ENGLISH, OnLanguageEnglish)
	ON_COMMAND(ID_LANGUAGE_GERMAN, OnLanguageGerman)
	ON_COMMAND(ID_LANGUAGE_FRENCH, OnLanguageFrench)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_pMenuNew		= NULL;

	m_nLanguage		= English;

	m_hInstEnglish	= NULL;
	m_hInstFrench	= NULL;
	m_hInstGerman	= NULL;
}

CMainFrame::~CMainFrame()
{
		// Just tidy up
	if(m_pMenuNew)
		delete m_pMenuNew;

	if(m_hInstFrench)
		FreeLibrary(m_hInstFrench);

	if(m_hInstGerman)
		FreeLibrary(m_hInstGerman);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}


void CMainFrame::OnLanguageDefault() 
{
	SetLanguage(Default);
}

void CMainFrame::OnLanguageEnglish() 
{
	SetLanguage(English);
}

void CMainFrame::OnLanguageFrench() 
{
	SetLanguage(French);	
}

void CMainFrame::OnLanguageGerman() 
{
	SetLanguage(German);	

	return;
}
/**
 *
 * Simple error report to somewhere
 *
 * szMessage	[IN]	Our message
 * dwLastErro	[IN]	The error number
 *
 */
void CMainFrame::ReportError(LPCTSTR szMessage, DWORD dwLastError)
{
	CString		strError = _T("");

	strError.Format(_T("%s %d\n"), szMessage, dwLastError);
	AfxMessageBox(strError);
}

/**
 *
 * Change the language
 * 
 * nLanguage	[IN]	The new language
 *
 */
void CMainFrame::SetLanguage(LANGUAGES nLanguage)
{
	CString		strBuffer	= _T("");

	HINSTANCE	hInst			= NULL;

	LCID			lcid			= NULL;

		// Store the Default resource instance
	if(!m_hInstEnglish)
		m_hInstEnglish = AfxGetInstanceHandle();

	if(nLanguage == Default)
		{
		lcid= GetThreadLocale();
			// We only want the low order 8 bits
		lcid &= 0xFF;
			// Evaluate what the locale is and map onto the languages we have
		switch(lcid)
			{
			default:
			case LANG_ENGLISH:
				nLanguage = English;
				break;

			case LANG_FRENCH:
				nLanguage = French;
				break;

			case LANG_GERMAN:
				nLanguage = German;
				break;
			}
		}

		// Load the relevant resource DLL
	m_nLanguage = nLanguage;
	switch(nLanguage)
		{
		case French:
				// Only call LoadLibrary once, because 
				// using LoadLibrary() and FreeLibrary()
				// seemed to cause problems, i,e repeatedly 
				// removing the library after use, in VC++ 6.0 & NT 4.0
			if(!m_hInstFrench)
				m_hInstFrench = LoadLibrary(_T("LangFRA.dll"));
			hInst = m_hInstFrench;
			break;

		case German:
			if(!m_hInstGerman)
				m_hInstGerman = LoadLibrary(_T("LangGER.dll"));
			hInst = m_hInstGerman;
			break;
		}

		// If we have succesfully loaded a resource DLL, use it, otherwise
		// load the resources from the EXE
	if(hInst)
		AfxSetResourceHandle(hInst);
	else
		AfxSetResourceHandle(m_hInstEnglish);

		// we MUST get a handle to the menu in the Mainframe
		// YOU may need to use a pointer to the Frame:-

		// CMainFrame* pFrame = (CMainFrame *) AfxGetApp()->m_pMainWnd;
		// i.e.	pFrame->GetMenu()
		//			pFrame->m_hMenu()
		//
		// Or without using CMainFrame, using Win32 calls
		//		HMENU hMenu= ::GetMenu(AfxGetApp()->m_pMainWnd->GetSafeHwnd());
		//		CMenu *pMenuCurrent = CMenu::FromHandle(hMenu);

	CMenu *pMenuCurrent = GetMenu();

		// Create a new menu instance, we need to use this in SetMenu
	m_pMenuNew = new CMenu;

		// has the menu changed?
		// m_hMenuDefault is the default menu resource for this frame see AFXWIN.H
	if(pMenuCurrent->m_hMenu != m_hMenuDefault)
		{
			// Destroy the "New" menu and delete the resource
			// We, after all created it!
		pMenuCurrent->DestroyMenu();
		delete pMenuCurrent;
		}

		// Load our new resource menu
	m_pMenuNew->LoadMenu(IDR_MAINFRAME);
		// Display the new menu
	SetMenu(m_pMenuNew);

		// Update any other text strings that are displayed
		// e.g. The Status bar
	strBuffer.LoadString(AFX_IDS_IDLEMESSAGE);
	m_wndStatusBar.SetPaneText(0, strBuffer);

		// We need to change the accelerators
		// m_hAccelTable is used in Winfrm.cpp as the accelerator handle,
		// only one accelerator can be loaded at a time so we MUST clear it
	m_hAccelTable = NULL;		

	if(!LoadAccelTable(MAKEINTRESOURCE(IDR_MAINFRAME)))
		ReportError(_T("LoadAccelTable(MAKEINTRESOURCE(IDR_MAINFRAME)"), GetLastError());

		// Our view, force a repaint to update the text
	m_wndView.Invalidate();
}
/**
 *
 * Get the date in the current locale format
 * Based on a MSDN article
 *
 */
void CMainFrame::GetDate(CString& strDate)
{
	TCHAR		*szLocale		= NULL;

	TCHAR		szBuffer[128];

	time_t	ltime;
	
	struct tm *thetime	= NULL;

		// Branch on the language
	switch(m_nLanguage)
		{
		default:
		case English:
			szLocale = _tsetlocale(LC_ALL, _T("english"));
			break;

		case German:
			szLocale = _tsetlocale(LC_ALL, _T("german"));
			break;

		case French:
			szLocale = _tsetlocale(LC_ALL, _T("french"));
			break;
		}

	if(!szLocale)
		{
		strDate.Format(_T("Failed calling _tsetlocale()"));
		return;
		}

	time (&ltime);
	thetime = gmtime(&ltime);

		// %#x is the long date representation, appropriate to the current locale
	if(!_tcsftime((TCHAR*)szBuffer, sizeof(szBuffer), _T("%#x"), (const struct tm *)thetime))
		strDate.Format(_T("Failed in _tcsftime"));
	else
		strDate = szBuffer;

		// Set locale back to normal
	setlocale(LC_ALL, _T(""));
 }
/**
 *
 * Uses the Win32 common dialog to open a file
 * using out template, ofn.lpTemplateName = MAKEINTRESOURCE(1537)
 * Also needs #include <dlgs.h>
 *
 * Based on MSDN article Q102332
 * I have been unable to get this to work using CFileDialog
 * if you can please let me know!
 *
 */
void CMainFrame::OnFileOpen() 
{
	OPENFILENAME	ofn;
	
	TCHAR				szFile[MAX_PATH + 1];       // buffer for file name

	ZeroMemory(szFile,	sizeof(szFile));
	ZeroMemory(&ofn,		sizeof(OPENFILENAME));

	ofn.lStructSize		= sizeof(OPENFILENAME);
	ofn.hwndOwner			= NULL;
	ofn.lpstrFile			= szFile;
	ofn.nMaxFile			= sizeof(szFile);
	ofn.lpstrFilter		= "Exe\0*.exe\0All\0*.*\0";
	ofn.nFilterIndex		= 1;
	ofn.lpstrFileTitle	= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir	= NULL;
	ofn.Flags				= OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ENABLETEMPLATE | OFN_NONETWORKBUTTON;

	ofn.hInstance			= AfxGetResourceHandle();
		// The magic number 1537 is the resource template ID
	ofn.lpTemplateName	= MAKEINTRESOURCE(1537);

	GetOpenFileName(&ofn);
		// If it fails check the extended error
//	DWORD dwErr = CommDlgExtendedError();
}
