/*****************************************************************************

Program....:	ChildView
Version....:	1.0
Author.....:	Ted Ferenc
Date.......:	Dec 2002
Notice.....:	Copyright (C) NDW Ltd. http://www.ndrw.co.uk
					This source code is placed into the public domain
					under the GNU Copyleft Licence
Description:	
				
Modified...:  1.01	Outputs today's date in the user selected language

Ammendments..: 	
	

*****************************************************************************/

#include "stdafx.h"
#include "MultiLang.h"
#include "ChildView.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint()
{
	CMainFrame* pFrame = (CMainFrame *) AfxGetApp()->m_pMainWnd;

	CString		strBuffer	= _T("");
	CPaintDC dc(this); // device context for painting
	
	strBuffer.LoadString(IDS_LANG_STRING);
	dc.TextOut(10, 10, strBuffer);

		// Get todays date
	pFrame->GetDate(strBuffer);
	dc.TextOut(10, 30, strBuffer);
	
	// Do not call CWnd::OnPaint() for painting messages
}

