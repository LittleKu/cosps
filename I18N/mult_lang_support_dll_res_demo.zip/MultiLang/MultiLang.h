/*****************************************************************************

Program....:	MultiLang
Version....:	1.0
Author.....:	Ted Ferenc
Date.......:	Dec 2002
Notice.....:	Copyright (C) NDW Ltd. http://www.ndrw.co.uk
					This source code is placed into the public domain
					under the GNU Copyleft Licence
Description:	The Application
				
Modified...:  

Ammendments..: 	
	

*****************************************************************************/

#if !defined(AFX_MULTILANG_H__41DCD69E_5985_41E5_9F3D_33124581112A__INCLUDED_)
#define AFX_MULTILANG_H__41DCD69E_5985_41E5_9F3D_33124581112A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMultiLangApp:
// See MultiLang.cpp for the implementation of this class
//

class CMultiLangApp : public CWinApp
{
public:
	CMultiLangApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMultiLangApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CMultiLangApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MULTILANG_H__41DCD69E_5985_41E5_9F3D_33124581112A__INCLUDED_)
