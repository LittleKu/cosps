//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_Main                        100
#define IDD_Main                        200
#define IDC_Path                        300
#define IDC_LngPath                     301
#define IDC_Path2                       302
#define IDC_Browse                      303
#define IDC_Brand                       304
#define IDC_LngBrowse                   305
#define IDC_Import                      310
#define IDC_Export                      312
#define IDC_Logo                        321
#define IDC_Tip                         322
#define IDC_ExeTip                      323
#define IDC_LngTip                      324
#define IDS_AppName                     500
#define IDS_Sucess                      501
#define IDS_Fail                        502
#define IDS_Filter                      503
#define IDS_SelfSucess                  504
#define IDS_LngFilter                   505

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        10016
#define _APS_NEXT_COMMAND_VALUE         20122
#define _APS_NEXT_CONTROL_VALUE         30108
#define _APS_NEXT_SYMED_VALUE           40007
#endif
#endif
