


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#include "Define.h"
#include "UniBase.h"
#include "ResBorn.h"
#include "Resource.h"

#ifdef WINCE
#include <CommDlg.h>
#include <AygShell.h>
#pragma comment(lib,"AygShell.lib")
#define OFN_ENABLESIZING 0
#endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Browse file path
BOOL BrowseFile(HWND hWnd, UINT uCtrl, UINT uFilter, BOOL fSave = FALSE)
{
	TCHAR tzPath[MAX_PATH];
	GetDlgItemText(hWnd, uCtrl, tzPath, MAX_PATH);

	TCHAR tzFilter[MAX_PATH];
	UStrLoad(uFilter, tzFilter);
	UStrRep(tzFilter, '|', 0);

	OPENFILENAME ofn = {0};
	ofn.hwndOwner = hWnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFile = tzPath;
	ofn.lpstrFilter = tzFilter;
	ofn.nMaxFile = MAX_PATH;
	ofn.lStructSize = sizeof(OPENFILENAME);

	TCHAR tzDefExt[MAX_NAME];
	if (fSave)
	{
		// Parse default extension
		PTSTR p = UStrChr(tzFilter, 0) + 1;
		if (p = UStrChr(p, '.'))
		{
			UStrCopy(tzDefExt, p);
			if (p = UStrChr(tzDefExt, ';')) *p = 0;
			ofn.lpstrDefExt = tzDefExt;
		}
	}

	BOOL fRet;
	if (fSave)
	{
		ofn.Flags = OFN_ENABLESIZING | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
		fRet = GetSaveFileName(&ofn);
	}
	else
	{
		ofn.Flags = OFN_ENABLESIZING | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
		fRet = GetOpenFileName(&ofn);
	}

	if (fRet)
	{
		SetDlgItemText(hWnd, uCtrl, tzPath);
	}

	return fRet;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Adjust control size and position for Windows Mobile
INT GetCtrlRect(HWND hWnd, HWND hCtrl, RECT& rtRect)
{
	GetWindowRect(hCtrl, &rtRect);
	return MapWindowPoints(NULL, hWnd, (PPOINT) &rtRect, 2);
}

INT GetCtrlRect(HWND hWnd, UINT uCtrlID, RECT& rtRect)
{
	return GetCtrlRect(hWnd, GetDlgItem(hWnd, uCtrlID), rtRect);
}

UINT ReWidth(HWND hWnd, UINT uCtrlID, UINT uWidth)
{
	RECT rt;
	HWND hCtrl = GetDlgItem(hWnd, uCtrlID);
	GetCtrlRect(hWnd, hCtrl, rt);
	uWidth -= (rt.left + 5);
	MoveWindow(hCtrl, rt.left, rt.top, uWidth, _RectHeight(rt), TRUE);
	return uWidth;
}

UINT ReLeft(HWND hWnd, UINT uCtrlID, UINT uWidth)
{
	RECT rt;
	HWND hCtrl = GetDlgItem(hWnd, uCtrlID);
	GetCtrlRect(hWnd, hCtrl, rt);
	uWidth -= (_RectWidth(rt) + 5);
	MoveWindow(hCtrl, uWidth, rt.top, _RectWidth(rt), _RectHeight(rt), TRUE);
	return uWidth;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Command handler
BOOL OnCommand(HWND hWnd, WPARAM wParam)
{
	TCHAR tzStr[MAX_PATH];

	switch (LOWORD(wParam))
	{
	case IDC_Logo:
		if (HIWORD(wParam) == STN_CLICKED)
		{
			MessageBox(hWnd, STR_About, STR_AppName, MB_ICONINFORMATION);
		}
		break;

	case IDC_Browse:
		BrowseFile(hWnd, IDC_Path, IDS_Filter);
		break;

	case IDC_LngBrowse:
		BrowseFile(hWnd, IDC_LngPath, IDS_LngFilter);
		break;

	case IDC_Path:
		if (HIWORD(wParam) == EN_CHANGE)
		{
			UINT uLen = GetDlgItemText(hWnd, IDC_Path, tzStr, MAX_PATH);
			if (uLen)
			{
				PTSTR p = UStrRChr(tzStr, '.');
				UStrCopy(p ? p : (tzStr + uLen), TEXT(".lng"));
			}
			SetDlgItemText(hWnd, IDC_LngPath, tzStr);
			EnableWindow(GetDlgItem(hWnd, IDC_Export), uLen);
			EnableWindow(GetDlgItem(hWnd, IDC_Import), uLen);
		}
		break;

	case IDC_LngPath:
		if (HIWORD(wParam) == EN_CHANGE)
		{
			BOOL bEnable = SendDlgItemMessage(hWnd, IDC_Path, WM_GETTEXTLENGTH, 0, 0) &&
				SendDlgItemMessage(hWnd, IDC_LngPath, WM_GETTEXTLENGTH, 0, 0);
			EnableWindow(GetDlgItem(hWnd, IDC_Export), bEnable);
			EnableWindow(GetDlgItem(hWnd, IDC_Import), bEnable);
		}
		break;

	case IDC_Import:
	case IDC_Export:
		if (HIWORD(wParam) == BN_CLICKED)
		{
			HRESULT hResult;
			UDirGetAppPath(tzStr);
			TCHAR tzSrcFile[MAX_PATH];
			TCHAR tzLngFile[MAX_PATH];
			TCHAR tzDstFile[MAX_PATH];
			GetDlgItemText(hWnd, IDC_Path, tzSrcFile, MAX_PATH);
			GetDlgItemText(hWnd, IDC_LngPath, tzLngFile, MAX_PATH);
			if (UStrCmpI(tzSrcFile, tzStr))
			{
				UStrPrint(tzDstFile, TEXT("%s.RB"), tzSrcFile);
				hResult = ResBorn(tzSrcFile, tzLngFile, (LOWORD(wParam) == IDC_Import) ? tzDstFile : NULL);
			}
			else
			{
				if (LOWORD(wParam) == IDC_Import)
				{
					hResult = RBImport(tzLngFile);
					if (hResult == S_OK)
					{
						MessageBox(hWnd, UStrGet(IDS_SelfSucess), STR_AppName, MB_ICONINFORMATION);
						if (RBExit() == S_OK)
						{
							return EndDialog(hWnd, TRUE);
						}
						else
						{
							hResult = GetLastError();
						}
					}
				}
				else
				{
					hResult =  RBExport(tzLngFile);
				}
			}

			if (hResult == S_OK)
			{
				MessageBox(hWnd, UStrGet(IDS_Sucess), STR_AppName, MB_ICONINFORMATION);
				if (LOWORD(wParam) == IDC_Import)
				{
					DeleteFile(tzSrcFile);
					MoveFile(tzDstFile, tzSrcFile);
				}
			}
			else
			{
				LoadString(g_hInst, IDS_Fail, tzStr, MAX_PATH);
				FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, hResult, 0, UStrEnd(tzStr), MAX_PATH, NULL);
				MessageBox(hWnd, tzStr, STR_AppName, MB_ICONERROR);
			}
		}
		break;

	case IDOK:
	case IDCANCEL:
		EndDialog(hWnd, S_OK);
		break;

#ifndef WINCE
	case IDC_ExeTip:
	case IDC_LngTip:
		if ((HIWORD(wParam) == STN_DBLCLK) && GetDlgItemText(hWnd, (LOWORD(wParam) == IDC_LngTip) ? IDC_LngPath : IDC_Path, tzStr, MAX_PATH))
		{
			SHELLEXECUTEINFO se ={sizeof(SHELLEXECUTEINFO)};
			se.hwnd = hWnd;
			se.lpVerb = TEXT("Open");
			se.nShow = SW_SHOWNORMAL;
			if (LOWORD(wParam) == IDC_LngTip)
			{
				se.lpFile = TEXT("Notepad.exe");
				se.lpParameters = tzStr;
			}
			else
			{
				se.lpFile = tzStr;
			}
			ShellExecuteEx(&se);
		}
		break;
#endif

	default:
		return FALSE;
	}

	return TRUE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Main dialog
INT_PTR CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
#ifndef WINCE
#pragma warning(disable:4244)
		SetClassLongPtr(hWnd, GCLP_HICON, (LONG_PTR) LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_Main)));
#pragma warning(default:4244)
#else
		SHINITDLGINFO di;
		di.dwMask = SHIDIM_FLAGS;
		di.dwFlags  = SHIDIF_EMPTYMENU | SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_DONEBUTTON;
		di.hDlg = hWnd;
		SHInitDialog(&di);
#endif
		if (*((PCTSTR) lParam))
		{
			SetDlgItemText(hWnd, IDC_Path, (PCTSTR) lParam);
		}
		else
		{
#ifdef _DEBUG
			TCHAR tzPath[MAX_PATH];
			UDirGetAppPath(tzPath);
			SetDlgItemText(hWnd, IDC_Path, tzPath);
#endif
		}
		if (HFONT hFont = (HFONT) SendMessage(hWnd, WM_GETFONT, 0, 0))
		{
			LOGFONT lf;
			GetObject(hFont, sizeof(LOGFONT), &lf);
			lf.lfHeight *= 2;
			lf.lfItalic = TRUE;
			hFont = CreateFontIndirect(&lf);
			SendDlgItemMessage(hWnd, IDC_Brand, WM_SETFONT, (WPARAM) hFont, 0);
		}
		return TRUE;

#ifndef WINCE
	case WM_DROPFILES:
		TCHAR tzPath[MAX_PATH];
		DragQueryFile((HDROP) wParam, 0, tzPath, MAX_PATH);
		DragFinish((HDROP) wParam);
		SetDlgItemText(hWnd, IDC_Path, tzPath);
		break;

	case WM_SYSCOMMAND:
		if (LOWORD(wParam) == SC_CONTEXTHELP)
		{
			MainDlgProc(hWnd, WM_COMMAND, MAKELONG(IDC_Logo, STN_CLICKED), 0);
			return TRUE;
		}
		break;
#else
	case WM_SIZE:
		ReWidth(hWnd, IDC_Tip, LOWORD(lParam));
		ReWidth(hWnd, IDC_Path, ReLeft(hWnd, IDC_Browse, LOWORD(lParam)));
		ReWidth(hWnd, IDC_LngPath, ReLeft(hWnd, IDC_LngBrowse, LOWORD(lParam)));
		break;
#endif

	case WM_COMMAND:
		return OnCommand(hWnd, wParam);
	}

	return FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Entry
INT APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PTSTR ptzCmdLine, INT iShowCmd)
{
	g_hInst = hInstance;
	if (RBInit())
	{
		return 0;
	}
	return (INT) DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_Main), NULL, MainDlgProc, (LPARAM) UStrTrim(ptzCmdLine));
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
