
#pragma once
#include <Windows.h>

class CPEHelper
{
public:
	STATIC PIMAGE_NT_HEADERS GetHeader(PBYTE pbBase)
	{
		if ((((PIMAGE_DOS_HEADER) pbBase)->e_magic == IMAGE_DOS_SIGNATURE))
		{
			PIMAGE_NT_HEADERS pNTHdr = (PIMAGE_NT_HEADERS) (pbBase + ((PIMAGE_DOS_HEADER) pbBase)->e_lfanew);
			if (pNTHdr->Signature == IMAGE_NT_SIGNATURE)
			{
				return pNTHdr;
			}
		}
		return NULL;
	}

	STATIC PIMAGE_SECTION_HEADER GetSection(const PIMAGE_NT_HEADERS pNTHdr, UINT uSecIndex)
	{
		DWORD dwVA = pNTHdr->OptionalHeader.DataDirectory[uSecIndex].VirtualAddress;
		if (dwVA)
		{
			PIMAGE_SECTION_HEADER pSecHdr = (PIMAGE_SECTION_HEADER) &pNTHdr[1];
			for (UINT i = pNTHdr->FileHeader.NumberOfSections; i; i--, pSecHdr++)
			{
				if ((dwVA >= pSecHdr->VirtualAddress) &&
					(dwVA < pSecHdr->VirtualAddress + pSecHdr->SizeOfRawData))
				{
					return pSecHdr;
				}
			}
		}
		return NULL;
	}

	STATIC PIMAGE_SECTION_HEADER GetSection(const PIMAGE_NT_HEADERS pNTHdr, PCTSTR ptzSecName)
	{
		PIMAGE_SECTION_HEADER pSecHdr = (PIMAGE_SECTION_HEADER) &pNTHdr[1];
		for (UINT i = pNTHdr->FileHeader.NumberOfSections; i; i--, pSecHdr++)
		{
			if (IsSectionEqual(pSecHdr->Name, ptzSecName))
			{
				return pSecHdr;
			}
		}
		return NULL;
	}

	STATIC DWORD VAToOffset(const PIMAGE_NT_HEADERS pNTHdr, DWORD dwVA)
	{
		PIMAGE_SECTION_HEADER pSecHdr = (PIMAGE_SECTION_HEADER) &pNTHdr[1];
		for (UINT i = pNTHdr->FileHeader.NumberOfSections; i; i--, pSecHdr++)
		{
			if ((dwVA >= pSecHdr->VirtualAddress) &&
				(dwVA < pSecHdr->VirtualAddress + pSecHdr->SizeOfRawData))
			{
				return dwVA - pSecHdr->VirtualAddress + pSecHdr->PointerToRawData;
			}
		}
		return 0;
	}

	STATIC BOOL IsSectionEqual(PCBYTE pbName1, PCTSTR ptzName2)
	{
		UINT i = 0;
		for (; i < IMAGE_SIZEOF_SHORT_NAME; i++)
		{
			if (ptzName2[i])
			{
				if (pbName1[i] != ptzName2[i])
				{
					return FALSE;
				}
			}
			else
			{
				return !pbName1[i];
			}
		}
		return !ptzName2[i];
	}
};
