
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Header
#include "UniBase.h"
#include "PEHelper.h"
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Resource structure
#pragma pack(push, 1)
typedef struct _DLGHDR
{
	DWORD dwStyle;
	DWORD dwExStyle;
	WORD wCount;
	SHORT x;
	SHORT y;
	SHORT cx;
	SHORT cy;
}
DLGHDR, *PDLGHDR;

typedef struct _DLGITEM
{
	DWORD dwStyle;
	DWORD dwExStyle;
	SHORT x;
	SHORT y;
	SHORT cx;
	SHORT cy;
	WORD wID;
}
DLGITEM, *PDLGITEM;

typedef struct _DLGHDR2
{
	WORD wVersion;
	WORD wSignature;
	DWORD dwHelpID;
	DWORD dwExStyle;
	DWORD dwStyle;
	WORD wCount;
	SHORT x;
	SHORT y;
	SHORT cx;
	SHORT cy;
}
DLGHDR2, *PDLGHDR2;

typedef struct _DLGITEM2
{
	DWORD dwHelpID;
	DWORD dwExStyle;
	DWORD dwStyle;
	SHORT x;
	SHORT y;
	SHORT cx;
	SHORT cy;
	WORD wID;
	WORD wPad;
}
DLGITEM2, *PDLGITEM2;

typedef struct _DLGFONT
{
	WORD wPoint;
	WCHAR wzFont[1];
}
DLGFONT, *PDLGFONT;

typedef struct _DLGFONT2
{
	WORD wPoint;
	WORD wWeight;
	BYTE bItalic;
	BYTE bCharset;
	WCHAR wzFont[1];
}
DLGFONT2, *PDLGFONT2;

typedef struct _MENUHDR
{
	WORD wVersion;
	WORD wOffset;
}
MENUHDR, *PMENUHDR;

typedef struct
{
	WORD wOption;
	union
	{
		WCHAR wzPopup[1];
		struct
		{
			WORD wID;
			WCHAR wzStr[1];
		};
	};
}
MENUITEM, *PMENUITEM;

typedef struct _MENUHDR2
{
	WORD wVersion;
	WORD wOffset;
	DWORD dwHelpID;
}
MENUHDR2, *PMENUHDR2;

typedef struct _MENUITEM2
{
	DWORD dwHelpID;
	DWORD dwType;
	DWORD dwState;
	DWORD wID;
	WORD bResInfo;
	WCHAR wzStr[1];
}
MENUITEM2, *PMENUITEM2;

typedef struct _STRITEM
{
	WORD wLen;
	WCHAR wzStr[1];
}
STRITEM, *PSTRITEM;
#pragma pack(pop)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CResBorn struct
//#define _POS_ONLY
struct CResBorn
{
	// Member variable
	DWORD m_dwLng;
	DWORD m_dwResVA;
	PBYTE m_pbSrcRes;
	PBYTE m_pbDstRes;
	PBYTE m_pbDstResEnd;
	WCHAR m_wzName[4096];
	union {HANDLE m_hLng; PSTRITEM m_psLng;};

	// Parse
	UINT Parse(PBYTE pbSrcRes, DWORD dwResVA, PCTSTR ptzLngFile, PBYTE pbDstRes = NULL)
	{
		// Initialize member variable
		m_wzName[0] = 0;
		m_dwResVA = dwResVA;
		m_pbSrcRes = pbSrcRes;
		m_pbDstResEnd = m_pbDstRes = pbDstRes;

		// Initialize language file
		if (m_pbDstRes)
		{
			// Load language file
			m_psLng = LoadLng(ptzLngFile);
			if (m_psLng == NULL)
			{
				return -1;
			}
			PWSTR pwzLng = GetLng(L"LANG");
			m_dwLng = pwzLng ? UWStrToInt(pwzLng) : -1;
		}
		else
		{
			// Open language file for write
			m_hLng = UFileOpen(ptzLngFile, UFILE_WRITE);
			if (m_hLng == NULL)
			{
				return -1;
			}
			else
			{
				// Write UNICODE BOM
				WORD wBOM = 0xFEFF;
				UFileWrite(m_hLng, &wBOM, 2);
			}
		}

		// Parse resource directory
		ParseDirectory((PIMAGE_RESOURCE_DIRECTORY) m_pbSrcRes);

		// Clean up
		m_pbDstRes ? UMemFree(m_psLng) : UFileClose(m_hLng);

		return (UINT) (m_pbDstResEnd - m_pbDstRes);
	}

	// Parse resource
	VOID ParseDirectory(PIMAGE_RESOURCE_DIRECTORY pSrcDir)
	{
		PIMAGE_RESOURCE_DIRECTORY_ENTRY pDstEntry = NULL;
		if (m_pbDstRes)
		{
			// Copy directory and entry items
			pDstEntry = (PIMAGE_RESOURCE_DIRECTORY_ENTRY) (m_pbDstResEnd + sizeof(IMAGE_RESOURCE_DIRECTORY));
			UINT uSize = sizeof(IMAGE_RESOURCE_DIRECTORY) + (pSrcDir->NumberOfIdEntries + pSrcDir->NumberOfNamedEntries) * sizeof(IMAGE_RESOURCE_DIRECTORY_ENTRY);
			UMemCopy(m_pbDstResEnd, pSrcDir, uSize);
			m_pbDstResEnd += uSize;
		}

		// Parse entry items
		PIMAGE_RESOURCE_DIRECTORY_ENTRY pSrcEntry = (PIMAGE_RESOURCE_DIRECTORY_ENTRY) &pSrcDir[1];
		for (UINT i = pSrcDir->NumberOfIdEntries + pSrcDir->NumberOfNamedEntries; i; i--, pSrcEntry++, pDstEntry++)
		{
			ParseEntry(pSrcEntry, pDstEntry);
		}
	}

	// Parse entry [String]<<Directory>|<DataEntry><Data>>
	VOID ParseEntry(PIMAGE_RESOURCE_DIRECTORY_ENTRY pSrcEntry, PIMAGE_RESOURCE_DIRECTORY_ENTRY pDstEntry)
	{
		PWSTR pwzName = UWStrEnd(m_wzName);

		// Copy name
		if (pSrcEntry->NameIsString)
		{
			PSTRITEM p = (PSTRITEM) (m_pbSrcRes + pSrcEntry->NameOffset);
			UMemCopy(pwzName, p->wzStr, p->wLen * sizeof(WCHAR));
			pwzName[p->wLen] = '.';
			pwzName[p->wLen + 1] = 0;
			if (m_pbDstRes)
			{
				// Store entry name string
				pDstEntry->NameOffset = (DWORD) (m_pbDstResEnd - m_pbDstRes);
				UINT uSize = p->wLen * sizeof(WCHAR) + sizeof(p->wLen);
				UMemCopy(m_pbDstResEnd, p, uSize);
				m_pbDstResEnd += uSize;
			}
		}
		else
		{
			if (pSrcEntry->DataIsDirectory)	// Skip language for data
			{
				UWStrPrint(pwzName, L"%d.", pSrcEntry->Name);
			}
		}

		// Parse entry
		if (pSrcEntry->DataIsDirectory)
		{
			if (m_pbDstRes)
			{
				// Fix entry offset
				AssignVal(pDstEntry->OffsetToData, ((DWORD) (m_pbDstResEnd - m_pbDstRes)) | IMAGE_RESOURCE_DATA_IS_DIRECTORY);
				//pDstEntry->OffsetToDirectory = (DWORD) (m_pbDstResEnd - m_pbDstRes);
			}

			// Parse entry recursively
			ParseDirectory((PIMAGE_RESOURCE_DIRECTORY) (m_pbSrcRes + pSrcEntry->OffsetToDirectory));
		}
		else
		{
			ParseData(pSrcEntry, pDstEntry);
		}

		*pwzName = 0;
	}

	// Parse data
	VOID ParseData(PIMAGE_RESOURCE_DIRECTORY_ENTRY pSrcEntry, PIMAGE_RESOURCE_DIRECTORY_ENTRY pDstEntry)
	{
		PIMAGE_RESOURCE_DATA_ENTRY pSrcData = (PIMAGE_RESOURCE_DATA_ENTRY) (m_pbSrcRes + pSrcEntry->OffsetToData);
		PBYTE pbSrcData = m_pbSrcRes + (pSrcData->OffsetToData - m_dwResVA);

		PBYTE pbDstData;
		PIMAGE_RESOURCE_DATA_ENTRY pDstData;
		if (m_pbDstRes)
		{
			// Fix data offset in directory entry
			AssignVal(pDstEntry->OffsetToData, (DWORD) (m_pbDstResEnd - m_pbDstRes));
			if (!pSrcEntry->NameIsString && (m_dwLng != -1))
			{
				// Modify language
				pDstEntry->Name = m_dwLng;
			}

			// Copy data entry
			pDstData = (PIMAGE_RESOURCE_DATA_ENTRY) m_pbDstResEnd;
			UMemCopy(m_pbDstResEnd, pSrcData, sizeof(IMAGE_RESOURCE_DATA_ENTRY));
			m_pbDstResEnd += sizeof(IMAGE_RESOURCE_DATA_ENTRY);

			// Align data
			m_pbDstResEnd = AlignPtr(m_pbDstResEnd);
			pbDstData = m_pbDstResEnd;
		}

		if (m_wzName[0] == '4')
		{
			// Menu
			if (((PMENUHDR) pbSrcData)->wVersion == 0)
			{
				ParseMenu((PMENUHDR) pbSrcData, (PMENUITEM) (pbSrcData + pSrcData->Size));
			}
			else
			{
				ParseMenu((PMENUHDR2) pbSrcData, (PMENUITEM2) (pbSrcData + pSrcData->Size));
			}
		}
		else if (m_wzName[0] == '5')
		{
			// Dialog
			if (((PDLGHDR2) pbSrcData)->wSignature == 0xFFFF)
			{
				ParseDialog<DLGHDR2, DLGITEM2, DLGFONT2>((PDLGHDR2) pbSrcData);
			}
			else
			{
				ParseDialog<DLGHDR, DLGITEM, DLGFONT>((PDLGHDR) pbSrcData);
			}
		}
		else if (m_wzName[0] == '6')
		{
			// String table
			ParseString((PSTRITEM) pbSrcData);
		}
		else
		{
			if (m_pbDstRes)
			{
				// Copy resource directly
				UMemCopy(m_pbDstResEnd, pbSrcData, pSrcData->Size);
				m_pbDstResEnd += pSrcData->Size;
			}
		}

		if (m_pbDstRes)
		{
			AssignVal(pDstData->Size, (DWORD) (m_pbDstResEnd - pbDstData));
			AssignVal(pDstData->OffsetToData, (DWORD) (pbDstData - m_pbDstRes) + m_dwResVA);
		}
	}

	// Parse dialog template
	template<typename T1, typename T2, typename T3> VOID ParseDialog(T1* ptDlg)
	{
		PWSTR pwzMenu = (PWSTR) &ptDlg[1];
		PWSTR pwzCalss = pwzMenu + ((*pwzMenu == 0xFFFF) ? 2 : (UWStrLen(pwzMenu) + 1));
		PWSTR pwzTitle = pwzCalss + ((*pwzCalss == 0xFFFF) ? 2 : (UWStrLen(pwzCalss) + 1));
		T3* ptFont = (T3*) (pwzTitle + UWStrLen(pwzTitle) + 1);
		T2* ptItem = (ptDlg->dwStyle & DS_SETFONT) ? (T2*) (ptFont->wzFont + UWStrLen(ptFont->wzFont) + 1) : (T2*) ptFont;

		WCHAR wzFont[MAX_NAME];
		UWStrPrint(wzFont, L"%s,%d", ptFont->wzFont, ptFont->wPoint);
		if (m_pbDstRes)
		{
			UINT uSize = (UINT) ((PBYTE) pwzTitle - (PBYTE) ptDlg);
			UMemCopy(m_pbDstResEnd, ptDlg, uSize);
			m_pbDstResEnd += uSize;
			m_pbDstResEnd += GetStr(L"HEAD", (PWSTR) m_pbDstResEnd, pwzTitle) * sizeof(WCHAR);
			if (ptDlg->dwStyle & DS_SETFONT)
			{
				uSize = sizeof(*ptFont) - sizeof(ptFont->wzFont);
				UMemCopy(m_pbDstResEnd, ptFont, uSize);

				PWSTR pwzFont = (PWSTR) (m_pbDstResEnd + uSize);
				GetStr(L"FONT", (PWSTR) pwzFont, wzFont);
				for (; *pwzFont; pwzFont++)
				{
					if (*pwzFont == ',')
					{
						*pwzFont = 0;
						((T3*) m_pbDstResEnd)->wPoint = UWStrToInt(pwzFont + 1);
						break;
					}
				}
				m_pbDstResEnd = (PBYTE) &pwzFont[1];
			}
		}
		else
		{
			SetStr(L"HEAD", pwzTitle);
			if (ptDlg->dwStyle & DS_SETFONT)
			{
				SetStr(L"FONT", wzFont);
			}
		}

		UINT uID = 0;
		for (UINT i = ptDlg->wCount; i; i--)
		{
			ptItem = (T2*) (m_pbSrcRes + (((DWORD) ((PBYTE) ptItem - m_pbSrcRes) + 3) & ~3));
			pwzCalss = (PWSTR) &ptItem[1];
			pwzTitle = pwzCalss + ((*pwzCalss == 0xFFFF) ? 2 : (UWStrLen(pwzCalss) + 1));

			if (m_pbDstRes)
			{
				UINT uPad = ((DWORD) (m_pbDstResEnd - m_pbDstRes)) & 3;
				if (uPad)
				{
					uPad = 4 - uPad;
					UMemSet(m_pbDstResEnd, 0, uPad);
					m_pbDstResEnd += uPad;
				}
				UINT uSize = (UINT) ((PBYTE) pwzTitle - (PBYTE) ptItem);
				UMemCopy(m_pbDstResEnd, ptItem, uSize);
				m_pbDstResEnd += uSize;
			}

			PWORD pwExtra;
			if (*pwzTitle == 0xFFFF)
			{
				pwExtra = (PWORD) pwzTitle + 2;
				if (m_pbDstRes)
				{
					UMemCopy(m_pbDstResEnd, pwzTitle, 4);
					m_pbDstResEnd += 4;
				}
			}
			else
			{
#ifdef _POS_ONLY
				PWSTR pwzID = MAKEINTRESOURCEW(uID);
				uID++;
#else
				WCHAR wzID[16];
				PWSTR pwzID = (ptItem->wID == 0xFFFF) ? (UWStrPrint(wzID, L"S%d", uID++), wzID) : MAKEINTRESOURCEW(ptItem->wID);
#endif
				pwExtra = (PWORD) pwzTitle + UWStrLen(pwzTitle) + 1;
				if (m_pbDstRes)
				{
					m_pbDstResEnd += GetStr(pwzID, (PWSTR) m_pbDstResEnd, pwzTitle) * sizeof(WCHAR);
				}
				else
				{
					SetStr(pwzID, pwzTitle);
				}
			}
			ptItem = *pwExtra ? (T2*) ((PBYTE) pwExtra + *pwExtra + (sizeof(T2) == sizeof(DLGITEM2)) * sizeof(WORD)) : (T2*) &pwExtra[1];
			if (m_pbDstRes)
			{
				UINT uSize = (UINT) ((PBYTE) ptItem - (PBYTE) pwExtra);
				UMemCopy(m_pbDstResEnd, pwExtra, uSize);
				m_pbDstResEnd += uSize;
			}
		}
	}

	// Parse menu template
	template<typename T1, typename T2> VOID ParseMenu(T1* ptHdr, T2* ptEnd)
	{
		T2* ptItem = (T2*) ((PBYTE) &ptHdr[1] + ptHdr->wOffset);

		if (m_pbDstRes)
		{
			UINT uSize = (UINT) ((PBYTE) ptItem - (PBYTE) ptHdr);
			UMemCopy(m_pbDstResEnd, ptHdr, uSize);
			m_pbDstResEnd += uSize;
		}

		for (UINT uID = 0; ptItem < ptEnd; )
		{
			BOOL bPopup = (sizeof(T1) == sizeof(MENUHDR)) && (((PMENUITEM) ptItem)->wOption & MF_POPUP);
			PWSTR pwzStr = bPopup ? ((PMENUITEM) ptItem)->wzPopup : ptItem->wzStr;

#ifdef _POS_ONLY
			PWSTR pwzID = MAKEINTRESOURCEW(uID);
			uID++;
#else
			WCHAR wzID[16];
			PWSTR pwzID = (bPopup || (ptItem->wID == 0xFFFF) || (ptItem->wID == 0)) ? (UWStrPrint(wzID, L"P%d", uID++), wzID) : MAKEINTRESOURCEW(ptItem->wID);
#endif

			if (m_pbDstRes)
			{
				UINT uSize = (UINT) ((PBYTE) pwzStr - (PBYTE) ptItem);
				UMemCopy(m_pbDstResEnd, ptItem, uSize);
				m_pbDstResEnd += uSize;
				m_pbDstResEnd += GetStr(pwzID, (PWSTR) m_pbDstResEnd, pwzStr) * sizeof(WCHAR);
			}
			else
			{
				SetStr(pwzID, pwzStr);
			}

			ptItem = (T2*) (UWStrEnd(pwzStr) + 1);
		}
	}

	VOID ParseString(PSTRITEM psItem)
	{
#ifdef _POS_ONLY
		UINT uMax = 16;
#else
		UINT uMax = UWStrToInt(m_wzName + 2) * 16;
#endif
		for (UINT uID = uMax - 16; uID < uMax; uID++)
		{
			if (m_pbDstRes)
			{
				PSTRITEM q = (PSTRITEM) m_pbDstResEnd;
				q->wLen = GetStr(MAKEINTRESOURCEW(uID), q->wzStr, psItem->wzStr, psItem->wLen);
				m_pbDstResEnd = (PBYTE) &q->wzStr[q->wLen];
			}
			else
			{
				SetStr(MAKEINTRESOURCEW(uID), psItem->wzStr, psItem->wLen);
			}
			psItem = (PSTRITEM) &psItem->wzStr[psItem->wLen];
		}
	}

	VOID SetStr(PWSTR pwzID, PCWSTR pwzStr, UINT uLen = -1)
	{
		PWSTR pwzName = UWStrEnd(m_wzName);
		PWSTR pwzData = pwzName;
		pwzData += UWStrPrint(pwzData, _IsIntRes(pwzID) ? L"%d=" : L"%s=", pwzID);
		PWSTR q = pwzData;
		for (; *pwzStr && uLen--; pwzStr++)
		{
			if (*pwzStr == '\\')
			{
				*q++ = '\\';
				*q++ = '\\';
			}
			else if (*pwzStr == '\r')
			{
				*q++ = '\\';
				*q++ = 'r';
			}
			else if (*pwzStr == '\n')
			{
				*q++ = '\\';
				*q++ = 'n';
			}
			else
			{
				*q++ = *pwzStr;
			}
		}
		if (q > pwzData)
		{
			*q++ = '\r';
			*q++ = '\n';
			UFileWrite(m_hLng, m_wzName, (UINT) (q - m_wzName) * sizeof(WCHAR));
		}
		*pwzName = 0;
	}

	UINT GetStr(PCWSTR pwzID, PWSTR pwzDst, PCWSTR pwzDef, UINT uDefLen = -1)
	{
		PWSTR q = UWStrEnd(m_wzName);
		UWStrPrint(q, _IsIntRes(pwzID) ? L"%d" : L"%s", pwzID);
		PWSTR p = GetLng(m_wzName);
		*q = 0;
		if (p == NULL)
		{
			if (uDefLen != -1)
			{
				UMemCopy(pwzDst, pwzDef, uDefLen * sizeof(WCHAR));
				return uDefLen;
			}
			else
			{
				return UWStrCopy(pwzDst, pwzDef);
			}
		}

		for (q = pwzDst; *p; p++, q++)
		{
			if (*p == '\\')
			{
				p++;
				if (*p == 'r')
				{
					*q = '\r';
				}
				else if (*p == 'n')
				{
					*q = '\n';
				}
				else
				{
					*q = *p;
				}
			}
			else
			{
				*q = *p;
			}
		}
		*q++ = 0;
		return (UINT) (q - pwzDst);
	}

	// Load language file (UNICODE/BOM INI format)
	PSTRITEM LoadLng(PCTSTR ptzLngFile)
	{
		// Load config file
		UINT uSize = -1;
		PSTRITEM psLng = (PSTRITEM) UFileLoad(ptzLngFile, NULL, &uSize);
		if (psLng == NULL)
		{
			return NULL;
		}
		else if (psLng->wLen != 0xFEFF)
		{
			UMemFree(psLng);
			return NULL;
		}

		// Build item chain
		PSTRITEM p = psLng;
		PWSTR pwStr = (PWSTR) psLng;
		for (uSize /= sizeof(WCHAR); uSize; uSize--, pwStr++)
		{
			if (*pwStr == '\r')
			{
				*pwStr = 0;
			}
			else if (*pwStr == '\n')
			{
				p->wLen = (WORD) (pwStr - p->wzStr);
				p = (PSTRITEM) pwStr;
			}
		}
		p->wLen = 0;
		p->wzStr[0] = 0xFFFF;
		return psLng;
	}

	// Search item by name
	PWSTR GetLng(PCWSTR pwzName)
	{
		for (PSTRITEM p = m_psLng; p->wzStr[0] != 0xFFFF; p = (PSTRITEM) &p->wzStr[p->wLen])
		{
			UINT i = 0;
			while (pwzName[i] == p->wzStr[i]) i++;
			if ((pwzName[i] == 0) && (p->wzStr[i] == '='))
			{
				return p->wzStr + i + 1;
			}
		}
		return NULL;
	}

	inline PBYTE AlignPtr(PBYTE pbPtr)
	{
		UINT nSize = (UINT) (pbPtr - m_pbDstRes);
		UINT nAlign = ((nSize + 16) & ~15);
		PBYTE pbAlign = m_pbDstRes + nAlign;
		UMemSet(pbPtr, 0, nAlign - nSize);
		return pbAlign;
	}

	inline VOID AssignVal(DWORD& dwDst, DWORD dwSrc)
	{
#ifdef WINCE
		UMemCopy(&dwDst, &dwSrc, sizeof(DWORD));
#else
		dwDst = dwSrc;
#endif
	}
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ResBorn engine
HRESULT ResBorn(PCTSTR ptzSrcFile, PCTSTR ptzLngFile, PCTSTR ptzDstFile = NULL)
{
	// Load file
	UMemFile fSrc(ptzSrcFile);
	PBYTE pbBase = fSrc;
	if (pbBase == NULL)
	{
		return ERROR_FILE_NOT_FOUND;
	}
	else if (fSrc < 512)
	{
		return ERROR_BAD_FORMAT;
	}

	// Get PE header
	PIMAGE_NT_HEADERS pNTHdr = CPEHelper::GetHeader(pbBase);
	if (pNTHdr == NULL)
	{
		return ERROR_BAD_FORMAT;
	}

	// Get resource section
	PIMAGE_SECTION_HEADER pSecHdr = CPEHelper::GetSection(pNTHdr, IMAGE_DIRECTORY_ENTRY_RESOURCE);
	if (pSecHdr == NULL)
	{
		return ERROR_RESOURCE_DATA_NOT_FOUND;
	}

	UAutoMem pbDstRes;
	if (ptzDstFile)
	{
		// Allocate destination resource buffer
		pbDstRes = UMemAlloc(pSecHdr->SizeOfRawData * 4 + 10240);
		if (pbDstRes == NULL)
		{
			return ERROR_OUTOFMEMORY;
		}
	}

	// Parse resource
	CResBorn rb;
	PBYTE pbSrcRes = pbBase + pSecHdr->PointerToRawData;
	UINT nDstResSize = rb.Parse(pbSrcRes, pSecHdr->VirtualAddress, ptzLngFile, pbDstRes);
	if (nDstResSize == -1)
	{
		return ERROR_OPEN_FAILED;
	}

	if (ptzDstFile)
	{
		// Write to destination file
		UAutoHandle hFile(UFileOpen(ptzDstFile, UFILE_WRITE));
		if (hFile == NULL)
		{
			return ERROR_WRITE_FAULT;
		}

		// Write data before resource section
#ifdef WINCE
		UINT uSize = (UINT) (pbSrcRes - pbBase);
		PVOID pvMem = UMemAlloc(uSize);
		if (pvMem)
		{
			// QUESTION: Windows Mobile could not write file mapping memory into another file?
			UMemCopy(pvMem, pbBase, uSize);
			UFileWrite(hFile, pvMem, uSize);
			UMemFree(pvMem);
		}
#else
		UFileWrite(hFile, pbBase, (UINT) (pbSrcRes - pbBase));
#endif

		// Pad to section alignment, write resource section
		UINT nPadSize = pNTHdr->OptionalHeader.SectionAlignment - (nDstResSize % pNTHdr->OptionalHeader.SectionAlignment);
		UINT nDstResSecSize = nDstResSize + nPadSize;
		UMemSet(pbDstRes + nDstResSize, 0, nPadSize);
		UFileWrite(hFile, pbDstRes, nDstResSecSize);

		// Write data after resource section
		PBYTE pbEnd = pbBase + (UINT) fSrc;
		PBYTE pbResEnd = pbSrcRes + pSecHdr->SizeOfRawData;
		if (pbResEnd != pbEnd)
		{
			UFileWrite(hFile, pbResEnd, (UINT) (pbEnd - pbResEnd));

			// IMAGE_SECTION_HEADER::PointerToRawData should be modified to adapt the section offset changing.
			// But, normally, the resource section is the last section, so this is not a problem.
			_Assert(pbResEnd != pbEnd);
		}

		// Resource size changed! Fix some field in header
		if (nDstResSecSize != pSecHdr->SizeOfRawData)
		{
			// Fix file size in IMAGE_OPTIONAL_HEADER32
			// Refer to http://www.heaventools.com/PE_Explorer_file_repair.htm
			UINT nDstSizeOfImage = pSecHdr->VirtualAddress + nDstResSecSize;
			if (nDstSizeOfImage != pNTHdr->OptionalHeader.SizeOfImage)
			{
				UFileSeek(hFile, (UINT) ((PBYTE) &pNTHdr->OptionalHeader.SizeOfImage - pbBase), UFILE_BEGIN);
				UFileWrite(hFile, &nDstSizeOfImage, sizeof(DWORD));
			}

			// Fix resource section size
			UFileSeek(hFile, (UINT) ((PBYTE) &pSecHdr->SizeOfRawData - pbBase), UFILE_BEGIN);
			UFileWrite(hFile, &nDstResSecSize, sizeof(DWORD));
		}

		// Fix actual resource size in memory
		if (nDstResSize != pSecHdr->Misc.VirtualSize)
		{
			UFileSeek(hFile, (UINT) ((PBYTE) &pSecHdr->Misc.VirtualSize - pbBase), UFILE_BEGIN);
			UFileWrite(hFile, &nDstResSize, sizeof(DWORD));
		}
	}

	return S_OK;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Application should call this function at startup, and must exit if this function doesn't return S_OK
#define STR_RBExt TEXT(".RB")
HRESULT RBInit()
{
	TCHAR tzPath[MAX_PATH];
	PTSTR ptzExt = tzPath + UDirGetAppPath(tzPath) - (_NumOf(STR_RBExt) - 1);
	if (UStrCmp(ptzExt, STR_RBExt))
	{
		return S_OK;
	}

	TCHAR tzCur[MAX_PATH];
	UStrCopy(tzCur, tzPath);
	*ptzExt = 0;
	for (UINT uTry = 1000; uTry--; Sleep(20))
	{
		DeleteFile(tzPath);
		if (MoveFile(tzCur, tzPath))
		{
			break;
		}
	}
	return S_FALSE;
}

// Export language file
HRESULT RBExport(PCTSTR ptzLngFile)
{
	TCHAR tzSrcFile[MAX_PATH];
	UDirGetAppPath(tzSrcFile);
	return ResBorn(tzSrcFile, ptzLngFile);
}

// Import language file
HRESULT RBImport(PCTSTR ptzLngFile)
{
	TCHAR tzSrcFile[MAX_PATH];
	TCHAR tzDstFile[MAX_PATH];
	UDirGetAppPath(tzSrcFile);
	UStrCopy(tzDstFile, tzSrcFile);
	UStrCat(tzDstFile, STR_RBExt);
	return ResBorn(tzSrcFile, ptzLngFile, tzDstFile);
}

// Application must call this function after RBImport
HRESULT RBExit()
{
	TCHAR tzExec[MAX_PATH];
	UDirGetAppPath(tzExec);
	UStrCat(tzExec, STR_RBExt);

	TCHAR tzParam[MAX_PATH];
	PROCESS_INFORMATION pi;
	STARTUPINFO si = {sizeof(STARTUPINFO)};

#ifdef _USRDLL
#ifdef _WIN32_WCE
	UStrPrint(tzParam, TEXT("%s,X"), tzExec);
	ptzExec = TEXT("RUNDLL32.EXE");
#else
	UStrPrint(tzParam, TEXT("RUNDLL32.EXE %s,X"), tzExec);
	ptzExec = NULL;
#endif
#else
	tzParam[0] = 0;
#endif
	if (CreateProcess(tzExec, tzParam, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
		return S_OK;
	}
	return S_FALSE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
