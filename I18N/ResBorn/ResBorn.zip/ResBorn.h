
#pragma once
#include <Windows.h>

// ResBorn Engine
HRESULT ResBorn(PCTSTR ptzSrcFile, PCTSTR ptzLngFile, PCTSTR ptzDstFile = NULL);


// Application should call this function at startup, and must exit if this function doesn't return S_OK
HRESULT RBInit();

// Export language file
HRESULT RBExport(PCTSTR ptzLngFile);

// Import language file
HRESULT RBImport(PCTSTR ptzLngFile);

// Application must call this function after RBImport
HRESULT RBExit();
